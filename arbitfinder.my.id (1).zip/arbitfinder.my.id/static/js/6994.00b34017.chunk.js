"use strict";
(self.webpackChunkarbitrage_notification = self.webpackChunkarbitrage_notification || []).push([
    [6994], {
        84905: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return u
                }
            });
            var r = n(1413),
                i = n(29439),
                a = n(45987),
                o = n(47313),
                s = n(69099),
                l = n(28100),
                c = n(46417),
                d = ["children", "text", "startIcon", "color", "onPress"];

            function u(e) {
                var t = e.children,
                    n = e.text,
                    u = void 0 === n ? "" : n,
                    x = e.startIcon,
                    h = void 0 === x ? null : x,
                    p = e.color,
                    m = void 0 === p ? "primary" : p,
                    f = e.onPress,
                    g = void 0 === f ? null : f,
                    v = (0, a.Z)(e, d),
                    Z = (0, o.useState)(null),
                    j = (0, i.Z)(Z, 2),
                    y = j[0],
                    b = j[1];
                return (0, c.jsxs)(c.Fragment, {
                    children: [(0, c.jsx)(s.Z, (0, r.Z)((0, r.Z)({
                        variant: "contained",
                        onClick: function(e) {
                            b(e.currentTarget), null != g && g()
                        },
                        startIcon: h,
                        color: m
                    }, v), {}, {
                        children: u
                    })), (0, c.jsx)(l.Z, {
                        open: Boolean(y),
                        anchorEl: y,
                        onClose: function() {
                            b(null)
                        },
                        sx: {
                            p: 2
                        },
                        children: t
                    })]
                })
            }
        },
        67871: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return m
                }
            });
            var r = n(1413),
                i = n(45987),
                a = n(57829),
                o = n(61113),
                s = n(90891),
                l = n(29466),
                c = n(3404),
                d = n(46417),
                u = ["links", "activeLast"];

            function x(e) {
                var t = e.links,
                    n = e.activeLast,
                    s = void 0 !== n && n,
                    l = (0, i.Z)(e, u),
                    x = t[t.length - 1].name,
                    p = t.map((function(e) {
                        return (0, d.jsx)(h, {
                            link: e
                        }, e.name)
                    })),
                    m = t.map((function(e) {
                        return (0, d.jsx)("div", {
                            children: e.name !== x ? (0, d.jsx)(h, {
                                link: e
                            }) : (0, d.jsx)(o.Z, {
                                variant: "body2",
                                sx: {
                                    maxWidth: 260,
                                    overflow: "hidden",
                                    whiteSpace: "nowrap",
                                    color: "text.disabled",
                                    textOverflow: "ellipsis"
                                },
                                children: x
                            })
                        }, e.name)
                    }));
                return (0, d.jsx)(c.Z, (0, r.Z)((0, r.Z)({
                    separator: (0, d.jsx)(a.Z, {
                        component: "span",
                        sx: {
                            width: 4,
                            height: 4,
                            borderRadius: "50%",
                            bgcolor: "text.disabled"
                        }
                    })
                }, l), {}, {
                    children: s ? p : m
                }))
            }

            function h(e) {
                var t = e.link,
                    n = t.href,
                    r = t.name,
                    i = t.icon;
                return (0, d.jsxs)(s.Z, {
                    variant: "body2",
                    component: l.rU,
                    to: n || "#",
                    sx: {
                        lineHeight: 2,
                        display: "flex",
                        alignItems: "center",
                        color: "text.primary",
                        "& > div": {
                            display: "inherit"
                        }
                    },
                    children: [i && (0, d.jsx)(a.Z, {
                        sx: {
                            mr: 1,
                            "& svg": {
                                width: 20,
                                height: 20
                            }
                        },
                        children: i
                    }), r]
                }, r)
            }
            var p = ["action", "actionLeft", "heading", "links", "moreLink", "sx"];

            function m(e) {
                var t = e.action,
                    n = e.actionLeft,
                    l = e.heading,
                    c = e.links,
                    u = e.moreLink,
                    h = void 0 === u ? [] : u,
                    m = e.sx,
                    f = (0, i.Z)(e, p);
                return (0, d.jsxs)(a.Z, {
                    sx: (0, r.Z)({
                        mb: 2
                    }, m),
                    children: [(0, d.jsxs)(a.Z, {
                        sx: {
                            display: "flex",
                            alignItems: "center"
                        },
                        children: [(0, d.jsxs)(a.Z, {
                            sx: {
                                flexGrow: 1
                            },
                            children: [(0, d.jsx)(o.Z, {
                                variant: "h5",
                                gutterBottom: !0,
                                children: l
                            }), c && (0, d.jsx)(x, (0, r.Z)({
                                links: c
                            }, f)), n && (0, d.jsx)(a.Z, {
                                sx: {
                                    flexShrink: 0
                                },
                                children: n
                            })]
                        }), t && (0, d.jsx)(a.Z, {
                            sx: {
                                flexShrink: 0
                            },
                            children: t
                        })]
                    }), (0, d.jsx)(a.Z, {
                        sx: {
                            mt: 2
                        },
                        children: "string" === typeof h ? (0, d.jsx)(s.Z, {
                            href: h,
                            target: "_blank",
                            rel: "noopener",
                            variant: "body2",
                            children: h
                        }) : h.map((function(e) {
                            return (0, d.jsx)(s.Z, {
                                noWrap: !0,
                                href: e,
                                variant: "body2",
                                target: "_blank",
                                rel: "noopener",
                                sx: {
                                    display: "table"
                                },
                                children: e
                            }, e)
                        }))
                    })]
                })
            }
        },
        90453: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return o
                }
            });
            var r = n(57829),
                i = n(85281),
                a = n(46417);

            function o() {
                return (0, a.jsx)(r.Z, {
                    sx: {
                        top: 0,
                        display: "flex",
                        flexDirection: "row",
                        alignItems: "center",
                        width: "100%",
                        height: "100%",
                        position: "absolute",
                        backgroundColor: "rgba(255, 255, 255, 0.5)",
                        zIndex: 1500
                    },
                    children: (0, a.jsxs)(r.Z, {
                        sx: {
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "center",
                            width: "100%"
                        },
                        children: [" ", (0, a.jsx)(i.Z, {}), " "]
                    })
                })
            }
        },
        17749: function(e, t, n) {
            n.d(t, {
                B: function() {
                    return I
                }
            });
            var r = n(15861),
                i = n(29439),
                a = n(64687),
                o = n.n(a),
                s = n(21933),
                l = n(47313),
                c = n(29466),
                d = n(75627),
                u = n(1432),
                x = n(70228),
                h = n(73428),
                p = n(57829),
                m = n(61113),
                f = n(42832),
                g = n(34953),
                v = n(90891),
                Z = n(32703),
                j = n(54285),
                y = n(58434),
                b = (n(42593), n(57367)),
                w = n(48175),
                k = n(62677),
                S = n(71609),
                P = n(91815),
                _ = n(46417);

            function I() {
                var e = (0, j.Z)().register,
                    t = ((0, y.Z)(), (0, l.useState)(!1)),
                    n = (0, i.Z)(t, 2),
                    a = n[0],
                    I = n[1],
                    D = (0, l.useState)(!1),
                    C = (0, i.Z)(D, 2),
                    W = (C[0], C[1], s.Ry().shape({
                        recaptchaToken: s.Z_().required(),
                        email: s.Z_().email("Email must be a valid email address").required(),
                        telegram: s.Z_(),
                        referrer_telegram: s.Z_().nullable(),
                        password: s.Z_().required("Password is required"),
                        repassword: s.Z_().oneOf([s.iH("password"), null], "Passwords must match").required("Please confirm your password")
                    })),
                    F = (0, d.cI)({
                        resolver: (0, u.X)(W),
                        defaultValues: {
                            recaptchaToken: "",
                            email: "",
                            telegram: "",
                            referrer_telegram: "",
                            password: "",
                            repassword: ""
                        }
                    }),
                    z = F.reset,
                    E = (F.setError, F.handleSubmit),
                    R = F.setValue,
                    B = F.formState,
                    T = B.errors,
                    A = B.isSubmitting,
                    V = function() {
                        var t = (0, r.Z)(o().mark((function t(n) {
                            return o().wrap((function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        return t.prev = 0, n.telegram = "".concat(n.telegram).replace("@", "").replace(" ", ""), n.referrer_telegram = "".concat(n.referrer_telegram).replace("@", "").replace(" ", ""), t.next = 5, e({
                                            email: n.email,
                                            telegram: n.telegram,
                                            password: n.password,
                                            referrer_telegram: n.referrer_telegram,
                                            recaptchaToken: n.recaptchaToken
                                        });
                                    case 5:
                                        t.next = 11;
                                        break;
                                    case 7:
                                        t.prev = 7, t.t0 = t.catch(0), console.error(t.t0), z();
                                    case 11:
                                    case "end":
                                        return t.stop()
                                }
                            }), t, null, [
                                [0, 7]
                            ])
                        })));
                        return function(e) {
                            return t.apply(this, arguments)
                        }
                    }(),
                    L = new URLSearchParams(document.location.search).get("referrer") || "",
                    N = !!L;
                return L && R("referrer_telegram", L), (0, _.jsxs)(h.Z, {
                    sx: {
                        py: 5,
                        px: 3
                    },
                    children: [(0, _.jsx)(p.Z, {
                        sx: {
                            mb: 5,
                            display: "flex",
                            alignItems: "center"
                        },
                        children: (0, _.jsxs)(p.Z, {
                            sx: {
                                flexGrow: 1
                            },
                            children: [(0, _.jsx)(m.Z, {
                                variant: "h4",
                                gutterBottom: !0,
                                children: "Get started free."
                            }), (0, _.jsx)(m.Z, {
                                sx: {
                                    color: "text.secondary"
                                },
                                children: "Start your profit now."
                            })]
                        })
                    }), (0, _.jsx)(b.RV, {
                        methods: F,
                        onSubmit: E(V),
                        children: (0, _.jsxs)(f.Z, {
                            spacing: 3,
                            children: [!!T.afterSubmit && (0, _.jsx)(g.Z, {
                                severity: "error",
                                children: T.afterSubmit.message
                            }), (0, _.jsx)(b.au, {
                                size: "small",
                                name: "email",
                                label: "Email address"
                            }), (0, _.jsx)(b.au, {
                                size: "small",
                                name: "telegram",
                                label: "Telegram username (without @)"
                            }), (0, _.jsxs)(f.Z, {
                                direction: {
                                    xs: "column",
                                    sm: "row"
                                },
                                spacing: 2,
                                children: [(0, _.jsx)(b.au, {
                                    size: "small",
                                    type: "password",
                                    name: "password",
                                    label: "Password"
                                }), (0, _.jsx)(b.au, {
                                    size: "small",
                                    type: "password",
                                    name: "repassword",
                                    label: "Retype Password"
                                })]
                            }), (0, _.jsx)(b.au, {
                                size: "small",
                                name: "referrer_telegram",
                                defaultValue: L || "",
                                label: "referrer telegram username (without @)",
                                disabled: N
                            }), (0, _.jsx)(x.mP, {
                                onVerify: function(e) {
                                    R("recaptchaToken", e), I(!0)
                                }
                            }), (0, _.jsx)(Z.Z, {
                                fullWidth: !0,
                                size: "large",
                                type: "submit",
                                variant: "contained",
                                loading: A || !a,
                                children: "Register"
                            })]
                        })
                    }), (0, _.jsxs)(m.Z, {
                        variant: "body2",
                        align: "center",
                        sx: {
                            color: "text.secondary",
                            mt: 3
                        },
                        children: ["By registering, I agree to Arbit Finder \xa0", (0, _.jsxs)(S.Z, {
                            dialogFullWidth: !0,
                            size: "small",
                            buttonText: "Terms of Service & Privacy Policy",
                            variant: "text",
                            children: [" ", (0, _.jsxs)(k.Z, {
                                children: [" ", (0, _.jsx)(P.Z, {}), " "]
                            }), " "]
                        })]
                    }), (0, _.jsxs)(m.Z, {
                        variant: "body2",
                        align: "center",
                        sx: {
                            mt: 3
                        },
                        children: ["Already have an account? ", "", (0, _.jsx)(v.Z, {
                            variant: "subtitle2",
                            component: c.rU,
                            to: w.EE.login,
                            children: "Login"
                        })]
                    }), (0, _.jsxs)(m.Z, {
                        variant: "body2",
                        align: "center",
                        sx: {
                            mt: 3
                        },
                        children: ["Do you want to back to  ", "", (0, _.jsx)(v.Z, {
                            variant: "subtitle2",
                            component: c.rU,
                            to: w.vB.root,
                            children: "Home"
                        })]
                    })]
                })
            }
        },
        2311: function(e, t, n) {
            n.d(t, {
                tB: function() {
                    return L
                },
                dN: function() {
                    return V
                },
                ke: function() {
                    return R
                },
                ZP: function() {
                    return A
                }
            });
            var r = n(45987),
                i = n(1413),
                a = n(36459),
                o = n(90891),
                s = n(69099),
                l = n(9019),
                c = n(73428),
                d = n(42832),
                u = n(61113),
                x = n(19536),
                h = n(57829),
                p = n(97890),
                m = (n(3484), n(42593)),
                f = n(71609),
                g = n(88669),
                v = (n(76221), n(5239)),
                Z = n(42111),
                j = (n(17749), n(47313)),
                y = n(90453),
                b = n(29439),
                w = (n(30421), n(34032)),
                k = n(13918),
                S = n(46417);

            function P(e) {
                var t = e.product,
                    n = ((0, w.Ds)().enqueueSnackbar, (0, v.I0)()),
                    r = (0, j.useState)(!1),
                    a = (0, b.Z)(r, 2),
                    o = a[0],
                    l = a[1],
                    c = (0, g.xp)(localStorage.getItem("accessToken")),
                    d = (0, v.v9)((function(e) {
                        return e.payment
                    })),
                    u = d.requestPayment;
                d.hasError;
                return (0, j.useEffect)((function() {
                    var e = k.jT,
                        t = document.createElement("script");
                    return t.setAttribute("data-client-key", e), t.setAttribute("crossorigin", "anonymous"), t.type = "text/javascript", t.src = "/snap/snap.js", t.async = !0, document.head.appendChild(t),
                        function() {
                            document.head.removeChild(t)
                        }
                }), []), (0, j.useEffect)((function() {
                    if (!0 === o)
                        if (t !== (null === u || void 0 === u ? void 0 : u.product)) n((0, Z.ng)({
                            data: {
                                product: t
                            }
                        }));
                        else {
                            var e = null === u || void 0 === u ? void 0 : u.result;
                            e && !0 !== (null === u || void 0 === u ? void 0 : u.verified) && "midtrans" === (null === u || void 0 === u ? void 0 : u.platform) ? window.snap ? window.snap.pay(e, {
                                onSuccess: function(e) {
                                    alert("Payment success!"), console.log(e), n((0, Z.wQ)((0, i.Z)((0, i.Z)({}, e), {}, {
                                        verified: !1
                                    })))
                                },
                                onPending: function(e) {
                                    alert("Wating your payment!"), console.log(e)
                                },
                                onError: function(e) {
                                    alert("Payment failed!"), console.log(e)
                                },
                                onClose: function() {
                                    alert("You closed the popup, checking your payment..."), n((0, Z._5)({
                                        data: {
                                            order_id: u.order_id,
                                            member_id: c.user_id
                                        }
                                    }))
                                }
                            }) : alert("FAILED load payment page") : !1 === (null === u || void 0 === u ? void 0 : u.verified) && "200" === (null === u || void 0 === u ? void 0 : u.status_code) && n((0, Z._5)({
                                data: {
                                    order_id: u.order_id,
                                    member_id: c.user_id
                                }
                            })), l(!1)
                        }
                }), [u, o]), (0, S.jsx)(s.Z, {
                    size: "small",
                    variant: "contained",
                    onClick: function() {
                        l(!0)
                    },
                    children: "Indonesian local payment"
                })
            }
            var _ = n(15861),
                I = n(64687),
                D = n.n(I),
                C = n(54285),
                W = n(48175);

            function F(e) {
                var t = e.product,
                    n = (0, w.Ds)().enqueueSnackbar,
                    r = (0, v.I0)(),
                    i = (0, C.Z)().logout,
                    a = (0, p.s0)(),
                    o = (0, j.useState)(!1),
                    s = (0, b.Z)(o, 2),
                    l = s[0],
                    c = s[1],
                    d = function() {
                        var e = (0, _.Z)(D().mark((function e() {
                            return D().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, i();
                                    case 2:
                                        a(W.EE.login, {
                                            replace: !0
                                        });
                                    case 3:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })));
                        return function() {
                            return e.apply(this, arguments)
                        }
                    }(),
                    x = (0, g.xp)(localStorage.getItem("accessToken")),
                    m = (0, v.v9)((function(e) {
                        return e.payment
                    })),
                    k = m.requestPayment,
                    P = m.hasError,
                    I = m.isLoading;
                return (0, j.useEffect)((function() {
                    !0 === l && (t !== (null === k || void 0 === k ? void 0 : k.product) ? r((0, Z.Ed)({
                        data: {
                            product: t
                        }
                    })) : function() {
                        var e = null === k || void 0 === k ? void 0 : k.result;
                        String(e).includes("https") && !0 !== (null === k || void 0 === k ? void 0 : k.verified) && "cryptocloud" === (null === k || void 0 === k ? void 0 : k.platform) && window.open(e, "_blank", "noreferrer")
                    }())
                }), [k, l]), (0, j.useEffect)((function() {
                    !1 === P && (n("Verification Success!, Please relog to apply", {
                        variant: "success"
                    }), d()), r((0, Z.oE)())
                }), [P]), (0, S.jsx)(f.Z, {
                    dialogFullWidth: !0,
                    size: "small",
                    buttonText: "Crypto payment",
                    variant: "contained",
                    onPress: function() {
                        c(!0)
                    },
                    onClose: function() {
                        r((0, Z._5)({
                            data: {
                                order_id: k.order_id,
                                member_id: x.user_id
                            }
                        })), c(!1)
                    },
                    children: (0, S.jsx)("div", {
                        children: I ? (0, S.jsx)(y.Z, {}) : (0, S.jsx)(h.Z, {
                            sx: {
                                my: 1,
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                flexDirection: "row"
                            },
                            children: (0, S.jsxs)(h.Z, {
                                sx: {
                                    my: 1,
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    flexDirection: "column"
                                },
                                children: [(0, S.jsx)(u.Z, {
                                    children: " Close this popup if you have paid, and we checking the payment, "
                                }), (0, S.jsx)(u.Z, {
                                    children: ' If still not update, you can manual click "Recheck" on your "payment history" in "Profile" tab with order ID '
                                }), (0, S.jsx)(u.Z, {
                                    variant: "h5",
                                    children: null === k || void 0 === k ? void 0 : k.order_id
                                })]
                            })
                        })
                    })
                })
            }

            function z(e) {
                var t = e.product,
                    n = ((0, v.I0)(), (0, v.v9)((function(e) {
                        return e.payment
                    })));
                n.requestPayment, n.isLoading;
                return (0, S.jsxs)("div", {
                    children: [(0, S.jsx)(h.Z, {
                        sx: {
                            display: "flex",
                            flexDirection: "row",
                            justifyContent: "center",
                            ml: 3
                        },
                        children: (0, S.jsx)(u.Z, {
                            variant: "h6",
                            children: "Select your payment method"
                        })
                    }), (0, S.jsxs)(h.Z, {
                        sx: {
                            display: "flex",
                            flexDirection: "column",
                            justifyContent: "center",
                            ml: 3
                        },
                        children: [(0, S.jsxs)(h.Z, {
                            sx: {
                                my: 1,
                                display: "flex",
                                flexDirection: "row"
                            },
                            children: [(0, S.jsx)(P, {
                                product: t
                            }), "\xa0", (0, S.jsx)("img", {
                                style: {
                                    width: 50,
                                    height: 50
                                },
                                src: "/assets/payment/qris.jpg",
                                alt: "qris"
                            }), (0, S.jsx)("img", {
                                style: {
                                    width: 50,
                                    height: 50
                                },
                                src: "/assets/payment/bank_transfer.jpg",
                                alt: "bank_transfer"
                            })]
                        }), (0, S.jsxs)(h.Z, {
                            sx: {
                                my: 1,
                                display: "flex",
                                flexDirection: "row"
                            },
                            children: [(0, S.jsx)(F, {
                                product: t
                            }), "\xa0", (0, S.jsx)("img", {
                                style: {
                                    width: 50,
                                    height: 50
                                },
                                src: "/assets/payment/usdt.jpg",
                                alt: "usdt"
                            })]
                        })]
                    })]
                })
            }
            var E = ["exclude_plan"],
                R = [{
                    type: 0,
                    product: null,
                    license: "Free Package",
                    price: 0,
                    yes: ["Limited Arbitrage Data"],
                    no: ["Get realtime current data", "Market Order Book", "View Coin Full Name", "View Network Chain", "Withdrawal Fee", "Wallet WD/DEPO availability", "Filter data"]
                }, {
                    type: 1,
                    product: 0,
                    license: "Premium +1 month",
                    price: "IDR 150.000 (USD 10)",
                    yes: ["+1 month arbitrage data", "Get realtime current data", "Market Order Book", "View Coin Full Name", "View Network Chain", "Withdrawal Fee", "Wallet WD/DEPO availability", "Filter data"],
                    no: []
                }, {
                    type: 2,
                    product: 1,
                    license: "Premium +3 month",
                    before_discount: "IDR 450.000",
                    price: "IDR 400.000 (USD 28)",
                    yes: ["+3 month arbitrage data", "Get realtime of current data", "Market Order Book", "View Coin Full Name", "View Network Chain", "Withdrawal Fee", "Wallet WD/DEPO availability", "Filter data"],
                    no: []
                }, {
                    type: 3,
                    product: 2,
                    license: "Premium +1 Year",
                    before_discount: "IDR 1.800.000",
                    price: "IDR 900.000 (USD 69)",
                    yes: ["+12 month arbitrage data", "Get realtime of current data", "Market Order Book", "View Coin Full Name", "View Network Chain", "Withdrawal Fee", "Wallet WD/DEPO availability", "Filter data", "Additional tutorial & guidance"],
                    no: []
                }];

            function B(e) {
                var t = e.userPayload,
                    n = e.type,
                    r = (e.isDesktop, e.product),
                    i = (0, v.I0)(),
                    a = (0, p.TH)().pathname;
                return t ? 0 !== n ? (0, S.jsx)(f.Z, {
                    dialogFullWidth: !0,
                    size: "small",
                    buttonText: "Choose plan",
                    variant: "contained",
                    onClose: function() {
                        "/menu/Profile" === a && i((0, Z.go)())
                    },
                    children: (0, S.jsx)(z, {
                        product: r
                    })
                }) : (0, S.jsx)(s.Z, {
                    fullWidth: !0,
                    disabled: !0,
                    children: "Currenly Here"
                }) : 0 === n ? (0, S.jsx)(o.Z, {
                    href: "/menu/Arbitrage_Data",
                    children: (0, S.jsx)(s.Z, {
                        fullWidth: !0,
                        size: "small",
                        variant: "outlined",
                        children: " View Data "
                    })
                }) : (0, S.jsx)(o.Z, {
                    href: "/auth/register",
                    children: (0, S.jsx)(s.Z, {
                        fullWidth: !0,
                        size: "small",
                        variant: "contained",
                        children: " Choose Plan "
                    })
                })
            }

            function T(e) {
                var t, n = e.plan,
                    r = ((0, v.I0)(), (0, g.xp)(localStorage.getItem("accessToken"))),
                    i = n.type,
                    a = n.product,
                    o = n.license,
                    s = n.price,
                    h = n.before_discount,
                    p = n.yes,
                    f = n.no,
                    Z = (n.icons, window.innerHeight < window.innerWidth),
                    j = Z ? 20 : 10,
                    y = Z ? {
                        title: 16,
                        price: 16,
                        item: 15
                    } : {
                        title: 12,
                        price: 12,
                        item: 8
                    };
                switch (i) {
                    case 1:
                        t = "rgba(0, 200, 0, 0.10) 0px 0px 5px 5px, rgba(0, 0, 0, 0.05) 0px 0px 10px 15px";
                        break;
                    case 2:
                        t = "0 0 10px #0ba9ca, rgba(11, 228, 245, 0.1) 0px 0px 20px 15px";
                        break;
                    case 3:
                        t = "0 0 15px #e3dd24, rgba(227, 221, 36, 0.3) 0px 0px 25px 20px";
                        break;
                    default:
                        t = "rgba(0, 0, 0, 0.05) 0px 0px 10px 15px"
                }
                return (0, S.jsx)(l.ZP, {
                    item: !0,
                    xs: 6,
                    sm: 6,
                    md: 3,
                    children: (0, S.jsx)(c.Z, {
                        sx: {
                            p: Z ? 3 : 1,
                            boxShadow: t,
                            m: 0
                        },
                        children: (0, S.jsxs)(d.Z, {
                            spacing: 2,
                            children: [(0, S.jsxs)("div", {
                                children: [(0, S.jsx)(u.Z, {
                                    variant: "overline",
                                    component: "div",
                                    sx: {
                                        mb: 2,
                                        color: "text.disabled"
                                    },
                                    children: "PLAN"
                                }), (0, S.jsx)(u.Z, {
                                    sx: {
                                        fontSize: y.title
                                    },
                                    variant: "h6",
                                    children: o
                                })]
                            }), s && 0 !== s ? (0, S.jsxs)(d.Z, {
                                alignItems: "center",
                                direction: "column",
                                spacing: .5,
                                children: [h && (0, S.jsxs)(S.Fragment, {
                                    children: [(0, S.jsx)(N, {
                                        percentage: Math.floor((h - s) / h * 100)
                                    }), (0, S.jsxs)(u.Z, {
                                        variant: "overline",
                                        sx: {
                                            fontSize: y.price,
                                            color: "grey",
                                            fontStyle: "italic",
                                            textDecoration: "line-through"
                                        },
                                        children: [h, " \xa0"]
                                    })]
                                }), (0, S.jsxs)(u.Z, {
                                    variant: "button",
                                    sx: {
                                        fontSize: y.price,
                                        fontStyle: "italic"
                                    },
                                    children: [s, " \xa0"]
                                })]
                            }) : " ", (0, S.jsxs)(d.Z, {
                                spacing: 1,
                                children: [p.map((function(e) {
                                    return (0, S.jsx)(d.Z, {
                                        spacing: 1,
                                        direction: "row",
                                        alignItems: "center",
                                        children: "" !== e ? (0, S.jsxs)(S.Fragment, {
                                            children: [(0, S.jsx)(m.Z, {
                                                icon: "eva:checkmark-fill",
                                                sx: {
                                                    color: "primary.main",
                                                    width: j,
                                                    height: j
                                                }
                                            }), (0, S.jsx)(u.Z, {
                                                sx: {
                                                    fontSize: y.item
                                                },
                                                variant: "body2",
                                                children: e
                                            })]
                                        }) : (0, S.jsx)(S.Fragment, {
                                            children: " \xa0 "
                                        })
                                    }, e)
                                })), (0, S.jsx)(x.Z, {
                                    sx: {
                                        borderStyle: "dashed"
                                    }
                                }), f.map((function(e) {
                                    return (0, S.jsx)(d.Z, {
                                        spacing: 1,
                                        direction: "row",
                                        alignItems: "center",
                                        children: "" !== e ? (0, S.jsxs)(S.Fragment, {
                                            children: [(0, S.jsx)(m.Z, {
                                                icon: "eva:close-fill",
                                                sx: {
                                                    size: y.item,
                                                    color: "error.main",
                                                    width: j,
                                                    height: j
                                                }
                                            }), (0, S.jsx)(u.Z, {
                                                sx: {
                                                    fontSize: y.item
                                                },
                                                variant: "body2",
                                                children: e
                                            })]
                                        }) : (0, S.jsx)(S.Fragment, {
                                            children: " \xa0 "
                                        })
                                    }, e)
                                }))]
                            }), B({
                                userPayload: r,
                                isDesktop: Z,
                                type: i,
                                product: a
                            })]
                        })
                    })
                })
            }

            function A() {
                var e = window.innerHeight < window.innerWidth;
                return (0, S.jsxs)(S.Fragment, {
                    children: [(0, S.jsxs)(u.Z, {
                        variant: "button",
                        sx: {
                            color: "error.main"
                        },
                        children: ["*) Please relog after payment to refresh profile AND Please see this video to avoid misunderstanding (", (0, S.jsx)(o.Z, {
                            href: "https://youtu.be/5hIlh6drvh0?si=hUPVP3WobfevHKtl",
                            target: "_blank",
                            children: "Common Arbitrage Mistake"
                        }), ")"]
                    }), (0, S.jsx)(l.ZP, {
                        container: !0,
                        sx: {
                            mt: .1
                        },
                        spacing: e ? 5 : 3,
                        children: R.map((function(e, t) {
                            return (0, S.jsx)(T, {
                                plan: e
                            }, t)
                        }))
                    })]
                })
            }

            function V(e) {
                var t = e.exclude_plan,
                    n = ((0, r.Z)(e, E), (0, g.xp)(localStorage.getItem("accessToken"))),
                    i = window.innerHeight < window.innerWidth;
                return (0, S.jsx)("div", {
                    children: (0, S.jsx)(d.Z, {
                        direction: {
                            xs: "column",
                            sm: "row"
                        },
                        divider: (0, S.jsx)(x.Z, {
                            orientation: i ? "vertical" : "horizontal",
                            flexItem: !0,
                            sx: {
                                borderStyle: "dashed"
                            }
                        }),
                        children: R.map((function(e, r) {
                            var a = e.type,
                                o = e.product,
                                s = e.license,
                                l = e.price,
                                x = e.before_discount;
                            e.yes, e.no, e.icons;
                            return null !== t && void 0 !== t && t.includes(r) ? " " : (0, S.jsx)(c.Z, {
                                children: (0, S.jsx)(d.Z, {
                                    direction: "row",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    spacing: 3,
                                    sx: {
                                        width: 1,
                                        py: 5,
                                        px: 2
                                    },
                                    children: (0, S.jsxs)("div", {
                                        children: [(0, S.jsx)(u.Z, {
                                            variant: "button",
                                            sx: {
                                                mb: .5
                                            },
                                            children: s
                                        }), (0, S.jsxs)(u.Z, {
                                            variant: "body2",
                                            sx: {
                                                opacity: .72
                                            },
                                            children: [x && (0, S.jsxs)(S.Fragment, {
                                                children: [(0, S.jsx)(N, {
                                                    percentage: Math.floor((x - l) / x * 100)
                                                }), (0, S.jsxs)(u.Z, {
                                                    variant: "overline",
                                                    sx: {
                                                        color: "grey",
                                                        fontStyle: "italic",
                                                        textDecoration: "line-through"
                                                    },
                                                    children: [x, " \xa0"]
                                                })]
                                            }), l]
                                        }), B({
                                            userPayload: n,
                                            isDesktop: i,
                                            type: a,
                                            product: o
                                        })]
                                    })
                                }, r)
                            }, r)
                        }))
                    })
                })
            }

            function L(e) {
                var t = Object.assign({}, ((0, a.Z)(e), e)),
                    n = window.innerHeight < window.innerWidth;
                return (0, S.jsx)(f.Z, (0, i.Z)((0, i.Z)({}, t), {}, {
                    children: (0, S.jsx)(h.Z, {
                        sx: {
                            bgcolor: "grey.350",
                            p: n ? 3 : 1
                        },
                        children: (0, S.jsx)(A, {})
                    })
                }))
            }

            function N(e) {
                e.percentage;
                return (0, S.jsx)(h.Z, {
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    textAlign: "center",
                    sx: {
                        transform: "rotate(-15deg)",
                        top: 3,
                        right: 3,
                        position: "absolute",
                        bgcolor: "#ffe34a",
                        width: 60,
                        height: 60,
                        borderRadius: "50%",
                        opacity: .8
                    },
                    children: (0, S.jsx)(u.Z, {
                        variant: "button",
                        sx: {
                            color: "red"
                        },
                        children: "Discount"
                    })
                })
            }
        },
        73112: function(e, t, n) {
            n.d(t, {
                $W: function() {
                    return m
                },
                K: function() {
                    return y
                },
                et: function() {
                    return p
                },
                Nl: function() {
                    return k
                }
            });
            var r = n(24076),
                i = n(67478),
                a = n(1413),
                o = n(45987),
                s = n(17592),
                l = n(61113),
                c = n(3484),
                d = n(46417),
                u = ["title", "description", "img"],
                x = (0, s.ZP)("div")((function(e) {
                    return {
                        height: "100%",
                        display: "flex",
                        textAlign: "center",
                        alignItems: "center",
                        flexDirection: "column",
                        justifyContent: "center",
                        padding: e.theme.spacing(8, 2)
                    }
                }));

            function h(e) {
                var t = e.title,
                    n = e.description,
                    r = e.img,
                    i = (0, o.Z)(e, u);
                return (0, d.jsxs)(x, (0, a.Z)((0, a.Z)({}, i), {}, {
                    children: [(0, d.jsx)(c.Z, {
                        disabledEffect: !0,
                        visibleByDefault: !0,
                        alt: "empty content",
                        src: r || "/assets/illustrations/illustration_empty_content.svg",
                        sx: {
                            height: 240,
                            mb: 3
                        }
                    }), (0, d.jsx)(l.Z, {
                        variant: "h5",
                        gutterBottom: !0,
                        children: t
                    }), n && (0, d.jsx)(l.Z, {
                        variant: "body2",
                        sx: {
                            color: "text.secondary"
                        },
                        children: n
                    })]
                }))
            }

            function p(e) {
                var t = e.isNotFound;
                return (0, d.jsx)(r.Z, {
                    children: t ? (0, d.jsx)(i.Z, {
                        colSpan: 12,
                        children: (0, d.jsx)(h, {
                            title: "No Data",
                            sx: {
                                "& span.MuiBox-root": {
                                    height: 160
                                }
                            }
                        })
                    }) : (0, d.jsx)(i.Z, {
                        colSpan: 12,
                        sx: {
                            p: 0
                        }
                    })
                })
            }
            n(42593), n(28100);

            function m(e) {
                var t = e.emptyRows,
                    n = e.height;
                return t ? (0, d.jsx)(r.Z, {
                    sx: (0, a.Z)({}, n && {
                        height: n * t
                    }),
                    children: (0, d.jsx)(i.Z, {
                        colSpan: 9
                    })
                }) : null
            }
            var f = n(23477),
                g = n(44758),
                v = n(82558),
                Z = n(57829),
                j = {
                    border: 0,
                    margin: -1,
                    padding: 0,
                    width: "1px",
                    height: "1px",
                    overflow: "hidden",
                    position: "absolute",
                    whiteSpace: "nowrap",
                    clip: "rect(0 0 0 0)"
                };
            (0, s.ZP)(r.Z)((function(e) {
                var t = e.theme;
                return {
                    head: {
                        backgroundColor: t.palette.common.black,
                        color: t.palette.common.white,
                        left: 0,
                        position: "sticky",
                        zIndex: t.zIndex.appBar + 2
                    },
                    body: {
                        backgroundColor: "#ddd",
                        minWidth: "50px",
                        left: 0,
                        position: "sticky",
                        zIndex: t.zIndex.appBar + 1
                    }
                }
            }));

            function y(e) {
                var t = e.checkbox,
                    n = e.order,
                    o = e.orderBy,
                    s = e.rowCount,
                    l = void 0 === s ? 0 : s,
                    c = e.headLabel,
                    u = e.numSelected,
                    x = void 0 === u ? 0 : u,
                    h = e.onSort,
                    p = e.onSelectAllRows,
                    m = e.sx;
                return (0, d.jsx)(f.Z, {
                    sx: m,
                    children: (0, d.jsxs)(r.Z, {
                        children: [t && p && (0, d.jsx)(i.Z, {
                            padding: "checkbox",
                            children: (0, d.jsx)(g.Z, {
                                indeterminate: x > 0 && x < l,
                                checked: l > 0 && x === l,
                                onChange: function(e) {
                                    return p(e.target.checked)
                                }
                            })
                        }), c.map((function(e) {
                            return (0, d.jsx)(i.Z, {
                                align: e.align || "left",
                                sortDirection: o === e.id && n,
                                sx: {
                                    width: e.width,
                                    minWidth: e.minWidth,
                                    background: "grey.400"
                                },
                                children: h ? (0, d.jsxs)(v.Z, {
                                    hideSortIcon: !0,
                                    active: o === e.id,
                                    direction: o === e.id ? n : "asc",
                                    onClick: function() {
                                        return h(e.id)
                                    },
                                    sx: {
                                        textTransform: "capitalize"
                                    },
                                    children: [e.label, o === e.id ? (0, d.jsx)(Z.Z, {
                                        sx: (0, a.Z)({}, j),
                                        children: "desc" === n ? "sorted descending" : "sorted ascending"
                                    }) : null]
                                }) : e.label
                            }, e.id)
                        }))]
                    })
                })
            }
            var b = n(42832),
                w = ["dense", "actions", "rowCount", "numSelected", "onSelectAllRows", "sx"];

            function k(e) {
                var t = e.dense,
                    n = e.actions,
                    r = e.rowCount,
                    i = e.numSelected,
                    s = e.onSelectAllRows,
                    c = e.sx,
                    u = (0, o.Z)(e, w);
                return (0, d.jsxs)(b.Z, (0, a.Z)((0, a.Z)({
                    direction: "row",
                    alignItems: "center",
                    sx: (0, a.Z)((0, a.Z)({
                        px: 2,
                        top: 0,
                        left: 8,
                        right: 8,
                        zIndex: 9,
                        height: 58,
                        borderRadius: 1,
                        position: "absolute",
                        bgcolor: "primary.lighter"
                    }, t && {
                        pl: 1,
                        height: 38
                    }), c)
                }, u), {}, {
                    children: [(0, d.jsx)(g.Z, {
                        indeterminate: i > 0 && i < r,
                        checked: r > 0 && i === r,
                        onChange: function(e) {
                            return s(e.target.checked)
                        }
                    }), (0, d.jsxs)(l.Z, {
                        variant: "subtitle1",
                        sx: (0, a.Z)({
                            ml: 2,
                            flexGrow: 1,
                            color: "primary.main"
                        }, t && {
                            ml: 3
                        }),
                        children: [i, " selected"]
                    }), n && n]
                }))
            }
        },
        66429: function(e, t, n) {
            n.d(t, {
                ZP: function() {
                    return a
                },
                sQ: function() {
                    return s
                }
            });
            var r = n(29439),
                i = n(47313);

            function a(e) {
                var t = (0, i.useState)((null === e || void 0 === e ? void 0 : e.defaultDense) || !0),
                    n = (0, r.Z)(t, 2),
                    a = n[0],
                    o = n[1],
                    s = (0, i.useState)((null === e || void 0 === e ? void 0 : e.defaultOrderBy) || "name"),
                    l = (0, r.Z)(s, 2),
                    c = l[0],
                    d = l[1],
                    u = (0, i.useState)((null === e || void 0 === e ? void 0 : e.defaultOrder) || "asc"),
                    x = (0, r.Z)(u, 2),
                    h = x[0],
                    p = x[1],
                    m = (0, i.useState)((null === e || void 0 === e ? void 0 : e.defaultCurrentPage) || 0),
                    f = (0, r.Z)(m, 2),
                    g = f[0],
                    v = f[1],
                    Z = (0, i.useState)((null === e || void 0 === e ? void 0 : e.defaultRowsPerPage) || 10),
                    j = (0, r.Z)(Z, 2),
                    y = j[0],
                    b = j[1],
                    w = (0, i.useState)((null === e || void 0 === e ? void 0 : e.defaultSelected) || []),
                    k = (0, r.Z)(w, 2),
                    S = k[0],
                    P = k[1];
                return {
                    dense: a,
                    order: h,
                    page: g,
                    setPage: v,
                    orderBy: c,
                    rowsPerPage: y,
                    selected: S,
                    setSelected: P,
                    onSelectRow: function(e) {
                        var t = S.indexOf(e),
                            n = []; - 1 === t ? n = n.concat(S, e) : 0 === t ? n = n.concat(S.slice(1)) : t === S.length - 1 ? n = n.concat(S.slice(0, -1)) : t > 0 && (n = n.concat(S.slice(0, t), S.slice(t + 1))), P(n)
                    },
                    onSelectAllRows: function(e, t) {
                        P(e ? t : [])
                    },
                    onSort: function(e) {
                        "" !== e && (p(c === e && "asc" === h ? "desc" : "asc"), d(e))
                    },
                    onChangePage: function(e, t) {
                        v(t)
                    },
                    onChangeDense: function(e) {
                        o(e.target.checked)
                    },
                    onChangeRowsPerPage: function(e) {
                        b(parseInt(e.target.value, 10)), v(0)
                    }
                }
            }

            function o(e, t, n) {
                return t[n] < e[n] ? -1 : t[n] > e[n] ? 1 : 0
            }

            function s(e, t) {
                return "desc" === e ? function(e, n) {
                    return o(e, n, t)
                } : function(e, n) {
                    return -o(e, n, t)
                }
            }
        }
    }
]);