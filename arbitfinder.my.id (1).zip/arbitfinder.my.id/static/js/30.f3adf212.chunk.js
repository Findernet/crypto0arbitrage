"use strict";
(self.webpackChunkarbitrage_notification = self.webpackChunkarbitrage_notification || []).push([
    [30, 2054, 5581], {
        82836: function(n, i, a) {
            a.r(i), a.d(i, {
                default: function() {
                    return f
                }
            });
            var e = a(29439),
                r = a(47313),
                t = (a(84389), a(34032)),
                s = a(73428),
                o = a(61113),
                c = a(57829),
                l = a(94157),
                d = (a(98481), a(60933)),
                x = a(13047),
                h = (a(67871), a(90453), a(72563), a(62677), a(84905), a(42593), a(90205), a(71361), a(13918)),
                m = a(88669),
                u = a(31848),
                g = a(5239),
                j = a(66914),
                p = a(46417);

            function b() {
                window.innerHeight, window.innerWidth;
                var n, i = (0, r.useContext)(u.z),
                    a = i.preference;
                i.setPreference;
                return (0, p.jsxs)(p.Fragment, {
                    children: [(0, p.jsx)(s.Z, {
                        sx: {
                            mb: 10
                        },
                        children: (n = null === a || void 0 === a ? void 0 : a.view, "2" === n ? (0, p.jsx)(d.Z, {
                            fixed: Boolean(!1),
                            unregistered: Boolean(!0)
                        }) : (0, p.jsx)(x.Z, {
                            fixed: Boolean(!1),
                            unregistered: Boolean(!0)
                        }))
                    }), (0, p.jsx)(o.Z, {
                        variant: "caption",
                        children: "Arbit Finder \xa92023 By: Erwin San"
                    })]
                })
            }

            function v() {
                return (0, p.jsx)(c.Z, {
                    sx: {
                        display: "flex",
                        alignItems: "center",
                        flexDirection: "column"
                    },
                    children: (0, p.jsx)(b, {})
                })
            }

            function Z() {
                return (0, p.jsx)(c.Z, {
                    sx: {},
                    children: (0, p.jsx)(b, {})
                })
            }

            function f() {
                (0, t.Ds)().enqueueSnackbar;
                var n = (0, g.I0)(),
                    i = ((0, m.xp)(localStorage.getItem("accessToken")), (0, g.v9)((function(n) {
                        return n.monitoring
                    }))),
                    a = (i.datas, i.isLoading);
                i.hasError;
                var s = (0, r.useState)(null),
                    o = (0, e.Z)(s, 2),
                    c = o[0],
                    d = o[1];
                (0, r.useEffect)((function() {
                    return n((0, j.Yu)()), d((0, l.ZP)(h.LS)),
                        function() {
                            c && c.disconnect()
                        }
                }), []), (0, r.useEffect)((function() {
                    c && (c.on("connect", (function() {})), c.on("disconnect", (function() {})), c.on("arb_data", (function(i) {
                        null !== i && void 0 !== i && i.arb_data && Array.isArray(null === i || void 0 === i ? void 0 : i.arb_data) && n((0, j.E)(i))
                    })))
                }), [c]);
                var x = window.innerHeight < window.innerWidth;
                return (0, p.jsx)(p.Fragment, {
                    children: !a && (0, p.jsx)(p.Fragment, {
                        children: x && window.screen.width >= 1e3 ? (0, p.jsx)(Z, {}) : (0, p.jsx)(v, {})
                    })
                })
            }
        },
        40895: function(n, i, a) {
            a.r(i), a.d(i, {
                default: function() {
                    return u
                }
            });
            var e = a(47313),
                r = (a(84389), a(34032)),
                t = a(73428),
                s = a(61113),
                o = (a(94157), a(98481), a(60933)),
                c = a(13047),
                l = (a(67871), a(90453), a(72563), a(62677), a(84905), a(42593), a(90205), a(71361), a(54285)),
                d = (a(13918), a(88669), a(31848)),
                x = a(5239),
                h = a(66914),
                m = a(46417);

            function u() {
                (0, r.Ds)().enqueueSnackbar;
                var n = (0, x.I0)(),
                    i = (0, x.v9)((function(n) {
                        return n.monitoring
                    })),
                    a = (i.datas, i.isLoading);
                i.hasError;
                (0, e.useEffect)((function() {
                    n((0, h.Yu)())
                }), []);
                window.innerHeight, window.innerWidth, (0, l.Z)().user;
                var u, g = (0, e.useContext)(d.z),
                    j = g.preference;
                g.setPreference;
                return (0, m.jsxs)(m.Fragment, {
                    children: [!a && (0, m.jsx)(t.Z, {
                        sx: {
                            mb: 10
                        },
                        children: (u = null === j || void 0 === j ? void 0 : j.view, "2" === u ? (0, m.jsx)(o.Z, {
                            fixed: Boolean(!1),
                            limit: 8
                        }) : (0, m.jsx)(c.Z, {
                            fixed: Boolean(!1),
                            limit: 3
                        }))
                    }), (0, m.jsx)(s.Z, {
                        variant: "caption",
                        children: "Arbit Finder \xa92023 By: Erwin San"
                    })]
                })
            }
        },
        89515: function(n, i, a) {
            a.r(i), a.d(i, {
                default: function() {
                    return G
                }
            });
            var e = a(17592),
                r = a(71361),
                t = a(4942),
                s = a(1413),
                o = a(28630),
                c = a(19860),
                l = a(42832),
                d = a(57829),
                x = a(47825),
                h = a(9019),
                m = a(78770),
                u = a(3789),
                g = a(90891),
                j = a(61113),
                p = a(69099),
                b = (a(48175), a(5239)),
                v = a(2311),
                Z = a(54285),
                f = a(3484),
                k = a(42593),
                w = a(46417);
            var y = a(57597),
                A = a(40895),
                E = a(66914),
                D = (0, e.ZP)(o.m.div)((function(n) {
                    return {
                        backgroundColor: n.theme.palette.grey[350],
                        top: 0,
                        left: 0,
                        width: "100%",
                        position: "fixed"
                    }
                })),
                P = (0, e.ZP)((function(n) {
                    return (0, w.jsx)(l.Z, (0, s.Z)({
                        spacing: 5
                    }, n))
                }))((function(n) {
                    var i = n.theme;
                    return {
                        zIndex: 10,
                        position: "relative",
                        paddingTop: i.spacing(10),
                        paddingBottom: i.spacing(5)
                    }
                })),
                U = (0, e.ZP)((function(n) {
                    return (0, w.jsx)(d.Z, (0, s.Z)({}, n))
                }))((function(n) {
                    var i = n.theme;
                    return (0, t.Z)({}, i.breakpoints.up("md"), {})
                }));

            function F() {
                var n = (0, b.I0)(),
                    i = (0, Z.Z)(),
                    a = i.isAuthenticated,
                    e = (i.isInitialized, (0, c.Z)(), window.innerHeight < window.innerWidth),
                    r = (0, b.v9)((function(n) {
                        return n.monitoring
                    })).language;
                return (0, w.jsx)(w.Fragment, {
                    children: e ? (0, w.jsxs)(y.NM, {
                        children: [(0, w.jsx)(D, {
                            children: (0, w.jsx)(x.Z, {
                                children: (0, w.jsx)(P, {
                                    children: (0, w.jsx)(U, {
                                        children: (0, w.jsxs)(h.ZP, {
                                            container: !0,
                                            children: [(0, w.jsx)(h.ZP, {
                                                item: !0,
                                                xs: 12,
                                                sx: {
                                                    textAlign: "right",
                                                    marginBottom: 1
                                                },
                                                children: (0, w.jsxs)(m.Z, {
                                                    size: "small",
                                                    value: r,
                                                    exclusive: !0,
                                                    onChange: function(i, a) {
                                                        n((0, E.m0)(a))
                                                    },
                                                    "aria-label": "text alignment",
                                                    children: [(0, w.jsx)(u.Z, {
                                                        value: "id",
                                                        "aria-label": "left aligned",
                                                        children: (0, w.jsx)(k.Z, {
                                                            icon: "emojione:flag-for-indonesia"
                                                        })
                                                    }), (0, w.jsx)(u.Z, {
                                                        value: "en",
                                                        "aria-label": "centered",
                                                        children: (0, w.jsx)(k.Z, {
                                                            icon: "circle-flags:uk"
                                                        })
                                                    })]
                                                })
                                            }), a ? " " : (0, w.jsxs)(h.ZP, {
                                                item: !0,
                                                xs: 12,
                                                sx: {
                                                    textAlign: "right",
                                                    marginBottom: 1
                                                },
                                                children: [(0, w.jsx)(g.Z, {
                                                    href: "/auth/member",
                                                    children: "Login"
                                                }), " or ", (0, w.jsx)(g.Z, {
                                                    href: "/auth/register",
                                                    children: "Register"
                                                }), " for Subscriber"]
                                            }), (0, w.jsx)(h.ZP, {
                                                item: !0,
                                                xs: 12,
                                                md: 6,
                                                children: (0, w.jsxs)(l.Z, {
                                                    spacing: 3,
                                                    alignItems: "left",
                                                    direction: {
                                                        xs: "column"
                                                    },
                                                    sx: {
                                                        mt: 15
                                                    },
                                                    children: [(0, w.jsx)(o.m.div, {
                                                        variants: (0, y.EU)().inLeft,
                                                        children: "id" === r ? (0, w.jsxs)(w.Fragment, {
                                                            children: [(0, w.jsxs)(j.Z, {
                                                                variant: "h2",
                                                                sx: {
                                                                    color: "common.black"
                                                                },
                                                                children: ["Dapatkan \xa0", (0, w.jsx)(j.Z, {
                                                                    component: "span",
                                                                    variant: "h2",
                                                                    sx: {
                                                                        color: "primary.main"
                                                                    },
                                                                    children: "Keuntungan \xa0"
                                                                })]
                                                            }), (0, w.jsx)(j.Z, {
                                                                variant: "h2",
                                                                sx: {
                                                                    color: "common.black"
                                                                },
                                                                children: "Dari Selisih Harga"
                                                            }), (0, w.jsx)(j.Z, {
                                                                variant: "h3",
                                                                sx: {
                                                                    color: "common.black"
                                                                },
                                                                children: "Antar Kripto Exchanges"
                                                            }), (0, w.jsxs)(j.Z, {
                                                                variant: "button",
                                                                children: ["Anda juga dapat memonitor Pump&dump hingga spike harga", (0, w.jsx)(j.Z, {
                                                                    component: "span",
                                                                    variant: "button",
                                                                    sx: {
                                                                        color: "primary.main"
                                                                    },
                                                                    children: "\xa0 Coin \xa0"
                                                                }), "dari", (0, w.jsx)(j.Z, {
                                                                    component: "span",
                                                                    variant: "button",
                                                                    sx: {
                                                                        color: "primary.main"
                                                                    },
                                                                    children: "\xa0 Crypto Market \xa0"
                                                                }), "dengan ArbitFinder"]
                                                            }), (0, w.jsx)("br", {}), (0, w.jsx)(j.Z, {
                                                                component: "span",
                                                                variant: "caption",
                                                                children: "Segala tindakan merupakan tanggung jawab anda dan kami tidak meminta sepeserpun dari keuntungan anda"
                                                            }), (0, w.jsx)("br", {}), (0, w.jsx)(j.Z, {
                                                                variant: "button",
                                                                sx: {
                                                                    color: "error.main"
                                                                },
                                                                children: "* Kami adalah data aggregator dan hanya menginfo selisih harga #BukanRobotTrading *"
                                                            })]
                                                        }) : (0, w.jsxs)(w.Fragment, {
                                                            children: [(0, w.jsxs)(j.Z, {
                                                                variant: "h2",
                                                                sx: {
                                                                    color: "common.black"
                                                                },
                                                                children: ["Find Your \xa0", (0, w.jsx)(j.Z, {
                                                                    component: "span",
                                                                    variant: "h2",
                                                                    sx: {
                                                                        color: "primary.main"
                                                                    },
                                                                    children: "Profit \xa0"
                                                                })]
                                                            }), (0, w.jsx)(j.Z, {
                                                                variant: "h2",
                                                                sx: {
                                                                    color: "common.black"
                                                                },
                                                                children: "From Price Difference"
                                                            }), (0, w.jsx)(j.Z, {
                                                                variant: "h3",
                                                                sx: {
                                                                    color: "common.black"
                                                                },
                                                                children: "Between Crypto Exchanges"
                                                            }), (0, w.jsxs)(j.Z, {
                                                                variant: "button",
                                                                children: ["Also you can monitor pump&dump or price spike of", (0, w.jsx)(j.Z, {
                                                                    component: "span",
                                                                    variant: "button",
                                                                    sx: {
                                                                        color: "primary.main"
                                                                    },
                                                                    children: "\xa0 Coin \xa0"
                                                                }), "from", (0, w.jsx)(j.Z, {
                                                                    component: "span",
                                                                    variant: "button",
                                                                    sx: {
                                                                        color: "primary.main"
                                                                    },
                                                                    children: "\xa0 Crypto Market \xa0"
                                                                }), "with ArbitFinder"]
                                                            }), (0, w.jsx)("br", {}), (0, w.jsx)(j.Z, {
                                                                component: "span",
                                                                variant: "caption",
                                                                children: "All actions are your responsibility and we do not ask for a single penny of your profits"
                                                            }), (0, w.jsx)("br", {}), (0, w.jsx)(j.Z, {
                                                                variant: "button",
                                                                sx: {
                                                                    color: "error.main"
                                                                },
                                                                children: "* We Are a Data Aggregator and Only Inform Price Difference #NotATradingBot *"
                                                            })]
                                                        })
                                                    }), (0, w.jsx)(o.m.div, {
                                                        variants: (0, y.EU)().inLeft,
                                                        children: (0, w.jsx)(g.Z, {
                                                            href: "/menu/Arbitrage_Data",
                                                            children: (0, w.jsxs)(p.Z, {
                                                                variant: "contained",
                                                                sx: {
                                                                    boxShadow: "0 0 15px #e3dd24, rgba(227, 221, 36, 0.3) 0px 0px 25px 20px"
                                                                },
                                                                children: [" ", "id" === r ? "Lihat Data" : "See Data", "  "]
                                                            })
                                                        })
                                                    }), (0, w.jsxs)(l.Z, {
                                                        spacing: 3,
                                                        alignItems: "center",
                                                        direction: "column",
                                                        children: [(0, w.jsx)(o.m.div, {
                                                            variants: (0, y.EU)().inLeft,
                                                            children: "id" === r ? (0, w.jsx)(j.Z, {
                                                                variant: "overline",
                                                                children: "List exchange yang didukung :"
                                                            }) : (0, w.jsx)(j.Z, {
                                                                variant: "overline",
                                                                children: "List supported exchanges :"
                                                            })
                                                        }), (0, w.jsx)(l.Z, {
                                                            direction: "row",
                                                            spacing: 1.5,
                                                            justifyContent: {
                                                                xs: "center",
                                                                md: "flex-start"
                                                            },
                                                            flexWrap: "wrap",
                                                            children: ["indodax", "tokocrypto", "binance", "okx", "bybit", "bitget", "kucoin", "huobi", "gateio", "mexc", "bitmart"].map((function(n) {
                                                                return (0, w.jsx)(o.m.img, {
                                                                    style: {
                                                                        width: 50,
                                                                        height: 50,
                                                                        marginTop: "10px"
                                                                    },
                                                                    variants: (0, y.EU)().inLeft,
                                                                    src: "/assets/exchange/".concat(n, ".jpg")
                                                                }, n)
                                                            }))
                                                        })]
                                                    })]
                                                })
                                            }), (0, w.jsx)(h.ZP, {
                                                item: !0,
                                                xs: 12,
                                                md: 6,
                                                children: (0, w.jsx)(o.m.div, {
                                                    variants: (0, y.EU)().inRight,
                                                    children: (0, w.jsx)(A.default, {})
                                                })
                                            })]
                                        })
                                    })
                                })
                            })
                        }), (0, w.jsx)(d.Z, {
                            sx: {
                                height: "100vh"
                            }
                        })]
                    }) : (0, w.jsxs)(y.NM, {
                        children: [(0, w.jsx)(D, {
                            children: (0, w.jsx)(x.Z, {
                                children: (0, w.jsx)(P, {
                                    children: (0, w.jsx)(U, {
                                        children: (0, w.jsxs)(h.ZP, {
                                            container: !0,
                                            children: [(0, w.jsx)(h.ZP, {
                                                item: !0,
                                                xs: 12,
                                                sx: {
                                                    textAlign: "right",
                                                    marginBottom: 1
                                                },
                                                children: (0, w.jsxs)(m.Z, {
                                                    size: "small",
                                                    value: r,
                                                    exclusive: !0,
                                                    onChange: function(i, a) {
                                                        n((0, E.m0)(a))
                                                    },
                                                    "aria-label": "text alignment",
                                                    children: [(0, w.jsx)(u.Z, {
                                                        value: "id",
                                                        "aria-label": "left aligned",
                                                        children: (0, w.jsx)(k.Z, {
                                                            icon: "emojione:flag-for-indonesia"
                                                        })
                                                    }), (0, w.jsx)(u.Z, {
                                                        value: "en",
                                                        "aria-label": "centered",
                                                        children: (0, w.jsx)(k.Z, {
                                                            icon: "circle-flags:uk"
                                                        })
                                                    })]
                                                })
                                            }), a ? " " : (0, w.jsxs)(h.ZP, {
                                                item: !0,
                                                xs: 12,
                                                sx: {
                                                    textAlign: "right",
                                                    marginBottom: 1
                                                },
                                                children: [(0, w.jsx)(g.Z, {
                                                    href: "/auth/member",
                                                    children: "Login"
                                                }), " or ", (0, w.jsx)(g.Z, {
                                                    href: "/auth/register",
                                                    children: "Register"
                                                }), " for Subscriber"]
                                            }), (0, w.jsxs)(h.ZP, {
                                                item: !0,
                                                xs: 12,
                                                md: 6,
                                                children: [(0, w.jsx)(l.Z, {
                                                    spacing: 2,
                                                    alignItems: "center",
                                                    direction: {
                                                        xs: "column"
                                                    },
                                                    sx: {
                                                        mt: 0,
                                                        textAlign: "center"
                                                    },
                                                    children: (0, w.jsx)(o.m.div, {
                                                        variants: (0, y.EU)().inLeft,
                                                        children: "id" === r ? (0, w.jsxs)(w.Fragment, {
                                                            children: [(0, w.jsxs)(j.Z, {
                                                                variant: "h6",
                                                                sx: {
                                                                    color: "common.black"
                                                                },
                                                                children: ["Dapatkan \xa0", (0, w.jsx)(j.Z, {
                                                                    component: "span",
                                                                    variant: "h6",
                                                                    sx: {
                                                                        color: "primary.main"
                                                                    },
                                                                    children: "Keuntungan \xa0"
                                                                }), "Dari Selisih Harga Antar Kripto Exchanges"]
                                                            }), (0, w.jsxs)(j.Z, {
                                                                variant: "button",
                                                                children: ["Anda juga dapat memonitor Pump&dump hingga spike harga", (0, w.jsx)(j.Z, {
                                                                    component: "span",
                                                                    variant: "button",
                                                                    sx: {
                                                                        color: "primary.main"
                                                                    },
                                                                    children: "\xa0 Coin \xa0"
                                                                }), "dari", (0, w.jsx)(j.Z, {
                                                                    component: "span",
                                                                    variant: "button",
                                                                    sx: {
                                                                        color: "primary.main"
                                                                    },
                                                                    children: "\xa0 Crypto Market \xa0"
                                                                }), "dengan ArbitFinder"]
                                                            }), (0, w.jsx)("br", {}), (0, w.jsx)(j.Z, {
                                                                component: "span",
                                                                variant: "caption",
                                                                children: "Segala tindakan merupakan tanggung jawab anda dan kami tidak meminta sepeserpun dari keuntungan anda"
                                                            }), (0, w.jsx)("br", {}), (0, w.jsx)(j.Z, {
                                                                variant: "button",
                                                                sx: {
                                                                    color: "error.main"
                                                                },
                                                                children: "* Kami adalah data aggregator dan hanya menginfo selisih harga #BukanRobotTrading *"
                                                            })]
                                                        }) : (0, w.jsxs)(w.Fragment, {
                                                            children: [(0, w.jsxs)(j.Z, {
                                                                variant: "h6",
                                                                sx: {
                                                                    color: "common.black"
                                                                },
                                                                children: ["Find Your \xa0", (0, w.jsx)(j.Z, {
                                                                    component: "span",
                                                                    variant: "h6",
                                                                    sx: {
                                                                        color: "primary.main"
                                                                    },
                                                                    children: "Profit \xa0"
                                                                }), "From Price Difference Between Crypto Exchanges"]
                                                            }), (0, w.jsxs)(j.Z, {
                                                                variant: "button",
                                                                children: ["Also you can monitor pump&dump or price spike of", (0, w.jsx)(j.Z, {
                                                                    component: "span",
                                                                    variant: "button",
                                                                    sx: {
                                                                        color: "primary.main"
                                                                    },
                                                                    children: "\xa0 Coin \xa0"
                                                                }), "from", (0, w.jsx)(j.Z, {
                                                                    component: "span",
                                                                    variant: "button",
                                                                    sx: {
                                                                        color: "primary.main"
                                                                    },
                                                                    children: "\xa0 Crypto Market \xa0"
                                                                }), "with ArbitFinder"]
                                                            }), (0, w.jsx)("br", {}), (0, w.jsx)(j.Z, {
                                                                component: "span",
                                                                variant: "caption",
                                                                children: "All actions are your responsibility and we do not ask for a single penny of your profits"
                                                            }), (0, w.jsx)("br", {}), (0, w.jsx)(j.Z, {
                                                                variant: "button",
                                                                sx: {
                                                                    color: "error.main"
                                                                },
                                                                children: "* We Are a Data Aggregator and Only Inform Price Difference #NotATradingBot *"
                                                            })]
                                                        })
                                                    })
                                                }), (0, w.jsx)(l.Z, {
                                                    spacing: 3,
                                                    alignItems: "center",
                                                    direction: "column",
                                                    sx: {
                                                        my: 2
                                                    },
                                                    children: (0, w.jsx)(o.m.div, {
                                                        variants: (0, y.EU)().inLeft,
                                                        children: (0, w.jsx)(g.Z, {
                                                            href: "/menu/Arbitrage_Data",
                                                            children: (0, w.jsxs)(p.Z, {
                                                                variant: "contained",
                                                                sx: {
                                                                    boxShadow: "0 0 15px #e3dd24, rgba(227, 221, 36, 0.3) 0px 0px 25px 20px"
                                                                },
                                                                children: [" ", "id" === r ? "Lihat Data" : "See Data", "  "]
                                                            })
                                                        })
                                                    })
                                                })]
                                            }), (0, w.jsx)(h.ZP, {
                                                item: !0,
                                                xs: 12,
                                                md: 6,
                                                children: (0, w.jsx)(o.m.div, {
                                                    variants: (0, y.EU)().inRight,
                                                    children: (0, w.jsx)(A.default, {})
                                                })
                                            })]
                                        })
                                    })
                                })
                            })
                        }), (0, w.jsx)(d.Z, {
                            sx: {
                                height: "100vh"
                            }
                        })]
                    })
                })
            }
            var C = a(47131),
                I = (a(62677), a(47313)),
                B = function(n) {
                    var i = n.embedId,
                        a = n.width,
                        e = n.height;
                    return (0, w.jsx)("div", {
                        className: "video-responsive",
                        children: (0, w.jsx)("iframe", {
                            width: a || "320",
                            height: e || "320",
                            src: "https://www.youtube.com/embed/".concat(i),
                            frameBorder: "0",
                            allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
                            allowFullScreen: !0,
                            title: "Embedded youtube"
                        })
                    })
                },
                R = (0, e.ZP)("div")((function(n) {
                    var i = n.theme;
                    return {
                        paddingTop: i.spacing(10),
                        backgroundImage: "linear-gradient(0deg, rgba(213,224,240,1) 0%, rgba(65,204,135,1) 30%);",
                        paddingBottom: i.spacing(15)
                    }
                })),
                S = (0, e.ZP)((function(n) {
                    return (0, w.jsx)(l.Z, (0, s.Z)({
                        spacing: 5
                    }, n))
                }))((function(n) {
                    var i = n.theme;
                    return (0, t.Z)({
                        margin: "auto",
                        textAlign: "center",
                        position: "relative",
                        paddingTop: i.spacing(5)
                    }, i.breakpoints.up("md"), {
                        margin: "unset"
                    })
                }));

            function T() {
                var n = (0, c.Z)(),
                    i = (0, b.v9)((function(n) {
                        return n.monitoring
                    })).language;
                n.palette.mode;
                return (0, w.jsx)(R, {
                    id: "how_it_works",
                    children: (0, w.jsx)(x.Z, {
                        component: y.DG,
                        children: (0, w.jsxs)(S, {
                            children: [(0, w.jsx)(l.Z, {
                                spacing: 3,
                                alignItems: "center",
                                direction: "column",
                                children: (0, w.jsx)(o.m.div, {
                                    variants: (0, y.EU)().inDown,
                                    children: "id" === i ? (0, w.jsx)(j.Z, {
                                        variant: "h2",
                                        sx: {
                                            color: "common.black"
                                        },
                                        children: "Cara kerjanya ?"
                                    }) : (0, w.jsx)(j.Z, {
                                        variant: "h2",
                                        sx: {
                                            color: "common.black"
                                        },
                                        children: "How it works ?"
                                    })
                                })
                            }), (0, w.jsx)(l.Z, {
                                spacing: 3,
                                alignItems: "center",
                                direction: "column",
                                children: (0, w.jsxs)(o.m.div, {
                                    variants: (0, y.EU)().inDown,
                                    children: ["id" === i ? (0, w.jsx)(j.Z, {
                                        variant: "h6",
                                        sx: {
                                            color: "common.black"
                                        },
                                        children: "Crypto arbitrage trading adalah jenis strategi perdagangan di mana investor memanfaatkan perbedaan harga aset digital antar beberapa pasar atau tempat jual beli crypto."
                                    }) : (0, w.jsx)(j.Z, {
                                        variant: "h6",
                                        sx: {
                                            color: "common.black"
                                        },
                                        children: "Crypto arbitrage trading is a type of trading strategy where investors capitalize on price discrepancies of a digital asset across multiple Markets or Exchanges."
                                    }), "id" === i ? (0, w.jsx)(j.Z, {
                                        variant: "body1",
                                        sx: {
                                            color: "common.black"
                                        },
                                        children: "Mengapa manual trading dan bukan bot arbitrage? karena kami mengantisipasi terekspose nya key wallet. Dengan manual arbitrage, maka semua aksi di tangan anda."
                                    }) : (0, w.jsx)(j.Z, {
                                        variant: "body1",
                                        sx: {
                                            color: "common.black"
                                        },
                                        children: "Why manual trading and not arbitrage bots? because we anticipate the wallet's key being exposed. With manual arbitrage, all the action is in your hands."
                                    })]
                                })
                            }), (0, w.jsxs)(l.Z, {
                                spacing: 1,
                                alignItems: "center",
                                direction: "column",
                                children: [(0, w.jsx)(o.m.img, {
                                    variants: (0, y.EU)().inDown,
                                    src: "/assets/arbitrage_triangle.png"
                                }), (0, w.jsxs)(o.m.div, {
                                    variants: (0, y.EU)().inDown,
                                    children: ["id" === i ? (0, w.jsx)(j.Z, {
                                        variant: "h5",
                                        sx: {
                                            color: "common.black"
                                        },
                                        children: "Bagaimana cara mengetahui selisih koin apa dan di market mana ? anda dapat menemukannya dengan ArbitFinder"
                                    }) : (0, w.jsx)(j.Z, {
                                        variant: "h5",
                                        sx: {
                                            color: "common.black"
                                        },
                                        children: "How to find out what coin difference and in which market? You can find it with ArbitFinder"
                                    }), "id" === i ? (0, w.jsx)(j.Z, {
                                        variant: "body1",
                                        sx: {
                                            color: "common.black"
                                        },
                                        children: "Arbit Finder adalah data aggregator seperti Coinmarketcap tetapi kami mencari selisih koin antar market dan memberi perhitungan serta data orderbook pada market. Untuk info lebih lanjut silahkan tonton video berikut."
                                    }) : (0, w.jsx)(j.Z, {
                                        variant: "body1",
                                        sx: {
                                            color: "common.black"
                                        },
                                        children: "Arbit Finder is a data aggregator like Coinmarketcap but we look for the difference in coins between markets and provide calculations and orderbook data on the market. For more info please watch the following video."
                                    })]
                                }), (0, w.jsxs)(o.m.div, {
                                    variants: (0, y.EU)().inDown,
                                    children: [(0, w.jsx)(B, {
                                        embedId: "EEfH-H_M7EM"
                                    }), (0, w.jsx)(B, {
                                        embedId: "5hIlh6drvh0"
                                    })]
                                }), (0, w.jsxs)(o.m.div, {
                                    variants: (0, y.EU)().inDown,
                                    children: ["id" === i ? (0, w.jsx)(j.Z, {
                                        variant: "h6",
                                        sx: {
                                            color: "common.black"
                                        },
                                        children: "Check Youtube kami untuk Info & Tutorial lainnya"
                                    }) : (0, w.jsx)(j.Z, {
                                        variant: "h6",
                                        sx: {
                                            color: "common.black"
                                        },
                                        children: "Please check our Youtube videos for More Info & Tutorial"
                                    }), (0, w.jsx)(g.Z, {
                                        href: "https://www.youtube.com/@ArbitFinderOfficial",
                                        target: "_blank",
                                        children: (0, w.jsx)(C.Z, {
                                            children: (0, w.jsx)(k.Z, {
                                                icon: "ant-design:youtube-filled",
                                                width: 50,
                                                height: 50,
                                                sx: {
                                                    color: "red"
                                                }
                                            })
                                        })
                                    })]
                                })]
                            }), (0, w.jsxs)(l.Z, {
                                spacing: 2.5,
                                alignItems: "center",
                                direction: "column",
                                children: [(0, w.jsx)(o.m.div, {
                                    variants: (0, y.EU)().inRight,
                                    children: "id" === i ? (0, w.jsx)(j.Z, {
                                        variant: "overline",
                                        children: "List exchange yang kami dukung :"
                                    }) : (0, w.jsx)(j.Z, {
                                        variant: "overline",
                                        children: "List supported exchanges :"
                                    })
                                }), (0, w.jsx)(l.Z, {
                                    direction: "row",
                                    spacing: 1.5,
                                    justifyContent: {
                                        xs: "center",
                                        md: "flex-start"
                                    },
                                    flexWrap: "wrap",
                                    children: ["indodax", "tokocrypto", "binance", "okx", "bybit", "bitget", "kucoin", "huobi", "gateio", "mexc", "bitmart"].map((function(n) {
                                        return (0, w.jsx)(o.m.img, {
                                            style: {
                                                width: 50,
                                                height: 50,
                                                marginTop: "10px"
                                            },
                                            variants: (0, y.EU)().inRight,
                                            src: "/assets/exchange/".concat(n, ".jpg")
                                        }, n)
                                    }))
                                })]
                            })]
                        })
                    })
                })
            }
            var _ = a(73428),
                L = (a(82836), (0, e.ZP)("div")((function(n) {
                    return {
                        backgroundColor: n.theme.palette.grey[350]
                    }
                }))),
                W = (0, e.ZP)((function(n) {
                    return (0, w.jsx)(l.Z, (0, s.Z)({
                        spacing: 5
                    }, n))
                }))((function(n) {
                    var i = n.theme;
                    return (0, t.Z)({
                        margin: "auto",
                        textAlign: "center",
                        position: "relative",
                        paddingTop: i.spacing(10),
                        paddingBottom: i.spacing(1)
                    }, i.breakpoints.up("md"), {
                        margin: "unset",
                        textAlign: "left"
                    })
                }));

            function M() {
                var n = (0, c.Z)(),
                    i = (0, b.v9)((function(n) {
                        return n.monitoring
                    })).language;
                n.palette.mode;
                return (0, w.jsx)(L, {
                    id: "feature",
                    children: (0, w.jsx)(x.Z, {
                        component: y.DG,
                        children: (0, w.jsxs)(W, {
                            children: [(0, w.jsxs)(l.Z, {
                                spacing: 3,
                                alignItems: "center",
                                direction: "column",
                                children: [(0, w.jsx)(o.m.div, {
                                    variants: (0, y.EU)().inDown,
                                    children: "id" === i ? (0, w.jsx)(j.Z, {
                                        variant: "h2",
                                        sx: {
                                            color: "common.black"
                                        },
                                        children: "Fitur"
                                    }) : (0, w.jsx)(j.Z, {
                                        variant: "h2",
                                        sx: {
                                            color: "common.black"
                                        },
                                        children: "Features"
                                    })
                                }), (0, w.jsx)(o.m.div, {
                                    variants: (0, y.EU)().inDown,
                                    children: "id" === i ? (0, w.jsxs)(w.Fragment, {
                                        children: [(0, w.jsxs)(j.Z, {
                                            variant: "h5",
                                            sx: {
                                                color: "common.black"
                                            },
                                            children: [(0, w.jsx)(k.Z, {
                                                icon: "eva:checkmark-fill",
                                                sx: {
                                                    color: "success.main"
                                                }
                                            }), " Data real time(selalu diupdate)"]
                                        }), (0, w.jsxs)(j.Z, {
                                            variant: "h5",
                                            sx: {
                                                color: "common.black"
                                            },
                                            children: [(0, w.jsx)(k.Z, {
                                                icon: "eva:checkmark-fill",
                                                sx: {
                                                    color: "success.main"
                                                }
                                            }), " Filter data"]
                                        }), (0, w.jsxs)(j.Z, {
                                            variant: "h5",
                                            sx: {
                                                color: "common.black"
                                            },
                                            children: [(0, w.jsx)(k.Z, {
                                                icon: "eva:checkmark-fill",
                                                sx: {
                                                    color: "success.main"
                                                }
                                            }), " Mudah digunakan"]
                                        })]
                                    }) : (0, w.jsxs)(w.Fragment, {
                                        children: [(0, w.jsxs)(j.Z, {
                                            variant: "h5",
                                            sx: {
                                                color: "common.black"
                                            },
                                            children: [(0, w.jsx)(k.Z, {
                                                icon: "eva:checkmark-fill",
                                                sx: {
                                                    color: "success.main"
                                                }
                                            }), " Real time data (regularly updated)"]
                                        }), (0, w.jsxs)(j.Z, {
                                            variant: "h5",
                                            sx: {
                                                color: "common.black"
                                            },
                                            children: [(0, w.jsx)(k.Z, {
                                                icon: "eva:checkmark-fill",
                                                sx: {
                                                    color: "success.main"
                                                }
                                            }), " Filter data"]
                                        }), (0, w.jsxs)(j.Z, {
                                            variant: "h5",
                                            sx: {
                                                color: "common.black"
                                            },
                                            children: [(0, w.jsx)(k.Z, {
                                                icon: "eva:checkmark-fill",
                                                sx: {
                                                    color: "success.main"
                                                }
                                            }), " Easy to use"]
                                        })]
                                    })
                                }), (0, w.jsx)(o.m.div, {
                                    variants: (0, y.EU)().inDown,
                                    children: (0, w.jsx)(l.Z, {
                                        spacing: 3,
                                        alignItems: "center",
                                        direction: "column",
                                        children: (0, w.jsx)(f.Z, {
                                            alt: "sketch icon",
                                            src: "/assets/feature1.png",
                                            sx: {
                                                maxWidth: 800
                                            }
                                        })
                                    })
                                }), (0, w.jsx)(o.m.div, {
                                    variants: (0, y.EU)().inDown,
                                    children: (0, w.jsx)(l.Z, {
                                        spacing: 3,
                                        alignItems: "center",
                                        direction: "column",
                                        children: (0, w.jsx)(f.Z, {
                                            alt: "sketch icon",
                                            src: "/assets/feature2.png",
                                            sx: {
                                                maxWidth: 800
                                            }
                                        })
                                    })
                                }), (0, w.jsx)(o.m.div, {
                                    variants: (0, y.EU)().inDown,
                                    children: (0, w.jsx)(l.Z, {
                                        spacing: 3,
                                        alignItems: "center",
                                        direction: "column",
                                        children: (0, w.jsx)(f.Z, {
                                            alt: "sketch icon",
                                            src: "/assets/feature3.png",
                                            sx: {
                                                maxWidth: 800
                                            }
                                        })
                                    })
                                })]
                            }), (0, w.jsxs)(l.Z, {
                                spacing: 2.5,
                                alignItems: "center",
                                direction: "column",
                                children: [(0, w.jsx)(o.m.div, {
                                    variants: (0, y.EU)().inDown,
                                    children: "id" === i ? (0, w.jsx)(j.Z, {
                                        variant: "h2",
                                        sx: {
                                            color: "common.black"
                                        },
                                        children: "Cara memulai"
                                    }) : (0, w.jsx)(j.Z, {
                                        variant: "h2",
                                        sx: {
                                            color: "common.black"
                                        },
                                        children: "How to start"
                                    })
                                }), (0, w.jsx)(o.m.div, {
                                    variants: (0, y.EU)().inRight,
                                    children: (0, w.jsx)(_.Z, {
                                        sx: {
                                            p: 2
                                        },
                                        children: "id" === i ? (0, w.jsx)(w.Fragment, {
                                            children: (0, w.jsxs)(d.Z, {
                                                sx: {
                                                    textAlign: "left",
                                                    maxWidth: 500
                                                },
                                                children: [(0, w.jsx)(j.Z, {
                                                    variant: "button",
                                                    children: "1. Register pada beberapa exchange yang didukung ArbitFinder."
                                                }), (0, w.jsx)("br", {}), (0, w.jsx)(j.Z, {
                                                    variant: "button",
                                                    children: "2. Register pada ArbitFinder & login (anda menjadi Free User dengan beberapa keterbatasan)"
                                                }), (0, w.jsx)("br", {}), (0, w.jsx)(j.Z, {
                                                    variant: "button",
                                                    children: "3. Klik icon avatar pada bagian atas , lalu klik Profile"
                                                }), (0, w.jsx)(o.m.img, {
                                                    style: {
                                                        width: "50%"
                                                    },
                                                    variants: (0, y.EU)().inRight,
                                                    src: "/assets/tutorial_account_popover.jpg"
                                                }), (0, w.jsx)("br", {}), (0, w.jsx)(j.Z, {
                                                    variant: "button",
                                                    children: "4. Pilih membership sesuai keinginan anda."
                                                }), (0, w.jsx)(o.m.img, {
                                                    style: {
                                                        width: "100%"
                                                    },
                                                    variants: (0, y.EU)().inRight,
                                                    src: "/assets/tutorial_pricing.png"
                                                })]
                                            })
                                        }) : (0, w.jsx)(w.Fragment, {
                                            children: (0, w.jsxs)(d.Z, {
                                                sx: {
                                                    textAlign: "left",
                                                    maxWidth: 500
                                                },
                                                children: [(0, w.jsx)(j.Z, {
                                                    variant: "button",
                                                    children: "1. Register to any supported exchange."
                                                }), (0, w.jsx)("br", {}), (0, w.jsx)(j.Z, {
                                                    variant: "button",
                                                    children: "2. Register in ArbitFinder & login (become Free User with any limitation)"
                                                }), (0, w.jsx)("br", {}), (0, w.jsx)(j.Z, {
                                                    variant: "button",
                                                    children: "3. Click avatar icon on the top , then click Profile"
                                                }), (0, w.jsx)(o.m.img, {
                                                    style: {
                                                        width: "50%"
                                                    },
                                                    variants: (0, y.EU)().inRight,
                                                    src: "/assets/tutorial_account_popover.jpg"
                                                }), (0, w.jsx)("br", {}), (0, w.jsx)(j.Z, {
                                                    variant: "button",
                                                    children: "4. Pick best plan for you."
                                                }), (0, w.jsx)(o.m.img, {
                                                    style: {
                                                        width: "100%"
                                                    },
                                                    variants: (0, y.EU)().inRight,
                                                    src: "/assets/tutorial_pricing.png"
                                                })]
                                            })
                                        })
                                    })
                                })]
                            })]
                        })
                    })
                })
            }
            var H = (0, e.ZP)("div")((function(n) {
                var i = n.theme;
                return {
                    backgroundColor: i.palette.grey[350],
                    padding: i.spacing(8, 0)
                }
            }));

            function K() {
                var n = (0, c.Z)(),
                    i = (0, b.v9)((function(n) {
                        return n.monitoring
                    })).language;
                n.palette.mode;
                return (0, w.jsx)(H, {
                    id: "pricing",
                    children: (0, w.jsxs)(x.Z, {
                        component: y.DG,
                        children: ["id" === i ? (0, w.jsxs)(d.Z, {
                            sx: {
                                my: 2,
                                textAlign: "center"
                            },
                            children: [(0, w.jsx)(j.Z, {
                                variant: "h2",
                                sx: {
                                    color: "error.main"
                                },
                                children: "Perhatian!"
                            }), (0, w.jsx)(d.Z, {
                                sx: {
                                    my: 2
                                },
                                children: (0, w.jsx)(j.Z, {
                                    variant: "button",
                                    sx: {
                                        color: "common.black"
                                    },
                                    children: "Kami hanyalah data aggregator. BUKAN berarti dengan app ini anda PASTI 100% profit, Tetapi kami memberi info untuk memperbesar kemungkinan profit."
                                })
                            }), (0, w.jsx)(d.Z, {
                                sx: {
                                    my: 2
                                },
                                children: (0, w.jsx)(j.Z, {
                                    variant: "button",
                                    sx: {
                                        color: "common.black"
                                    },
                                    children: "Banyak dari kita mengetahui kejadian LUNA & GALA setelah menjadi berita, Tetapi kami bisa profit saat kejadian itu terjadi (Realtime) dengan ArbitFinder ini."
                                })
                            }), (0, w.jsx)(d.Z, {
                                sx: {
                                    my: 2
                                },
                                children: (0, w.jsx)(j.Z, {
                                    variant: "button",
                                    sx: {
                                        color: "common.black"
                                    },
                                    children: "Memungkinkan adanya perbedaan jaringan koin antar Exchanges , Data tetap ditampilkan agar anda tetap bisa memonitor adanya Pump & Dump."
                                })
                            }), (0, w.jsx)(d.Z, {
                                sx: {
                                    my: 2
                                },
                                children: (0, w.jsx)(j.Z, {
                                    variant: "button",
                                    sx: {
                                        color: "common.black"
                                    },
                                    children: "Cek likuiditas koin, Kroscek semua transaksi yang akan anda lakukan dan DYOR."
                                })
                            })]
                        }) : (0, w.jsxs)(d.Z, {
                            sx: {
                                my: 2,
                                textAlign: "center"
                            },
                            children: [(0, w.jsx)(j.Z, {
                                variant: "h2",
                                sx: {
                                    color: "error.main"
                                },
                                children: "Attention!"
                            }), (0, w.jsx)(d.Z, {
                                sx: {
                                    my: 2
                                },
                                children: (0, w.jsx)(j.Z, {
                                    variant: "button",
                                    sx: {
                                        color: "common.black"
                                    },
                                    children: "We are only a data aggregator. This does NOT mean that you GUARANTEED 100% will profit with this app, but we give info to increase the possibility to take profit."
                                })
                            }), (0, w.jsx)(d.Z, {
                                sx: {
                                    my: 2
                                },
                                children: (0, w.jsx)(j.Z, {
                                    variant: "button",
                                    sx: {
                                        color: "common.black"
                                    },
                                    children: "Many of us know about the LUNA & GALA incident after it became news, but we can profit when it happens (Realtime) with ArbitFinder."
                                })
                            }), (0, w.jsx)(d.Z, {
                                sx: {
                                    my: 2
                                },
                                children: (0, w.jsx)(j.Z, {
                                    variant: "button",
                                    sx: {
                                        color: "common.black"
                                    },
                                    children: "Some coin maybe different network between Exchanges , The data still show to monitor any Pump & Dump or price spike."
                                })
                            }), (0, w.jsx)(d.Z, {
                                sx: {
                                    my: 2
                                },
                                children: (0, w.jsx)(j.Z, {
                                    variant: "button",
                                    sx: {
                                        color: "common.black"
                                    },
                                    children: "Check the liquidity of coin, Please beware of all your transaction and DYOR."
                                })
                            })]
                        }), "id" === i ? (0, w.jsxs)(d.Z, {
                            sx: {
                                mt: 4,
                                mb: 2,
                                textAlign: "center"
                            },
                            children: [(0, w.jsx)(o.m.div, {
                                variants: (0, y.EU)().inDown,
                                children: (0, w.jsx)(j.Z, {
                                    variant: "h2",
                                    sx: {
                                        mb: 1
                                    },
                                    children: "Pilih plan terbaik untuk anda"
                                })
                            }), (0, w.jsx)(o.m.div, {
                                variants: (0, y.EU)().inDown,
                                children: (0, w.jsx)(j.Z, {
                                    children: "Dukungan anda sangat berarti bagi kami untuk mengembangkan lebih banyak fitur dan informasi untuk anda."
                                })
                            })]
                        }) : (0, w.jsxs)(d.Z, {
                            sx: {
                                mt: 4,
                                mb: 2,
                                textAlign: "center"
                            },
                            children: [(0, w.jsx)(o.m.div, {
                                variants: (0, y.EU)().inDown,
                                children: (0, w.jsx)(j.Z, {
                                    variant: "h2",
                                    sx: {
                                        mb: 1
                                    },
                                    children: "Pick the right plan for you"
                                })
                            }), (0, w.jsx)(o.m.div, {
                                variants: (0, y.EU)().inDown,
                                children: (0, w.jsx)(j.Z, {
                                    children: "Your support means a lot for us to develop more features and information for you."
                                })
                            })]
                        }), (0, w.jsx)(d.Z, {
                            sx: {
                                p: 2
                            },
                            children: (0, w.jsx)(o.m.div, {
                                variants: (0, y.EU)().inDown,
                                children: (0, w.jsx)(v.ZP, {})
                            })
                        })]
                    })
                })
            }
            var N = a(31848),
                Y = (0, e.ZP)("div")((function(n) {
                    var i = n.theme;
                    return {
                        backgroundColor: i.palette.grey[350],
                        padding: i.spacing(5, 0)
                    }
                }));

            function z() {
                var n = (0, c.Z)(),
                    i = (window.innerHeight, window.innerWidth, (0, b.v9)((function(n) {
                        return n.monitoring
                    })).language),
                    a = (n.palette.mode, (0, I.useContext)(N.z).preference);
                return (0, w.jsxs)(Y, {
                    id: "pricing",
                    children: [(0, w.jsxs)(d.Z, {
                        sx: {
                            position: "fixed",
                            left: 20,
                            bottom: !0 === a.consent ? 20 : 70
                        },
                        children: ["id" === i ? (0, w.jsx)(j.Z, {
                            variant: "button",
                            children: "Ada pertanyaan?"
                        }) : (0, w.jsx)(j.Z, {
                            variant: "button",
                            children: "Any questions?"
                        }), (0, w.jsx)("br", {}), (0, w.jsx)(p.Z, {
                            size: "small",
                            variant: "contained",
                            href: "https://t.me/ArbitFinderAdmin",
                            sx: {
                                color: "#ffffff",
                                backgroundColor: n.palette.primary.dark
                            },
                            children: "id" === i ? "Hubungi kami" : "Contact us"
                        })]
                    }), (0, w.jsx)(x.Z, {
                        component: y.DG,
                        children: (0, w.jsxs)(h.ZP, {
                            container: !0,
                            children: [(0, w.jsxs)(h.ZP, {
                                item: !0,
                                xs: 12,
                                sm: 4,
                                sx: {
                                    mb: 3
                                },
                                children: [(0, w.jsx)(o.m.div, {
                                    variants: (0, y.EU)().inDown,
                                    children: "id" === i ? (0, w.jsx)(j.Z, {
                                        variant: "h6",
                                        children: "Selalu Terhubung Dengan Kami Melalui"
                                    }) : (0, w.jsx)(j.Z, {
                                        variant: "h5",
                                        children: "Always Connect With Us With"
                                    })
                                }), (0, w.jsx)(o.m.div, {
                                    variants: (0, y.EU)().inUp,
                                    children: (0, w.jsxs)(l.Z, {
                                        spacing: 3,
                                        direction: "row",
                                        children: [(0, w.jsx)(g.Z, {
                                            href: "https://www.youtube.com/@ArbitFinderOfficial",
                                            target: "_blank",
                                            children: (0, w.jsx)(C.Z, {
                                                children: (0, w.jsx)(k.Z, {
                                                    icon: "ant-design:youtube-filled",
                                                    width: 50,
                                                    height: 50,
                                                    sx: {
                                                        color: "red"
                                                    }
                                                })
                                            })
                                        }), (0, w.jsx)(g.Z, {
                                            href: "https://t.me/ArbitFinderAdmin",
                                            children: (0, w.jsx)(C.Z, {
                                                children: (0, w.jsx)(k.Z, {
                                                    icon: "logos:telegram",
                                                    width: 50,
                                                    height: 50
                                                })
                                            })
                                        }), (0, w.jsx)(g.Z, {
                                            href: "https://www.instagram.com/arbitfinder.official/",
                                            target: "_blank",
                                            children: (0, w.jsx)(C.Z, {
                                                children: (0, w.jsx)(k.Z, {
                                                    icon: "skill-icons:instagram",
                                                    width: 50,
                                                    height: 50
                                                })
                                            })
                                        })]
                                    })
                                })]
                            }), (0, w.jsxs)(h.ZP, {
                                item: !0,
                                xs: 12,
                                sm: 4,
                                sx: {
                                    mb: 3
                                },
                                children: [(0, w.jsx)(o.m.div, {
                                    variants: (0, y.EU)().inDown,
                                    children: "id" === i ? (0, w.jsx)(j.Z, {
                                        variant: "h4",
                                        children: "Tim Kami"
                                    }) : (0, w.jsx)(j.Z, {
                                        variant: "h4",
                                        children: "Our Team"
                                    })
                                }), (0, w.jsx)(o.m.div, {
                                    variants: (0, y.EU)().inUp,
                                    children: (0, w.jsx)(l.Z, {
                                        spacing: 3,
                                        direction: "row",
                                        children: (0, w.jsx)(g.Z, {
                                            href: "https://www.linkedin.com/in/erwin-sanjaya-7a2733169/",
                                            target: "_blank",
                                            children: (0, w.jsx)(C.Z, {
                                                children: (0, w.jsx)(k.Z, {
                                                    icon: "devicon:linkedin",
                                                    width: 50,
                                                    height: 50
                                                })
                                            })
                                        })
                                    })
                                })]
                            }), (0, w.jsx)(h.ZP, {
                                item: !0,
                                xs: 12,
                                sm: 4,
                                sx: {
                                    mt: 0,
                                    mb: 8
                                },
                                children: (0, w.jsx)(o.m.div, {
                                    variants: (0, y.EU)().inUp,
                                    children: (0, w.jsxs)(j.Z, {
                                        variant: "button",
                                        children: ["See our ", (0, w.jsx)(g.Z, {
                                            href: "/Privacy_Policy",
                                            children: "Privacy Policy"
                                        }), ". ", " ", " "]
                                    })
                                })
                            })]
                        })
                    }), (0, w.jsx)(d.Z, {
                        sx: {
                            textAlign: "center"
                        },
                        children: (0, w.jsx)(j.Z, {
                            variant: "caption",
                            children: "Arbit Finder \xa92023 By: Erwin San"
                        })
                    })]
                })
            }
            var O = (0, e.ZP)("div")((function(n) {
                return {
                    overflow: "hidden",
                    position: "relative",
                    backgroundColor: n.theme.palette.background.default
                }
            }));

            function G() {
                return (0, w.jsxs)(r.Z, {
                    children: [(0, w.jsx)(F, {}), (0, w.jsxs)(O, {
                        children: [(0, w.jsx)(T, {}), (0, w.jsx)(M, {}), (0, w.jsx)(K, {}), (0, w.jsx)(z, {})]
                    })]
                })
            }
        }
    }
]);