/*! For license information please see 9860.7360c7e2.chunk.js.LICENSE.txt */
(self.webpackChunkarbitrage_notification = self.webpackChunkarbitrage_notification || []).push([
    [9860], {
        14173: function(e, t, n) {
            "use strict";
            var i = n(90997),
                r = n(25307),
                o = "value",
                s = "\n  ",
                a = {};

            function u(e) {
                var t = Array.isArray(e);
                return function(n) {
                    var i, r = c(a.plainArray, n);
                    if (r) return r;
                    if (t && n.length !== e.length) return "an array with " + e.length + " items";
                    for (var o = 0; o < n.length; o++)
                        if (r = c((i = o, t ? e[i] : e), n[o])) return [o].concat(r)
                }
            }

            function c(e, t) {
                if (null != t || e.hasOwnProperty("__required")) {
                    var n = e(t);
                    return n ? Array.isArray(n) ? n : [n] : void 0
                }
            }

            function l(e, t) {
                var n = e.length,
                    i = e[n - 1],
                    s = e.slice(0, n - 1);
                return 0 === s.length && (s = [o]), t = r(t, {
                    path: s
                }), "function" === typeof i ? i(t) : h(t, function(e) {
                    return "must be " + function(e) {
                        if (/^an? /.test(e)) return e;
                        if (/^[aeiou]/i.test(e)) return "an " + e;
                        if (/^[a-z]/i.test(e)) return "a " + e;
                        return e
                    }(e) + "."
                }(i))
            }

            function h(e, t) {
                return (d(e.path) ? "Item at position " : "") + (e.path.join(".") + " " + t)
            }

            function d(e) {
                return "number" == typeof e[e.length - 1] || "number" == typeof e[0]
            }
            a.assert = function(e, t) {
                return t = t || {},
                    function(n) {
                        var i = c(e, n);
                        if (i) {
                            var r = l(i, t);
                            throw t.apiName && (r = t.apiName + ": " + r), new Error(r)
                        }
                    }
            }, a.shape = function(e) {
                var t, n = (t = e, Object.keys(t || {}).map((function(e) {
                    return {
                        key: e,
                        value: t[e]
                    }
                })));
                return function(e) {
                    var t, i = c(a.plainObject, e);
                    if (i) return i;
                    for (var r = [], u = 0; u < n.length; u++) t = n[u].key, (i = c(n[u].value, e[t])) && r.push([t].concat(i));
                    return r.length < 2 ? r[0] : function(e) {
                        r = r.map((function(t) {
                            return "- " + t[0] + ": " + l(t, e).split("\n").join(s)
                        }));
                        var t = e.path.join(".");
                        return "The following properties" + (t === o ? "" : " of " + t) + " have invalid values:" + s + r.join(s)
                    }
                }
            }, a.strictShape = function(e) {
                var t = a.shape(e);
                return function(n) {
                    var i = t(n);
                    if (i) return i;
                    var r = Object.keys(n).reduce((function(t, n) {
                        return void 0 === e[n] && t.push(n), t
                    }), []);
                    return 0 !== r.length ? function() {
                        return "The following keys are invalid: " + r.join(", ")
                    } : void 0
                }
            }, a.arrayOf = function(e) {
                return u(e)
            }, a.tuple = function() {
                return u(Array.isArray(arguments[0]) ? arguments[0] : Array.prototype.slice.call(arguments))
            }, a.required = function(e) {
                function t(t) {
                    return null == t ? function(e) {
                        return h(e, d(e.path) ? "cannot be undefined/null." : "is required.")
                    } : e.apply(this, arguments)
                }
                return t.__required = !0, t
            }, a.oneOfType = function() {
                var e = Array.isArray(arguments[0]) ? arguments[0] : Array.prototype.slice.call(arguments);
                return function(t) {
                    var n = e.map((function(e) {
                        return c(e, t)
                    })).filter(Boolean);
                    if (n.length === e.length) return n.every((function(e) {
                        return 1 === e.length && "string" === typeof e[0]
                    })) ? function(e) {
                        if (e.length < 2) return e[0];
                        if (2 === e.length) return e.join(" or ");
                        return e.slice(0, -1).join(", ") + ", or " + e.slice(-1)
                    }(n.map((function(e) {
                        return e[0]
                    }))) : n.reduce((function(e, t) {
                        return t.length > e.length ? t : e
                    }))
                }
            }, a.equal = function(e) {
                return function(t) {
                    if (t !== e) return JSON.stringify(e)
                }
            }, a.oneOf = function() {
                var e = (Array.isArray(arguments[0]) ? arguments[0] : Array.prototype.slice.call(arguments)).map((function(e) {
                    return a.equal(e)
                }));
                return a.oneOfType.apply(this, e)
            }, a.range = function(e) {
                var t = e[0],
                    n = e[1];
                return function(e) {
                    if (c(a.number, e) || e < t || e > n) return "number between " + t + " & " + n + " (inclusive)"
                }
            }, a.any = function() {}, a.boolean = function(e) {
                if ("boolean" !== typeof e) return "boolean"
            }, a.number = function(e) {
                if ("number" !== typeof e) return "number"
            }, a.plainArray = function(e) {
                if (!Array.isArray(e)) return "array"
            }, a.plainObject = function(e) {
                if (!i(e)) return "object"
            }, a.string = function(e) {
                if ("string" !== typeof e) return "string"
            }, a.func = function(e) {
                if ("function" !== typeof e) return "function"
            }, a.validate = c, a.processMessage = l, e.exports = a
        },
        90997: function(e) {
            "use strict";
            var t = Object.prototype.toString;
            e.exports = function(e) {
                var n;
                return "[object Object]" === t.call(e) && (null === (n = Object.getPrototypeOf(e)) || n === Object.getPrototypeOf({}))
            }
        },
        71894: function(e, t, n) {
            "use strict";
            var i = n(82751).x0;

            function r(e) {
                this.origin = e.origin || "https://api.mapbox.com", this.endpoint = "events/v2", this.access_token = e.accessToken, this.version = "0.2.0", this.sessionID = this.generateSessionID(), this.userAgent = this.getUserAgent(), this.options = e, this.send = this.send.bind(this), this.countries = e.countries ? e.countries.split(",") : null, this.types = e.types ? e.types.split(",") : null, this.bbox = e.bbox ? e.bbox : null, this.language = e.language ? e.language.split(",") : null, this.limit = e.limit ? +e.limit : null, this.locale = navigator.language || null, this.enableEventLogging = this.shouldEnableLogging(e), this.eventQueue = new Array, this.flushInterval = e.flushInterval || 1e3, this.maxQueueSize = e.maxQueueSize || 100, this.timer = this.flushInterval ? setTimeout(this.flush.bind(this), this.flushInterval) : null, this.lastSentInput = "", this.lastSentIndex = 0
            }
            r.prototype = {
                select: function(e, t) {
                    var n = this.getSelectedIndex(e, t),
                        i = this.getEventPayload("search.select", t);
                    if (i.resultIndex = n, i.resultPlaceName = e.place_name, i.resultId = e.id, (n !== this.lastSentIndex || i.queryString !== this.lastSentInput) && -1 != n && (this.lastSentIndex = n, this.lastSentInput = i.queryString, i.queryString)) return this.push(i)
                },
                start: function(e) {
                    var t = this.getEventPayload("search.start", e);
                    if (t.queryString) return this.push(t)
                },
                keyevent: function(e, t) {
                    if (e.key && !e.metaKey && -1 === [9, 27, 37, 39, 13, 38, 40].indexOf(e.keyCode)) {
                        var n = this.getEventPayload("search.keystroke", t);
                        if (n.lastAction = e.key, n.queryString) return this.push(n)
                    }
                },
                send: function(e, t) {
                    if (!this.enableEventLogging) return t ? t() : void 0;
                    var n = this.getRequestOptions(e);
                    this.request(n, function(e) {
                        return e ? this.handleError(e, t) : t ? t() : void 0
                    }.bind(this))
                },
                getRequestOptions: function(e) {
                    return Array.isArray(e) || (e = [e]), {
                        method: "POST",
                        host: this.origin,
                        path: this.endpoint + "?access_token=" + this.access_token,
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(e)
                    }
                },
                getEventPayload: function(e, t) {
                    var n;
                    n = t.options.proximity ? "object" === typeof t.options.proximity ? [t.options.proximity.longitude, t.options.proximity.latitude] : "ip" === t.options.proximity ? [999, 999] : t.options.proximity : null;
                    var i = t._map ? t._map.getZoom() : void 0,
                        r = {
                            event: e,
                            created: +new Date,
                            sessionIdentifier: this.sessionID,
                            country: this.countries,
                            userAgent: this.userAgent,
                            language: this.language,
                            bbox: this.bbox,
                            types: this.types,
                            endpoint: "mapbox.places",
                            autocomplete: t.options.autocomplete,
                            fuzzyMatch: t.options.fuzzyMatch,
                            proximity: n,
                            limit: t.options.limit,
                            routing: t.options.routing,
                            worldview: t.options.worldview,
                            mapZoom: i,
                            keyboardLocale: this.locale
                        };
                    return "search.select" === e ? r.queryString = t.inputString : "search.select" != e && t._inputEl ? r.queryString = t._inputEl.value : r.queryString = t.inputString, r
                },
                request: function(e, t) {
                    var n = new XMLHttpRequest;
                    for (var i in n.onreadystatechange = function() {
                            if (4 == this.readyState) return 204 == this.status ? t(null) : t(this.statusText)
                        }, n.open(e.method, e.host + "/" + e.path, !0), e.headers) {
                        var r = e.headers[i];
                        n.setRequestHeader(i, r)
                    }
                    n.send(e.body)
                },
                handleError: function(e, t) {
                    if (t) return t(e)
                },
                generateSessionID: function() {
                    return i()
                },
                getUserAgent: function() {
                    return "mapbox-gl-geocoder." + this.version + "." + navigator.userAgent
                },
                getSelectedIndex: function(e, t) {
                    if (t._typeahead) {
                        var n = t._typeahead.data,
                            i = e.id;
                        return n.map((function(e) {
                            return e.id
                        })).indexOf(i)
                    }
                },
                shouldEnableLogging: function(e) {
                    return !1 !== e.enableEventLogging && ((!e.origin || "https://api.mapbox.com" === e.origin) && (!e.localGeocoder && !e.filter))
                },
                flush: function() {
                    this.eventQueue.length > 0 && (this.send(this.eventQueue), this.eventQueue = new Array), this.timer && clearTimeout(this.timer), this.flushInterval && (this.timer = setTimeout(this.flush.bind(this), this.flushInterval))
                },
                push: function(e, t) {
                    this.eventQueue.push(e), (this.eventQueue.length >= this.maxQueueSize || t) && this.flush()
                },
                remove: function() {
                    this.flush()
                }
            }, e.exports = r
        },
        13901: function(e) {
            e.exports = {
                fr: {
                    name: "France",
                    bbox: [
                        [-4.59235, 41.380007],
                        [9.560016, 51.148506]
                    ]
                },
                us: {
                    name: "United States",
                    bbox: [
                        [-171.791111, 18.91619],
                        [-66.96466, 71.357764]
                    ]
                },
                ru: {
                    name: "Russia",
                    bbox: [
                        [19.66064, 41.151416],
                        [190.10042, 81.2504]
                    ]
                },
                ca: {
                    name: "Canada",
                    bbox: [
                        [-140.99778, 41.675105],
                        [-52.648099, 83.23324]
                    ]
                }
            }
        },
        15636: function(e) {
            function t() {}
            t.prototype = {
                isSupport: function() {
                    return Boolean(window.navigator.geolocation)
                },
                getCurrentPosition: function() {
                    var e = {
                        enableHighAccuracy: !0
                    };
                    return new Promise((function(t, n) {
                        window.navigator.geolocation.getCurrentPosition(t, n, e)
                    }))
                }
            }, e.exports = t
        },
        63457: function(e, t, n) {
            "use strict";
            var i = n(93215),
                r = n(80936),
                o = n(25307),
                s = n(68041).EventEmitter,
                a = n(13901),
                u = n(30599),
                c = n(58348),
                l = n(71894),
                h = n(13291),
                d = n(93284),
                p = n(15636),
                f = n(98942),
                v = 0,
                g = 1,
                m = 2;

            function y(e) {
                this._eventEmitter = new s, this.options = o({}, this.options, e), this.inputString = "", this.fresh = !0, this.lastSelected = null, this.geolocation = new p
            }
            y.prototype = {
                options: {
                    zoom: 16,
                    flyTo: !0,
                    trackProximity: !0,
                    minLength: 2,
                    reverseGeocode: !1,
                    flipCoordinates: !1,
                    limit: 5,
                    origin: "https://api.mapbox.com",
                    enableEventLogging: !0,
                    marker: !0,
                    mapboxgl: null,
                    collapsed: !1,
                    clearAndBlurOnEsc: !1,
                    clearOnBlur: !1,
                    enableGeolocation: !1,
                    addressAccuracy: "street",
                    getItemValue: function(e) {
                        return e.place_name
                    },
                    render: function(e) {
                        var t = e.place_name.split(",");
                        return '<div class="mapboxgl-ctrl-geocoder--suggestion"><div class="mapboxgl-ctrl-geocoder--suggestion-title">' + t[0] + '</div><div class="mapboxgl-ctrl-geocoder--suggestion-address">' + t.splice(1, t.length).join(",") + "</div></div>"
                    }
                },
                addTo: function(e) {
                    function t(e, t) {
                        if (!document.body.contains(t)) throw new Error("Element provided to #addTo() exists, but is not in the DOM");
                        var n = e.onAdd();
                        t.appendChild(n)
                    }
                    if (e._controlContainer) e.addControl(this);
                    else if (e instanceof HTMLElement) t(this, e);
                    else {
                        if ("string" != typeof e) throw new Error("Error: addTo must be a mapbox-gl-js map, an html element, or a CSS selector query for a single html element");
                        var n = document.querySelectorAll(e);
                        if (0 === n.length) throw new Error("Element ", e, "not found.");
                        if (n.length > 1) throw new Error("Geocoder can only be added to a single html element");
                        t(this, n[0])
                    }
                },
                onAdd: function(e) {
                    if (e && "string" != typeof e && (this._map = e), this.setLanguage(), this.options.localGeocoderOnly || (this.geocoderService = c(u({
                            accessToken: this.options.accessToken,
                            origin: this.options.origin
                        }))), this.options.localGeocoderOnly && !this.options.localGeocoder) throw new Error("A localGeocoder function must be specified to use localGeocoderOnly mode");
                    this.eventManager = new l(this.options), this._onChange = this._onChange.bind(this), this._onKeyDown = this._onKeyDown.bind(this), this._onPaste = this._onPaste.bind(this), this._onBlur = this._onBlur.bind(this), this._showButton = this._showButton.bind(this), this._hideButton = this._hideButton.bind(this), this._onQueryResult = this._onQueryResult.bind(this), this.clear = this.clear.bind(this), this._updateProximity = this._updateProximity.bind(this), this._collapse = this._collapse.bind(this), this._unCollapse = this._unCollapse.bind(this), this._clear = this._clear.bind(this), this._clearOnBlur = this._clearOnBlur.bind(this), this._geolocateUser = this._geolocateUser.bind(this);
                    var t = this.container = document.createElement("div");
                    t.className = "mapboxgl-ctrl-geocoder mapboxgl-ctrl";
                    var n = this.createIcon("search", '<path d="M7.4 2.5c-2.7 0-4.9 2.2-4.9 4.9s2.2 4.9 4.9 4.9c1 0 1.8-.2 2.5-.8l3.7 3.7c.2.2.4.3.8.3.7 0 1.1-.4 1.1-1.1 0-.3-.1-.5-.3-.8L11.4 10c.4-.8.8-1.6.8-2.5.1-2.8-2.1-5-4.8-5zm0 1.6c1.8 0 3.2 1.4 3.2 3.2s-1.4 3.2-3.2 3.2-3.3-1.3-3.3-3.1 1.4-3.3 3.3-3.3z"/>');
                    this._inputEl = document.createElement("input"), this._inputEl.type = "text", this._inputEl.className = "mapboxgl-ctrl-geocoder--input", this.setPlaceholder(), this.options.collapsed && (this._collapse(), this.container.addEventListener("mouseenter", this._unCollapse), this.container.addEventListener("mouseleave", this._collapse), this._inputEl.addEventListener("focus", this._unCollapse)), (this.options.collapsed || this.options.clearOnBlur) && this._inputEl.addEventListener("blur", this._onBlur), this._inputEl.addEventListener("keydown", r(this._onKeyDown, 200)), this._inputEl.addEventListener("paste", this._onPaste), this._inputEl.addEventListener("change", this._onChange), this.container.addEventListener("mouseenter", this._showButton), this.container.addEventListener("mouseleave", this._hideButton), this._inputEl.addEventListener("keyup", function(e) {
                        this.eventManager.keyevent(e, this)
                    }.bind(this));
                    var o = document.createElement("div");
                    o.classList.add("mapboxgl-ctrl-geocoder--pin-right"), this._clearEl = document.createElement("button"), this._clearEl.setAttribute("aria-label", "Clear"), this._clearEl.addEventListener("click", this.clear), this._clearEl.className = "mapboxgl-ctrl-geocoder--button";
                    var s = this.createIcon("close", '<path d="M3.8 2.5c-.6 0-1.3.7-1.3 1.3 0 .3.2.7.5.8L7.2 9 3 13.2c-.3.3-.5.7-.5 1 0 .6.7 1.3 1.3 1.3.3 0 .7-.2 1-.5L9 10.8l4.2 4.2c.2.3.7.3 1 .3.6 0 1.3-.7 1.3-1.3 0-.3-.2-.7-.3-1l-4.4-4L15 4.6c.3-.2.5-.5.5-.8 0-.7-.7-1.3-1.3-1.3-.3 0-.7.2-1 .3L9 7.1 4.8 2.8c-.3-.1-.7-.3-1-.3z"/>');
                    if (this._clearEl.appendChild(s), this._loadingEl = this.createIcon("loading", '<path fill="#333" d="M4.4 4.4l.8.8c2.1-2.1 5.5-2.1 7.6 0l.8-.8c-2.5-2.5-6.7-2.5-9.2 0z"/><path opacity=".1" d="M12.8 12.9c-2.1 2.1-5.5 2.1-7.6 0-2.1-2.1-2.1-5.5 0-7.7l-.8-.8c-2.5 2.5-2.5 6.7 0 9.2s6.6 2.5 9.2 0 2.5-6.6 0-9.2l-.8.8c2.2 2.1 2.2 5.6 0 7.7z"/>'), o.appendChild(this._clearEl), o.appendChild(this._loadingEl), t.appendChild(n), t.appendChild(this._inputEl), t.appendChild(o), this.options.enableGeolocation && this.geolocation.isSupport()) {
                        this._geolocateEl = document.createElement("button"), this._geolocateEl.setAttribute("aria-label", "Geolocate"), this._geolocateEl.addEventListener("click", this._geolocateUser), this._geolocateEl.className = "mapboxgl-ctrl-geocoder--button";
                        var a = this.createIcon("geolocate", '<path d="M12.999 3.677L2.042 8.269c-.962.403-.747 1.823.29 1.912l5.032.431.431 5.033c.089 1.037 1.509 1.252 1.912.29l4.592-10.957c.345-.822-.477-1.644-1.299-1.299z" fill="#4264fb"/>');
                        this._geolocateEl.appendChild(a), o.appendChild(this._geolocateEl), this._showGeolocateButton()
                    }
                    var h = this._typeahead = new i(this._inputEl, [], {
                        filter: !1,
                        minLength: this.options.minLength,
                        limit: this.options.limit
                    });
                    this.setRenderFunction(this.options.render), h.getItemValue = this.options.getItemValue;
                    var d = h.list.draw,
                        p = this._footerNode = function() {
                            var e = document.createElement("div");
                            return e.className = "mapboxgl-ctrl-geocoder--powered-by", e.innerHTML = '<a href="https://www.mapbox.com/search-service" target="_blank">Powered by Mapbox</a>', e
                        }();
                    return h.list.draw = function() {
                        d.call(this), p.addEventListener("mousedown", function() {
                            this.selectingListItem = !0
                        }.bind(this)), p.addEventListener("mouseup", function() {
                            this.selectingListItem = !1
                        }.bind(this)), this.element.appendChild(p)
                    }, this.mapMarker = null, this._handleMarker = this._handleMarker.bind(this), this._map && (this.options.trackProximity && (this._updateProximity(), this._map.on("moveend", this._updateProximity)), this._mapboxgl = this.options.mapboxgl, !this._mapboxgl && this.options.marker && (console.error("No mapboxgl detected in options. Map markers are disabled. Please set options.mapboxgl."), this.options.marker = !1)), t
                },
                _geolocateUser: function() {
                    this._hideGeolocateButton(), this._showLoadingIcon(), this.geolocation.getCurrentPosition().then(function(e) {
                        this._hideLoadingIcon();
                        var t = {
                            geometry: {
                                type: "Point",
                                coordinates: [e.coords.longitude, e.coords.latitude]
                            }
                        };
                        this._handleMarker(t), this._fly(t), this._typeahead.clear(), this._typeahead.selected = !0, this.lastSelected = JSON.stringify(t), this._showClearButton(), this.fresh = !1;
                        var n = {
                            limit: 1,
                            language: [this.options.language],
                            query: t.geometry.coordinates,
                            types: ["address"]
                        };
                        if (this.options.localGeocoderOnly) {
                            var i = t.geometry.coordinates[0] + "," + t.geometry.coordinates[1];
                            this._setInputValue(i), this._eventEmitter.emit("result", {
                                result: t
                            })
                        } else this.geocoderService.reverseGeocode(n).send().then(function(e) {
                            var n = e.body.features[0];
                            if (n) {
                                var i = f.transformFeatureToGeolocationText(n, this.options.addressAccuracy);
                                this._setInputValue(i), n.user_coordinates = t.geometry.coordinates, this._eventEmitter.emit("result", {
                                    result: n
                                })
                            } else this._eventEmitter.emit("result", {
                                result: {
                                    user_coordinates: t.geometry.coordinates
                                }
                            })
                        }.bind(this))
                    }.bind(this)).catch(function(e) {
                        1 === e.code ? this._renderUserDeniedGeolocationError() : this._renderLocationError(), this._hideLoadingIcon(), this._showGeolocateButton(), this._hideAttribution()
                    }.bind(this))
                },
                createIcon: function(e, t) {
                    var n = document.createElementNS("http://www.w3.org/2000/svg", "svg");
                    return n.setAttribute("class", "mapboxgl-ctrl-geocoder--icon mapboxgl-ctrl-geocoder--icon-" + e), n.setAttribute("viewBox", "0 0 18 18"), n.setAttribute("xml:space", "preserve"), n.setAttribute("width", 18), n.setAttribute("height", 18), n.innerHTML = t, n
                },
                onRemove: function() {
                    return this.container.parentNode.removeChild(this.container), this.options.trackProximity && this._map && this._map.off("moveend", this._updateProximity), this._removeMarker(), this._map = null, this
                },
                _setInputValue: function(e) {
                    this._inputEl.value = e, setTimeout(function() {
                        this._inputEl.focus(), this._inputEl.scrollLeft = 0, this._inputEl.setSelectionRange(0, 0)
                    }.bind(this), 1)
                },
                _onPaste: function(e) {
                    var t = (e.clipboardData || window.clipboardData).getData("text");
                    t.length >= this.options.minLength && this._geocode(t)
                },
                _onKeyDown: function(e) {
                    var t = 27,
                        n = 9;
                    if (e.keyCode === t && this.options.clearAndBlurOnEsc) return this._clear(e), this._inputEl.blur();
                    var i = e.target && e.target.shadowRoot ? e.target.shadowRoot.activeElement : e.target;
                    if (!(i ? i.value : "")) return this.fresh = !0, e.keyCode !== n && this.clear(e), this._showGeolocateButton(), this._hideClearButton();
                    this._hideGeolocateButton(), e.metaKey || -1 !== [n, t, 37, 39, 13, 38, 40].indexOf(e.keyCode) || i.value.length >= this.options.minLength && this._geocode(i.value)
                },
                _showButton: function() {
                    this._typeahead.selected && this._showClearButton()
                },
                _hideButton: function() {
                    this._typeahead.selected && this._hideClearButton()
                },
                _showClearButton: function() {
                    this._clearEl.style.display = "block"
                },
                _hideClearButton: function() {
                    this._clearEl.style.display = "none"
                },
                _showGeolocateButton: function() {
                    this._geolocateEl && this.geolocation.isSupport() && (this._geolocateEl.style.display = "block")
                },
                _hideGeolocateButton: function() {
                    this._geolocateEl && (this._geolocateEl.style.display = "none")
                },
                _showLoadingIcon: function() {
                    this._loadingEl.style.display = "block"
                },
                _hideLoadingIcon: function() {
                    this._loadingEl.style.display = "none"
                },
                _showAttribution: function() {
                    this._footerNode.style.display = "block"
                },
                _hideAttribution: function() {
                    this._footerNode.style.display = "none"
                },
                _onBlur: function(e) {
                    this.options.clearOnBlur && this._clearOnBlur(e), this.options.collapsed && this._collapse()
                },
                _onChange: function() {
                    var e = this._typeahead.selected;
                    e && JSON.stringify(e) !== this.lastSelected && (this._hideClearButton(), this.options.flyTo && this._fly(e), this.options.marker && this._mapboxgl && this._handleMarker(e), this._inputEl.focus(), this._inputEl.scrollLeft = 0, this._inputEl.setSelectionRange(0, 0), this.lastSelected = JSON.stringify(e), this._eventEmitter.emit("result", {
                        result: e
                    }), this.eventManager.select(e, this))
                },
                _fly: function(e) {
                    var t;
                    if (e.properties && a[e.properties.short_code]) t = o({}, this.options.flyTo), this._map && this._map.fitBounds(a[e.properties.short_code].bbox, t);
                    else if (e.bbox) {
                        var n = e.bbox;
                        t = o({}, this.options.flyTo), this._map && this._map.fitBounds([
                            [n[0], n[1]],
                            [n[2], n[3]]
                        ], t)
                    } else {
                        var i = {
                            zoom: this.options.zoom
                        };
                        t = o({}, i, this.options.flyTo), e.center ? t.center = e.center : e.geometry && e.geometry.type && "Point" === e.geometry.type && e.geometry.coordinates && (t.center = e.geometry.coordinates), this._map && this._map.flyTo(t)
                    }
                },
                _requestType: function(e, t) {
                    return e.localGeocoderOnly ? g : e.reverseGeocode && f.REVERSE_GEOCODE_COORD_RGX.test(t) ? m : v
                },
                _setupConfig: function(e, t) {
                    var n = /[\s,]+/,
                        i = this,
                        r = ["bbox", "limit", "proximity", "countries", "types", "language", "reverseMode", "mode", "autocomplete", "fuzzyMatch", "routing", "worldview"].reduce((function(e, t) {
                            if (void 0 === i.options[t] || null === i.options[t]) return e;
                            ["countries", "types", "language"].indexOf(t) > -1 ? e[t] = i.options[t].split(n) : e[t] = i.options[t];
                            var r = "number" === typeof i.options[t].longitude && "number" === typeof i.options[t].latitude;
                            if ("proximity" === t && r) {
                                var o = i.options[t].longitude,
                                    s = i.options[t].latitude;
                                e[t] = [o, s]
                            }
                            return e
                        }), {});
                    switch (e) {
                        case m:
                            var s = t.split(n).map((function(e) {
                                return parseFloat(e, 10)
                            }));
                            i.options.flipCoordinates || s.reverse(), !r.types || r.types[0], r = o(r, {
                                query: s,
                                limit: 1
                            }), ["proximity", "autocomplete", "fuzzyMatch", "bbox"].forEach((function(e) {
                                e in r && delete r[e]
                            }));
                            break;
                        case v:
                            var a = t.trim();
                            /^(-?\d{1,3}(\.\d{0,256})?)[, ]+(-?\d{1,3}(\.\d{0,256})?)?$/.test(a) && (t = t.replace(/,/g, " ")), r = o(r, {
                                query: t
                            })
                    }
                    return r
                },
                _geocode: function(e) {
                    this.inputString = e, this._showLoadingIcon(), this._eventEmitter.emit("loading", {
                        query: e
                    });
                    var t, n = this._requestType(this.options, e),
                        i = this._setupConfig(n, e);
                    switch (n) {
                        case g:
                            t = Promise.resolve();
                            break;
                        case v:
                            t = this.geocoderService.forwardGeocode(i).send();
                            break;
                        case m:
                            t = this.geocoderService.reverseGeocode(i).send()
                    }
                    var r = this.options.localGeocoder && this.options.localGeocoder(e) || [],
                        o = [],
                        s = null;
                    return t.catch(function(e) {
                        s = e
                    }.bind(this)).then(function(t) {
                        this._hideLoadingIcon();
                        var n = {};
                        return t ? "200" == t.statusCode && ((n = t.body).request = t.request, n.headers = t.headers) : n = {
                            type: "FeatureCollection",
                            features: []
                        }, n.config = i, this.fresh && (this.eventManager.start(this), this.fresh = !1), n.features = n.features ? r.concat(n.features) : r, this.options.externalGeocoder ? (o = this.options.externalGeocoder(e, n.features) || Promise.resolve([])).then((function(e) {
                            return n.features = n.features ? e.concat(n.features) : e, n
                        }), (function() {
                            return n
                        })) : n
                    }.bind(this)).then(function(e) {
                        if (s) throw s;
                        this.options.filter && e.features.length && (e.features = e.features.filter(this.options.filter)), e.features.length ? (this._showClearButton(), this._hideGeolocateButton(), this._showAttribution(), this._eventEmitter.emit("results", e), this._typeahead.update(e.features)) : (this._hideClearButton(), this._hideAttribution(), this._typeahead.selected = null, this._renderNoResults(), this._eventEmitter.emit("results", e))
                    }.bind(this)).catch(function(e) {
                        this._hideLoadingIcon(), this._hideAttribution(), r.length && this.options.localGeocoder || o.length && this.options.externalGeocoder ? (this._showClearButton(), this._hideGeolocateButton(), this._typeahead.update(r)) : (this._hideClearButton(), this._typeahead.selected = null, this._renderError()), this._eventEmitter.emit("results", {
                            features: r
                        }), this._eventEmitter.emit("error", {
                            error: e
                        })
                    }.bind(this)), t
                },
                _clear: function(e) {
                    e && e.preventDefault(), this._inputEl.value = "", this._typeahead.selected = null, this._typeahead.clear(), this._onChange(), this._hideClearButton(), this._showGeolocateButton(), this._removeMarker(), this.lastSelected = null, this._eventEmitter.emit("clear"), this.fresh = !0
                },
                clear: function(e) {
                    this._clear(e), this._inputEl.focus()
                },
                _clearOnBlur: function(e) {
                    e.relatedTarget && this._clear(e)
                },
                _onQueryResult: function(e) {
                    var t = e.body;
                    if (t.features.length) {
                        var n = t.features[0];
                        this._typeahead.selected = n, this._inputEl.value = n.place_name, this._onChange()
                    }
                },
                _updateProximity: function() {
                    if (this._map && this.options.trackProximity)
                        if (this._map.getZoom() > 9) {
                            var e = this._map.getCenter().wrap();
                            this.setProximity({
                                longitude: e.lng,
                                latitude: e.lat
                            }, !1)
                        } else this.setProximity(null, !1)
                },
                _collapse: function() {
                    this._inputEl.value || this._inputEl === document.activeElement || this.container.classList.add("mapboxgl-ctrl-geocoder--collapsed")
                },
                _unCollapse: function() {
                    this.container.classList.remove("mapboxgl-ctrl-geocoder--collapsed")
                },
                query: function(e) {
                    return this._geocode(e).then(this._onQueryResult), this
                },
                _renderError: function() {
                    this._renderMessage("<div class='mapbox-gl-geocoder--error'>There was an error reaching the server</div>")
                },
                _renderLocationError: function() {
                    this._renderMessage("<div class='mapbox-gl-geocoder--error'>A location error has occurred</div>")
                },
                _renderNoResults: function() {
                    this._renderMessage("<div class='mapbox-gl-geocoder--error mapbox-gl-geocoder--no-results'>No results found</div>")
                },
                _renderUserDeniedGeolocationError: function() {
                    this._renderMessage("<div class='mapbox-gl-geocoder--error'>Geolocation permission denied</div>")
                },
                _renderMessage: function(e) {
                    this._typeahead.update([]), this._typeahead.selected = null, this._typeahead.clear(), this._typeahead.renderError(e)
                },
                _getPlaceholderText: function() {
                    if (this.options.placeholder) return this.options.placeholder;
                    if (this.options.language) {
                        var e = this.options.language.split(",")[0],
                            t = d.language(e),
                            n = h.placeholder[t];
                        if (n) return n
                    }
                    return "Search"
                },
                setInput: function(e) {
                    return this._inputEl.value = e, this._typeahead.selected = null, this._typeahead.clear(), e.length >= this.options.minLength && this._geocode(e), this
                },
                setProximity: function(e) {
                    var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                    return this.options.proximity = e, t && (this.options.trackProximity = !1), this
                },
                getProximity: function() {
                    return this.options.proximity
                },
                setRenderFunction: function(e) {
                    return e && "function" == typeof e && (this._typeahead.render = e), this
                },
                getRenderFunction: function() {
                    return this._typeahead.render
                },
                setLanguage: function(e) {
                    var t = navigator.language || navigator.userLanguage || navigator.browserLanguage;
                    return this.options.language = e || this.options.language || t, this
                },
                getLanguage: function() {
                    return this.options.language
                },
                getZoom: function() {
                    return this.options.zoom
                },
                setZoom: function(e) {
                    return this.options.zoom = e, this
                },
                getFlyTo: function() {
                    return this.options.flyTo
                },
                setFlyTo: function(e) {
                    return this.options.flyTo = e, this
                },
                getPlaceholder: function() {
                    return this.options.placeholder
                },
                setPlaceholder: function(e) {
                    return this.placeholder = e || this._getPlaceholderText(), this._inputEl.placeholder = this.placeholder, this._inputEl.setAttribute("aria-label", this.placeholder), this
                },
                getBbox: function() {
                    return this.options.bbox
                },
                setBbox: function(e) {
                    return this.options.bbox = e, this
                },
                getCountries: function() {
                    return this.options.countries
                },
                setCountries: function(e) {
                    return this.options.countries = e, this
                },
                getTypes: function() {
                    return this.options.types
                },
                setTypes: function(e) {
                    return this.options.types = e, this
                },
                getMinLength: function() {
                    return this.options.minLength
                },
                setMinLength: function(e) {
                    return this.options.minLength = e, this._typeahead && (this._typeahead.options.minLength = e), this
                },
                getLimit: function() {
                    return this.options.limit
                },
                setLimit: function(e) {
                    return this.options.limit = e, this._typeahead && (this._typeahead.options.limit = e), this
                },
                getFilter: function() {
                    return this.options.filter
                },
                setFilter: function(e) {
                    return this.options.filter = e, this
                },
                setOrigin: function(e) {
                    return this.options.origin = e, this.geocoderService = c(u({
                        accessToken: this.options.accessToken,
                        origin: this.options.origin
                    })), this
                },
                getOrigin: function() {
                    return this.options.origin
                },
                setAccessToken: function(e) {
                    return this.options.accessToken = e, this.geocoderService = c(u({
                        accessToken: this.options.accessToken,
                        origin: this.options.origin
                    })), this
                },
                setAutocomplete: function(e) {
                    return this.options.autocomplete = e, this
                },
                getAutocomplete: function() {
                    return this.options.autocomplete
                },
                setFuzzyMatch: function(e) {
                    return this.options.fuzzyMatch = e, this
                },
                getFuzzyMatch: function() {
                    return this.options.fuzzyMatch
                },
                setRouting: function(e) {
                    return this.options.routing = e, this
                },
                getRouting: function() {
                    return this.options.routing
                },
                setWorldview: function(e) {
                    return this.options.worldview = e, this
                },
                getWorldview: function() {
                    return this.options.worldview
                },
                _handleMarker: function(e) {
                    if (this._map) {
                        this._removeMarker();
                        var t = o({}, {
                            color: "#4668F2"
                        }, this.options.marker);
                        return this.mapMarker = new this._mapboxgl.Marker(t), e.center ? this.mapMarker.setLngLat(e.center).addTo(this._map) : e.geometry && e.geometry.type && "Point" === e.geometry.type && e.geometry.coordinates && this.mapMarker.setLngLat(e.geometry.coordinates).addTo(this._map), this
                    }
                },
                _removeMarker: function() {
                    this.mapMarker && (this.mapMarker.remove(), this.mapMarker = null)
                },
                on: function(e, t) {
                    return this._eventEmitter.on(e, t), this
                },
                off: function(e, t) {
                    return this._eventEmitter.removeListener(e, t), this.eventManager.remove(), this
                }
            }, e.exports = y
        },
        13291: function(e) {
            "use strict";
            e.exports = {
                placeholder: {
                    de: "Suche",
                    it: "Ricerca",
                    en: "Search",
                    nl: "Zoeken",
                    fr: "Chercher",
                    ca: "Cerca",
                    he: "\u05dc\u05d7\u05e4\u05e9",
                    ja: "\u30b5\u30fc\u30c1",
                    lv: "Mekl\u0113t",
                    pt: "Procurar",
                    sr: "\u041f\u0440\u0435\u0442\u0440\u0430\u0433\u0430",
                    zh: "\u641c\u7d22",
                    cs: "Vyhled\xe1v\xe1n\xed",
                    hu: "Keres\xe9s",
                    ka: "\u10eb\u10d8\u10d4\u10d1\u10d0",
                    nb: "S\xf8ke",
                    sk: "Vyh\u013ead\xe1vanie",
                    th: "\u0e04\u0e49\u0e19\u0e2b\u0e32",
                    fi: "Hae",
                    is: "Leita",
                    ko: "\uc218\uc0c9",
                    pl: "Szukaj",
                    sl: "Iskanje",
                    fa: "\u062c\u0633\u062a\u062c\u0648",
                    ru: "\u041f\u043e\u0438\u0441\u043a"
                }
            }
        },
        98942: function(e) {
            function t(e) {
                var t = e.address || "",
                    n = e.text || "",
                    i = e.place_name || "",
                    r = {
                        address: i.split(",")[0],
                        houseNumber: t,
                        street: n,
                        placeName: i
                    };
                return e.context.forEach((function(e) {
                    var t = e.id.split(".")[0];
                    r[t] = e.text
                })), r
            }
            e.exports = {
                transformFeatureToGeolocationText: function(e, n) {
                    var i = t(e),
                        r = ["address", "street", "place", "country"];
                    if ("function" === typeof n) return n(i);
                    var o = r.indexOf(n);
                    return (-1 === o ? r : r.slice(o)).reduce((function(e, t) {
                        return i[t] ? ("" !== e && (e += ", "), e + i[t]) : e
                    }), "")
                },
                getAddressInfo: t,
                REVERSE_GEOCODE_COORD_RGX: /^[ ]*(-?\d{1,3}(\.\d{0,256})?)[, ]+(-?\d{1,3}(\.\d{0,256})?)[ ]*$/
            }
        },
        30599: function(e, t, n) {
            "use strict";
            var i = n(37962);
            e.exports = i
        },
        37962: function(e, t, n) {
            "use strict";
            var i = n(54516),
                r = n(89609);

            function o(e) {
                r.call(this, e)
            }
            o.prototype = Object.create(r.prototype), o.prototype.constructor = o, o.prototype.sendRequest = i.browserSend, o.prototype.abortRequest = i.browserAbort, e.exports = function(e) {
                return new o(e)
            }
        },
        54516: function(e, t, n) {
            "use strict";
            var i = n(91188),
                r = n(97698),
                o = n(762),
                s = n(9928),
                a = {};

            function u(e) {
                var t = e.total,
                    n = e.loaded;
                return {
                    total: t,
                    transferred: n,
                    percent: 100 * n / t
                }
            }

            function c(e, t) {
                return new Promise((function(n, i) {
                    t.onprogress = function(t) {
                        e.emitter.emit(o.EVENT_PROGRESS_DOWNLOAD, u(t))
                    };
                    var s = e.file;
                    s && (t.upload.onprogress = function(t) {
                        e.emitter.emit(o.EVENT_PROGRESS_UPLOAD, u(t))
                    }), t.onerror = function(e) {
                        i(e)
                    }, t.onabort = function() {
                        var t = new r({
                            request: e,
                            type: o.ERROR_REQUEST_ABORTED
                        });
                        i(t)
                    }, t.onload = function() {
                        if (delete a[e.id], t.status < 200 || t.status >= 400) {
                            var o = new r({
                                request: e,
                                body: t.response,
                                statusCode: t.status
                            });
                            i(o)
                        } else n(t)
                    };
                    var c = e.body;
                    "string" === typeof c ? t.send(c) : c ? t.send(JSON.stringify(c)) : s ? t.send(s) : t.send(), a[e.id] = t
                })).then((function(t) {
                    return function(e, t) {
                        return new i(e, {
                            body: t.response,
                            headers: s(t.getAllResponseHeaders()),
                            statusCode: t.status
                        })
                    }(e, t)
                }))
            }

            function l(e, t) {
                var n = e.url(t),
                    i = new window.XMLHttpRequest;
                return i.open(e.method, n), Object.keys(e.headers).forEach((function(t) {
                    i.setRequestHeader(t, e.headers[t])
                })), i
            }
            e.exports = {
                browserAbort: function(e) {
                    var t = a[e.id];
                    t && (t.abort(), delete a[e.id])
                },
                sendRequestXhr: c,
                browserSend: function(e) {
                    return Promise.resolve().then((function() {
                        var t = l(e, e.client.accessToken);
                        return c(e, t)
                    }))
                },
                createRequestXhr: l
            }
        },
        89609: function(e, t, n) {
            "use strict";
            var i = n(60247),
                r = n(53307),
                o = n(762);

            function s(e) {
                if (!e || !e.accessToken) throw new Error("Cannot create a client without an access token");
                i(e.accessToken), this.accessToken = e.accessToken, this.origin = e.origin || o.API_ORIGIN
            }
            s.prototype.createRequest = function(e) {
                return new r(this, e)
            }, e.exports = s
        },
        97698: function(e, t, n) {
            "use strict";
            var i = n(762);
            e.exports = function(e) {
                var t, n = e.type || i.ERROR_HTTP;
                if (e.body) try {
                    t = JSON.parse(e.body)
                } catch (o) {
                    t = e.body
                } else t = null;
                var r = e.message || null;
                r || ("string" === typeof t ? r = t : t && "string" === typeof t.message ? r = t.message : n === i.ERROR_REQUEST_ABORTED && (r = "Request aborted")), this.message = r, this.type = n, this.statusCode = e.statusCode || null, this.request = e.request, this.body = t
            }
        },
        53307: function(e, t, n) {
            "use strict";
            var i = n(60247),
                r = n(25307),
                o = n(37991),
                s = n(35607),
                a = n(762),
                u = 1;

            function c(e, t) {
                if (!e) throw new Error("MapiRequest requires a client");
                if (!t || !t.path || !t.method) throw new Error("MapiRequest requires an options object with path and method properties");
                var n = {};
                t.body && (n["content-type"] = "application/json");
                var i = r(n, t.headers),
                    s = Object.keys(i).reduce((function(e, t) {
                        return e[t.toLowerCase()] = i[t], e
                    }), {});
                this.id = u++, this._options = t, this.emitter = new o, this.client = e, this.response = null, this.error = null, this.sent = !1, this.aborted = !1, this.path = t.path, this.method = t.method, this.origin = t.origin || e.origin, this.query = t.query || {}, this.params = t.params || {}, this.body = t.body || null, this.file = t.file || null, this.encoding = t.encoding || "utf8", this.sendFileAs = t.sendFileAs || null, this.headers = s
            }
            c.prototype.url = function(e) {
                var t = s.prependOrigin(this.path, this.origin);
                t = s.appendQueryObject(t, this.query);
                var n = this.params,
                    o = null == e ? this.client.accessToken : e;
                if (o) {
                    t = s.appendQueryParam(t, "access_token", o);
                    var a = i(o).user;
                    n = r({
                        ownerId: a
                    }, n)
                }
                return t = s.interpolateRouteParams(t, n), t
            }, c.prototype.send = function() {
                var e = this;
                if (e.sent) throw new Error("This request has already been sent. Check the response and error properties. Create a new request with clone().");
                return e.sent = !0, e.client.sendRequest(e).then((function(t) {
                    return e.response = t, e.emitter.emit(a.EVENT_RESPONSE, t), t
                }), (function(t) {
                    throw e.error = t, e.emitter.emit(a.EVENT_ERROR, t), t
                }))
            }, c.prototype.abort = function() {
                this._nextPageRequest && (this._nextPageRequest.abort(), delete this._nextPageRequest), this.response || this.error || this.aborted || (this.aborted = !0, this.client.abortRequest(this))
            }, c.prototype.eachPage = function(e) {
                var t = this;

                function n(n) {
                    e(null, n, (function() {
                        delete t._nextPageRequest;
                        var e = n.nextPage();
                        e && (t._nextPageRequest = e, r(e))
                    }))
                }

                function i(t) {
                    e(t, null, (function() {}))
                }

                function r(e) {
                    e.send().then(n, i)
                }
                r(this)
            }, c.prototype.clone = function() {
                return this._extend()
            }, c.prototype._extend = function(e) {
                var t = r(this._options, e);
                return new c(this.client, t)
            }, e.exports = c
        },
        91188: function(e, t, n) {
            "use strict";
            var i = n(33212);

            function r(e, t) {
                this.request = e, this.headers = t.headers, this.rawBody = t.body, this.statusCode = t.statusCode;
                try {
                    this.body = JSON.parse(t.body || "{}")
                } catch (n) {
                    this.body = t.body
                }
                this.links = i(this.headers.link)
            }
            r.prototype.hasNextPage = function() {
                return !!this.links.next
            }, r.prototype.nextPage = function() {
                return this.hasNextPage() ? this.request._extend({
                    path: this.links.next.url
                }) : null
            }, e.exports = r
        },
        762: function(e) {
            "use strict";
            e.exports = {
                API_ORIGIN: "https://api.mapbox.com",
                EVENT_PROGRESS_DOWNLOAD: "downloadProgress",
                EVENT_PROGRESS_UPLOAD: "uploadProgress",
                EVENT_ERROR: "error",
                EVENT_RESPONSE: "response",
                ERROR_HTTP: "HttpError",
                ERROR_REQUEST_ABORTED: "RequestAbortedError"
            }
        },
        9928: function(e) {
            "use strict";
            e.exports = function(e) {
                var t = {};
                return e ? (e.trim().split(/[\r|\n]+/).forEach((function(e) {
                    var n = function(e) {
                        var t = e.indexOf(":");
                        return {
                            name: e.substring(0, t).trim().toLowerCase(),
                            value: e.substring(t + 1).trim()
                        }
                    }(e);
                    t[n.name] = n.value
                })), t) : t
            }
        },
        33212: function(e) {
            "use strict";
            e.exports = function(e) {
                return e ? e.split(/,\s*</).reduce((function(e, t) {
                    var n = function(e) {
                        var t = e.match(/<?([^>]*)>(.*)/);
                        if (!t) return null;
                        var n = t[1],
                            i = t[2].split(";"),
                            r = null,
                            o = i.reduce((function(e, t) {
                                var n = function(e) {
                                    var t = e.match(/\s*(.+)\s*=\s*"?([^"]+)"?/);
                                    return t ? {
                                        key: t[1],
                                        value: t[2]
                                    } : null
                                }(t);
                                return n ? "rel" === n.key ? (r || (r = n.value), e) : (e[n.key] = n.value, e) : e
                            }), {});
                        return r ? {
                            url: n,
                            rel: r,
                            params: o
                        } : null
                    }(t);
                    return n ? (n.rel.split(/\s+/).forEach((function(t) {
                        e[t] || (e[t] = {
                            url: n.url,
                            params: n.params
                        })
                    })), e) : e
                }), {}) : {}
            }
        },
        35607: function(e) {
            "use strict";

            function t(e) {
                return Array.isArray(e) ? e.map(encodeURIComponent).join(",") : encodeURIComponent(String(e))
            }

            function n(e, n, i) {
                if (!1 === i || null === i) return e;
                var r = /\?/.test(e) ? "&" : "?",
                    o = encodeURIComponent(n);
                return void 0 !== i && "" !== i && !0 !== i && (o += "=" + t(i)), "" + e + r + o
            }
            e.exports = {
                appendQueryObject: function(e, t) {
                    if (!t) return e;
                    var i = e;
                    return Object.keys(t).forEach((function(e) {
                        var r = t[e];
                        void 0 !== r && (Array.isArray(r) && (r = r.filter((function(e) {
                            return null !== e && void 0 !== e
                        })).join(",")), i = n(i, e, r))
                    })), i
                },
                appendQueryParam: n,
                prependOrigin: function(e, t) {
                    if (!t) return e;
                    if ("http" === e.slice(0, 4)) return e;
                    var n = "/" === e[0] ? "" : "/";
                    return "" + t.replace(/\/$/, "") + n + e
                },
                interpolateRouteParams: function(e, n) {
                    return n ? e.replace(/\/:([a-zA-Z0-9]+)/g, (function(e, i) {
                        var r = n[i];
                        if (void 0 === r) throw new Error("Unspecified route parameter " + i);
                        return "/" + t(r)
                    })) : e
                }
            }
        },
        37991: function(e) {
            "use strict";
            var t = Object.prototype.hasOwnProperty,
                n = "~";

            function i() {}

            function r(e, t, n) {
                this.fn = e, this.context = t, this.once = n || !1
            }

            function o(e, t, i, o, s) {
                if ("function" !== typeof i) throw new TypeError("The listener must be a function");
                var a = new r(i, o || e, s),
                    u = n ? n + t : t;
                return e._events[u] ? e._events[u].fn ? e._events[u] = [e._events[u], a] : e._events[u].push(a) : (e._events[u] = a, e._eventsCount++), e
            }

            function s(e, t) {
                0 === --e._eventsCount ? e._events = new i : delete e._events[t]
            }

            function a() {
                this._events = new i, this._eventsCount = 0
            }
            Object.create && (i.prototype = Object.create(null), (new i).__proto__ || (n = !1)), a.prototype.eventNames = function() {
                var e, i, r = [];
                if (0 === this._eventsCount) return r;
                for (i in e = this._events) t.call(e, i) && r.push(n ? i.slice(1) : i);
                return Object.getOwnPropertySymbols ? r.concat(Object.getOwnPropertySymbols(e)) : r
            }, a.prototype.listeners = function(e) {
                var t = n ? n + e : e,
                    i = this._events[t];
                if (!i) return [];
                if (i.fn) return [i.fn];
                for (var r = 0, o = i.length, s = new Array(o); r < o; r++) s[r] = i[r].fn;
                return s
            }, a.prototype.listenerCount = function(e) {
                var t = n ? n + e : e,
                    i = this._events[t];
                return i ? i.fn ? 1 : i.length : 0
            }, a.prototype.emit = function(e, t, i, r, o, s) {
                var a = n ? n + e : e;
                if (!this._events[a]) return !1;
                var u, c, l = this._events[a],
                    h = arguments.length;
                if (l.fn) {
                    switch (l.once && this.removeListener(e, l.fn, void 0, !0), h) {
                        case 1:
                            return l.fn.call(l.context), !0;
                        case 2:
                            return l.fn.call(l.context, t), !0;
                        case 3:
                            return l.fn.call(l.context, t, i), !0;
                        case 4:
                            return l.fn.call(l.context, t, i, r), !0;
                        case 5:
                            return l.fn.call(l.context, t, i, r, o), !0;
                        case 6:
                            return l.fn.call(l.context, t, i, r, o, s), !0
                    }
                    for (c = 1, u = new Array(h - 1); c < h; c++) u[c - 1] = arguments[c];
                    l.fn.apply(l.context, u)
                } else {
                    var d, p = l.length;
                    for (c = 0; c < p; c++) switch (l[c].once && this.removeListener(e, l[c].fn, void 0, !0), h) {
                        case 1:
                            l[c].fn.call(l[c].context);
                            break;
                        case 2:
                            l[c].fn.call(l[c].context, t);
                            break;
                        case 3:
                            l[c].fn.call(l[c].context, t, i);
                            break;
                        case 4:
                            l[c].fn.call(l[c].context, t, i, r);
                            break;
                        default:
                            if (!u)
                                for (d = 1, u = new Array(h - 1); d < h; d++) u[d - 1] = arguments[d];
                            l[c].fn.apply(l[c].context, u)
                    }
                }
                return !0
            }, a.prototype.on = function(e, t, n) {
                return o(this, e, t, n, !1)
            }, a.prototype.once = function(e, t, n) {
                return o(this, e, t, n, !0)
            }, a.prototype.removeListener = function(e, t, i, r) {
                var o = n ? n + e : e;
                if (!this._events[o]) return this;
                if (!t) return s(this, o), this;
                var a = this._events[o];
                if (a.fn) a.fn !== t || r && !a.once || i && a.context !== i || s(this, o);
                else {
                    for (var u = 0, c = [], l = a.length; u < l; u++)(a[u].fn !== t || r && !a[u].once || i && a[u].context !== i) && c.push(a[u]);
                    c.length ? this._events[o] = 1 === c.length ? c[0] : c : s(this, o)
                }
                return this
            }, a.prototype.removeAllListeners = function(e) {
                var t;
                return e ? (t = n ? n + e : e, this._events[t] && s(this, t)) : (this._events = new i, this._eventsCount = 0), this
            }, a.prototype.off = a.prototype.removeListener, a.prototype.addListener = a.prototype.on, a.prefixed = n, a.EventEmitter = a, e.exports = a
        },
        58348: function(e, t, n) {
            "use strict";
            var i = n(25307),
                r = n(13269),
                o = n(33970),
                s = n(99216),
                a = n(70598),
                u = {},
                c = ["country", "region", "postcode", "district", "place", "locality", "neighborhood", "address", "poi", "poi.landmark"];
            u.forwardGeocode = function(e) {
                r.assertShape({
                    query: r.required(r.string),
                    mode: r.oneOf("mapbox.places", "mapbox.places-permanent"),
                    countries: r.arrayOf(r.string),
                    proximity: r.oneOf(r.coordinates, "ip"),
                    types: r.arrayOf(r.oneOf(c)),
                    autocomplete: r.boolean,
                    bbox: r.arrayOf(r.number),
                    limit: r.number,
                    language: r.arrayOf(r.string),
                    routing: r.boolean,
                    fuzzyMatch: r.boolean,
                    worldview: r.string
                })(e), e.mode = e.mode || "mapbox.places";
                var t = s(i({
                    country: e.countries
                }, o(e, ["proximity", "types", "autocomplete", "bbox", "limit", "language", "routing", "fuzzyMatch", "worldview"])));
                return this.client.createRequest({
                    method: "GET",
                    path: "/geocoding/v5/:mode/:query.json",
                    params: o(e, ["mode", "query"]),
                    query: t
                })
            }, u.reverseGeocode = function(e) {
                r.assertShape({
                    query: r.required(r.coordinates),
                    mode: r.oneOf("mapbox.places", "mapbox.places-permanent"),
                    countries: r.arrayOf(r.string),
                    types: r.arrayOf(r.oneOf(c)),
                    bbox: r.arrayOf(r.number),
                    limit: r.number,
                    language: r.arrayOf(r.string),
                    reverseMode: r.oneOf("distance", "score"),
                    routing: r.boolean,
                    worldview: r.string
                })(e), e.mode = e.mode || "mapbox.places";
                var t = s(i({
                    country: e.countries
                }, o(e, ["country", "types", "bbox", "limit", "language", "reverseMode", "routing", "worldview"])));
                return this.client.createRequest({
                    method: "GET",
                    path: "/geocoding/v5/:mode/:query.json",
                    params: o(e, ["mode", "query"]),
                    query: t
                })
            }, e.exports = a(u)
        },
        70598: function(e, t, n) {
            "use strict";
            var i = n(89609),
                r = n(37962);
            e.exports = function(e) {
                return function(t) {
                    var n;
                    n = i.prototype.isPrototypeOf(t) ? t : r(t);
                    var o = Object.create(e);
                    return o.client = n, o
                }
            }
        },
        18480: function(e) {
            "use strict";
            e.exports = function(e, t) {
                return Object.keys(e).reduce((function(n, i) {
                    return n[i] = t(i, e[i]), n
                }), {})
            }
        },
        33970: function(e) {
            "use strict";
            e.exports = function(e, t) {
                var n = function(e, n) {
                    return -1 !== t.indexOf(e) && void 0 !== n
                };
                return "function" === typeof t && (n = t), Object.keys(e).filter((function(t) {
                    return n(t, e[t])
                })).reduce((function(t, n) {
                    return t[n] = e[n], t
                }), {})
            }
        },
        99216: function(e, t, n) {
            "use strict";
            var i = n(18480);
            e.exports = function(e) {
                return i(e, (function(e, t) {
                    return "boolean" === typeof t ? JSON.stringify(t) : t
                }))
            }
        },
        13269: function(e, t, n) {
            "use strict";
            var i = n(25307),
                r = n(14173);
            e.exports = i(r, {
                file: function(e) {
                    if ("undefined" !== typeof window) {
                        if (e instanceof n.g.Blob || e instanceof n.g.ArrayBuffer) return;
                        return "Blob or ArrayBuffer"
                    }
                    if ("string" !== typeof e && void 0 === e.pipe) return "Filename or Readable stream"
                },
                date: function(e) {
                    var t = "date";
                    if ("boolean" === typeof e) return t;
                    try {
                        var n = new Date(e);
                        if (n.getTime && isNaN(n.getTime())) return t
                    } catch (i) {
                        return t
                    }
                },
                coordinates: function(e) {
                    return r.tuple(r.number, r.number)(e)
                },
                assertShape: function(e, t) {
                    return r.assert(r.strictShape(e), t)
                }
            })
        },
        60247: function(e, t, n) {
            "use strict";
            var i = n(7538),
                r = {};

            function o(e, t) {
                return Object.prototype.hasOwnProperty.call(e, t)
            }
            e.exports = function(e) {
                if (r[e]) return r[e];
                var t = e.split("."),
                    n = t[0],
                    s = t[1];
                if (!s) throw new Error("Invalid token");
                var a = function(e) {
                        try {
                            return JSON.parse(i.decode(e))
                        } catch (t) {
                            throw new Error("Invalid token")
                        }
                    }(s),
                    u = {
                        usage: n,
                        user: a.u
                    };
                return o(a, "a") && (u.authorization = a.a), o(a, "exp") && (u.expires = 1e3 * a.exp), o(a, "iat") && (u.created = 1e3 * a.iat), o(a, "scopes") && (u.scopes = a.scopes), o(a, "client") && (u.client = a.client), o(a, "ll") && (u.lastLogin = a.ll), o(a, "iu") && (u.impersonator = a.iu), r[e] = u, u
            }
        },
        83929: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return E
                }
            });
            var i = n(4942),
                r = n(63366),
                o = n(87462),
                s = n(47313),
                a = n(83061),
                u = n(21921),
                c = n(99008),
                l = n(61113),
                h = n(91615),
                d = n(17592),
                p = n(77342),
                f = n(77430),
                v = n(32298);

            function g(e) {
                return (0, v.Z)("MuiFormControlLabel", e)
            }
            var m = (0, f.Z)("MuiFormControlLabel", ["root", "labelPlacementStart", "labelPlacementTop", "labelPlacementBottom", "disabled", "label", "error", "required", "asterisk"]),
                y = n(80300),
                b = n(46417),
                _ = ["checked", "className", "componentsProps", "control", "disabled", "disableTypography", "inputRef", "label", "labelPlacement", "name", "onChange", "required", "slotProps", "value"],
                w = (0, d.ZP)("label", {
                    name: "MuiFormControlLabel",
                    slot: "Root",
                    overridesResolver: function(e, t) {
                        var n = e.ownerState;
                        return [(0, i.Z)({}, "& .".concat(m.label), t.label), t.root, t["labelPlacement".concat((0, h.Z)(n.labelPlacement))]]
                    }
                })((function(e) {
                    var t = e.theme,
                        n = e.ownerState;
                    return (0, o.Z)((0, i.Z)({
                        display: "inline-flex",
                        alignItems: "center",
                        cursor: "pointer",
                        verticalAlign: "middle",
                        WebkitTapHighlightColor: "transparent",
                        marginLeft: -11,
                        marginRight: 16
                    }, "&.".concat(m.disabled), {
                        cursor: "default"
                    }), "start" === n.labelPlacement && {
                        flexDirection: "row-reverse",
                        marginLeft: 16,
                        marginRight: -11
                    }, "top" === n.labelPlacement && {
                        flexDirection: "column-reverse",
                        marginLeft: 16
                    }, "bottom" === n.labelPlacement && {
                        flexDirection: "column",
                        marginLeft: 16
                    }, (0, i.Z)({}, "& .".concat(m.label), (0, i.Z)({}, "&.".concat(m.disabled), {
                        color: (t.vars || t).palette.text.disabled
                    })))
                })),
                x = (0, d.ZP)("span", {
                    name: "MuiFormControlLabel",
                    slot: "Asterisk",
                    overridesResolver: function(e, t) {
                        return t.asterisk
                    }
                })((function(e) {
                    var t = e.theme;
                    return (0, i.Z)({}, "&.".concat(m.error), {
                        color: (t.vars || t).palette.error.main
                    })
                })),
                E = s.forwardRef((function(e, t) {
                    var n, i, d = (0, p.Z)({
                            props: e,
                            name: "MuiFormControlLabel"
                        }),
                        f = d.className,
                        v = d.componentsProps,
                        m = void 0 === v ? {} : v,
                        E = d.control,
                        O = d.disabled,
                        L = d.disableTypography,
                        C = d.label,
                        S = d.labelPlacement,
                        k = void 0 === S ? "end" : S,
                        R = d.required,
                        M = d.slotProps,
                        P = void 0 === M ? {} : M,
                        A = (0, r.Z)(d, _),
                        T = (0, c.Z)(),
                        q = null != (n = null != O ? O : E.props.disabled) ? n : null == T ? void 0 : T.disabled,
                        I = null != R ? R : E.props.required,
                        j = {
                            disabled: q,
                            required: I
                        };
                    ["checked", "name", "onChange", "value", "inputRef"].forEach((function(e) {
                        "undefined" === typeof E.props[e] && "undefined" !== typeof d[e] && (j[e] = d[e])
                    }));
                    var z = (0, y.Z)({
                            props: d,
                            muiFormControl: T,
                            states: ["error"]
                        }),
                        Z = (0, o.Z)({}, d, {
                            disabled: q,
                            labelPlacement: k,
                            required: I,
                            error: z.error
                        }),
                        B = function(e) {
                            var t = e.classes,
                                n = e.disabled,
                                i = e.labelPlacement,
                                r = e.error,
                                o = e.required,
                                s = {
                                    root: ["root", n && "disabled", "labelPlacement".concat((0, h.Z)(i)), r && "error", o && "required"],
                                    label: ["label", n && "disabled"],
                                    asterisk: ["asterisk", r && "error"]
                                };
                            return (0, u.Z)(s, g, t)
                        }(Z),
                        N = null != (i = P.typography) ? i : m.typography,
                        U = C;
                    return null == U || U.type === l.Z || L || (U = (0, b.jsx)(l.Z, (0, o.Z)({
                        component: "span"
                    }, N, {
                        className: (0, a.Z)(B.label, null == N ? void 0 : N.className),
                        children: U
                    }))), (0, b.jsxs)(w, (0, o.Z)({
                        className: (0, a.Z)(B.root, f),
                        ownerState: Z,
                        ref: t
                    }, A, {
                        children: [s.cloneElement(E, j), U, I && (0, b.jsxs)(x, {
                            ownerState: Z,
                            "aria-hidden": !0,
                            className: B.asterisk,
                            children: ["\u2009", "*"]
                        })]
                    }))
                }))
        },
        78770: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return _
                }
            });
            var i = n(4942),
                r = n(63366),
                o = n(87462),
                s = n(47313),
                a = (n(20478), n(83061)),
                u = n(21921),
                c = n(17592),
                l = n(77342),
                h = n(91615);

            function d(e, t) {
                return void 0 !== t && void 0 !== e && (Array.isArray(t) ? t.indexOf(e) >= 0 : e === t)
            }
            var p = n(77430),
                f = n(32298);

            function v(e) {
                return (0, f.Z)("MuiToggleButtonGroup", e)
            }
            var g = (0, p.Z)("MuiToggleButtonGroup", ["root", "selected", "vertical", "disabled", "grouped", "groupedHorizontal", "groupedVertical"]),
                m = n(46417),
                y = ["children", "className", "color", "disabled", "exclusive", "fullWidth", "onChange", "orientation", "size", "value"],
                b = (0, c.ZP)("div", {
                    name: "MuiToggleButtonGroup",
                    slot: "Root",
                    overridesResolver: function(e, t) {
                        var n = e.ownerState;
                        return [(0, i.Z)({}, "& .".concat(g.grouped), t.grouped), (0, i.Z)({}, "& .".concat(g.grouped), t["grouped".concat((0, h.Z)(n.orientation))]), t.root, "vertical" === n.orientation && t.vertical, n.fullWidth && t.fullWidth]
                    }
                })((function(e) {
                    var t = e.ownerState,
                        n = e.theme;
                    return (0, o.Z)({
                        display: "inline-flex",
                        borderRadius: (n.vars || n).shape.borderRadius
                    }, "vertical" === t.orientation && {
                        flexDirection: "column"
                    }, t.fullWidth && {
                        width: "100%"
                    }, (0, i.Z)({}, "& .".concat(g.grouped), (0, o.Z)({}, "horizontal" === t.orientation ? (0, i.Z)({
                        "&:not(:first-of-type)": {
                            marginLeft: -1,
                            borderLeft: "1px solid transparent",
                            borderTopLeftRadius: 0,
                            borderBottomLeftRadius: 0
                        },
                        "&:not(:last-of-type)": {
                            borderTopRightRadius: 0,
                            borderBottomRightRadius: 0
                        }
                    }, "&.".concat(g.selected, " + .").concat(g.grouped, ".").concat(g.selected), {
                        borderLeft: 0,
                        marginLeft: 0
                    }) : (0, i.Z)({
                        "&:not(:first-of-type)": {
                            marginTop: -1,
                            borderTop: "1px solid transparent",
                            borderTopLeftRadius: 0,
                            borderTopRightRadius: 0
                        },
                        "&:not(:last-of-type)": {
                            borderBottomLeftRadius: 0,
                            borderBottomRightRadius: 0
                        }
                    }, "&.".concat(g.selected, " + .").concat(g.grouped, ".").concat(g.selected), {
                        borderTop: 0,
                        marginTop: 0
                    }))))
                })),
                _ = s.forwardRef((function(e, t) {
                    var n = (0, l.Z)({
                            props: e,
                            name: "MuiToggleButtonGroup"
                        }),
                        i = n.children,
                        c = n.className,
                        p = n.color,
                        f = void 0 === p ? "standard" : p,
                        g = n.disabled,
                        _ = void 0 !== g && g,
                        w = n.exclusive,
                        x = void 0 !== w && w,
                        E = n.fullWidth,
                        O = void 0 !== E && E,
                        L = n.onChange,
                        C = n.orientation,
                        S = void 0 === C ? "horizontal" : C,
                        k = n.size,
                        R = void 0 === k ? "medium" : k,
                        M = n.value,
                        P = (0, r.Z)(n, y),
                        A = (0, o.Z)({}, n, {
                            disabled: _,
                            fullWidth: O,
                            orientation: S,
                            size: R
                        }),
                        T = function(e) {
                            var t = e.classes,
                                n = e.orientation,
                                i = e.fullWidth,
                                r = e.disabled,
                                o = {
                                    root: ["root", "vertical" === n && "vertical", i && "fullWidth"],
                                    grouped: ["grouped", "grouped".concat((0, h.Z)(n)), r && "disabled"]
                                };
                            return (0, u.Z)(o, v, t)
                        }(A),
                        q = function(e, t) {
                            if (L) {
                                var n, i = M && M.indexOf(t);
                                M && i >= 0 ? (n = M.slice()).splice(i, 1) : n = M ? M.concat(t) : [t], L(e, n)
                            }
                        },
                        I = function(e, t) {
                            L && L(e, M === t ? null : t)
                        };
                    return (0, m.jsx)(b, (0, o.Z)({
                        role: "group",
                        className: (0, a.Z)(T.root, c),
                        ref: t,
                        ownerState: A
                    }, P, {
                        children: s.Children.map(i, (function(e) {
                            return s.isValidElement(e) ? s.cloneElement(e, {
                                className: (0, a.Z)(T.grouped, e.props.className),
                                onChange: x ? I : q,
                                selected: void 0 === e.props.selected ? d(e.props.value, M) : e.props.selected,
                                size: e.props.size || R,
                                fullWidth: O,
                                color: e.props.color || f,
                                disabled: e.props.disabled || _
                            }) : null
                        }))
                    }))
                }))
        },
        3789: function(e, t, n) {
            "use strict";
            n.d(t, {
                Z: function() {
                    return w
                }
            });
            var i = n(4942),
                r = n(63366),
                o = n(87462),
                s = n(47313),
                a = n(83061),
                u = n(21921),
                c = n(17551),
                l = n(67999),
                h = n(91615),
                d = n(77342),
                p = n(17592),
                f = n(77430),
                v = n(32298);

            function g(e) {
                return (0, v.Z)("MuiToggleButton", e)
            }
            var m = (0, f.Z)("MuiToggleButton", ["root", "disabled", "selected", "standard", "primary", "secondary", "sizeSmall", "sizeMedium", "sizeLarge"]),
                y = n(46417),
                b = ["children", "className", "color", "disabled", "disableFocusRipple", "fullWidth", "onChange", "onClick", "selected", "size", "value"],
                _ = (0, p.ZP)(l.Z, {
                    name: "MuiToggleButton",
                    slot: "Root",
                    overridesResolver: function(e, t) {
                        var n = e.ownerState;
                        return [t.root, t["size".concat((0, h.Z)(n.size))]]
                    }
                })((function(e) {
                    var t, n, r = e.theme,
                        s = e.ownerState,
                        a = "standard" === s.color ? r.palette.text.primary : r.palette[s.color].main;
                    return r.vars && (a = "standard" === s.color ? r.vars.palette.text.primary : r.vars.palette[s.color].main, n = "standard" === s.color ? r.vars.palette.text.primaryChannel : r.vars.palette[s.color].mainChannel), (0, o.Z)({}, r.typography.button, {
                        borderRadius: (r.vars || r).shape.borderRadius,
                        padding: 11,
                        border: "1px solid ".concat((r.vars || r).palette.divider),
                        color: (r.vars || r).palette.action.active
                    }, s.fullWidth && {
                        width: "100%"
                    }, (t = {}, (0, i.Z)(t, "&.".concat(m.disabled), {
                        color: (r.vars || r).palette.action.disabled,
                        border: "1px solid ".concat((r.vars || r).palette.action.disabledBackground)
                    }), (0, i.Z)(t, "&:hover", {
                        textDecoration: "none",
                        backgroundColor: r.vars ? "rgba(".concat(r.vars.palette.text.primaryChannel, " / ").concat(r.vars.palette.action.hoverOpacity, ")") : (0, c.Fq)(r.palette.text.primary, r.palette.action.hoverOpacity),
                        "@media (hover: none)": {
                            backgroundColor: "transparent"
                        }
                    }), (0, i.Z)(t, "&.".concat(m.selected), {
                        color: a,
                        backgroundColor: r.vars ? "rgba(".concat(n, " / ").concat(r.vars.palette.action.selectedOpacity, ")") : (0, c.Fq)(a, r.palette.action.selectedOpacity),
                        "&:hover": {
                            backgroundColor: r.vars ? "rgba(".concat(n, " / calc(").concat(r.vars.palette.action.selectedOpacity, " + ").concat(r.vars.palette.action.hoverOpacity, "))") : (0, c.Fq)(a, r.palette.action.selectedOpacity + r.palette.action.hoverOpacity),
                            "@media (hover: none)": {
                                backgroundColor: r.vars ? "rgba(".concat(n, " / ").concat(r.vars.palette.action.selectedOpacity, ")") : (0, c.Fq)(a, r.palette.action.selectedOpacity)
                            }
                        }
                    }), t), "small" === s.size && {
                        padding: 7,
                        fontSize: r.typography.pxToRem(13)
                    }, "large" === s.size && {
                        padding: 15,
                        fontSize: r.typography.pxToRem(15)
                    })
                })),
                w = s.forwardRef((function(e, t) {
                    var n = (0, d.Z)({
                            props: e,
                            name: "MuiToggleButton"
                        }),
                        i = n.children,
                        s = n.className,
                        c = n.color,
                        l = void 0 === c ? "standard" : c,
                        p = n.disabled,
                        f = void 0 !== p && p,
                        v = n.disableFocusRipple,
                        m = void 0 !== v && v,
                        w = n.fullWidth,
                        x = void 0 !== w && w,
                        E = n.onChange,
                        O = n.onClick,
                        L = n.selected,
                        C = n.size,
                        S = void 0 === C ? "medium" : C,
                        k = n.value,
                        R = (0, r.Z)(n, b),
                        M = (0, o.Z)({}, n, {
                            color: l,
                            disabled: f,
                            disableFocusRipple: m,
                            fullWidth: x,
                            size: S
                        }),
                        P = function(e) {
                            var t = e.classes,
                                n = e.fullWidth,
                                i = e.selected,
                                r = e.disabled,
                                o = e.size,
                                s = e.color,
                                a = {
                                    root: ["root", i && "selected", r && "disabled", n && "fullWidth", "size".concat((0, h.Z)(o)), s]
                                };
                            return (0, u.Z)(a, g, t)
                        }(M);
                    return (0, y.jsx)(_, (0, o.Z)({
                        className: (0, a.Z)(P.root, s),
                        disabled: f,
                        focusRipple: !m,
                        ref: t,
                        onClick: function(e) {
                            O && (O(e, k), e.defaultPrevented) || E && E(e, k)
                        },
                        onChange: E,
                        value: k,
                        ownerState: M,
                        "aria-pressed": L
                    }, R, {
                        children: i
                    }))
                }))
        },
        7538: function(e, t, n) {
            var i;
            e = n.nmd(e),
                function(r) {
                    var o = t,
                        s = (e && e.exports, "object" == typeof n.g && n.g);
                    s.global !== s && s.window;
                    var a = function(e) {
                        this.message = e
                    };
                    (a.prototype = new Error).name = "InvalidCharacterError";
                    var u = function(e) {
                            throw new a(e)
                        },
                        c = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
                        l = /[\t\n\f\r ]/g,
                        h = {
                            encode: function(e) {
                                e = String(e), /[^\0-\xFF]/.test(e) && u("The string to be encoded contains characters outside of the Latin1 range.");
                                for (var t, n, i, r, o = e.length % 3, s = "", a = -1, l = e.length - o; ++a < l;) t = e.charCodeAt(a) << 16, n = e.charCodeAt(++a) << 8, i = e.charCodeAt(++a), s += c.charAt((r = t + n + i) >> 18 & 63) + c.charAt(r >> 12 & 63) + c.charAt(r >> 6 & 63) + c.charAt(63 & r);
                                return 2 == o ? (t = e.charCodeAt(a) << 8, n = e.charCodeAt(++a), s += c.charAt((r = t + n) >> 10) + c.charAt(r >> 4 & 63) + c.charAt(r << 2 & 63) + "=") : 1 == o && (r = e.charCodeAt(a), s += c.charAt(r >> 2) + c.charAt(r << 4 & 63) + "=="), s
                            },
                            decode: function(e) {
                                var t = (e = String(e).replace(l, "")).length;
                                t % 4 == 0 && (t = (e = e.replace(/==?$/, "")).length), (t % 4 == 1 || /[^+a-zA-Z0-9/]/.test(e)) && u("Invalid character: the string to be decoded is not correctly encoded.");
                                for (var n, i, r = 0, o = "", s = -1; ++s < t;) i = c.indexOf(e.charAt(s)), n = r % 4 ? 64 * n + i : i, r++ % 4 && (o += String.fromCharCode(255 & n >> (-2 * r & 6)));
                                return o
                            },
                            version: "0.1.0"
                        };
                    void 0 === (i = function() {
                        return h
                    }.call(t, n, t, e)) || (e.exports = i)
                }()
        },
        68041: function(e) {
            "use strict";
            var t, n = "object" === typeof Reflect ? Reflect : null,
                i = n && "function" === typeof n.apply ? n.apply : function(e, t, n) {
                    return Function.prototype.apply.call(e, t, n)
                };
            t = n && "function" === typeof n.ownKeys ? n.ownKeys : Object.getOwnPropertySymbols ? function(e) {
                return Object.getOwnPropertyNames(e).concat(Object.getOwnPropertySymbols(e))
            } : function(e) {
                return Object.getOwnPropertyNames(e)
            };
            var r = Number.isNaN || function(e) {
                return e !== e
            };

            function o() {
                o.init.call(this)
            }
            e.exports = o, e.exports.once = function(e, t) {
                return new Promise((function(n, i) {
                    function r(n) {
                        e.removeListener(t, o), i(n)
                    }

                    function o() {
                        "function" === typeof e.removeListener && e.removeListener("error", r), n([].slice.call(arguments))
                    }
                    v(e, t, o, {
                        once: !0
                    }), "error" !== t && function(e, t, n) {
                        "function" === typeof e.on && v(e, "error", t, n)
                    }(e, r, {
                        once: !0
                    })
                }))
            }, o.EventEmitter = o, o.prototype._events = void 0, o.prototype._eventsCount = 0, o.prototype._maxListeners = void 0;
            var s = 10;

            function a(e) {
                if ("function" !== typeof e) throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof e)
            }

            function u(e) {
                return void 0 === e._maxListeners ? o.defaultMaxListeners : e._maxListeners
            }

            function c(e, t, n, i) {
                var r, o, s, c;
                if (a(n), void 0 === (o = e._events) ? (o = e._events = Object.create(null), e._eventsCount = 0) : (void 0 !== o.newListener && (e.emit("newListener", t, n.listener ? n.listener : n), o = e._events), s = o[t]), void 0 === s) s = o[t] = n, ++e._eventsCount;
                else if ("function" === typeof s ? s = o[t] = i ? [n, s] : [s, n] : i ? s.unshift(n) : s.push(n), (r = u(e)) > 0 && s.length > r && !s.warned) {
                    s.warned = !0;
                    var l = new Error("Possible EventEmitter memory leak detected. " + s.length + " " + String(t) + " listeners added. Use emitter.setMaxListeners() to increase limit");
                    l.name = "MaxListenersExceededWarning", l.emitter = e, l.type = t, l.count = s.length, c = l, console && console.warn && console.warn(c)
                }
                return e
            }

            function l() {
                if (!this.fired) return this.target.removeListener(this.type, this.wrapFn), this.fired = !0, 0 === arguments.length ? this.listener.call(this.target) : this.listener.apply(this.target, arguments)
            }

            function h(e, t, n) {
                var i = {
                        fired: !1,
                        wrapFn: void 0,
                        target: e,
                        type: t,
                        listener: n
                    },
                    r = l.bind(i);
                return r.listener = n, i.wrapFn = r, r
            }

            function d(e, t, n) {
                var i = e._events;
                if (void 0 === i) return [];
                var r = i[t];
                return void 0 === r ? [] : "function" === typeof r ? n ? [r.listener || r] : [r] : n ? function(e) {
                    for (var t = new Array(e.length), n = 0; n < t.length; ++n) t[n] = e[n].listener || e[n];
                    return t
                }(r) : f(r, r.length)
            }

            function p(e) {
                var t = this._events;
                if (void 0 !== t) {
                    var n = t[e];
                    if ("function" === typeof n) return 1;
                    if (void 0 !== n) return n.length
                }
                return 0
            }

            function f(e, t) {
                for (var n = new Array(t), i = 0; i < t; ++i) n[i] = e[i];
                return n
            }

            function v(e, t, n, i) {
                if ("function" === typeof e.on) i.once ? e.once(t, n) : e.on(t, n);
                else {
                    if ("function" !== typeof e.addEventListener) throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof e);
                    e.addEventListener(t, (function r(o) {
                        i.once && e.removeEventListener(t, r), n(o)
                    }))
                }
            }
            Object.defineProperty(o, "defaultMaxListeners", {
                enumerable: !0,
                get: function() {
                    return s
                },
                set: function(e) {
                    if ("number" !== typeof e || e < 0 || r(e)) throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + e + ".");
                    s = e
                }
            }), o.init = function() {
                void 0 !== this._events && this._events !== Object.getPrototypeOf(this)._events || (this._events = Object.create(null), this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0
            }, o.prototype.setMaxListeners = function(e) {
                if ("number" !== typeof e || e < 0 || r(e)) throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + e + ".");
                return this._maxListeners = e, this
            }, o.prototype.getMaxListeners = function() {
                return u(this)
            }, o.prototype.emit = function(e) {
                for (var t = [], n = 1; n < arguments.length; n++) t.push(arguments[n]);
                var r = "error" === e,
                    o = this._events;
                if (void 0 !== o) r = r && void 0 === o.error;
                else if (!r) return !1;
                if (r) {
                    var s;
                    if (t.length > 0 && (s = t[0]), s instanceof Error) throw s;
                    var a = new Error("Unhandled error." + (s ? " (" + s.message + ")" : ""));
                    throw a.context = s, a
                }
                var u = o[e];
                if (void 0 === u) return !1;
                if ("function" === typeof u) i(u, this, t);
                else {
                    var c = u.length,
                        l = f(u, c);
                    for (n = 0; n < c; ++n) i(l[n], this, t)
                }
                return !0
            }, o.prototype.addListener = function(e, t) {
                return c(this, e, t, !1)
            }, o.prototype.on = o.prototype.addListener, o.prototype.prependListener = function(e, t) {
                return c(this, e, t, !0)
            }, o.prototype.once = function(e, t) {
                return a(t), this.on(e, h(this, e, t)), this
            }, o.prototype.prependOnceListener = function(e, t) {
                return a(t), this.prependListener(e, h(this, e, t)), this
            }, o.prototype.removeListener = function(e, t) {
                var n, i, r, o, s;
                if (a(t), void 0 === (i = this._events)) return this;
                if (void 0 === (n = i[e])) return this;
                if (n === t || n.listener === t) 0 === --this._eventsCount ? this._events = Object.create(null) : (delete i[e], i.removeListener && this.emit("removeListener", e, n.listener || t));
                else if ("function" !== typeof n) {
                    for (r = -1, o = n.length - 1; o >= 0; o--)
                        if (n[o] === t || n[o].listener === t) {
                            s = n[o].listener, r = o;
                            break
                        }
                    if (r < 0) return this;
                    0 === r ? n.shift() : function(e, t) {
                        for (; t + 1 < e.length; t++) e[t] = e[t + 1];
                        e.pop()
                    }(n, r), 1 === n.length && (i[e] = n[0]), void 0 !== i.removeListener && this.emit("removeListener", e, s || t)
                }
                return this
            }, o.prototype.off = o.prototype.removeListener, o.prototype.removeAllListeners = function(e) {
                var t, n, i;
                if (void 0 === (n = this._events)) return this;
                if (void 0 === n.removeListener) return 0 === arguments.length ? (this._events = Object.create(null), this._eventsCount = 0) : void 0 !== n[e] && (0 === --this._eventsCount ? this._events = Object.create(null) : delete n[e]), this;
                if (0 === arguments.length) {
                    var r, o = Object.keys(n);
                    for (i = 0; i < o.length; ++i) "removeListener" !== (r = o[i]) && this.removeAllListeners(r);
                    return this.removeAllListeners("removeListener"), this._events = Object.create(null), this._eventsCount = 0, this
                }
                if ("function" === typeof(t = n[e])) this.removeListener(e, t);
                else if (void 0 !== t)
                    for (i = t.length - 1; i >= 0; i--) this.removeListener(e, t[i]);
                return this
            }, o.prototype.listeners = function(e) {
                return d(this, e, !0)
            }, o.prototype.rawListeners = function(e) {
                return d(this, e, !1)
            }, o.listenerCount = function(e, t) {
                return "function" === typeof e.listenerCount ? e.listenerCount(t) : p.call(e, t)
            }, o.prototype.listenerCount = p, o.prototype.eventNames = function() {
                return this._eventsCount > 0 ? t(this._events) : []
            }
        },
        31507: function(e) {
            ! function() {
                var t = {};
                e.exports = t, t.simpleFilter = function(e, n) {
                    return n.filter((function(n) {
                        return t.test(e, n)
                    }))
                }, t.test = function(e, n) {
                    return null !== t.match(e, n)
                }, t.match = function(e, t, n) {
                    n = n || {};
                    var i, r = 0,
                        o = [],
                        s = t.length,
                        a = 0,
                        u = 0,
                        c = n.pre || "",
                        l = n.post || "",
                        h = n.caseSensitive && t || t.toLowerCase();
                    e = n.caseSensitive && e || e.toLowerCase();
                    for (var d = 0; d < s; d++) i = t[d], h[d] === e[r] ? (i = c + i + l, r += 1, u += 1 + u) : u = 0, a += u, o[o.length] = i;
                    return r === e.length ? (a = h === e ? 1 / 0 : a, {
                        rendered: o.join(""),
                        score: a
                    }) : null
                }, t.filter = function(e, n, i) {
                    return n && 0 !== n.length ? "string" !== typeof e ? n : (i = i || {}, n.reduce((function(n, r, o, s) {
                        var a = r;
                        i.extract && (a = i.extract(r));
                        var u = t.match(e, a, i);
                        return null != u && (n[n.length] = {
                            string: u.rendered,
                            score: u.score,
                            index: o,
                            original: r
                        }), n
                    }), []).sort((function(e, t) {
                        var n = t.score - e.score;
                        return n || e.index - t.index
                    }))) : []
                }
            }()
        },
        62790: function(e, t, n) {
            var i;
            i = function(e) {
                return function(e) {
                    var t = {};

                    function n(i) {
                        if (t[i]) return t[i].exports;
                        var r = t[i] = {
                            i: i,
                            l: !1,
                            exports: {}
                        };
                        return e[i].call(r.exports, r, r.exports, n), r.l = !0, r.exports
                    }
                    return n.m = e, n.c = t, n.d = function(e, t, i) {
                        n.o(e, t) || Object.defineProperty(e, t, {
                            enumerable: !0,
                            get: i
                        })
                    }, n.r = function(e) {
                        "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                            value: "Module"
                        }), Object.defineProperty(e, "__esModule", {
                            value: !0
                        })
                    }, n.t = function(e, t) {
                        if (1 & t && (e = n(e)), 8 & t) return e;
                        if (4 & t && "object" === typeof e && e && e.__esModule) return e;
                        var i = Object.create(null);
                        if (n.r(i), Object.defineProperty(i, "default", {
                                enumerable: !0,
                                value: e
                            }), 2 & t && "string" != typeof e)
                            for (var r in e) n.d(i, r, function(t) {
                                return e[t]
                            }.bind(null, r));
                        return i
                    }, n.n = function(e) {
                        var t = e && e.__esModule ? function() {
                            return e.default
                        } : function() {
                            return e
                        };
                        return n.d(t, "a", t), t
                    }, n.o = function(e, t) {
                        return Object.prototype.hasOwnProperty.call(e, t)
                    }, n.p = "", n(n.s = "./src/react-webcam.tsx")
                }({
                    "./src/react-webcam.tsx": function(e, t, n) {
                        "use strict";
                        n.r(t);
                        var i = n("react"),
                            r = function() {
                                var e = function(t, n) {
                                    return e = Object.setPrototypeOf || {
                                        __proto__: []
                                    }
                                    instanceof Array && function(e, t) {
                                        e.__proto__ = t
                                    } || function(e, t) {
                                        for (var n in t) t.hasOwnProperty(n) && (e[n] = t[n])
                                    }, e(t, n)
                                };
                                return function(t, n) {
                                    function i() {
                                        this.constructor = t
                                    }
                                    e(t, n), t.prototype = null === n ? Object.create(n) : (i.prototype = n.prototype, new i)
                                }
                            }(),
                            o = function() {
                                return o = Object.assign || function(e) {
                                    for (var t, n = 1, i = arguments.length; n < i; n++)
                                        for (var r in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
                                    return e
                                }, o.apply(this, arguments)
                            },
                            s = function(e, t) {
                                var n = {};
                                for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && t.indexOf(i) < 0 && (n[i] = e[i]);
                                if (null != e && "function" === typeof Object.getOwnPropertySymbols) {
                                    var r = 0;
                                    for (i = Object.getOwnPropertySymbols(e); r < i.length; r++) t.indexOf(i[r]) < 0 && Object.prototype.propertyIsEnumerable.call(e, i[r]) && (n[i[r]] = e[i[r]])
                                }
                                return n
                            };

                        function a() {
                            return !(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia)
                        }
                        "undefined" !== typeof window && (void 0 === navigator.mediaDevices && (navigator.mediaDevices = {}), void 0 === navigator.mediaDevices.getUserMedia && (navigator.mediaDevices.getUserMedia = function(e) {
                            var t = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia;
                            return t ? new Promise((function(n, i) {
                                t.call(navigator, e, n, i)
                            })) : Promise.reject(new Error("getUserMedia is not implemented in this browser"))
                        }));
                        var u = function(e) {
                            function t(t) {
                                var n = e.call(this, t) || this;
                                return n.canvas = null, n.ctx = null, n.requestUserMediaId = 0, n.unmounted = !1, n.state = {
                                    hasUserMedia: !1
                                }, n
                            }
                            return r(t, e), t.prototype.componentDidMount = function() {
                                var e = this.state,
                                    t = this.props;
                                this.unmounted = !1, a() ? (e.hasUserMedia || this.requestUserMedia(), t.children && "function" != typeof t.children && console.warn("children must be a function")) : t.onUserMediaError("getUserMedia not supported")
                            }, t.prototype.componentDidUpdate = function(e) {
                                var t = this.props;
                                if (a()) {
                                    var n = JSON.stringify(e.audioConstraints) !== JSON.stringify(t.audioConstraints),
                                        i = JSON.stringify(e.videoConstraints) !== JSON.stringify(t.videoConstraints),
                                        r = e.minScreenshotWidth !== t.minScreenshotWidth,
                                        o = e.minScreenshotHeight !== t.minScreenshotHeight;
                                    (i || r || o) && (this.canvas = null, this.ctx = null), (n || i) && (this.stopAndCleanup(), this.requestUserMedia())
                                } else t.onUserMediaError("getUserMedia not supported")
                            }, t.prototype.componentWillUnmount = function() {
                                this.unmounted = !0, this.stopAndCleanup()
                            }, t.stopMediaStream = function(e) {
                                e && (e.getVideoTracks && e.getAudioTracks ? (e.getVideoTracks().map((function(t) {
                                    e.removeTrack(t), t.stop()
                                })), e.getAudioTracks().map((function(t) {
                                    e.removeTrack(t), t.stop()
                                }))) : e.stop())
                            }, t.prototype.stopAndCleanup = function() {
                                var e = this.state;
                                e.hasUserMedia && (t.stopMediaStream(this.stream), e.src && window.URL.revokeObjectURL(e.src))
                            }, t.prototype.getScreenshot = function(e) {
                                var t = this.state,
                                    n = this.props;
                                if (!t.hasUserMedia) return null;
                                var i = this.getCanvas(e);
                                return i && i.toDataURL(n.screenshotFormat, n.screenshotQuality)
                            }, t.prototype.getCanvas = function(e) {
                                var t = this.state,
                                    n = this.props;
                                if (!this.video) return null;
                                if (!t.hasUserMedia || !this.video.videoHeight) return null;
                                if (!this.ctx) {
                                    var i = this.video.videoWidth,
                                        r = this.video.videoHeight;
                                    if (!this.props.forceScreenshotSourceSize) {
                                        var o = i / r;
                                        r = (i = n.minScreenshotWidth || this.video.clientWidth) / o, n.minScreenshotHeight && r < n.minScreenshotHeight && (i = (r = n.minScreenshotHeight) * o)
                                    }
                                    this.canvas = document.createElement("canvas"), this.canvas.width = (null === e || void 0 === e ? void 0 : e.width) || i, this.canvas.height = (null === e || void 0 === e ? void 0 : e.height) || r, this.ctx = this.canvas.getContext("2d")
                                }
                                var s = this.ctx,
                                    a = this.canvas;
                                return s && a && (n.mirrored && (s.translate(a.width, 0), s.scale(-1, 1)), s.imageSmoothingEnabled = n.imageSmoothing, s.drawImage(this.video, 0, 0, (null === e || void 0 === e ? void 0 : e.width) || a.width, (null === e || void 0 === e ? void 0 : e.height) || a.height), n.mirrored && (s.scale(-1, 1), s.translate(-a.width, 0))), a
                            }, t.prototype.requestUserMedia = function() {
                                var e = this,
                                    n = this.props,
                                    i = function(i, r) {
                                        var o = {
                                            video: "undefined" === typeof r || r
                                        };
                                        n.audio && (o.audio = "undefined" === typeof i || i), e.requestUserMediaId++;
                                        var s = e.requestUserMediaId;
                                        navigator.mediaDevices.getUserMedia(o).then((function(n) {
                                            e.unmounted || s !== e.requestUserMediaId ? t.stopMediaStream(n) : e.handleUserMedia(null, n)
                                        })).catch((function(t) {
                                            e.handleUserMedia(t)
                                        }))
                                    };
                                if ("mediaDevices" in navigator) i(n.audioConstraints, n.videoConstraints);
                                else {
                                    var r = function(e) {
                                            return {
                                                optional: [{
                                                    sourceId: e
                                                }]
                                            }
                                        },
                                        o = function(e) {
                                            var t = e.deviceId;
                                            return "string" === typeof t ? t : Array.isArray(t) && t.length > 0 ? t[0] : "object" === typeof t && t.ideal ? t.ideal : null
                                        };
                                    MediaStreamTrack.getSources((function(e) {
                                        var t = null,
                                            s = null;
                                        e.forEach((function(e) {
                                            "audio" === e.kind ? t = e.id : "video" === e.kind && (s = e.id)
                                        }));
                                        var a = o(n.audioConstraints);
                                        a && (t = a);
                                        var u = o(n.videoConstraints);
                                        u && (s = u), i(r(t), r(s))
                                    }))
                                }
                            }, t.prototype.handleUserMedia = function(e, t) {
                                var n = this.props;
                                if (e || !t) return this.setState({
                                    hasUserMedia: !1
                                }), void n.onUserMediaError(e);
                                this.stream = t;
                                try {
                                    this.video && (this.video.srcObject = t), this.setState({
                                        hasUserMedia: !0
                                    })
                                } catch (i) {
                                    this.setState({
                                        hasUserMedia: !0,
                                        src: window.URL.createObjectURL(t)
                                    })
                                }
                                n.onUserMedia(t)
                            }, t.prototype.render = function() {
                                var e = this,
                                    t = this.state,
                                    n = this.props,
                                    r = n.audio,
                                    a = (n.forceScreenshotSourceSize, n.onUserMedia, n.onUserMediaError, n.screenshotFormat, n.screenshotQuality, n.minScreenshotWidth, n.minScreenshotHeight, n.audioConstraints, n.videoConstraints, n.imageSmoothing, n.mirrored),
                                    u = n.style,
                                    c = void 0 === u ? {} : u,
                                    l = n.children,
                                    h = s(n, ["audio", "forceScreenshotSourceSize", "onUserMedia", "onUserMediaError", "screenshotFormat", "screenshotQuality", "minScreenshotWidth", "minScreenshotHeight", "audioConstraints", "videoConstraints", "imageSmoothing", "mirrored", "style", "children"]),
                                    d = a ? o(o({}, c), {
                                        transform: (c.transform || "") + " scaleX(-1)"
                                    }) : c,
                                    p = {
                                        getScreenshot: this.getScreenshot.bind(this)
                                    };
                                return i.createElement(i.Fragment, null, i.createElement("video", o({
                                    autoPlay: !0,
                                    src: t.src,
                                    muted: !r,
                                    playsInline: !0,
                                    ref: function(t) {
                                        e.video = t
                                    },
                                    style: d
                                }, h)), l && l(p))
                            }, t.defaultProps = {
                                audio: !1,
                                forceScreenshotSourceSize: !1,
                                imageSmoothing: !0,
                                mirrored: !1,
                                onUserMedia: function() {},
                                onUserMediaError: function() {},
                                screenshotFormat: "image/webp",
                                screenshotQuality: .92
                            }, t
                        }(i.Component);
                        t.default = u
                    },
                    react: function(t, n) {
                        t.exports = e
                    }
                }).default
            }, e.exports = i(n(47313))
        },
        93284: function(e) {
            var t, n;
            t = this, n = function() {
                var e = "",
                    t = /^([a-zA-Z]{2,3})(?:[_-]+([a-zA-Z]{3})(?=$|[_-]+))?(?:[_-]+([a-zA-Z]{4})(?=$|[_-]+))?(?:[_-]+([a-zA-Z]{2}|[0-9]{3})(?=$|[_-]+))?/;

                function n(e) {
                    return e.match(t) || []
                }

                function i(t) {
                    return {
                        language: (t = n(t))[1] || e,
                        extlang: t[2] || e,
                        script: t[3] || e,
                        region: t[4] || e
                    }
                }

                function r(e, t, n) {
                    Object.defineProperty(e, t, {
                        value: n,
                        enumerable: !0
                    })
                }

                function o(t, o, s) {
                    function a(i) {
                        return n(i)[t] || e
                    }
                    r(a, "pattern", o), r(i, s, a)
                }
                return o(1, /^[a-zA-Z]{2,3}$/, "language"), o(2, /^[a-zA-Z]{3}$/, "extlang"), o(3, /^[a-zA-Z]{4}$/, "script"), o(4, /^[a-zA-Z]{2}$|^[0-9]{3}$/, "region"), r(i, "split", (function(e) {
                    return n(e).filter((function(e, t) {
                        return e && t
                    }))
                })), i
            }, e.exports ? e.exports = n() : t.subtag = n()
        },
        93215: function(e, t, n) {
            "use strict";
            var i = n(41009);
            e.exports = i, "undefined" !== typeof window && (window.Suggestions = i)
        },
        90908: function(e) {
            "use strict";
            var t = function(e) {
                return this.component = e, this.items = [], this.active = 0, this.wrapper = document.createElement("div"), this.wrapper.className = "suggestions-wrapper", this.element = document.createElement("ul"), this.element.className = "suggestions", this.wrapper.appendChild(this.element), this.selectingListItem = !1, e.el.parentNode.insertBefore(this.wrapper, e.el.nextSibling), this
            };
            t.prototype.show = function() {
                this.element.style.display = "block"
            }, t.prototype.hide = function() {
                this.element.style.display = "none"
            }, t.prototype.add = function(e) {
                this.items.push(e)
            }, t.prototype.clear = function() {
                this.items = [], this.active = 0
            }, t.prototype.isEmpty = function() {
                return !this.items.length
            }, t.prototype.isVisible = function() {
                return "block" === this.element.style.display
            }, t.prototype.draw = function() {
                if (this.element.innerHTML = "", 0 !== this.items.length) {
                    for (var e = 0; e < this.items.length; e++) this.drawItem(this.items[e], this.active === e);
                    this.show()
                } else this.hide()
            }, t.prototype.drawItem = function(e, t) {
                var n = document.createElement("li"),
                    i = document.createElement("a");
                t && (n.className += " active"), i.innerHTML = e.string, n.appendChild(i), this.element.appendChild(n), n.addEventListener("mousedown", function() {
                    this.selectingListItem = !0
                }.bind(this)), n.addEventListener("mouseup", function() {
                    this.handleMouseUp.call(this, e)
                }.bind(this))
            }, t.prototype.handleMouseUp = function(e) {
                this.selectingListItem = !1, this.component.value(e.original), this.clear(), this.draw()
            }, t.prototype.move = function(e) {
                this.active = e, this.draw()
            }, t.prototype.previous = function() {
                this.move(0 === this.active ? this.items.length - 1 : this.active - 1)
            }, t.prototype.next = function() {
                this.move(this.active === this.items.length - 1 ? 0 : this.active + 1)
            }, t.prototype.drawError = function(e) {
                var t = document.createElement("li");
                t.innerHTML = e, this.element.appendChild(t), this.show()
            }, e.exports = t
        },
        41009: function(e, t, n) {
            "use strict";
            var i = n(25307),
                r = n(31507),
                o = n(90908),
                s = function(e, t, n) {
                    return n = n || {}, this.options = i({
                        minLength: 2,
                        limit: 5,
                        filter: !0,
                        hideOnBlur: !0
                    }, n), this.el = e, this.data = t || [], this.list = new o(this), this.query = "", this.selected = null, this.list.draw(), this.el.addEventListener("keyup", function(e) {
                        this.handleKeyUp(e.keyCode)
                    }.bind(this), !1), this.el.addEventListener("keydown", function(e) {
                        this.handleKeyDown(e)
                    }.bind(this)), this.el.addEventListener("focus", function() {
                        this.handleFocus()
                    }.bind(this)), this.el.addEventListener("blur", function() {
                        this.handleBlur()
                    }.bind(this)), this.el.addEventListener("paste", function(e) {
                        this.handlePaste(e)
                    }.bind(this)), this.render = this.options.render ? this.options.render.bind(this) : this.render.bind(this), this.getItemValue = this.options.getItemValue ? this.options.getItemValue.bind(this) : this.getItemValue.bind(this), this
                };
            s.prototype.handleKeyUp = function(e) {
                40 !== e && 38 !== e && 27 !== e && 13 !== e && 9 !== e && this.handleInputChange(this.el.value)
            }, s.prototype.handleKeyDown = function(e) {
                switch (e.keyCode) {
                    case 13:
                    case 9:
                        this.list.isEmpty() || (this.list.isVisible() && e.preventDefault(), this.value(this.list.items[this.list.active].original), this.list.hide());
                        break;
                    case 27:
                        this.list.isEmpty() || this.list.hide();
                        break;
                    case 38:
                        this.list.previous();
                        break;
                    case 40:
                        this.list.next()
                }
            }, s.prototype.handleBlur = function() {
                !this.list.selectingListItem && this.options.hideOnBlur && this.list.hide()
            }, s.prototype.handlePaste = function(e) {
                if (e.clipboardData) this.handleInputChange(e.clipboardData.getData("Text"));
                else {
                    var t = this;
                    setTimeout((function() {
                        t.handleInputChange(e.target.value)
                    }), 100)
                }
            }, s.prototype.handleInputChange = function(e) {
                this.query = this.normalize(e), this.list.clear(), this.query.length < this.options.minLength ? this.list.draw() : this.getCandidates(function(e) {
                    for (var t = 0; t < e.length && (this.list.add(e[t]), t !== this.options.limit - 1); t++);
                    this.list.draw()
                }.bind(this))
            }, s.prototype.handleFocus = function() {
                this.list.isEmpty() || this.list.show(), this.list.selectingListItem = !1
            }, s.prototype.update = function(e) {
                this.data = e, this.handleKeyUp()
            }, s.prototype.clear = function() {
                this.data = [], this.list.clear()
            }, s.prototype.normalize = function(e) {
                return e = e.toLowerCase()
            }, s.prototype.match = function(e, t) {
                return e.indexOf(t) > -1
            }, s.prototype.value = function(e) {
                if (this.selected = e, this.el.value = this.getItemValue(e), document.createEvent) {
                    var t = document.createEvent("HTMLEvents");
                    t.initEvent("change", !0, !1), this.el.dispatchEvent(t)
                } else this.el.fireEvent("onchange")
            }, s.prototype.getCandidates = function(e) {
                var t = {
                    pre: "<strong>",
                    post: "</strong>",
                    extract: function(e) {
                        return this.getItemValue(e)
                    }.bind(this)
                };
                e(this.options.filter ? r.filter(this.query, this.data, t).map(function(e) {
                    return {
                        original: e.original,
                        string: this.render(e.original, e.string)
                    }
                }.bind(this)) : this.data.map(function(e) {
                    return {
                        original: e,
                        string: this.render(e)
                    }
                }.bind(this)))
            }, s.prototype.getItemValue = function(e) {
                return e
            }, s.prototype.render = function(e, t) {
                if (t) return t;
                for (var n = e.original ? this.getItemValue(e.original) : this.getItemValue(e), i = this.normalize(n), r = i.lastIndexOf(this.query); r > -1;) {
                    var o = r + this.query.length;
                    n = n.slice(0, r) + "<strong>" + n.slice(r, o) + "</strong>" + n.slice(o), r = i.slice(0, r).lastIndexOf(this.query)
                }
                return n
            }, s.prototype.renderError = function(e) {
                this.list.drawError(e)
            }, e.exports = s
        },
        25307: function(e) {
            e.exports = function() {
                for (var e = {}, n = 0; n < arguments.length; n++) {
                    var i = arguments[n];
                    for (var r in i) t.call(i, r) && (e[r] = i[r])
                }
                return e
            };
            var t = Object.prototype.hasOwnProperty
        },
        76195: function() {},
        82751: function(e, t, n) {
            "use strict";
            n.d(t, {
                x0: function() {
                    return i
                }
            });
            var i = function() {
                for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 21, t = "", n = crypto.getRandomValues(new Uint8Array(e)); e--;) {
                    var i = 63 & n[e];
                    t += i < 36 ? i.toString(36) : i < 62 ? (i - 26).toString(36).toUpperCase() : i < 63 ? "_" : "-"
                }
                return t
            }
        }
    }
]);