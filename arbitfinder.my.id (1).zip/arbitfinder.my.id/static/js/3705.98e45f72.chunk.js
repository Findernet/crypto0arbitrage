"use strict";
(self.webpackChunkarbitrage_notification = self.webpackChunkarbitrage_notification || []).push([
    [3705], {
        33705: function(a, i, t) {
            t.r(i);
            var e = t(26939);
            i.default = e.g
        }
    }
]);