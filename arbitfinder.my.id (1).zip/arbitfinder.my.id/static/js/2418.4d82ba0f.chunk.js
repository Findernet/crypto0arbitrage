"use strict";
(self.webpackChunkarbitrage_notification = self.webpackChunkarbitrage_notification || []).push([
    [2418], {
        99029: function(e, t, n) {
            n(47313), n(46417)
        },
        90205: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return E
                }
            });
            var r = n(1413),
                i = n(15861),
                s = n(29439),
                o = n(64687),
                a = n.n(o),
                c = n(21933),
                l = n(47313),
                d = n(75627),
                u = n(1432),
                x = n(61113),
                h = n(42832),
                p = n(57829),
                f = n(15082),
                g = n(19536),
                b = n(24537),
                j = n(16429),
                v = n(83929),
                m = n(44758),
                Z = n(34953),
                w = n(32703),
                y = (n(62790), n(34032)),
                S = (n(81627), n(31881), n(42593), n(57367)),
                k = n(62677),
                z = n(67250),
                _ = (n(54285), n(55347)),
                C = n(2311),
                T = n(5239),
                D = (n(71430), n(88669)),
                I = n(17391),
                N = (n(50659), n(13918), n(46417));

            function E(e) {
                var t = e.text,
                    n = void 0 === t ? "" : t,
                    o = (e.formValue, (0, z.Z)("up", "lg")),
                    E = (0, D.xp)(localStorage.getItem("accessToken")),
                    q = (0, y.Ds)().enqueueSnackbar,
                    A = ((0, T.I0)(), (0, l.useContext)(_.f)),
                    F = A.filter,
                    L = A.setFilter,
                    R = (0, l.useState)([]),
                    U = (0, s.Z)(R, 2),
                    P = U[0],
                    B = U[1],
                    W = (0, T.v9)((function(e) {
                        return e.monitoring
                    })).datas;
                (0, l.useEffect)((function() {
                    Array.isArray(W) && B((0, I.hr)(W))
                }), []);
                var O = c.Ry().shape({
                        percentRange: c.IX(),
                        exchanges: c.Ry(),
                        exchange_side: c.IX(),
                        coinName: c.Z_(),
                        lower_volume: c.Rx(),
                        higher_volume: c.Rx(),
                        allowedNetwork: c.Ry()
                    }),
                    G = {
                        percentRange: (null === F || void 0 === F ? void 0 : F.percentRange) || [0, 100],
                        exchanges: (null === F || void 0 === F ? void 0 : F.exchanges) || P,
                        coinName: (null === F || void 0 === F ? void 0 : F.coinName) || "",
                        lower_volume: (null === F || void 0 === F ? void 0 : F.lower_volume) || 0,
                        higher_volume: (null === F || void 0 === F ? void 0 : F.higher_volume) || 0,
                        allowedNetwork: (null === F || void 0 === F ? void 0 : F.allowedNetwork) || {
                            ETH: !0,
                            BSC: !0,
                            BNB: !0,
                            MATIC: !0,
                            SOL: !0,
                            ZKSYNC: !0,
                            ARBITRUM: !0,
                            AVAX: !0,
                            XLM: !0
                        }
                    },
                    H = (0, d.cI)({
                        resolver: (0, u.X)(O),
                        defaultValues: G
                    }),
                    Y = H.control,
                    M = H.reset,
                    V = (H.setError, H.handleSubmit),
                    K = H.register,
                    Q = H.setValue,
                    X = H.getValues,
                    $ = H.formState,
                    J = $.errors,
                    ee = $.isSubmitting,
                    te = function() {
                        var e = (0, i.Z)(a().mark((function e(t) {
                            return a().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        try {
                                            L(t), q("Success!", {
                                                variant: "success"
                                            })
                                        } catch (n) {
                                            console.error(n), M()
                                        }
                                    case 1:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })));
                        return function(t) {
                            return e.apply(this, arguments)
                        }
                    }();
                return (0, N.jsx)(k.Z, {
                    sx: {
                        minWidth: o ? 500 : 320,
                        maxHeight: .75 * window.innerHeight
                    },
                    children: (0, N.jsxs)(S.RV, {
                        methods: H,
                        onSubmit: V(te),
                        children: [(0, N.jsx)(x.Z, {
                            align: "center",
                            variant: "h6",
                            sx: {
                                my: 1
                            },
                            children: n
                        }), (0, N.jsxs)(h.Z, {
                            spacing: 2,
                            children: [(0, N.jsxs)(p.Z, {
                                children: [(0, N.jsx)(x.Z, {
                                    children: "Coin Name Include Word"
                                }), (0, N.jsx)(p.Z, {
                                    sx: {
                                        px: 1
                                    },
                                    children: (0, N.jsx)(f.Z, (0, r.Z)({
                                        fullWidth: !0,
                                        size: "small"
                                    }, K("coinName")))
                                })]
                            }), (0, N.jsx)(g.Z, {}), (0, N.jsxs)(p.Z, {
                                children: [(0, N.jsx)(x.Z, {
                                    children: "Diff(%) Range"
                                }), (0, N.jsx)(p.Z, {
                                    sx: {
                                        px: 3
                                    },
                                    children: (0, N.jsx)(b.ZP, {
                                        disableSwap: !0,
                                        getAriaLabel: function() {
                                            return "Percentage range"
                                        },
                                        defaultValue: G.percentRange,
                                        valueLabelDisplay: "auto",
                                        onChange: function(e, t) {
                                            Q("percentRange", t, {
                                                shouldValidate: !0
                                            })
                                        },
                                        name: "percentRange"
                                    })
                                })]
                            }), (0, N.jsx)(g.Z, {}), (0, N.jsxs)(p.Z, {
                                children: [(0, N.jsx)(x.Z, {
                                    children: "Exclude trade volume under ($)"
                                }), (0, N.jsx)(p.Z, {
                                    sx: {
                                        px: 1,
                                        mt: 2
                                    },
                                    children: (0, N.jsxs)(h.Z, {
                                        direction: "row",
                                        spacing: 1,
                                        children: [(0, N.jsx)(f.Z, (0, r.Z)({
                                            fullWidth: !0,
                                            size: "small",
                                            type: "number",
                                            label: "In Lower Exchange",
                                            InputLabelProps: {
                                                style: {
                                                    color: "#54d62c"
                                                }
                                            }
                                        }, K("lower_volume"))), (0, N.jsx)(f.Z, (0, r.Z)({
                                            fullWidth: !0,
                                            size: "small",
                                            type: "number",
                                            label: "In Higher Exchange",
                                            InputLabelProps: {
                                                style: {
                                                    color: "#ff5954"
                                                }
                                            }
                                        }, K("higher_volume")))]
                                    })
                                })]
                            }), (0, N.jsx)(g.Z, {}), (0, N.jsxs)(p.Z, {
                                children: ["Exchanges:", (0, N.jsx)(d.Qr, {
                                    name: "exchanges",
                                    control: Y,
                                    render: function(e) {
                                        var t = e.field,
                                            n = function(e, t) {
                                                var n = (0, r.Z)({}, X("exchanges"));
                                                if (1 === t.length) {
                                                    n[e] || (n[e] = []);
                                                    var i = n[e].indexOf(t[0]); - 1 === i ? n[e].push(t[0]) : n[e].splice(i, 1), 0 === n[e].length && delete n[e]
                                                } else if (2 === t.length) {
                                                    var s, o;
                                                    null !== (s = n[e]) && void 0 !== s && s.includes(t[0]) || null !== (o = n[e]) && void 0 !== o && o.includes(t[1]) ? n[e] = [] : n[e] = t
                                                }
                                                return n
                                            };
                                        return (0, N.jsx)(j.Z, {
                                            children: P.map((function(e, r) {
                                                var i, s, o, a;
                                                return (0, N.jsxs)("div", {
                                                    children: [(0, N.jsx)(v.Z, {
                                                        control: (0, N.jsx)(m.Z, {
                                                            checked: Boolean((null === (i = t.value[e]) || void 0 === i ? void 0 : i.length) > 1),
                                                            indeterminate: Boolean(1 === (null === (s = t.value[e]) || void 0 === s ? void 0 : s.length)),
                                                            onChange: function() {
                                                                return t.onChange(n(e, ["BUY", "SELL"]))
                                                            }
                                                        }),
                                                        label: e
                                                    }, r), (0, N.jsxs)(p.Z, {
                                                        sx: {
                                                            display: "flex",
                                                            flexDirection: "row",
                                                            ml: 3
                                                        },
                                                        children: [(0, N.jsx)(v.Z, {
                                                            label: "BUY",
                                                            control: (0, N.jsx)(m.Z, {
                                                                checked: Boolean(null === (o = t.value[e]) || void 0 === o ? void 0 : o.includes("BUY")),
                                                                onChange: function() {
                                                                    return t.onChange(n(e, ["BUY"]))
                                                                }
                                                            })
                                                        }), (0, N.jsx)(v.Z, {
                                                            label: "SELL",
                                                            control: (0, N.jsx)(m.Z, {
                                                                checked: Boolean(null === (a = t.value[e]) || void 0 === a ? void 0 : a.includes("SELL")),
                                                                onChange: function() {
                                                                    return t.onChange(n(e, ["SELL"]))
                                                                }
                                                            })
                                                        })]
                                                    })]
                                                }, r)
                                            }))
                                        })
                                    }
                                })]
                            }), (0, N.jsx)(g.Z, {}), (0, N.jsxs)(p.Z, {
                                children: ["Networks: \xa0", (0, N.jsx)(p.Z, {
                                    children: Object.entries(G.allowedNetwork).map((function(e) {
                                        var t = (0, s.Z)(e, 2),
                                            n = t[0],
                                            i = t[1];
                                        return (0, N.jsx)(d.Qr, {
                                            name: "allowedNetwork.".concat(n),
                                            control: Y,
                                            defaultValue: i,
                                            render: function(e) {
                                                var t = e.field;
                                                return (0, N.jsx)(v.Z, {
                                                    control: (0, N.jsx)(m.Z, (0, r.Z)((0, r.Z)({}, t), {}, {
                                                        checked: t.value
                                                    })),
                                                    label: n
                                                }, n)
                                            }
                                        }, n)
                                    }))
                                })]
                            }), (0, N.jsx)(g.Z, {})]
                        }), (0, N.jsx)(h.Z, {
                            direction: "row",
                            alignItems: "center",
                            justifyContent: "space-between",
                            sx: {
                                my: 2
                            },
                            children: !!J.afterSubmit && (0, N.jsx)(Z.Z, {
                                severity: "error",
                                children: J.afterSubmit.message
                            })
                        }), 2 !== (null === E || void 0 === E ? void 0 : E.room) ? (0, N.jsx)(C.tB, {
                            fullWidth: !0,
                            dialogFullWidth: !0,
                            buttonText: "Submit",
                            dialogText: "Select Plan",
                            bgcolor: "grey.350"
                        }) : (0, N.jsx)(w.Z, {
                            fullWidth: !0,
                            size: "large",
                            type: "Submit",
                            variant: "contained",
                            loading: ee,
                            sx: {
                                my: 2
                            },
                            children: "Submit"
                        })]
                    })
                })
            }
        },
        13047: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return E
                }
            });
            var r = n(29439),
                i = n(47313),
                s = n(19860),
                o = n(57829),
                a = n(73428),
                c = n(9019),
                l = n(61113),
                d = n(83213),
                u = n(42832),
                x = n(69099),
                h = (n(36804), n(76221), n(5239)),
                p = n(49130),
                f = (n(66429), n(54285), n(17391)),
                g = n(88669),
                b = (n(84905), n(71609)),
                j = (n(42593), n(86853), n(3484), n(62677), n(28100), n(73112), n(90205), n(58096)),
                v = n(2311),
                m = n(55347),
                Z = n(28045),
                w = (n(99029), n(46417));
            var y = window.innerHeight < window.innerWidth,
                S = .1,
                k = y ? 120 : 70,
                z = y ? 150 : 110,
                _ = y ? 150 : 110,
                C = y ? 15 : 13,
                T = y ? 14 : 12,
                D = y ? 11 : 9,
                I = y ? 13 : 12,
                N = y ? 13 : 12;

            function E(e) {
                var t = e.fixed,
                    n = void 0 === t || t,
                    E = e.limit,
                    q = void 0 === E ? 0 : E,
                    A = (e.unregistered, (0, s.Z)(), (0, h.I0)()),
                    F = ((0, i.useRef)(null), (0, i.useContext)(m.f)),
                    L = F.filter,
                    R = F.setFilter,
                    U = (0, h.v9)((function(e) {
                        return e.monitoring
                    })),
                    P = U.datas,
                    B = U.timestamp,
                    W = q > 0 ? P.slice(0, q) : P,
                    O = (0, g.xp)(localStorage.getItem("accessToken")),
                    G = !(2 === (null === O || void 0 === O ? void 0 : O.room));
                if (null !== P && void 0 !== P && P.id) {
                    var H, Y = new Date(P.id);
                    "".concat(null === (H = new Date(P.id - 6e4 * Y.getTimezoneOffset())) || void 0 === H ? void 0 : H.toISOString()).split("T")
                }
                var M = (0, i.useState)([]),
                    V = (0, r.Z)(M, 2),
                    K = V[0],
                    Q = V[1];
                (0, i.useEffect)((function() {
                    Q(G ? W : (0, f.cm)({
                        filter: L,
                        arb_data: W,
                        user: O
                    }))
                }), []), (0, i.useEffect)((function() {
                    (!("exchanges" in L) || 0 === Object.keys(null === L || void 0 === L ? void 0 : L.exchanges).length && (null === L || void 0 === L ? void 0 : L.exchanges.constructor) === Object) && R({
                        exchanges: (0, f.$l)(W)
                    }), Q(G ? W : (0, f.cm)({
                        filter: L,
                        arb_data: W,
                        user: O
                    }))
                }), [L, P]);
                var X = (0, i.useState)(null),
                    $ = (0, r.Z)(X, 2);
                $[0], $[1];

                function J(e) {
                    if (e) {
                        var t = e.toString();
                        "number" !== typeof e && (e = parseInt(e, 10)), 10 === t.length && (e *= 1e3);
                        var n = new Date(e + 252e5),
                            r = "".concat(null === n || void 0 === n ? void 0 : n.toDateString()).split(" "),
                            i = "".concat(null === n || void 0 === n ? void 0 : n.toISOString()).split("T");
                        return "".concat(r[2], " ").concat(r[1], " ").concat(i[1].substring(0, 5))
                    }
                    return ""
                }
                var ee = q > 0 ? "Arbitrage Possibility" : "".concat(K.length, " Arbitrage Possibility"),
                    te = 1;
                return n && (te = y ? 7 : 8), (0, w.jsxs)(w.Fragment, {
                    children: [(0, w.jsx)(o.Z, {
                        sx: {
                            width: "100%",
                            position: n ? "fixed" : "static",
                            top: 64,
                            left: 0,
                            zIndex: 3,
                            bgcolor: "grey.100"
                        },
                        children: (0, w.jsx)(j.Z, {
                            title: ee,
                            timestamp: B
                        })
                    }), (0, w.jsx)(a.Z, {
                        children: (0, w.jsx)(c.ZP, {
                            container: !0,
                            sx: {
                                p: 0,
                                mt: te
                            },
                            children: K.length > 0 ? K.map((function(e, t) {
                                var n, r;
                                e.arbitrage_data[0].higher_time && (n = J(e.arbitrage_data[0].higher_time)), e.arbitrage_data[0].lower_time && (r = J(e.arbitrage_data[0].lower_time));
                                var s = q > 0 ? 12 : 6,
                                    o = q > 0 ? 12 : 4;
                                return 2 === K.length ? o = 6 : 1 === K.length && (o = 12), (0, w.jsx)(i.Fragment, {
                                    children: (0, w.jsx)(c.ZP, {
                                        item: !0,
                                        xs: 12,
                                        sm: s,
                                        md: o,
                                        alignItems: "flex-start",
                                        sx: {
                                            p: 2
                                        },
                                        children: (0, w.jsx)(a.Z, {
                                            sx: {
                                                p: 1,
                                                border: 1,
                                                borderRadius: "10px",
                                                borderColor: "grey.300",
                                                boxShadow: "rgba(0, 200, 0, 0.10) 0px 0px 5px 5px, rgba(0, 0, 0, 0.05) 0px 0px 10px 15px"
                                            },
                                            children: (0, w.jsx)("table", {
                                                style: {
                                                    width: "100%",
                                                    borderCollapse: "collapse"
                                                },
                                                children: (0, w.jsxs)("tbody", {
                                                    children: [(0, w.jsxs)("tr", {
                                                        children: [(0, w.jsx)("td", {
                                                            children: (0, w.jsx)(l.Z, {
                                                                variant: "h6",
                                                                sx: {
                                                                    fontSize: C
                                                                },
                                                                children: e.asset
                                                            })
                                                        }), (0, w.jsx)("td", {
                                                            children: (0, w.jsxs)(l.Z, {
                                                                variant: "subtitle2",
                                                                sx: {
                                                                    fontSize: T
                                                                },
                                                                children: ["Difference : ", e.arbitrage_data[0].diffP, "% "]
                                                            })
                                                        }), (0, w.jsx)("td", {
                                                            children: (0, w.jsxs)(b.Z, {
                                                                dialogFullWidth: !0,
                                                                size: "small",
                                                                buttonText: "Detail",
                                                                variant: "outlined",
                                                                onPress: function() {
                                                                    A((0, p.a)(e))
                                                                },
                                                                children: [" ", (0, w.jsx)(Z.Z, {}), " "]
                                                            })
                                                        })]
                                                    }), (0, w.jsxs)("tr", {
                                                        style: {
                                                            borderTop: "1px solid #DFE3E8",
                                                            borderBottom: "1px solid #DFE3E8"
                                                        },
                                                        children: [(0, w.jsx)("td", {
                                                            children: (0, w.jsx)(l.Z, {
                                                                variant: "button",
                                                                sx: {
                                                                    fontSize: T,
                                                                    color: "error.main"
                                                                },
                                                                children: "HIGH"
                                                            })
                                                        }), (0, w.jsx)("td", {
                                                            children: (0, w.jsx)(d.Z, {
                                                                sx: {
                                                                    mx: S,
                                                                    width: k
                                                                },
                                                                primary: (0, w.jsxs)(l.Z, {
                                                                    variant: "body1",
                                                                    sx: {
                                                                        fontSize: D
                                                                    },
                                                                    children: ["Price: (", e.arbitrage_data[0].higher_quoteAsset, ")"]
                                                                }),
                                                                secondary: (0, w.jsx)(l.Z, {
                                                                    variant: "body1",
                                                                    sx: {
                                                                        fontSize: D
                                                                    },
                                                                    children: (0, w.jsx)("b", {
                                                                        children: e.arbitrage_data[0].higher_price
                                                                    })
                                                                }),
                                                                disableTypography: !0
                                                            })
                                                        }), (0, w.jsx)("td", {
                                                            children: (0, w.jsx)(d.Z, {
                                                                sx: {
                                                                    mx: S,
                                                                    width: z
                                                                },
                                                                primary: (0, w.jsxs)(u.Z, {
                                                                    direction: "row",
                                                                    spacing: 0,
                                                                    children: [(0, w.jsxs)(l.Z, {
                                                                        variant: "body1",
                                                                        sx: {
                                                                            fontSize: N
                                                                        },
                                                                        children: [e.arbitrage_data[0].higher, "\xa0"]
                                                                    }), (0, w.jsxs)(l.Z, {
                                                                        variant: "body1",
                                                                        sx: {
                                                                            fontSize: N
                                                                        },
                                                                        children: [e.arbitrage_data[0].higher_quoteAsset, " "]
                                                                    })]
                                                                }),
                                                                secondary: (0, w.jsx)(l.Z, {
                                                                    sx: {
                                                                        fontSize: D
                                                                    },
                                                                    variant: "caption",
                                                                    children: n
                                                                }),
                                                                disableTypography: !0
                                                            })
                                                        })]
                                                    }), (0, w.jsxs)("tr", {
                                                        children: [(0, w.jsx)("td", {
                                                            children: (0, w.jsx)(l.Z, {
                                                                variant: "button",
                                                                sx: {
                                                                    fontSize: T,
                                                                    color: "success.main"
                                                                },
                                                                children: "LOW"
                                                            })
                                                        }), (0, w.jsx)("td", {
                                                            children: (0, w.jsx)(d.Z, {
                                                                primary: (0, w.jsxs)(l.Z, {
                                                                    variant: "body1",
                                                                    sx: {
                                                                        fontSize: D
                                                                    },
                                                                    children: ["Price: (", e.arbitrage_data[0].lower_quoteAsset, ")"]
                                                                }),
                                                                secondary: (0, w.jsx)(l.Z, {
                                                                    variant: "body1",
                                                                    sx: {
                                                                        fontSize: D
                                                                    },
                                                                    children: (0, w.jsx)("b", {
                                                                        children: e.arbitrage_data[0].lower_price
                                                                    })
                                                                }),
                                                                disableTypography: !0
                                                            })
                                                        }), (0, w.jsx)("td", {
                                                            children: (0, w.jsx)(d.Z, {
                                                                sx: {
                                                                    mx: S,
                                                                    width: _
                                                                },
                                                                primary: (0, w.jsxs)(u.Z, {
                                                                    direction: "row",
                                                                    spacing: 0,
                                                                    children: [(0, w.jsxs)(l.Z, {
                                                                        variant: "body1",
                                                                        sx: {
                                                                            fontSize: I
                                                                        },
                                                                        children: [e.arbitrage_data[0].lower, "\xa0"]
                                                                    }), (0, w.jsx)(l.Z, {
                                                                        variant: "body1",
                                                                        sx: {
                                                                            fontSize: I - 1
                                                                        },
                                                                        children: e.arbitrage_data[0].lower_quoteAsset
                                                                    })]
                                                                }),
                                                                secondary: (0, w.jsx)(l.Z, {
                                                                    sx: {
                                                                        fontSize: D
                                                                    },
                                                                    variant: "caption",
                                                                    children: r
                                                                }),
                                                                disableTypography: !0
                                                            })
                                                        })]
                                                    })]
                                                })
                                            })
                                        })
                                    })
                                }, t)
                            })) : " "
                        })
                    }), (0, w.jsx)(o.Z, {
                        sx: {
                            display: "flex",
                            alignItems: "center",
                            flexDirection: "column",
                            py: 1
                        },
                        children: G ? (0, w.jsx)(v.tB, {
                            buttonText: " More data ... ",
                            bgcolor: "grey.350"
                        }) : (0, w.jsx)(x.Z, {
                            onClick: function() {
                                window.scrollTo({
                                    top: 0,
                                    left: 0,
                                    behavior: "smooth"
                                })
                            },
                            children: " Back to top"
                        })
                    })]
                })
            }
        },
        58096: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return j
                }
            });
            var r = n(1413),
                i = n(47313),
                s = n(54641),
                o = n(57829),
                a = n(61113),
                c = n(78770),
                l = n(3789),
                d = n(5239),
                u = n(84905),
                x = n(42593),
                h = n(90205),
                p = n(2311),
                f = n(88669),
                g = (n(54285), n(31848)),
                b = n(46417);

            function j(e) {
                var t = e.title,
                    n = e.timestamp,
                    j = window.innerHeight < window.innerWidth,
                    v = ((0, d.I0)(), (0, i.useContext)(g.z)),
                    m = v.preference,
                    Z = v.setPreference,
                    w = (null === m || void 0 === m ? void 0 : m.view) || "1",
                    y = ["", ""];
                if (n) {
                    var S = new Date(n);
                    y = "".concat(new Date(n - 6e4 * S.getTimezoneOffset()).toISOString()).split("T")
                }
                var k = (0, f.xp)(localStorage.getItem("accessToken")),
                    z = "Last Update :".concat(y[0], " ").concat(y[1].substring(0, 8)),
                    _ = !(2 === (null === k || void 0 === k ? void 0 : k.room)),
                    C = j ? 13 : 10,
                    T = j ? 11 : 8;
                return (0, b.jsx)(s.Z, {
                    sx: {
                        mb: 1,
                        py: 0,
                        px: 1,
                        left: 0,
                        zIndex: 10
                    },
                    title: (0, b.jsxs)(o.Z, {
                        sx: {
                            display: "inline-flex",
                            flexDirection: "column"
                        },
                        children: [(0, b.jsxs)(a.Z, {
                            variant: "button",
                            children: [" ", t, " "]
                        }), _ ? (0, b.jsxs)("div", {
                            children: [(0, b.jsxs)(a.Z, {
                                variant: "button",
                                sx: {
                                    fontSize: T
                                },
                                children: ["Last Update : ".concat(y[0], " "), (0, b.jsxs)(a.Z, {
                                    variant: "button",
                                    sx: {
                                        color: "error.main",
                                        fontSize: T
                                    },
                                    children: [y[1].substring(0, 8), " Not Realtime"]
                                })]
                            }), " ", (0, b.jsx)("br", {}), (0, b.jsxs)(a.Z, {
                                variant: "button",
                                sx: {
                                    fontSize: T
                                },
                                children: ["Subscribe to get full & realtime data ", (0, b.jsx)(p.tB, {
                                    sx: {
                                        p: 0,
                                        minWidth: 0,
                                        width: "fit-content",
                                        fontSize: T + 1
                                    },
                                    size: "small",
                                    variant: "text",
                                    buttonText: "here",
                                    dialogText: "Select Plan",
                                    bgcolor: "grey.350"
                                }), " "]
                            })]
                        }) : (0, b.jsx)(a.Z, {
                            variant: "button",
                            sx: {
                                fontSize: C
                            },
                            children: z
                        })]
                    }),
                    action: (0, b.jsxs)(o.Z, {
                        sx: {
                            mt: .5,
                            display: "inline-flex",
                            flexDirection: j ? "row-reverse" : "column"
                        },
                        children: [(0, b.jsx)(p.tB, {
                            sx: {
                                m: .5
                            },
                            color: "warning",
                            size: "small",
                            buttonText: "Buy Premium",
                            dialogText: "Select Plan",
                            bgcolor: "grey.350",
                            startIcon: (0, b.jsx)(x.Z, {
                                icon: "eva:shopping-cart-outline"
                            })
                        }), (0, b.jsxs)(o.Z, {
                            sx: {
                                display: "flex",
                                flexDirection: "row"
                            },
                            children: [(0, b.jsxs)(c.Z, {
                                size: "small",
                                value: w,
                                exclusive: !0,
                                onChange: function(e, t) {
                                    Z((0, r.Z)((0, r.Z)({}, m), {}, {
                                        view: t
                                    }))
                                },
                                "aria-label": "text alignment",
                                children: [(0, b.jsx)(l.Z, {
                                    value: "1",
                                    "aria-label": "left aligned",
                                    children: (0, b.jsx)(x.Z, {
                                        icon: "ant-design:border-outlined"
                                    })
                                }), (0, b.jsx)(l.Z, {
                                    value: "2",
                                    "aria-label": "centered",
                                    children: (0, b.jsx)(x.Z, {
                                        icon: "ant-design:bars-outlined"
                                    })
                                })]
                            }), (0, b.jsx)(u.Z, {
                                size: "small",
                                sx: {
                                    m: .5,
                                    fontSize: C
                                },
                                text: "Filter",
                                startIcon: (0, b.jsx)(x.Z, {
                                    icon: "ant-design:filter-twotone"
                                }),
                                children: (0, b.jsx)(h.Z, {})
                            })]
                        })]
                    })
                })
            }
        },
        60933: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return U
                }
            });
            var r = n(29439),
                i = n(47313),
                s = n(19860),
                o = n(57829),
                a = n(48310),
                c = n(67216),
                l = n(83213),
                d = n(61113),
                u = n(73428),
                x = n(42832),
                h = n(69099),
                p = n(5239),
                f = n(49130),
                g = (n(54285), n(17391)),
                b = n(88669),
                j = n(71609),
                v = (n(42593), n(99029), n(58096)),
                m = n(2311),
                Z = n(55347),
                w = n(28045),
                y = n(46417);
            var S = "rgba(69, 219, 22, 1)",
                k = "rgba(240, 48, 81, 1)";
            var z = window.innerHeight < window.innerWidth,
                _ = .1,
                C = z ? 90 : 50,
                T = z ? 110 : 70,
                D = z ? 150 : 80,
                I = z ? 150 : 80,
                N = z ? 90 : 60,
                E = z ? 17 : 11,
                q = z ? 18 : 12,
                A = z ? 11 : 9,
                F = z ? 16 : 11,
                L = z ? 16 : 11,
                R = z ? 16 : 11;

            function U(e) {
                var t = e.fixed,
                    n = void 0 === t || t,
                    z = e.limit,
                    U = void 0 === z ? 0 : z,
                    P = e.unregistered,
                    B = ((0, s.Z)(), (0, p.I0)()),
                    W = (0, b.xp)(localStorage.getItem("accessToken")),
                    O = !(2 === (null === W || void 0 === W ? void 0 : W.room)),
                    G = (0, i.useContext)(Z.f),
                    H = G.filter,
                    Y = G.setFilter,
                    M = (0, p.v9)((function(e) {
                        return e.monitoring
                    })),
                    V = M.datas,
                    K = M.timestamp,
                    Q = U > 0 ? V.slice(0, U) : V;
                if (null !== V && void 0 !== V && V.id) {
                    var X, $ = new Date(V.id);
                    "".concat(null === (X = new Date(V.id - 6e4 * $.getTimezoneOffset())) || void 0 === X ? void 0 : X.toISOString()).split("T")
                }
                var J = (0, i.useState)([]),
                    ee = (0, r.Z)(J, 2),
                    te = ee[0],
                    ne = ee[1];
                (0, i.useEffect)((function() {
                    ne(O ? Q : (0, g.cm)({
                        filter: H,
                        arb_data: Q,
                        user: W
                    }))
                }), []), (0, i.useEffect)((function() {
                    (!("exchanges" in H) || 0 === Object.keys(null === H || void 0 === H ? void 0 : H.exchanges).length && (null === H || void 0 === H ? void 0 : H.exchanges.constructor) === Object) && Y({
                        exchanges: (0, g.$l)(Q)
                    }), ne(O ? Q : (0, g.cm)({
                        filter: H,
                        arb_data: Q,
                        user: W
                    }))
                }), [H, V]);
                var re = (0, i.useState)(null),
                    ie = (0, r.Z)(re, 2);
                ie[0], ie[1];

                function se(e) {
                    if (e) {
                        var t = e.toString();
                        "number" !== typeof e && (e = parseInt(e, 10)), 10 === t.length && (e *= 1e3);
                        var n = new Date(e + 252e5),
                            r = "".concat(null === n || void 0 === n ? void 0 : n.toDateString()).split(" "),
                            i = "".concat(null === n || void 0 === n ? void 0 : n.toISOString()).split("T");
                        return "".concat(r[2], " ").concat(r[1], " ").concat(i[1].substring(0, 5))
                    }
                    return ""
                }
                var oe = U > 0 ? "Arbitrage Possibility" : "".concat(te.length, " Arbitrage Possibility");
                return (0, y.jsxs)(y.Fragment, {
                    children: [(0, y.jsxs)(o.Z, {
                        sx: {
                            position: n ? "fixed" : "static",
                            top: 64,
                            zIndex: 3,
                            bgcolor: "grey.100"
                        },
                        children: [(0, y.jsx)(v.Z, {
                            title: oe,
                            timestamp: K
                        }), (0, y.jsx)(a.Z, {
                            sx: {
                                p: 0
                            },
                            children: (0, y.jsxs)(c.ZP, {
                                alignItems: "flex-start",
                                sx: {
                                    bgcolor: "grey.200",
                                    px: 1,
                                    height: 50
                                },
                                children: [(0, y.jsx)(l.Z, {
                                    primary: (0, y.jsx)(d.Z, {
                                        variant: "button",
                                        sx: {
                                            fontSize: E
                                        },
                                        children: "Coin"
                                    }),
                                    sx: {
                                        mx: _,
                                        width: C
                                    }
                                }), (0, y.jsx)(l.Z, {
                                    primary: (0, y.jsx)(d.Z, {
                                        variant: "button",
                                        sx: {
                                            fontSize: q
                                        },
                                        children: "Difference"
                                    }),
                                    sx: {
                                        mx: _,
                                        width: T
                                    }
                                }), (0, y.jsx)(l.Z, {
                                    primary: (0, y.jsx)(d.Z, {
                                        variant: "button",
                                        sx: {
                                            fontSize: L,
                                            color: S
                                        },
                                        children: "LOW At"
                                    }),
                                    sx: {
                                        mx: _,
                                        width: I
                                    }
                                }), (0, y.jsx)(l.Z, {
                                    primary: (0, y.jsx)(d.Z, {
                                        variant: "button",
                                        sx: {
                                            fontSize: F,
                                            color: k
                                        },
                                        children: "HIGH At"
                                    }),
                                    sx: {
                                        mx: _,
                                        width: D
                                    }
                                }), (0, y.jsx)(l.Z, {
                                    primary: (0, y.jsx)(d.Z, {
                                        variant: "button",
                                        sx: {
                                            fontSize: R
                                        },
                                        children: "Action"
                                    }),
                                    sx: {
                                        mx: _,
                                        width: N
                                    }
                                })]
                            })
                        })]
                    }), (0, y.jsx)(u.Z, {
                        children: (0, y.jsx)(a.Z, {
                            sx: {
                                p: 0,
                                mt: n ? 14 : 1
                            },
                            children: te.length > 0 ? te.map((function(e, t) {
                                var n, r;
                                return e.arbitrage_data[0].higher_time && (n = se(e.arbitrage_data[0].higher_time)), e.arbitrage_data[0].lower_time && (r = se(e.arbitrage_data[0].lower_time)), (0, y.jsx)(i.Fragment, {
                                    children: (0, y.jsxs)(c.ZP, {
                                        alignItems: "flex-start",
                                        sx: {
                                            p: 1,
                                            borderBottom: 1,
                                            borderColor: "grey.300"
                                        },
                                        children: [(0, y.jsx)(l.Z, {
                                            sx: {
                                                mx: _,
                                                width: C
                                            },
                                            primary: (0, y.jsx)(d.Z, {
                                                variant: "body1",
                                                sx: {
                                                    fontSize: E
                                                },
                                                children: e.asset
                                            }),
                                            disableTypography: !0
                                        }), (0, y.jsx)(l.Z, {
                                            sx: {
                                                mx: _,
                                                width: T
                                            },
                                            primary: (0, y.jsxs)(d.Z, {
                                                variant: "subtitle2",
                                                sx: {
                                                    fontSize: q
                                                },
                                                children: [e.arbitrage_data[0].diffP, "%"]
                                            }),
                                            disableTypography: !0
                                        }), (0, y.jsx)(l.Z, {
                                            sx: {
                                                mx: _,
                                                width: I
                                            },
                                            primary: (0, y.jsxs)(x.Z, {
                                                direction: "row",
                                                spacing: 0,
                                                children: [(0, y.jsxs)(d.Z, {
                                                    variant: "body1",
                                                    sx: {
                                                        fontSize: L
                                                    },
                                                    children: [e.arbitrage_data[0].lower, "\xa0"]
                                                }), (0, y.jsx)(d.Z, {
                                                    variant: "body1",
                                                    sx: {
                                                        fontSize: L - 1
                                                    },
                                                    children: e.arbitrage_data[0].lower_quoteAsset
                                                })]
                                            }),
                                            secondary: (0, y.jsx)(d.Z, {
                                                sx: {
                                                    fontSize: A
                                                },
                                                variant: "caption",
                                                children: r
                                            }),
                                            disableTypography: !0
                                        }), (0, y.jsx)(l.Z, {
                                            sx: {
                                                mx: _,
                                                width: D
                                            },
                                            primary: (0, y.jsxs)(x.Z, {
                                                direction: "row",
                                                spacing: 0,
                                                children: [(0, y.jsxs)(d.Z, {
                                                    variant: "body1",
                                                    sx: {
                                                        fontSize: F
                                                    },
                                                    children: [e.arbitrage_data[0].higher, "\xa0"]
                                                }), (0, y.jsx)(d.Z, {
                                                    variant: "body1",
                                                    sx: {
                                                        fontSize: F - 1
                                                    },
                                                    children: e.arbitrage_data[0].higher_quoteAsset
                                                })]
                                            }),
                                            secondary: (0, y.jsx)(d.Z, {
                                                sx: {
                                                    fontSize: A
                                                },
                                                variant: "caption",
                                                children: n
                                            }),
                                            disableTypography: !0
                                        }), (0, y.jsx)(l.Z, {
                                            sx: {
                                                mx: _,
                                                width: N
                                            },
                                            primary: P ? (0, y.jsx)(m.tB, {
                                                fullWidth: !0,
                                                variant: "text",
                                                buttonText: "Detail",
                                                dialogText: "Select Plan",
                                                bgcolor: "grey.350"
                                            }) : (0, y.jsxs)(j.Z, {
                                                fullWidth: !0,
                                                size: "small",
                                                buttonText: "Detail",
                                                variant: "outlined",
                                                onPress: function() {
                                                    B((0, f.a)(e))
                                                },
                                                children: [" ", (0, y.jsx)(w.Z, {}), " "]
                                            }),
                                            disableTypography: !0
                                        })]
                                    })
                                }, t)
                            })) : (0, y.jsxs)(c.ZP, {
                                alignItems: "flex-start",
                                sx: {
                                    p: 1
                                },
                                children: [(0, y.jsx)(l.Z, {
                                    sx: {
                                        mx: _,
                                        width: C
                                    },
                                    primary: (0, y.jsx)(d.Z, {
                                        variant: "body1",
                                        sx: {
                                            fontSize: E
                                        },
                                        children: " "
                                    }),
                                    disableTypography: !0
                                }), (0, y.jsx)(l.Z, {
                                    sx: {
                                        mx: _,
                                        width: T
                                    },
                                    primary: (0, y.jsx)(d.Z, {
                                        variant: "subtitle2",
                                        sx: {
                                            fontSize: q
                                        },
                                        children: " "
                                    }),
                                    secondary: (0, y.jsx)(d.Z, {
                                        variant: "body1",
                                        sx: {
                                            fontSize: A
                                        },
                                        children: " "
                                    }),
                                    disableTypography: !0
                                }), (0, y.jsx)(l.Z, {
                                    sx: {
                                        mx: _,
                                        width: D
                                    },
                                    primary: (0, y.jsxs)(x.Z, {
                                        direction: "row",
                                        spacing: 0,
                                        children: [(0, y.jsx)(d.Z, {
                                            variant: "body1",
                                            sx: {
                                                fontSize: F
                                            },
                                            children: " "
                                        }), (0, y.jsx)(d.Z, {
                                            variant: "body1",
                                            sx: {
                                                fontSize: F - 1
                                            },
                                            children: " "
                                        })]
                                    }),
                                    secondary: (0, y.jsx)(d.Z, {
                                        sx: {
                                            fontSize: A
                                        },
                                        variant: "caption",
                                        children: " "
                                    }),
                                    disableTypography: !0
                                }), (0, y.jsx)(l.Z, {
                                    sx: {
                                        mx: _,
                                        width: I
                                    },
                                    primary: (0, y.jsxs)(x.Z, {
                                        direction: "row",
                                        spacing: 0,
                                        children: [(0, y.jsx)(d.Z, {
                                            variant: "body1",
                                            sx: {
                                                fontSize: L
                                            },
                                            children: " "
                                        }), (0, y.jsx)(d.Z, {
                                            variant: "body1",
                                            sx: {
                                                fontSize: L - 1
                                            },
                                            children: " "
                                        })]
                                    }),
                                    secondary: (0, y.jsx)(d.Z, {
                                        sx: {
                                            fontSize: A
                                        },
                                        variant: "caption",
                                        children: " "
                                    }),
                                    disableTypography: !0
                                }), (0, y.jsx)(l.Z, {
                                    sx: {
                                        mx: _,
                                        width: N
                                    },
                                    primary: (0, y.jsxs)(x.Z, {
                                        direction: "row",
                                        spacing: 0,
                                        children: [(0, y.jsx)(d.Z, {
                                            variant: "body1",
                                            sx: {
                                                fontSize: R
                                            },
                                            children: " "
                                        }), (0, y.jsx)(d.Z, {
                                            variant: "body1",
                                            sx: {
                                                fontSize: R - 1
                                            },
                                            children: " "
                                        })]
                                    }),
                                    secondary: (0, y.jsx)(d.Z, {
                                        sx: {
                                            fontSize: A
                                        },
                                        variant: "caption",
                                        children: " "
                                    }),
                                    disableTypography: !0
                                })]
                            })
                        })
                    }), (0, y.jsx)(o.Z, {
                        sx: {
                            display: "flex",
                            alignItems: "center",
                            flexDirection: "column",
                            py: 1
                        },
                        children: O ? (0, y.jsx)(m.tB, {
                            buttonText: " More data ... ",
                            bgcolor: "grey.350"
                        }) : (0, y.jsx)(h.Z, {
                            onClick: function() {
                                window.scrollTo({
                                    top: 0,
                                    left: 0,
                                    behavior: "smooth"
                                })
                            },
                            children: " Back to top"
                        })
                    })]
                })
            }
        },
        98481: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return w
                }
            });
            var r = n(1413),
                i = n(29439),
                s = n(45987),
                o = n(47313),
                a = n(17592),
                c = n(24076),
                l = n(73428),
                d = n(54641),
                u = n(66835),
                x = n(57861),
                h = n(67478),
                p = n(61113),
                f = (n(36804), n(76221), n(66429)),
                g = n(42593),
                b = (n(86853), n(3484), n(62677), n(73112)),
                j = n(46417),
                v = ["title", "subheader", "tableData", "tableLabels"];
            (0, a.ZP)(c.Z)((function(e) {
                return {
                    "&:nth-of-type(odd)": {
                        backgroundColor: e.theme.palette.action.hover
                    },
                    "&:last-child td, &:last-child th": {
                        border: 0
                    }
                }
            }));

            function m(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                switch (e) {
                    case 1:
                        return "rgba(185, 252, 164, 0.8)";
                    case -1:
                        return "rgba(252, 164, 179, 0.8)";
                    default:
                        return t ? "black" : "transparent"
                }
            }

            function Z(e) {
                switch (e) {
                    case 1:
                        return (0, j.jsx)(g.Z, {
                            sx: {
                                fontSize: 18,
                                color: m(e)
                            },
                            icon: "eva:arrow-circle-up-fill"
                        });
                    case -1:
                        return (0, j.jsx)(g.Z, {
                            sx: {
                                fontSize: 18,
                                color: m(e)
                            },
                            icon: "eva:arrow-circle-down-fill"
                        });
                    default:
                        return (0, j.jsx)(g.Z, {
                            sx: {
                                fontSize: 18
                            },
                            icon: "eva:minus-fill"
                        })
                }
            }

            function w(e) {
                var t = e.title,
                    n = e.subheader,
                    g = e.tableData,
                    m = e.tableLabels,
                    w = (0, s.Z)(e, v),
                    y = (0, o.useState)(""),
                    S = (0, i.Z)(y, 2),
                    k = (S[0], S[1], (0, f.ZP)({
                        defaultOrderBy: "diff",
                        defaultOrder: "desc"
                    })),
                    z = (k.dense, k.page, k.order, k.orderBy, k.rowsPerPage, k.setPage, k.selected, k.setSelected, k.onSelectRow, k.onSelectAllRows, k.onSort, k.onChangeDense, k.onChangePage, k.onChangeRowsPerPage, g);
                var _ = (0, a.ZP)(c.Z)((function(e) {
                        return {
                            "&:nth-of-type(odd)": {
                                backgroundColor: e.theme.palette.grey[100]
                            },
                            "&:last-child td, &:last-child th": {
                                border: 0
                            }
                        }
                    })),
                    C = window.innerHeight < window.innerWidth;
                return (0, j.jsxs)(l.Z, (0, r.Z)((0, r.Z)({}, w), {}, {
                    children: [(0, j.jsx)(d.Z, {
                        title: t,
                        subheader: n,
                        sx: {
                            mb: 3
                        }
                    }), (0, j.jsxs)(u.Z, {
                        size: "small",
                        sx: {
                            transform: C ? void 0 : "scaleX(0.75)",
                            transformOrigin: "left top"
                        },
                        stickyHeader: !0,
                        children: [(0, j.jsx)(b.K, {
                            headLabel: m
                        }), (0, j.jsx)(x.Z, {
                            children: null === z || void 0 === z ? void 0 : z.map((function(e, t) {
                                var n = "",
                                    r = "".concat(new Date(e.higher_time).toISOString()).split("T"),
                                    i = "".concat(new Date(e.lower_time).toISOString()).split("T");
                                try {
                                    n = function(e) {
                                        var t = Date.now() - e;
                                        return t < 6e4 ? "".concat(Math.floor(t / 1e3), "s ago") : t < 36e5 ? "".concat(Math.floor(t / 6e4), "m ago") : t < 864e5 ? "".concat(Math.floor(t / 36e5), "h ago") : t < 2592e6 ? "".concat(Math.floor(t / 864e5), "d ago") : t < 31536e6 ? "".concat(Math.floor(t / 2592e6), "mo ago") : "".concat(Math.floor(t / 31536e6), "y ago")
                                    }(e.timestamp)
                                } catch (s) {
                                    console.log("")
                                }
                                return (0, j.jsxs)(_, {
                                    children: [(0, j.jsx)(h.Z, {
                                        children: e.higher_baseAsset
                                    }), (0, j.jsxs)(h.Z, {
                                        children: [e.diffP, "% ", Z(e.diffStatus)]
                                    }), (0, j.jsx)(h.Z, {
                                        children: (0, j.jsx)(p.Z, {
                                            variant: 0 === e.diffStatus ? "caption" : "subtitle2",
                                            sx: {
                                                fontSize: [10, "!important"]
                                            },
                                            children: n
                                        })
                                    }), (0, j.jsxs)(h.Z, {
                                        children: [e.higher, " - ", e.higher_quoteAsset, " ", Z(e.diffStatusHigher), " ", (0, j.jsx)("br", {}), " ", (0, j.jsxs)(p.Z, {
                                            variant: "caption",
                                            children: [r[0], " ", r[1].substring(0, 8)]
                                        }), " "]
                                    }), (0, j.jsxs)(h.Z, {
                                        children: [e.lower, " - ", e.lower_quoteAsset, " ", Z(e.diffStatusLower), " ", (0, j.jsx)("br", {}), " ", (0, j.jsxs)(p.Z, {
                                            variant: "caption",
                                            children: [i[0], " ", i[1].substring(0, 8)]
                                        }), " "]
                                    })]
                                }, t)
                            }))
                        })]
                    })]
                }))
            }
        },
        28045: function(e, t, n) {
            n.d(t, {
                Z: function() {
                    return ee
                }
            });
            var r = n(1413),
                i = n(29439),
                s = n(36459),
                o = n(47313),
                a = n(9019),
                c = n(73428),
                l = n(57829),
                d = n(61113),
                u = n(42832),
                x = n(88669),
                h = (n(54285), n(5239)),
                p = (n(62677), n(42593)),
                f = n(93433),
                g = n(15861),
                b = n(64687),
                j = n.n(b),
                v = n(31881),
                m = n.n(v),
                Z = n(85077);

            function w(e) {
                return y.apply(this, arguments)
            }

            function y() {
                return (y = (0, g.Z)(j().mark((function e(t) {
                    var n, i, s, o;
                    return j().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = t.url, i = t.method, s = t.data, e.prev = 1, e.next = 4, m()((0, r.Z)({
                                    method: i,
                                    url: n,
                                    headers: {
                                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36",
                                        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
                                        "Accept-Language": "en-US,en;q=0.9",
                                        "Accept-Encoding": "gzip, deflate"
                                    },
                                    withCredentials: !1
                                }, "GET" === i ? {
                                    params: (0, r.Z)({}, s)
                                } : {
                                    data: (0, r.Z)({}, s)
                                })).then((function(e) {
                                    return null === e || void 0 === e ? void 0 : e.data
                                }));
                            case 4:
                                o = e.sent, e.next = 11;
                                break;
                            case 7:
                                e.prev = 7, e.t0 = e.catch(1), console.log(e.t0), console.log(o);
                            case 11:
                                return e.abrupt("return", o);
                            case 12:
                            case "end":
                                return e.stop()
                        }
                    }), e, null, [
                        [1, 7]
                    ])
                })))).apply(this, arguments)
            }

            function S(e) {
                return k.apply(this, arguments)
            }

            function k() {
                return (k = (0, g.Z)(j().mark((function e(t) {
                    var n, i, s, o, a;
                    return j().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = t.base, i = t.quote, s = {}, e.prev = 2, o = {
                                    symbol: "".concat(String(n).toLowerCase()).concat(String(i).toLowerCase()),
                                    depth: 10,
                                    type: "step0"
                                }, "GET", e.next = 7, w({
                                    url: "https://www.htx.com/-/x/pro/market/depth",
                                    method: "GET",
                                    data: o
                                });
                            case 7:
                                null !== (a = e.sent) && void 0 !== a && a.tick ? ((s = (0, r.Z)({}, a.tick)).asks.sort((function(e, t) {
                                    return t[0] - e[0]
                                })), s.bids.sort((function(e, t) {
                                    return t[0] - e[0]
                                }))) : console.log("NO TICK", a), e.next = 15;
                                break;
                            case 11:
                                e.prev = 11, e.t0 = e.catch(2), console.log(e.t0), s = void 0;
                            case 15:
                                return e.abrupt("return", s);
                            case 16:
                            case "end":
                                return e.stop()
                        }
                    }), e, null, [
                        [2, 11]
                    ])
                })))).apply(this, arguments)
            }

            function z(e) {
                return _.apply(this, arguments)
            }

            function _() {
                return (_ = (0, g.Z)(j().mark((function e(t) {
                    var n, r, i, s, o, a, c, l;
                    return j().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = t.base, r = t.quote, t.url, i = {}, e.prev = 2, s = {}, o = "".concat(String(n).toLowerCase()).concat(String(r).toLowerCase()), "GET", e.next = 8, w({
                                    url: "https://indodax.com/api/depth/".concat(o),
                                    method: "GET",
                                    data: s
                                });
                            case 8:
                                (a = e.sent) ? (i.asks = null === a || void 0 === a || null === (c = a.sell) || void 0 === c ? void 0 : c.sort((function(e, t) {
                                    return t[0] - e[0]
                                })).slice(-10), i.bids = null === a || void 0 === a || null === (l = a.buy) || void 0 === l ? void 0 : l.sort((function(e, t) {
                                    return t[0] - e[0]
                                })).slice(0, 10)) : console.log("NO TICK"), e.next = 16;
                                break;
                            case 12:
                                e.prev = 12, e.t0 = e.catch(2), console.log(e.t0), i = void 0;
                            case 16:
                                return e.abrupt("return", i);
                            case 17:
                            case "end":
                                return e.stop()
                        }
                    }), e, null, [
                        [2, 12]
                    ])
                })))).apply(this, arguments)
            }

            function C(e) {
                return T.apply(this, arguments)
            }

            function T() {
                return (T = (0, g.Z)(j().mark((function e(t) {
                    var n, r, i, s, o, a;
                    return j().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = t.base, r = t.quote, t.url, i = {}, e.prev = 2, a = {
                                    currency_pair: "".concat(String(n).toLowerCase(), "_").concat(String(r).toLowerCase())
                                }, "GET", e.next = 7, (0, Z.Z)({
                                    url: "/exchange/order_book/gateio",
                                    method: "GET",
                                    params: a
                                }).then((function(e) {
                                    return null === e || void 0 === e ? void 0 : e.data
                                }));
                            case 7:
                                i = e.sent, null !== (s = i) && void 0 !== s && s.bids && null !== (o = i) && void 0 !== o && o.asks ? (i.asks.sort((function(e, t) {
                                    return t[0] - e[0]
                                })), i.bids.sort((function(e, t) {
                                    return t[0] - e[0]
                                }))) : console.log("NO response"), e.next = 15;
                                break;
                            case 11:
                                e.prev = 11, e.t0 = e.catch(2), console.log(e.t0), i = void 0;
                            case 15:
                                return e.abrupt("return", i);
                            case 16:
                            case "end":
                                return e.stop()
                        }
                    }), e, null, [
                        [2, 11]
                    ])
                })))).apply(this, arguments)
            }

            function D(e) {
                return I.apply(this, arguments)
            }

            function I() {
                return (I = (0, g.Z)(j().mark((function e(t) {
                    var n, r, i, s, o;
                    return j().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = t.base, r = t.quote, i = {}, e.prev = 2, s = {
                                    symbol: "".concat(String(n).toUpperCase(), "-").concat(String(r).toUpperCase())
                                }, "GET", e.next = 7, (0, Z.Z)({
                                    url: "/exchange/order_book/kucoin",
                                    method: "GET",
                                    params: s
                                }).then((function(e) {
                                    return null === e || void 0 === e ? void 0 : e.data
                                }));
                            case 7:
                                null !== (o = e.sent) && void 0 !== o && o.bids && null !== o && void 0 !== o && o.asks ? (i.asks = o.asks.sort((function(e, t) {
                                    return t[0] - e[0]
                                })).slice(-10), i.bids = o.bids.sort((function(e, t) {
                                    return t[0] - e[0]
                                })).slice(0, 10)) : console.log("NO response"), e.next = 15;
                                break;
                            case 11:
                                e.prev = 11, e.t0 = e.catch(2), console.log(e.t0), i = void 0;
                            case 15:
                                return e.abrupt("return", i);
                            case 16:
                            case "end":
                                return e.stop()
                        }
                    }), e, null, [
                        [2, 11]
                    ])
                })))).apply(this, arguments)
            }

            function N(e) {
                return E.apply(this, arguments)
            }

            function E() {
                return (E = (0, g.Z)(j().mark((function e(t) {
                    var n, r, i, s, o;
                    return j().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = t.base, r = t.quote, i = {}, e.prev = 2, s = {
                                    symbol: "".concat(String(n).toUpperCase()).concat(String(r).toUpperCase()),
                                    type: "step0",
                                    limit: 10
                                }, "GET", e.next = 7, (0, Z.Z)({
                                    url: "/exchange/order_book/bitget",
                                    method: "GET",
                                    params: s
                                }).then((function(e) {
                                    var t;
                                    return null === e || void 0 === e || null === (t = e.data) || void 0 === t ? void 0 : t.data
                                }));
                            case 7:
                                null !== (o = e.sent) && void 0 !== o && o.bids && null !== o && void 0 !== o && o.asks ? (i.asks = o.asks.sort((function(e, t) {
                                    return t[0] - e[0]
                                })).slice(-10), i.bids = o.bids.sort((function(e, t) {
                                    return t[0] - e[0]
                                })).slice(0, 10)) : console.log("NO response"), e.next = 15;
                                break;
                            case 11:
                                e.prev = 11, e.t0 = e.catch(2), console.log(e.t0), i = void 0;
                            case 15:
                                return e.abrupt("return", i);
                            case 16:
                            case "end":
                                return e.stop()
                        }
                    }), e, null, [
                        [2, 11]
                    ])
                })))).apply(this, arguments)
            }

            function q(e) {
                return A.apply(this, arguments)
            }

            function A() {
                return (A = (0, g.Z)(j().mark((function e(t) {
                    var n, r, i, s, o;
                    return j().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = t.base, r = t.quote, i = {}, e.prev = 2, s = {
                                    instId: "".concat(String(n).toUpperCase(), "-").concat(String(r).toUpperCase()),
                                    sz: 10
                                }, "GET", e.next = 7, w({
                                    url: "https://www.okx.com/api/v5/market/books",
                                    method: "GET",
                                    data: s
                                });
                            case 7:
                                null !== (o = e.sent) && void 0 !== o && o.data[0] ? (i.asks = o.data[0].asks.sort((function(e, t) {
                                    return t[0] - e[0]
                                })), i.bids = o.data[0].bids.sort((function(e, t) {
                                    return t[0] - e[0]
                                }))) : console.log("NO response"), e.next = 15;
                                break;
                            case 11:
                                e.prev = 11, e.t0 = e.catch(2), console.log(e.t0), i = void 0;
                            case 15:
                                return e.abrupt("return", i);
                            case 16:
                            case "end":
                                return e.stop()
                        }
                    }), e, null, [
                        [2, 11]
                    ])
                })))).apply(this, arguments)
            }

            function F(e) {
                return L.apply(this, arguments)
            }

            function L() {
                return (L = (0, g.Z)(j().mark((function e(t) {
                    var n, r, i, s, o;
                    return j().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = t.base, r = t.quote, i = {}, e.prev = 2, s = {
                                    symbol: "".concat(String(n).toUpperCase()).concat(String(r).toUpperCase()),
                                    limit: 10
                                }, "GET", e.next = 7, w({
                                    url: "https://api-gcp.binance.com/api/v3/depth",
                                    method: "GET",
                                    data: s
                                });
                            case 7:
                                null !== (o = e.sent) && void 0 !== o && o.bids && null !== o && void 0 !== o && o.asks ? (i.asks = o.asks.sort((function(e, t) {
                                    return t[0] - e[0]
                                })), i.bids = o.bids.sort((function(e, t) {
                                    return t[0] - e[0]
                                }))) : console.log("NO response"), e.next = 15;
                                break;
                            case 11:
                                e.prev = 11, e.t0 = e.catch(2), console.log(e.t0), i = void 0;
                            case 15:
                                return e.abrupt("return", i);
                            case 16:
                            case "end":
                                return e.stop()
                        }
                    }), e, null, [
                        [2, 11]
                    ])
                })))).apply(this, arguments)
            }

            function R(e) {
                return U.apply(this, arguments)
            }

            function U() {
                return (U = (0, g.Z)(j().mark((function e(t) {
                    var n, r, i, s, o;
                    return j().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = t.base, r = t.quote, i = {}, e.prev = 2, s = {
                                    symbol: "".concat(String(n).toUpperCase(), "_").concat(String(r).toUpperCase()),
                                    limit: 10
                                }, "GET", e.next = 7, (0, Z.Z)({
                                    url: "/exchange/order_book/tokocrypto",
                                    method: "GET",
                                    params: s
                                }).then((function(e) {
                                    return null === e || void 0 === e ? void 0 : e.data
                                }));
                            case 7:
                                null !== (o = e.sent) && void 0 !== o && o.data ? (i.asks = o.data.asks.sort((function(e, t) {
                                    return t[0] - e[0]
                                })), i.bids = o.data.bids.sort((function(e, t) {
                                    return t[0] - e[0]
                                }))) : console.log("NO response"), e.next = 15;
                                break;
                            case 11:
                                e.prev = 11, e.t0 = e.catch(2), console.log(e.t0), i = void 0;
                            case 15:
                                return e.abrupt("return", i);
                            case 16:
                            case "end":
                                return e.stop()
                        }
                    }), e, null, [
                        [2, 11]
                    ])
                })))).apply(this, arguments)
            }

            function P(e) {
                return B.apply(this, arguments)
            }

            function B() {
                return (B = (0, g.Z)(j().mark((function e(t) {
                    var n, r, i, s, o;
                    return j().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = t.base, r = t.quote, i = {}, e.prev = 2, s = {
                                    symbol: "".concat(String(n).toUpperCase()).concat(String(r).toUpperCase()),
                                    limit: 10,
                                    category: "spot"
                                }, "GET", e.next = 7, w({
                                    url: "https://api.bybit.com/v5/market/orderbook",
                                    method: "GET",
                                    data: s
                                });
                            case 7:
                                null !== (o = e.sent) && void 0 !== o && o.result ? (i.asks = o.result.a.sort((function(e, t) {
                                    return t[0] - e[0]
                                })), i.bids = o.result.b.sort((function(e, t) {
                                    return t[0] - e[0]
                                }))) : console.log("NO response"), e.next = 15;
                                break;
                            case 11:
                                e.prev = 11, e.t0 = e.catch(2), console.log(e.t0), i = void 0;
                            case 15:
                                return e.abrupt("return", i);
                            case 16:
                            case "end":
                                return e.stop()
                        }
                    }), e, null, [
                        [2, 11]
                    ])
                })))).apply(this, arguments)
            }

            function W(e) {
                return O.apply(this, arguments)
            }

            function O() {
                return (O = (0, g.Z)(j().mark((function e(t) {
                    var n, r, i, s, o, a;
                    return j().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = t.base, r = t.quote, i = {}, e.prev = 2, o = {
                                    symbol: "".concat(String(n).toUpperCase(), "_").concat(String(r).toUpperCase()),
                                    limit: 10
                                }, "GET", e.next = 7, (0, Z.Z)({
                                    url: "/exchange/order_book/mexc",
                                    method: "GET",
                                    params: o
                                }).then((function(e) {
                                    return null === e || void 0 === e ? void 0 : e.data
                                }));
                            case 7:
                                null !== (a = e.sent) && void 0 !== a && null !== (s = a.data) && void 0 !== s && s.data ? (i.asks = a.data.data.asks.map((function(e) {
                                    return [e.p, e.q]
                                })).sort((function(e, t) {
                                    return t[0] - e[0]
                                })).slice(-10), i.bids = a.data.data.bids.map((function(e) {
                                    return [e.p, e.q]
                                })).sort((function(e, t) {
                                    return t[0] - e[0]
                                })).slice(0, 10)) : console.log("NO response"), e.next = 15;
                                break;
                            case 11:
                                e.prev = 11, e.t0 = e.catch(2), console.log(e.t0), i = void 0;
                            case 15:
                                return e.abrupt("return", i);
                            case 16:
                            case "end":
                                return e.stop()
                        }
                    }), e, null, [
                        [2, 11]
                    ])
                })))).apply(this, arguments)
            }

            function G(e) {
                return H.apply(this, arguments)
            }

            function H() {
                return (H = (0, g.Z)(j().mark((function e(t) {
                    var n, r, i, s, o;
                    return j().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = t.base, r = t.quote, i = {}, e.prev = 2, s = {
                                    market_id: "".concat(String(n).toUpperCase(), "-").concat(String(r).toUpperCase()),
                                    limit: 10
                                }, "GET", e.next = 7, (0, Z.Z)({
                                    url: "/exchange/order_book/probit",
                                    method: "GET",
                                    params: s
                                }).then((function(e) {
                                    return null === e || void 0 === e ? void 0 : e.data
                                }));
                            case 7:
                                (o = e.sent) ? (i = {
                                    asks: [],
                                    bids: []
                                }, o.forEach((function(e) {
                                    "sell" === e.side ? i.asks.push([e.price, e.quantity]) : "buy" === e.side && i.bids.push([e.price, e.quantity])
                                })), i.asks = i.asks.sort((function(e, t) {
                                    return t[0] - e[0]
                                })).slice(-10), i.bids = i.bids.sort((function(e, t) {
                                    return t[0] - e[0]
                                })).slice(0, 10)) : console.log("NO response"), e.next = 15;
                                break;
                            case 11:
                                e.prev = 11, e.t0 = e.catch(2), console.log(e.t0), i = void 0;
                            case 15:
                                return e.abrupt("return", i);
                            case 16:
                            case "end":
                                return e.stop()
                        }
                    }), e, null, [
                        [2, 11]
                    ])
                })))).apply(this, arguments)
            }

            function Y(e) {
                return M.apply(this, arguments)
            }

            function M() {
                return (M = (0, g.Z)(j().mark((function e(t) {
                    var n, r, i, s, o;
                    return j().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = t.base, r = t.quote, i = {}, e.prev = 2, s = {
                                    symbol: "".concat(String(n).toUpperCase(), "_").concat(String(r).toUpperCase()),
                                    limit: 10
                                }, "GET", e.next = 7, w({
                                    url: "https://api-cloud.bitmart.com/spot/quotation/v3/books",
                                    method: "GET",
                                    data: s
                                });
                            case 7:
                                null !== (o = e.sent) && void 0 !== o && o.data ? (i.asks = o.data.asks.sort((function(e, t) {
                                    return t[0] - e[0]
                                })), i.bids = o.data.bids.sort((function(e, t) {
                                    return t[0] - e[0]
                                }))) : console.log("NO response"), e.next = 15;
                                break;
                            case 11:
                                e.prev = 11, e.t0 = e.catch(2), console.log(e.t0), i = void 0;
                            case 15:
                                return e.abrupt("return", i);
                            case 16:
                            case "end":
                                return e.stop()
                        }
                    }), e, null, [
                        [2, 11]
                    ])
                })))).apply(this, arguments)
            }

            function V(e) {
                return K.apply(this, arguments)
            }

            function K() {
                return (K = (0, g.Z)(j().mark((function e(t) {
                    var n, r, i, s, o;
                    return j().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = t.base, r = t.quote, i = {}, e.prev = 2, s = {
                                    symbol: "".concat(String(n).toLowerCase(), "_").concat(String(r).toLowerCase()),
                                    size: 10
                                }, "GET", e.next = 7, (0, Z.Z)({
                                    url: "/exchange/order_book/lbank",
                                    method: "GET",
                                    params: s
                                }).then((function(e) {
                                    return null === e || void 0 === e ? void 0 : e.data
                                }));
                            case 7:
                                null !== (o = e.sent) && void 0 !== o && o.data ? (i.asks = o.data.asks.sort((function(e, t) {
                                    return t[0] - e[0]
                                })), i.bids = o.data.bids.sort((function(e, t) {
                                    return t[0] - e[0]
                                }))) : console.log("NO response"), e.next = 15;
                                break;
                            case 11:
                                e.prev = 11, e.t0 = e.catch(2), console.log(e.t0), i = void 0;
                            case 15:
                                return e.abrupt("return", i);
                            case 16:
                            case "end":
                                return e.stop()
                        }
                    }), e, null, [
                        [2, 11]
                    ])
                })))).apply(this, arguments)
            }
            var Q = n(46417);

            function X(e) {
                var t = e.buy,
                    n = e.sell,
                    r = e.market,
                    s = e.base,
                    a = e.quote,
                    u = e.orderbook_data,
                    x = (0, h.v9)((function(e) {
                        return e.monitoring
                    })).rate,
                    b = (0, o.useState)(!0),
                    v = (0, i.Z)(b, 2),
                    m = v[0],
                    Z = v[1],
                    w = (0, o.useState)(u || {}),
                    y = (0, i.Z)(w, 2),
                    k = y[0],
                    _ = y[1];
                (0, o.useEffect)((function() {
                    function e() {
                        return (e = (0, g.Z)(j().mark((function e() {
                            var t;
                            return j().wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        t = [], r = String(r).toLowerCase().replace(".", ""), e.t0 = r, e.next = "huobi" === e.t0 ? 5 : "indodax" === e.t0 ? 9 : "gateio" === e.t0 ? 13 : "kucoin" === e.t0 ? 17 : "okx" === e.t0 ? 21 : "binance" === e.t0 ? 25 : "tokocrypto" === e.t0 ? 29 : "bybit" === e.t0 ? 33 : "mexc" === e.t0 ? 37 : "probit" === e.t0 ? 41 : "bitmart" === e.t0 ? 45 : "bitget" === e.t0 ? 49 : "lbank" === e.t0 ? 53 : 57;
                                        break;
                                    case 5:
                                        return e.next = 7, S({
                                            base: s,
                                            quote: a
                                        });
                                    case 7:
                                        return t = e.sent, e.abrupt("break", 59);
                                    case 9:
                                        return e.next = 11, z({
                                            base: s,
                                            quote: a
                                        });
                                    case 11:
                                        return t = e.sent, e.abrupt("break", 59);
                                    case 13:
                                        return e.next = 15, C({
                                            base: s,
                                            quote: a
                                        });
                                    case 15:
                                        return t = e.sent, e.abrupt("break", 59);
                                    case 17:
                                        return e.next = 19, D({
                                            base: s,
                                            quote: a
                                        });
                                    case 19:
                                        return t = e.sent, e.abrupt("break", 59);
                                    case 21:
                                        return e.next = 23, q({
                                            base: s,
                                            quote: a
                                        });
                                    case 23:
                                        return t = e.sent, e.abrupt("break", 59);
                                    case 25:
                                        return e.next = 27, F({
                                            base: s,
                                            quote: a
                                        });
                                    case 27:
                                        return t = e.sent, e.abrupt("break", 59);
                                    case 29:
                                        return e.next = 31, R({
                                            base: s,
                                            quote: a
                                        });
                                    case 31:
                                        return t = e.sent, e.abrupt("break", 59);
                                    case 33:
                                        return e.next = 35, P({
                                            base: s,
                                            quote: a
                                        });
                                    case 35:
                                        return t = e.sent, e.abrupt("break", 59);
                                    case 37:
                                        return e.next = 39, W({
                                            base: s,
                                            quote: a
                                        });
                                    case 39:
                                        return t = e.sent, e.abrupt("break", 59);
                                    case 41:
                                        return e.next = 43, G({
                                            base: s,
                                            quote: a
                                        });
                                    case 43:
                                        return t = e.sent, e.abrupt("break", 59);
                                    case 45:
                                        return e.next = 47, Y({
                                            base: s,
                                            quote: a
                                        });
                                    case 47:
                                        return t = e.sent, e.abrupt("break", 59);
                                    case 49:
                                        return e.next = 51, N({
                                            base: s,
                                            quote: a
                                        });
                                    case 51:
                                        return t = e.sent, e.abrupt("break", 59);
                                    case 53:
                                        return e.next = 55, V({
                                            base: s,
                                            quote: a
                                        });
                                    case 55:
                                        return t = e.sent, e.abrupt("break", 59);
                                    case 57:
                                        return t = [], e.abrupt("break", 59);
                                    case 59:
                                        _(t), Z(!1);
                                    case 61:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))).apply(this, arguments)
                    }
                    u || function() {
                        e.apply(this, arguments)
                    }()
                }), []);
                var T = window.innerHeight < window.innerWidth,
                    I = T ? 11 : 7,
                    E = T ? 10 : 8,
                    A = T ? 10 : 8,
                    L = function(e, t, n) {
                        var r;
                        if (null === x || void 0 === x || !x.USDT_IDR) return "Waiting USDT rate...";
                        switch (n) {
                            case "IDR":
                                r = (e / x.USDT_IDR).toFixed(6);
                                break;
                            case "BTC":
                                r = (e * x.BTC_IDR / x.USDT_IDR).toFixed(6);
                                break;
                            default:
                                r = e.toFixed(6)
                        }
                        return r
                    },
                    U = function(e) {
                        return m ? (0, Q.jsx)("tr", {
                            style: {
                                borderBottom: "1pt groove"
                            },
                            children: (0, Q.jsx)("td", {
                                rowSpan: "2",
                                children: (0, Q.jsx)("center", {
                                    children: "Loading..."
                                })
                            })
                        }) : Array.isArray(null === k || void 0 === k ? void 0 : k[e]) ? k[e].length > 0 ? k[e].map((function(e, t) {
                            var n = (0, f.Z)(e);
                            "string" !== typeof n[0] && "string" !== typeof n[1] || (n[0].length > 15 && String(n[0]).substring(0, 15), n[1].length > 15 && String(n[1]).substring(0, 15), n[0] = parseFloat(n[0]), n[1] = parseFloat(n[1]));
                            var r = function(e, t, n) {
                                var r;
                                switch (n) {
                                    case "IDR":
                                        r = (parseFloat(e) * parseFloat(t) / x.USDT_IDR).toFixed(6);
                                        break;
                                    case "BTC":
                                        r = (parseFloat(e) * parseFloat(t) * x.BTC_IDR / x.USDT_IDR).toFixed(6);
                                        break;
                                    default:
                                        r = (parseFloat(e) * parseFloat(t)).toFixed(6)
                                }
                                return r
                            }(n[0], n[1], a);
                            return (0, Q.jsxs)("tr", {
                                style: {
                                    borderBottom: "1pt groove"
                                },
                                children: [(0, Q.jsx)("td", {
                                    children: (0, Q.jsxs)(l.Z, {
                                        display: "flex",
                                        justifyContent: "center",
                                        alignItems: "left",
                                        flexDirection: "column",
                                        children: [(0, Q.jsx)(d.Z, {
                                            variant: "button",
                                            sx: {
                                                fontSize: E
                                            },
                                            children: parseFloat(parseFloat(n[1]).toFixed(2))
                                        }), (0, Q.jsxs)(d.Z, {
                                            variant: "caption",
                                            sx: {
                                                fontSize: A
                                            },
                                            children: ["(", r, ") ", r < 3 && (0, Q.jsx)(p.Z, {
                                                icon: "noto-v1:warning"
                                            }), " "]
                                        })]
                                    })
                                }), (0, Q.jsx)("td", {
                                    style: {
                                        paddingLeft: "5px",
                                        paddingRight: "5px"
                                    },
                                    children: (0, Q.jsxs)(l.Z, {
                                        display: "flex",
                                        justifyContent: "center",
                                        alignItems: "left",
                                        flexDirection: "column",
                                        children: [(0, Q.jsx)(d.Z, {
                                            variant: "button",
                                            sx: {
                                                fontSize: A
                                            },
                                            children: parseFloat(n[0])
                                        }), (0, Q.jsxs)(d.Z, {
                                            variant: "caption",
                                            sx: {
                                                fontSize: A
                                            },
                                            children: ["(", L(n[0], n[1], a), ")"]
                                        })]
                                    })
                                })]
                            }, t)
                        })) : (0, Q.jsx)("tr", {
                            style: {
                                borderBottom: "1pt groove"
                            },
                            children: (0, Q.jsx)("td", {
                                children: "No data for this market"
                            })
                        }) : (0, Q.jsx)("tr", {
                            style: {
                                borderBottom: "1pt groove"
                            },
                            children: (0, Q.jsx)("td", {
                                children: "Failed to get data, please reopen this popup"
                            })
                        })
                    };
                return (0, Q.jsxs)(Q.Fragment, {
                    children: [n ? (0, Q.jsx)(c.Z, {
                        sx: {
                            backgroundColor: "error.light",
                            p: 1,
                            borderBottomLeftRadius: 0,
                            borderBottomRightRadius: 0
                        },
                        children: (0, Q.jsxs)("table", {
                            style: {
                                borderCollapse: "collapse",
                                width: "100%"
                            },
                            children: [(0, Q.jsx)("thead", {
                                children: (0, Q.jsxs)("tr", {
                                    style: {
                                        borderBottom: "1pt solid black"
                                    },
                                    children: [(0, Q.jsx)("td", {
                                        nowrap: "nowrap",
                                        children: (0, Q.jsxs)(l.Z, {
                                            display: "flex",
                                            justifyContent: "center",
                                            alignItems: "left",
                                            flexDirection: "column",
                                            children: [(0, Q.jsx)(d.Z, {
                                                variant: "button",
                                                sx: {
                                                    fontSize: I
                                                },
                                                children: "QTY"
                                            }), (0, Q.jsx)(d.Z, {
                                                variant: "caption",
                                                sx: {
                                                    fontSize: I
                                                },
                                                children: "(total in USDT)"
                                            })]
                                        })
                                    }), (0, Q.jsx)("td", {
                                        style: {
                                            paddingLeft: "5px",
                                            paddingRight: "5px"
                                        },
                                        nowrap: "nowrap",
                                        children: (0, Q.jsxs)(l.Z, {
                                            display: "flex",
                                            justifyContent: "center",
                                            alignItems: "left",
                                            flexDirection: "column",
                                            children: [(0, Q.jsxs)(d.Z, {
                                                variant: "button",
                                                sx: {
                                                    fontSize: I
                                                },
                                                children: ["Price ", s]
                                            }), (0, Q.jsx)(d.Z, {
                                                variant: "caption",
                                                sx: {
                                                    fontSize: I
                                                },
                                                children: "(est. in USDT)"
                                            })]
                                        })
                                    })]
                                })
                            }), (0, Q.jsx)("tbody", {
                                children: U("asks")
                            })]
                        })
                    }) : " ", t ? (0, Q.jsx)(c.Z, {
                        sx: {
                            backgroundColor: "success.light",
                            p: 1,
                            borderTopLeftRadius: 0,
                            borderTopRightRadius: 0
                        },
                        children: (0, Q.jsxs)("table", {
                            style: {
                                borderCollapse: "collapse",
                                width: "100%"
                            },
                            children: [(0, Q.jsx)("thead", {
                                children: (0, Q.jsxs)("tr", {
                                    style: {
                                        borderBottom: "1pt solid black"
                                    },
                                    children: [(0, Q.jsx)("td", {
                                        nowrap: "nowrap",
                                        children: (0, Q.jsxs)(l.Z, {
                                            display: "flex",
                                            justifyContent: "center",
                                            alignItems: "left",
                                            flexDirection: "column",
                                            children: [(0, Q.jsx)(d.Z, {
                                                variant: "button",
                                                sx: {
                                                    fontSize: I
                                                },
                                                children: "QTY"
                                            }), (0, Q.jsx)(d.Z, {
                                                variant: "caption",
                                                sx: {
                                                    fontSize: I
                                                },
                                                children: "(total in USDT)"
                                            })]
                                        })
                                    }), (0, Q.jsx)("td", {
                                        style: {
                                            paddingLeft: "5px",
                                            paddingRight: "5px"
                                        },
                                        nowrap: "nowrap",
                                        children: (0, Q.jsxs)(l.Z, {
                                            display: "flex",
                                            justifyContent: "center",
                                            alignItems: "left",
                                            flexDirection: "column",
                                            children: [(0, Q.jsxs)(d.Z, {
                                                variant: "button",
                                                sx: {
                                                    fontSize: I
                                                },
                                                children: ["Price ", s]
                                            }), (0, Q.jsx)(d.Z, {
                                                variant: "caption",
                                                sx: {
                                                    fontSize: I
                                                },
                                                children: "(est. in USDT)"
                                            })]
                                        })
                                    })]
                                })
                            }), (0, Q.jsx)("tbody", {
                                children: U("bids")
                            })]
                        })
                    }) : " "]
                })
            }

            function $(e) {
                var t = e.buy,
                    n = e.sell,
                    r = (e.market, e.base),
                    s = (e.quote, (0, h.v9)((function(e) {
                        return e.monitoring
                    })).rate, (0, o.useState)(!0)),
                    a = (0, i.Z)(s, 2),
                    u = (a[0], a[1], (0, o.useState)([])),
                    x = (0, i.Z)(u, 2),
                    p = (x[0], x[1], window.innerHeight < window.innerWidth),
                    g = p ? 11 : 7,
                    b = p ? 10 : 8,
                    j = p ? 10 : 8,
                    v = function(e) {
                        var t = "******";
                        return (0, f.Z)(Array(10).keys()).map((function(e, n) {
                            return (0, Q.jsxs)("tr", {
                                style: {
                                    borderBottom: "1pt groove"
                                },
                                children: [(0, Q.jsx)("td", {
                                    children: (0, Q.jsxs)(l.Z, {
                                        display: "flex",
                                        justifyContent: "center",
                                        alignItems: "left",
                                        flexDirection: "column",
                                        children: [(0, Q.jsx)(d.Z, {
                                            variant: "button",
                                            sx: {
                                                fontSize: b
                                            },
                                            children: t
                                        }), (0, Q.jsxs)(d.Z, {
                                            variant: "caption",
                                            sx: {
                                                fontSize: j
                                            },
                                            children: ["(", t, ")"]
                                        })]
                                    })
                                }), (0, Q.jsx)("td", {
                                    style: {
                                        paddingLeft: "5px",
                                        paddingRight: "5px"
                                    },
                                    children: (0, Q.jsxs)(l.Z, {
                                        display: "flex",
                                        justifyContent: "center",
                                        alignItems: "left",
                                        flexDirection: "column",
                                        children: [(0, Q.jsx)(d.Z, {
                                            variant: "button",
                                            sx: {
                                                fontSize: j
                                            },
                                            children: t
                                        }), (0, Q.jsxs)(d.Z, {
                                            variant: "caption",
                                            sx: {
                                                fontSize: j
                                            },
                                            children: ["(", t, ")"]
                                        })]
                                    })
                                })]
                            }, n)
                        }))
                    };
                return (0, Q.jsxs)(Q.Fragment, {
                    children: [n ? (0, Q.jsx)(c.Z, {
                        sx: {
                            backgroundColor: "error.light",
                            p: 1,
                            borderBottomLeftRadius: 0,
                            borderBottomRightRadius: 0
                        },
                        children: (0, Q.jsxs)("table", {
                            style: {
                                borderCollapse: "collapse",
                                width: "100%"
                            },
                            children: [(0, Q.jsx)("thead", {
                                children: (0, Q.jsxs)("tr", {
                                    style: {
                                        borderBottom: "1pt solid black"
                                    },
                                    children: [(0, Q.jsx)("td", {
                                        nowrap: "nowrap",
                                        children: (0, Q.jsxs)(l.Z, {
                                            display: "flex",
                                            justifyContent: "center",
                                            alignItems: "left",
                                            flexDirection: "column",
                                            children: [(0, Q.jsx)(d.Z, {
                                                variant: "button",
                                                sx: {
                                                    fontSize: g
                                                },
                                                children: "QTY"
                                            }), (0, Q.jsx)(d.Z, {
                                                variant: "caption",
                                                sx: {
                                                    fontSize: g
                                                },
                                                children: "(total in USDT)"
                                            })]
                                        })
                                    }), (0, Q.jsx)("td", {
                                        style: {
                                            paddingLeft: "5px",
                                            paddingRight: "5px"
                                        },
                                        nowrap: "nowrap",
                                        children: (0, Q.jsxs)(l.Z, {
                                            display: "flex",
                                            justifyContent: "center",
                                            alignItems: "left",
                                            flexDirection: "column",
                                            children: [(0, Q.jsxs)(d.Z, {
                                                variant: "button",
                                                sx: {
                                                    fontSize: g
                                                },
                                                children: ["Price ", r]
                                            }), (0, Q.jsx)(d.Z, {
                                                variant: "caption",
                                                sx: {
                                                    fontSize: g
                                                },
                                                children: "(est. in USDT)"
                                            })]
                                        })
                                    })]
                                })
                            }), (0, Q.jsx)("tbody", {
                                children: v()
                            })]
                        })
                    }) : " ", t ? (0, Q.jsx)(c.Z, {
                        sx: {
                            backgroundColor: "success.light",
                            p: 1,
                            borderTopLeftRadius: 0,
                            borderTopRightRadius: 0
                        },
                        children: (0, Q.jsxs)("table", {
                            style: {
                                borderCollapse: "collapse",
                                width: "100%"
                            },
                            children: [(0, Q.jsx)("thead", {
                                children: (0, Q.jsxs)("tr", {
                                    style: {
                                        borderBottom: "1pt solid black"
                                    },
                                    children: [(0, Q.jsx)("td", {
                                        nowrap: "nowrap",
                                        children: (0, Q.jsxs)(l.Z, {
                                            display: "flex",
                                            justifyContent: "center",
                                            alignItems: "left",
                                            flexDirection: "column",
                                            children: [(0, Q.jsx)(d.Z, {
                                                variant: "button",
                                                sx: {
                                                    fontSize: g
                                                },
                                                children: "QTY"
                                            }), (0, Q.jsx)(d.Z, {
                                                variant: "caption",
                                                sx: {
                                                    fontSize: g
                                                },
                                                children: "(total in USDT)"
                                            })]
                                        })
                                    }), (0, Q.jsx)("td", {
                                        style: {
                                            paddingLeft: "5px",
                                            paddingRight: "5px"
                                        },
                                        nowrap: "nowrap",
                                        children: (0, Q.jsxs)(l.Z, {
                                            display: "flex",
                                            justifyContent: "center",
                                            alignItems: "left",
                                            flexDirection: "column",
                                            children: [(0, Q.jsxs)(d.Z, {
                                                variant: "button",
                                                sx: {
                                                    fontSize: g
                                                },
                                                children: ["Price ", r]
                                            }), (0, Q.jsx)(d.Z, {
                                                variant: "caption",
                                                sx: {
                                                    fontSize: g
                                                },
                                                children: "(est. in USDT)"
                                            })]
                                        })
                                    })]
                                })
                            }), (0, Q.jsx)("tbody", {
                                children: v()
                            })]
                        })
                    }) : " "]
                })
            }
            var J = function(e) {
                return new Intl.NumberFormat("en-US", {
                    style: "currency",
                    currency: "USD"
                }).format(e)
            };

            function ee(e) {
                var t = Object.assign({}, ((0, s.Z)(e), e)),
                    n = (0, x.xp)(localStorage.getItem("accessToken")),
                    f = !(2 === (null === n || void 0 === n ? void 0 : n.room)),
                    g = (0, h.v9)((function(e) {
                        return e.monitoring
                    })).rate,
                    b = function(e, t) {
                        var n;
                        switch (t) {
                            case "IDR":
                                n = (parseFloat(e) / g.USDT_IDR).toFixed(10);
                                break;
                            case "BTC":
                                n = (parseFloat(e) * g.BTC_IDR / g.USDT_IDR).toFixed(10);
                                break;
                            default:
                                n = parseFloat(e).toFixed(10)
                        }
                        return n
                    },
                    j = (0, h.v9)((function(e) {
                        return e.monitoringDetail
                    })).data,
                    v = (0, o.useState)(0),
                    m = (0, i.Z)(v, 2),
                    Z = m[0],
                    w = (m[1], j.arbitrage_data[Z]),
                    y = window.innerHeight < window.innerWidth,
                    S = y ? 13 : 10;
                return (0, Q.jsxs)(l.Z, (0, r.Z)((0, r.Z)({
                    sx: {
                        p: 0
                    }
                }, t), {}, {
                    children: [(0, Q.jsx)(u.Z, {
                        direction: "row",
                        justifyContent: "space-evenly",
                        alignItems: "center",
                        spacing: 0,
                        children: (0, Q.jsx)(d.Z, {
                            variant: "h5",
                            children: j.asset
                        })
                    }), (0, Q.jsx)(u.Z, {
                        direction: "row",
                        justifyContent: "space-evenly",
                        alignItems: "center",
                        spacing: 0,
                        children: (0, Q.jsxs)(l.Z, {
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            sx: {
                                backgroundColor: "#f5ea89"
                            },
                            children: [(0, Q.jsx)(d.Z, {
                                variant: "caption",
                                children: "Last Trade Gap:"
                            }), "  ", (0, Q.jsx)(d.Z, {
                                variant: "h6",
                                children: w.diffP
                            }), "%"]
                        })
                    }), (0, Q.jsx)(l.Z, {
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        textAlign: "center",
                        children: (0, Q.jsxs)(l.Z, {
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            textAlign: "center",
                            flexDirection: "column",
                            children: [(0, Q.jsxs)(d.Z, {
                                variant: "button",
                                color: "error.main",
                                children: [" *WARNING! beware for low liquidity (", (0, Q.jsx)(p.Z, {
                                    icon: "noto-v1:warning"
                                }), " if qty*price ", "<", " $3). Pay attention to the withdrawal duration. "]
                            }), (0, Q.jsx)(d.Z, {
                                variant: "button",
                                color: "error.main",
                                children: ' To do Arbitrage Trading : "network_type" , "coin_fullname" AND "contract_address" in both exchange (If not mainnet) must be same AND has sufficient coin qty. '
                            }), (0, Q.jsxs)(d.Z, {
                                variant: "button",
                                color: "error.main",
                                children: [" If difference is not reasonable like ", ">", ' 10%, You must carefully & double check the "coin_fullname" , "WD / DEPO availability" , "contract_address" in both exchange (If not mainnet) ']
                            })]
                        })
                    }), f ? function() {
                        var e = "*****";
                        return (0, Q.jsxs)(a.ZP, {
                            container: !0,
                            children: [(0, Q.jsx)(a.ZP, {
                                item: !0,
                                xs: 6,
                                sx: {
                                    p: 1
                                },
                                children: (0, Q.jsxs)(c.Z, {
                                    sx: {
                                        backgroundColor: "success.lighter",
                                        p: .5
                                    },
                                    children: [(0, Q.jsxs)(l.Z, {
                                        display: "flex",
                                        justifyContent: "center",
                                        alignItems: "center",
                                        textAlign: "center",
                                        flexDirection: "column",
                                        children: [(0, Q.jsxs)(d.Z, {
                                            variant: "caption",
                                            sx: {
                                                fontSize: 9
                                            },
                                            children: ["Volume \xa0", (0, Q.jsx)(d.Z, {
                                                variant: "caption",
                                                sx: {
                                                    fontSize: 11,
                                                    fontWeight: "bold"
                                                },
                                                children: J(w.lower_volume)
                                            })]
                                        }), (0, Q.jsxs)(d.Z, {
                                            variant: "caption",
                                            sx: {
                                                fontSize: 9
                                            },
                                            children: ["Last trade \xa0", (0, Q.jsxs)(d.Z, {
                                                variant: "caption",
                                                sx: {
                                                    fontSize: 11,
                                                    fontWeight: "bold"
                                                },
                                                children: [w.lower_price, " (", b(w.lower_price, w.lower_quoteAsset), " USDT)"]
                                            }), (0, Q.jsx)(d.Z, {
                                                variant: "caption",
                                                sx: {
                                                    fontSize: 9
                                                },
                                                children: " \xa0 Detected low at:"
                                            })]
                                        }), (0, Q.jsxs)(d.Z, {
                                            variant: "h6",
                                            children: [w.lower, " - ", w.lower_quoteAsset]
                                        }), (0, Q.jsx)(d.Z, {
                                            variant: "caption",
                                            color: "error.main",
                                            children: "Subscribe to show data"
                                        })]
                                    }), (0, Q.jsx)($, {
                                        buy: !0,
                                        sell: !0,
                                        market: w.higher,
                                        base: j.asset,
                                        quote: w.higher_quoteAsset
                                    }), (0, Q.jsxs)(l.Z, {
                                        children: [(0, Q.jsxs)(d.Z, {
                                            variant: "button",
                                            children: ["Coin Fullname: ", e]
                                        }), " ", (0, Q.jsx)("br", {}), (0, Q.jsx)(d.Z, {
                                            variant: "button",
                                            sx: {
                                                fontSize: S
                                            },
                                            children: "Network List: "
                                        }), (0, Q.jsxs)(l.Z, {
                                            sx: {
                                                p: .5,
                                                m: .5,
                                                backgroundColor: "white",
                                                border: 1,
                                                borderRadius: 1,
                                                borderColor: "grey.400"
                                            },
                                            children: [(0, Q.jsxs)(u.Z, {
                                                direction: "row",
                                                justifyContent: "space-between",
                                                alignItems: "center",
                                                spacing: 0,
                                                children: [(0, Q.jsx)(d.Z, {
                                                    sx: {
                                                        fontSize: S
                                                    },
                                                    children: "Type:"
                                                }), (0, Q.jsxs)(d.Z, {
                                                    sx: {
                                                        fontSize: S
                                                    },
                                                    children: [" ", e, " "]
                                                })]
                                            }), (0, Q.jsxs)(u.Z, {
                                                direction: "row",
                                                justifyContent: "space-between",
                                                alignItems: "center",
                                                spacing: 0,
                                                children: [(0, Q.jsx)(d.Z, {
                                                    sx: {
                                                        fontSize: S
                                                    },
                                                    children: "Name:"
                                                }), (0, Q.jsxs)(d.Z, {
                                                    sx: {
                                                        fontSize: S
                                                    },
                                                    children: [" ", e, " "]
                                                })]
                                            }), (0, Q.jsxs)(u.Z, {
                                                direction: "row",
                                                justifyContent: "space-between",
                                                alignItems: "center",
                                                spacing: 0,
                                                children: [(0, Q.jsx)(d.Z, {
                                                    sx: {
                                                        fontSize: S
                                                    },
                                                    children: "Depo Enable:"
                                                }), (0, Q.jsxs)(d.Z, {
                                                    sx: {
                                                        fontSize: S
                                                    },
                                                    children: [" ", e, " "]
                                                })]
                                            }), (0, Q.jsxs)(u.Z, {
                                                direction: "row",
                                                justifyContent: "space-between",
                                                alignItems: "center",
                                                spacing: 0,
                                                children: [(0, Q.jsx)(d.Z, {
                                                    sx: {
                                                        fontSize: S
                                                    },
                                                    children: "WD Enable:"
                                                }), (0, Q.jsxs)(d.Z, {
                                                    sx: {
                                                        fontSize: S
                                                    },
                                                    children: [" ", e, " "]
                                                })]
                                            }), (0, Q.jsxs)(u.Z, {
                                                direction: "row",
                                                justifyContent: "space-between",
                                                alignItems: "center",
                                                spacing: 0,
                                                children: [(0, Q.jsx)(d.Z, {
                                                    sx: {
                                                        fontSize: S
                                                    },
                                                    children: "WD Fee:"
                                                }), (0, Q.jsxs)(d.Z, {
                                                    sx: {
                                                        fontSize: S
                                                    },
                                                    children: [" ", e, " (", e, ") "]
                                                })]
                                            })]
                                        })]
                                    })]
                                })
                            }), (0, Q.jsx)(a.ZP, {
                                item: !0,
                                xs: 6,
                                sx: {
                                    p: 1
                                },
                                children: (0, Q.jsxs)(c.Z, {
                                    sx: {
                                        backgroundColor: "error.lighter",
                                        p: .5
                                    },
                                    children: [(0, Q.jsxs)(l.Z, {
                                        display: "flex",
                                        justifyContent: "center",
                                        alignItems: "center",
                                        textAlign: "center",
                                        flexDirection: "column",
                                        children: [(0, Q.jsxs)(d.Z, {
                                            variant: "caption",
                                            sx: {
                                                fontSize: 9
                                            },
                                            children: ["Volume \xa0", (0, Q.jsx)(d.Z, {
                                                variant: "caption",
                                                sx: {
                                                    fontSize: 11,
                                                    fontWeight: "bold"
                                                },
                                                children: J(w.higher_volume)
                                            })]
                                        }), (0, Q.jsxs)(d.Z, {
                                            variant: "caption",
                                            sx: {
                                                fontSize: 9
                                            },
                                            children: ["Last trade \xa0", (0, Q.jsxs)(d.Z, {
                                                variant: "caption",
                                                sx: {
                                                    fontSize: 11,
                                                    fontWeight: "bold"
                                                },
                                                children: [w.higher_price, " (", b(w.higher_price, w.higher_quoteAsset), " USDT)"]
                                            }), (0, Q.jsx)(d.Z, {
                                                variant: "caption",
                                                sx: {
                                                    fontSize: 9
                                                },
                                                children: " \xa0 Detected high at:"
                                            })]
                                        }), (0, Q.jsxs)(d.Z, {
                                            variant: "h6",
                                            children: [w.higher, " - ", w.higher_quoteAsset]
                                        }), (0, Q.jsx)(d.Z, {
                                            variant: "caption",
                                            color: "error.main",
                                            children: "Subscribe to show data"
                                        })]
                                    }), (0, Q.jsx)($, {
                                        buy: !0,
                                        sell: !0,
                                        market: w.higher,
                                        base: j.asset,
                                        quote: w.higher_quoteAsset
                                    }), (0, Q.jsxs)(l.Z, {
                                        children: [(0, Q.jsxs)(d.Z, {
                                            variant: "button",
                                            children: ["Coin Fullname: ", e]
                                        }), " ", (0, Q.jsx)("br", {}), (0, Q.jsx)(d.Z, {
                                            variant: "button",
                                            sx: {
                                                fontSize: S
                                            },
                                            children: "Network List: "
                                        }), (0, Q.jsxs)(l.Z, {
                                            sx: {
                                                p: .5,
                                                m: .5,
                                                border: 1,
                                                backgroundColor: "white",
                                                borderRadius: 1,
                                                borderColor: "grey.400"
                                            },
                                            children: [(0, Q.jsxs)(u.Z, {
                                                direction: "row",
                                                justifyContent: "space-between",
                                                alignItems: "center",
                                                spacing: 0,
                                                children: [(0, Q.jsx)(d.Z, {
                                                    sx: {
                                                        fontSize: S
                                                    },
                                                    children: "Type:"
                                                }), (0, Q.jsxs)(d.Z, {
                                                    sx: {
                                                        fontSize: S
                                                    },
                                                    children: [" ", e, " "]
                                                })]
                                            }), (0, Q.jsxs)(u.Z, {
                                                direction: "row",
                                                justifyContent: "space-between",
                                                alignItems: "center",
                                                spacing: 0,
                                                children: [(0, Q.jsx)(d.Z, {
                                                    sx: {
                                                        fontSize: S
                                                    },
                                                    children: "Name:"
                                                }), (0, Q.jsxs)(d.Z, {
                                                    sx: {
                                                        fontSize: S
                                                    },
                                                    children: [" ", e, " "]
                                                })]
                                            }), (0, Q.jsxs)(u.Z, {
                                                direction: "row",
                                                justifyContent: "space-between",
                                                alignItems: "center",
                                                spacing: 0,
                                                children: [(0, Q.jsx)(d.Z, {
                                                    sx: {
                                                        fontSize: S
                                                    },
                                                    children: "Depo Enable:"
                                                }), (0, Q.jsxs)(d.Z, {
                                                    sx: {
                                                        fontSize: S
                                                    },
                                                    children: [" ", e, " "]
                                                })]
                                            }), (0, Q.jsxs)(u.Z, {
                                                direction: "row",
                                                justifyContent: "space-between",
                                                alignItems: "center",
                                                spacing: 0,
                                                children: [(0, Q.jsx)(d.Z, {
                                                    sx: {
                                                        fontSize: S
                                                    },
                                                    children: "WD Enable:"
                                                }), (0, Q.jsxs)(d.Z, {
                                                    sx: {
                                                        fontSize: S
                                                    },
                                                    children: [" ", e, " "]
                                                })]
                                            }), (0, Q.jsxs)(u.Z, {
                                                direction: "row",
                                                justifyContent: "space-between",
                                                alignItems: "center",
                                                spacing: 0,
                                                children: [(0, Q.jsx)(d.Z, {
                                                    sx: {
                                                        fontSize: S
                                                    },
                                                    children: "WD Fee:"
                                                }), (0, Q.jsxs)(d.Z, {
                                                    sx: {
                                                        fontSize: S
                                                    },
                                                    children: [" ", e, " (", e, ") "]
                                                })]
                                            })]
                                        })]
                                    })]
                                })
                            })]
                        })
                    }() : (0, Q.jsxs)(a.ZP, {
                        container: !0,
                        children: [(0, Q.jsx)(a.ZP, {
                            item: !0,
                            xs: 6,
                            sx: {
                                p: 1
                            },
                            children: (0, Q.jsxs)(c.Z, {
                                sx: {
                                    backgroundColor: "success.lighter",
                                    p: .5
                                },
                                children: [(0, Q.jsxs)(l.Z, {
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    flexDirection: "column",
                                    children: [(0, Q.jsxs)(d.Z, {
                                        variant: "caption",
                                        sx: {
                                            fontSize: 9
                                        },
                                        children: ["Volume \xa0", (0, Q.jsxs)(d.Z, {
                                            variant: "caption",
                                            sx: {
                                                fontSize: 11,
                                                fontWeight: "bold"
                                            },
                                            children: [" ", J(w.lower_volume), " "]
                                        })]
                                    }), (0, Q.jsxs)(d.Z, {
                                        variant: "caption",
                                        sx: {
                                            fontSize: 9
                                        },
                                        children: ["Last trade \xa0", (0, Q.jsxs)(d.Z, {
                                            variant: "caption",
                                            sx: {
                                                fontSize: 11,
                                                fontWeight: "bold"
                                            },
                                            children: [w.lower_price, " ( ", b(w.lower_price, w.lower_quoteAsset), " USDT )"]
                                        }), (0, Q.jsx)(d.Z, {
                                            variant: "caption",
                                            sx: {
                                                fontSize: 9
                                            },
                                            children: " \xa0 Detected low at:"
                                        })]
                                    }), (0, Q.jsxs)(d.Z, {
                                        variant: "h6",
                                        children: [w.lower, " - ", w.lower_quoteAsset]
                                    })]
                                }), (0, Q.jsx)(X, {
                                    buy: !0,
                                    sell: !0,
                                    market: w.lower,
                                    base: j.asset,
                                    quote: w.lower_quoteAsset
                                }), (0, Q.jsxs)(l.Z, {
                                    children: [(0, Q.jsxs)(d.Z, {
                                        variant: "button",
                                        children: ["Fullname : ", w.lower_assetName]
                                    }), " ", (0, Q.jsx)("br", {}), (0, Q.jsx)(d.Z, {
                                        variant: "button",
                                        sx: {
                                            fontSize: S
                                        },
                                        children: "Network List: "
                                    }), (0, Q.jsx)(l.Z, {
                                        children: w.lower_assetNetwork ? w.lower_assetNetwork.map((function(e, t) {
                                            return (0, Q.jsxs)(l.Z, {
                                                sx: {
                                                    p: .5,
                                                    m: .5,
                                                    backgroundColor: "white",
                                                    border: 1,
                                                    borderRadius: 1,
                                                    borderColor: "grey.400"
                                                },
                                                children: [(0, Q.jsxs)(u.Z, {
                                                    direction: "row",
                                                    justifyContent: "space-between",
                                                    alignItems: "center",
                                                    spacing: 0,
                                                    children: [(0, Q.jsx)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: "Type:"
                                                    }), (0, Q.jsxs)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: [" ", e.network, " "]
                                                    })]
                                                }), (0, Q.jsxs)(u.Z, {
                                                    direction: "row",
                                                    justifyContent: "space-between",
                                                    alignItems: "center",
                                                    spacing: 0,
                                                    children: [(0, Q.jsx)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: "Name:"
                                                    }), (0, Q.jsxs)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: [" ", e.networkName, " "]
                                                    })]
                                                }), (0, Q.jsxs)(u.Z, {
                                                    direction: "row",
                                                    justifyContent: "space-between",
                                                    alignItems: "center",
                                                    spacing: 0,
                                                    children: [(0, Q.jsx)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: "Depo Enable:"
                                                    }), (0, Q.jsxs)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: [" ", e.depositEnable ? "YES" : "NO", " "]
                                                    })]
                                                }), (0, Q.jsxs)(u.Z, {
                                                    direction: "row",
                                                    justifyContent: "space-between",
                                                    alignItems: "center",
                                                    spacing: 0,
                                                    children: [(0, Q.jsx)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: "WD Enable:"
                                                    }), (0, Q.jsxs)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: [" ", e.withdrawEnable ? "YES" : "NO", " "]
                                                    })]
                                                }), (0, Q.jsxs)(u.Z, {
                                                    direction: "row",
                                                    justifyContent: "space-between",
                                                    alignItems: "center",
                                                    spacing: 0,
                                                    children: [(0, Q.jsxs)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: ["WD Fee (", e.withdrawFeeCurrency, "):"]
                                                    }), (0, Q.jsxs)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: [" ", e.withdrawFee, "  "]
                                                    })]
                                                }), "USDT" !== e.withdrawFeeCurrency && (0, Q.jsxs)(u.Z, {
                                                    direction: "row",
                                                    justifyContent: "space-between",
                                                    alignItems: "center",
                                                    spacing: 0,
                                                    children: [(0, Q.jsx)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: "WD Fee (USDT):"
                                                    }), (0, Q.jsxs)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: [" ", e.withdrawFee * b(w.lower_price, "USDT"), " "]
                                                    })]
                                                })]
                                            }, t)
                                        })) : " "
                                    })]
                                })]
                            })
                        }), (0, Q.jsx)(a.ZP, {
                            item: !0,
                            xs: 6,
                            sx: {
                                p: 1
                            },
                            children: (0, Q.jsxs)(c.Z, {
                                sx: {
                                    backgroundColor: "error.lighter",
                                    p: .5
                                },
                                children: [(0, Q.jsxs)(l.Z, {
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    flexDirection: "column",
                                    children: [(0, Q.jsxs)(d.Z, {
                                        variant: "caption",
                                        sx: {
                                            fontSize: 9
                                        },
                                        children: ["Volume \xa0", (0, Q.jsx)(d.Z, {
                                            variant: "caption",
                                            sx: {
                                                fontSize: 11,
                                                fontWeight: "bold"
                                            },
                                            children: J(w.higher_volume)
                                        })]
                                    }), (0, Q.jsxs)(d.Z, {
                                        variant: "caption",
                                        sx: {
                                            fontSize: 9
                                        },
                                        children: ["Last trade \xa0", (0, Q.jsxs)(d.Z, {
                                            variant: "caption",
                                            sx: {
                                                fontSize: 11,
                                                fontWeight: "bold"
                                            },
                                            children: [w.higher_price, " ( ", b(w.higher_price, w.higher_quoteAsset), " USDT )"]
                                        }), (0, Q.jsx)(d.Z, {
                                            variant: "caption",
                                            sx: {
                                                fontSize: 9
                                            },
                                            children: " \xa0 Detected high at:"
                                        })]
                                    }), (0, Q.jsxs)(d.Z, {
                                        variant: "h6",
                                        children: [w.higher, " - ", w.higher_quoteAsset]
                                    })]
                                }), (0, Q.jsx)(X, {
                                    buy: !0,
                                    sell: !0,
                                    market: w.higher,
                                    base: j.asset,
                                    quote: w.higher_quoteAsset
                                }), (0, Q.jsxs)(l.Z, {
                                    children: [(0, Q.jsxs)(d.Z, {
                                        variant: "button",
                                        children: ["Fullname : ", w.higher_assetName]
                                    }), " ", (0, Q.jsx)("br", {}), (0, Q.jsx)(d.Z, {
                                        variant: "button",
                                        sx: {
                                            fontSize: S
                                        },
                                        children: "Network List: "
                                    }), (0, Q.jsx)(l.Z, {
                                        children: w.higher_assetNetwork ? w.higher_assetNetwork.map((function(e, t) {
                                            return (0, Q.jsxs)(l.Z, {
                                                sx: {
                                                    p: .5,
                                                    m: .5,
                                                    border: 1,
                                                    backgroundColor: "white",
                                                    borderRadius: 1,
                                                    borderColor: "grey.400"
                                                },
                                                children: [(0, Q.jsxs)(u.Z, {
                                                    direction: "row",
                                                    justifyContent: "space-between",
                                                    alignItems: "center",
                                                    spacing: 0,
                                                    children: [(0, Q.jsx)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: "Type:"
                                                    }), (0, Q.jsxs)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: [" ", e.network, " "]
                                                    })]
                                                }), (0, Q.jsxs)(u.Z, {
                                                    direction: "row",
                                                    justifyContent: "space-between",
                                                    alignItems: "center",
                                                    spacing: 0,
                                                    children: [(0, Q.jsx)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: "Name:"
                                                    }), (0, Q.jsxs)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: [" ", e.networkName, " "]
                                                    })]
                                                }), (0, Q.jsxs)(u.Z, {
                                                    direction: "row",
                                                    justifyContent: "space-between",
                                                    alignItems: "center",
                                                    spacing: 0,
                                                    children: [(0, Q.jsx)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: "Depo Enable:"
                                                    }), (0, Q.jsxs)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: [" ", e.depositEnable ? "YES" : "NO", " "]
                                                    })]
                                                }), (0, Q.jsxs)(u.Z, {
                                                    direction: "row",
                                                    justifyContent: "space-between",
                                                    alignItems: "center",
                                                    spacing: 0,
                                                    children: [(0, Q.jsx)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: "WD Enable:"
                                                    }), (0, Q.jsxs)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: [" ", e.withdrawEnable ? "YES" : "NO", " "]
                                                    })]
                                                }), (0, Q.jsxs)(u.Z, {
                                                    direction: "row",
                                                    justifyContent: "space-between",
                                                    alignItems: "center",
                                                    spacing: 0,
                                                    children: [(0, Q.jsxs)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: ["WD Fee (", e.withdrawFeeCurrency, "):"]
                                                    }), (0, Q.jsxs)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: [" ", e.withdrawFee, "  "]
                                                    })]
                                                }), "USDT" !== e.withdrawFeeCurrency && (0, Q.jsxs)(u.Z, {
                                                    direction: "row",
                                                    justifyContent: "space-between",
                                                    alignItems: "center",
                                                    spacing: 0,
                                                    children: [(0, Q.jsx)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: "WD Fee (USDT):"
                                                    }), (0, Q.jsxs)(d.Z, {
                                                        sx: {
                                                            fontSize: S
                                                        },
                                                        children: [" ", e.withdrawFee * b(w.lower_price, "USDT"), " "]
                                                    })]
                                                })]
                                            }, t)
                                        })) : " "
                                    })]
                                })]
                            })
                        })]
                    })]
                }))
            }
        },
        50659: function(e, t, n) {
            n(47313), n(81627);
            var r = n(25056),
                i = n.n(r),
                s = (n(76195), n(63457), n(13918));
            n(46417);
            i().accessToken = s.YB
        },
        17391: function(e, t, n) {
            n.d(t, {
                cl: function() {
                    return s
                },
                hr: function() {
                    return a
                },
                $l: function() {
                    return c
                },
                cm: function() {
                    return l
                }
            });
            var r = n(1413),
                i = n(93433);

            function s(e) {
                return atob(e.replace(/_/g, "/"))
            }

            function o(e) {
                return (0, i.Z)(new Set(e))
            }

            function a(e) {
                return o(e.reduce((function(e, t) {
                    return t.arbitrage_data.forEach((function(t) {
                        e.push(t.higher, t.lower)
                    })), e
                }), []))
            }

            function c(e) {
                return a(e).reduce((function(e, t) {
                    return e[t] = ["BUY", "SELL"], e
                }), {})
            }

            function l(e) {
                var t, n = e.filter,
                    i = e.arb_data,
                    s = e.user,
                    o = [];

                function a(e) {
                    var o = [];
                    if (Array.isArray(i))
                        for (var a = 0; a < e.length; a++) {
                            var c, l, d = (0, r.Z)({}, e[a]),
                                u = 0,
                                x = 0;
                            if (n.exchanges && (null === s || void 0 === s ? void 0 : s.room) > 1) u++, null !== (c = n[t = "exchanges"][d.higher]) && void 0 !== c && c.includes("SELL") && null !== (l = n[t][d.lower]) && void 0 !== l && l.includes("BUY") && x++;
                            if (n.percentRange && (null === s || void 0 === s ? void 0 : s.room) > 1 && (u++, t = "percentRange", parseFloat(d.diffP) >= n[t][0] && parseFloat(d.diffP) <= n[t][1] && x++), n.lower_volume && n.higher_volume && (null === s || void 0 === s ? void 0 : s.room) > 1 && (u++, d.lower_volume > n.lower_volume && d.higher_volume > n.higher_volume && x++), n.allowedNetwork && (null === s || void 0 === s ? void 0 : s.room) > 1) {
                                if (u++, t = "allowedNetwork", Array.isArray(d.lower_assetNetwork) && Array.isArray(d.higher_assetNetwork)) {
                                    for (var h = [], p = 0; p < d.lower_assetNetwork.length; p++) {
                                        var f = d.lower_assetNetwork[p].network;
                                        !1 !== n[t][f] && h.push(d.lower_assetNetwork[p])
                                    }
                                    d.lower_assetNetwork = h;
                                    for (var g = [], b = 0; b < d.higher_assetNetwork.length; b++) {
                                        var j = d.higher_assetNetwork[b].network;
                                        !1 !== n[t][j] && g.push(d.higher_assetNetwork[b])
                                    }
                                    d.higher_assetNetwork = g
                                }
                                d.lower_assetNetwork.length > 0 && d.higher_assetNetwork.length > 0 && x++
                            }
                            u === x && o.push(d)
                        }
                    return o
                }
                if (Array.isArray(i))
                    for (var c = 0; c < i.length; c++) {
                        var l = [],
                            d = i[c].arbitrage_data;
                        n.coinName && "" !== n.coinName && (null === s || void 0 === s ? void 0 : s.room) > 1 ? (t = "coinName", String(i[c].asset).toLowerCase().includes(String(n[t]).toLowerCase()) && (l = a(d))) : l = a(d), l.length > 0 && o.push({
                            asset: i[c].asset,
                            arbitrage_data: l
                        })
                    }
                return o.sort((function(e, t) {
                    return t.arbitrage_data[0].diffP - e.arbitrage_data[0].diffP
                })), o
            }
        }
    }
]);