(function(sttc) {
    'use strict';
    var ca, da = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a
    };

    function ea(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    }
    var ha = ea(this),
        ia = "function" === typeof Symbol && "symbol" === typeof Symbol("x"),
        ja = {},
        ka = {};

    function ma(a, b, c) {
        if (!c || null != a) {
            c = ka[b];
            if (null == c) return a[b];
            c = a[c];
            return void 0 !== c ? c : a[b]
        }
    }

    function na(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = 1 === d.length;
            var e = d[0],
                f;!a && e in ja ? f = ja : f = ha;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = ia && "es6" === c ? f[d] : null;b = b(c);null != b && (a ? da(ja, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (void 0 === ka[d] && (a = 1E9 * Math.random() >>> 0, ka[d] = ia ? ha.Symbol(d) : "$jscp$" + a + "$" + d), da(f, ka[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    }
    na("String.prototype.replaceAll", function(a) {
        return a ? a : function(b, c) {
            if (b instanceof RegExp && !b.global) throw new TypeError("String.prototype.replaceAll called with a non-global RegExp argument.");
            return b instanceof RegExp ? this.replace(b, c) : this.replace(new RegExp(String(b).replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g, "\\$1").replace(/\x08/g, "\\x08"), "g"), c)
        }
    }, "es_2021");
    var oa = "function" == typeof Object.create ? Object.create : function(a) {
            function b() {}
            b.prototype = a;
            return new b
        },
        pa;
    if (ia && "function" == typeof Object.setPrototypeOf) pa = Object.setPrototypeOf;
    else {
        var qa;
        a: {
            var ra = {
                    a: !0
                },
                ta = {};
            try {
                ta.__proto__ = ra;
                qa = ta.a;
                break a
            } catch (a) {}
            qa = !1
        }
        pa = qa ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var ua = pa;

    function va(a, b) {
        a.prototype = oa(b.prototype);
        a.prototype.constructor = a;
        if (ua) ua(a, b);
        else
            for (var c in b)
                if ("prototype" != c)
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.Aj = b.prototype
    }
    na("AggregateError", function(a) {
        function b(c, d) {
            d = Error(d);
            "stack" in d && (this.stack = d.stack);
            this.errors = c;
            this.message = d.message
        }
        if (a) return a;
        va(b, Error);
        b.prototype.name = "AggregateError";
        return b
    }, "es_2021");
    na("Promise.any", function(a) {
        return a ? a : function(b) {
            b = b instanceof Array ? b : Array.from(b);
            return Promise.all(b.map(function(c) {
                return Promise.resolve(c).then(function(d) {
                    throw d;
                }, function(d) {
                    return d
                })
            })).then(function(c) {
                throw new ja.AggregateError(c, "All promises were rejected");
            }, function(c) {
                return c
            })
        }
    }, "es_2021");
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var r = this || self;

    function xa(a, b) {
        a: {
            var c = ["CLOSURE_FLAGS"];
            for (var d = r, e = 0; e < c.length; e++)
                if (d = d[c[e]], null == d) {
                    c = null;
                    break a
                }
            c = d
        }
        a = c && c[a];
        return null != a ? a : b
    }

    function ya(a) {
        var b = typeof a;
        return "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null"
    }

    function za(a) {
        var b = ya(a);
        return "array" == b || "object" == b && "number" == typeof a.length
    }

    function Aa(a) {
        var b = typeof a;
        return "object" == b && null != a || "function" == b
    }

    function Ba(a) {
        return Object.prototype.hasOwnProperty.call(a, Ca) && a[Ca] || (a[Ca] = ++Da)
    }
    var Ca = "closure_uid_" + (1E9 * Math.random() >>> 0),
        Da = 0;

    function Fa(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function Ia(a, b, c) {
        if (!a) throw Error();
        if (2 < arguments.length) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    }

    function Ja(a, b, c) {
        Ja = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? Fa : Ia;
        return Ja.apply(null, arguments)
    }

    function Ka(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    }

    function La(a, b, c) {
        a = a.split(".");
        c = c || r;
        a[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + a[0]);
        for (var d; a.length && (d = a.shift());) a.length || void 0 === b ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
    }

    function Ma(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.Aj = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a;
        a.Sn = function(d, e, f) {
            for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
            return b.prototype[e].apply(d, g)
        }
    }

    function Na(a) {
        return a
    };
    var Oa = {
        Qm: 0,
        Pm: 1,
        Om: 2
    };

    function Ra(a, b) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, Ra);
        else {
            const c = Error().stack;
            c && (this.stack = c)
        }
        a && (this.message = String(a));
        void 0 !== b && (this.cause = b)
    }
    Ma(Ra, Error);
    Ra.prototype.name = "CustomError";
    var Sa;

    function Ta(a, b) {
        a = a.split("%s");
        let c = "";
        const d = a.length - 1;
        for (let e = 0; e < d; e++) c += a[e] + (e < b.length ? b[e] : "%s");
        Ra.call(this, c + a[d])
    }
    Ma(Ta, Ra);
    Ta.prototype.name = "AssertionError";

    function Ua(a, b) {
        if ("string" === typeof a) return "string" !== typeof b || 1 != b.length ? -1 : a.indexOf(b, 0);
        for (let c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    }

    function Va(a, b) {
        const c = a.length,
            d = "string" === typeof a ? a.split("") : a;
        for (let e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
    }

    function Xa(a, b) {
        var c = a.length;
        const d = "string" === typeof a ? a.split("") : a;
        for (--c; 0 <= c; --c) c in d && b.call(void 0, d[c], c, a)
    }

    function Za(a, b) {
        const c = a.length,
            d = [];
        let e = 0;
        const f = "string" === typeof a ? a.split("") : a;
        for (let g = 0; g < c; g++)
            if (g in f) {
                const h = f[g];
                b.call(void 0, h, g, a) && (d[e++] = h)
            }
        return d
    }

    function $a(a, b) {
        const c = a.length,
            d = Array(c),
            e = "string" === typeof a ? a.split("") : a;
        for (let f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
        return d
    }

    function ab(a, b, c) {
        let d = c;
        Va(a, function(e, f) {
            d = b.call(void 0, d, e, f, a)
        });
        return d
    }

    function bb(a, b) {
        const c = a.length,
            d = "string" === typeof a ? a.split("") : a;
        for (let e = 0; e < c; e++)
            if (e in d && b.call(void 0, d[e], e, a)) return !0;
        return !1
    }

    function db(a, b) {
        return 0 <= Ua(a, b)
    }

    function eb(a, b) {
        b = Ua(a, b);
        let c;
        (c = 0 <= b) && Array.prototype.splice.call(a, b, 1);
        return c
    }

    function fb(a, b) {
        let c = 0;
        Xa(a, function(d, e) {
            b.call(void 0, d, e, a) && 1 == Array.prototype.splice.call(a, e, 1).length && c++
        })
    }

    function gb(a) {
        return Array.prototype.concat.apply([], arguments)
    }

    function hb(a) {
        const b = a.length;
        if (0 < b) {
            const c = Array(b);
            for (let d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    }

    function ib(a, b) {
        for (let c = 1; c < arguments.length; c++) {
            const d = arguments[c];
            if (za(d)) {
                const e = a.length || 0,
                    f = d.length || 0;
                a.length = e + f;
                for (let g = 0; g < f; g++) a[e + g] = d[g]
            } else a.push(d)
        }
    }

    function jb(a, b, c) {
        return 2 >= arguments.length ? Array.prototype.slice.call(a, b) : Array.prototype.slice.call(a, b, c)
    }

    function kb(a, b, c) {
        c = c || lb;
        let d = 0,
            e = a.length,
            f;
        for (; d < e;) {
            const g = d + (e - d >>> 1);
            let h;
            h = c(b, a[g]);
            0 < h ? d = g + 1 : (e = g, f = !h)
        }
        return f ? d : -d - 1
    }

    function ob(a, b) {
        if (!za(a) || !za(b) || a.length != b.length) return !1;
        const c = a.length,
            d = pb;
        for (let e = 0; e < c; e++)
            if (!d(a[e], b[e])) return !1;
        return !0
    }

    function lb(a, b) {
        return a > b ? 1 : a < b ? -1 : 0
    }

    function pb(a, b) {
        return a === b
    }

    function qb(a) {
        const b = [];
        for (let c = 0; c < arguments.length; c++) {
            const d = arguments[c];
            if (Array.isArray(d))
                for (let e = 0; e < d.length; e += 8192) {
                    const f = qb.apply(null, jb(d, e, e + 8192));
                    for (let g = 0; g < f.length; g++) b.push(f[g])
                } else b.push(d)
        }
        return b
    }

    function rb(a, b) {
        b = b || Math.random;
        for (let c = a.length - 1; 0 < c; c--) {
            const d = Math.floor(b() * (c + 1)),
                e = a[c];
            a[c] = a[d];
            a[d] = e
        }
    };
    var sb = {
        Oj: "google_adtest",
        Sj: "google_ad_client",
        Tj: "google_ad_format",
        Vj: "google_ad_height",
        jk: "google_ad_width",
        Zj: "google_ad_layout",
        ak: "google_ad_layout_key",
        bk: "google_ad_output",
        ck: "google_ad_region",
        fk: "google_ad_slot",
        hk: "google_ad_type",
        ik: "google_ad_url",
        kk: "google_allow_expandable_ads",
        Fk: "google_analytics_domain_name",
        Gk: "google_analytics_uacct",
        Uk: "google_container_id",
        fl: "google_gl",
        Fl: "google_enable_ose",
        Pl: "google_full_width_responsive",
        Tm: "google_rl_filtering",
        Sm: "google_rl_mode",
        Um: "google_rt",
        Rm: "google_rl_dest_url",
        wm: "google_max_radlink_len",
        Cm: "google_num_radlinks",
        Dm: "google_num_radlinks_per_unit",
        Rj: "google_ad_channel",
        vm: "google_max_num_ads",
        xm: "google_max_responsive_height",
        Pk: "google_color_border",
        El: "google_enable_content_recommendations",
        bl: "google_content_recommendation_ui_type",
        al: "google_source_type",
        Zk: "google_content_recommendation_rows_num",
        Yk: "google_content_recommendation_columns_num",
        Xk: "google_content_recommendation_ad_positions",
        dl: "google_content_recommendation_use_square_imgs",
        Rk: "google_color_link",
        Qk: "google_color_line",
        Tk: "google_color_url",
        Pj: "google_ad_block",
        ek: "google_ad_section",
        Qj: "google_ad_callback",
        Mk: "google_captcha_token",
        Sk: "google_color_text",
        xk: "google_alternate_ad_url",
        Yj: "google_ad_host_tier_id",
        Nk: "google_city",
        Wj: "google_ad_host",
        Xj: "google_ad_host_channel",
        yk: "google_alternate_color",
        Ok: "google_color_bg",
        Gl: "google_encoding",
        Nl: "google_font_face",
        jl: "google_cust_ch",
        ml: "google_cust_job",
        ll: "google_cust_interests",
        kl: "google_cust_id",
        ql: "google_cust_u_url",
        Rl: "google_hints",
        hm: "google_image_size",
        ym: "google_mtl",
        zn: "google_cpm",
        Wk: "google_contents",
        Am: "google_native_settings_key",
        el: "google_country",
        qn: "google_targeting",
        Ol: "google_font_size",
        vl: "google_disable_video_autoplay",
        Nn: "google_video_product_type",
        Mn: "google_video_doc_id",
        Ln: "google_cust_gender",
        kn: "google_cust_lh",
        jn: "google_cust_l",
        yn: "google_tfs",
        zm: "google_native_ad_template",
        nm: "google_kw",
        nn: "google_tag_for_child_directed_treatment",
        on: "google_tag_for_under_age_of_consent",
        Wm: "google_region",
        il: "google_cust_criteria",
        dk: "google_safe",
        gl: "google_ctr_threshold",
        Xm: "google_resizing_allowed",
        Zm: "google_resizing_width",
        Ym: "google_resizing_height",
        Kn: "google_cust_age",
        qm: "google_language",
        om: "google_kw_type",
        Lm: "google_pucrd",
        Jm: "google_page_url",
        pn: "google_tag_partner",
        dn: "google_restrict_data_processing",
        Kj: "google_adbreak_test",
        Uj: "google_ad_frequency_hint",
        Mj: "google_admob_interstitial_slot",
        Nj: "google_admob_rewarded_slot",
        Lj: "google_admob_ads_only",
        gk: "google_ad_start_delay_hint",
        um: "google_max_ad_content_rating",
        Nm: "google_ad_public_floor",
        Mm: "google_ad_private_floor",
        Jn: "google_traffic_source",
        gn: "google_shadow_mode",
        Gm: "google_overlays",
        Km: "google_privacy_treatments",
        ln: "google_xz"
    };

    function ub(a, b) {
        this.g = a === vb && b || "";
        this.i = yb
    }
    ub.prototype.toString = function() {
        return this.g
    };

    function zb(a) {
        return a instanceof ub && a.constructor === ub && a.i === yb ? a.g : "type_error:Const"
    }
    var yb = {},
        vb = {};
    var t = class {
            constructor(a, b = !1) {
                this.g = a;
                this.defaultValue = b
            }
        },
        Ab = class {
            constructor(a, b = 0) {
                this.g = a;
                this.defaultValue = b
            }
        },
        Bb = class {
            constructor(a, b = "") {
                this.g = a;
                this.defaultValue = b
            }
        },
        Cb = class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        };
    var Db = new t(590317302),
        Fb = new t(380025941);

    function Gb() {
        return !1
    }

    function Hb() {
        return !0
    }

    function Ib(a) {
        const b = arguments,
            c = b.length;
        return function() {
            for (let d = 0; d < c; d++)
                if (!b[d].apply(this, arguments)) return !1;
            return !0
        }
    }

    function Jb(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    }

    function Mb(a) {
        let b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }

    function Nb(a) {
        let b = a;
        return function() {
            if (b) {
                const c = b;
                b = null;
                c()
            }
        }
    }

    function Ob(a, b) {
        let c = 0;
        return function(d) {
            r.clearTimeout(c);
            const e = arguments;
            c = r.setTimeout(function() {
                a.apply(b, e)
            }, 63)
        }
    }

    function Pb(a, b) {
        function c() {
            e = r.setTimeout(d, 63);
            let h = g;
            g = [];
            a.apply(b, h)
        }

        function d() {
            e = 0;
            f && (f = !1, c())
        }
        let e = 0,
            f = !1,
            g = [];
        return function(h) {
            g = arguments;
            e ? f = !0 : c()
        }
    };
    var Qb = {
            passive: !0
        },
        Rb = Mb(function() {
            let a = !1;
            try {
                const b = Object.defineProperty({}, "passive", {
                    get: function() {
                        a = !0
                    }
                });
                r.addEventListener("test", null, b)
            } catch (b) {}
            return a
        });

    function Sb(a) {
        return a ? a.passive && Rb() ? a : a.capture || !1 : !1
    }

    function Tb(a, b, c, d) {
        return a.addEventListener ? (a.addEventListener(b, c, Sb(d)), !0) : !1
    }

    function Ub(a, b, c, d) {
        return a.removeEventListener ? (a.removeEventListener(b, c, Sb(d)), !0) : !1
    };

    function Vb(a) {
        Vb[" "](a);
        return a
    }
    Vb[" "] = function() {};

    function Wb(a, b) {
        try {
            return Vb(a[b]), !0
        } catch (c) {}
        return !1
    };
    var u = a => {
        var b = "Ne";
        if (a.Ne && a.hasOwnProperty(b)) return a.Ne;
        b = new a;
        return a.Ne = b
    };
    var Xb = class {
        constructor() {
            const a = {};
            this.j = (b, c) => null != a[b] ? a[b] : c;
            this.l = (b, c) => null != a[b] ? a[b] : c;
            this.A = (b, c) => null != a[b] ? a[b] : c;
            this.g = (b, c) => null != a[b] ? a[b] : c;
            this.i = () => {}
        }
    };

    function v(a) {
        return u(Xb).j(a.g, a.defaultValue)
    }

    function w(a) {
        return u(Xb).l(a.g, a.defaultValue)
    }

    function Yb(a) {
        return u(Xb).A(a.g, a.defaultValue)
    };
    var Zb = xa(610401301, !1),
        $b = xa(572417392, !0);

    function bc(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    }

    function cc(a) {
        if (!dc.test(a)) return a; - 1 != a.indexOf("&") && (a = a.replace(ec, "&amp;")); - 1 != a.indexOf("<") && (a = a.replace(fc, "&lt;")); - 1 != a.indexOf(">") && (a = a.replace(gc, "&gt;")); - 1 != a.indexOf('"') && (a = a.replace(hc, "&quot;")); - 1 != a.indexOf("'") && (a = a.replace(ic, "&#39;")); - 1 != a.indexOf("\x00") && (a = a.replace(jc, "&#0;"));
        return a
    }
    var ec = /&/g,
        fc = /</g,
        gc = />/g,
        hc = /"/g,
        ic = /'/g,
        jc = /\x00/g,
        dc = /[\x00&<>"']/;

    function kc(a, b) {
        return -1 != a.indexOf(b)
    };

    function lc() {
        var a = r.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var mc;
    const nc = r.navigator;
    mc = nc ? nc.userAgentData || null : null;

    function oc(a) {
        return Zb ? mc ? mc.brands.some(({
            brand: b
        }) => b && kc(b, a)) : !1 : !1
    }

    function y(a) {
        return kc(lc(), a)
    };

    function pc() {
        return Zb ? !!mc && 0 < mc.brands.length : !1
    }

    function qc() {
        return pc() ? !1 : y("Opera")
    }

    function vc() {
        return pc() ? !1 : y("Trident") || y("MSIE")
    }

    function wc() {
        return y("Safari") && !(xc() || (pc() ? 0 : y("Coast")) || qc() || (pc() ? 0 : y("Edge")) || (pc() ? oc("Microsoft Edge") : y("Edg/")) || (pc() ? oc("Opera") : y("OPR")) || y("Firefox") || y("FxiOS") || y("Silk") || y("Android"))
    }

    function xc() {
        return pc() ? oc("Chromium") : (y("Chrome") || y("CriOS")) && !(pc() ? 0 : y("Edge")) || y("Silk")
    }

    function yc() {
        return y("Android") && !(xc() || y("Firefox") || y("FxiOS") || qc() || y("Silk"))
    };
    var zc = qc(),
        Ac = vc(),
        Bc = y("Edge"),
        Cc = Bc || Ac,
        Dc = y("Gecko") && !(kc(lc().toLowerCase(), "webkit") && !y("Edge")) && !(y("Trident") || y("MSIE")) && !y("Edge"),
        Ec = kc(lc().toLowerCase(), "webkit") && !y("Edge");

    function Fc() {
        var a = r.document;
        return a ? a.documentMode : void 0
    }
    var Gc;
    a: {
        var Hc = "",
            Ic = function() {
                var a = lc();
                if (Dc) return /rv:([^\);]+)(\)|;)/.exec(a);
                if (Bc) return /Edge\/([\d\.]+)/.exec(a);
                if (Ac) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
                if (Ec) return /WebKit\/(\S+)/.exec(a);
                if (zc) return /(?:Version)[ \/]?(\S+)/.exec(a)
            }();Ic && (Hc = Ic ? Ic[1] : "");
        if (Ac) {
            var Jc = Fc();
            if (null != Jc && Jc > parseFloat(Hc)) {
                Gc = String(Jc);
                break a
            }
        }
        Gc = Hc
    }
    var Kc = Gc,
        Lc;
    if (r.document && Ac) {
        var Mc = Fc();
        Lc = Mc ? Mc : parseInt(Kc, 10) || void 0
    } else Lc = void 0;
    var Oc = Lc;

    function Pc(a, b) {
        const c = {};
        for (const d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
        return c
    }

    function Qc(a) {
        var b = Rc;
        a: {
            for (const c in b)
                if (b[c] == a) {
                    a = !0;
                    break a
                }
            a = !1
        }
        return a
    }

    function Sc(a) {
        const b = [];
        let c = 0;
        for (const d in a) b[c++] = a[d];
        return b
    }

    function Tc(a) {
        const b = {};
        for (const c in a) b[c] = a[c];
        return b
    }
    const Uc = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

    function Vc(a, b) {
        let c, d;
        for (let e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d) a[c] = d[c];
            for (let f = 0; f < Uc.length; f++) c = Uc[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    };
    var Wc = {
        area: !0,
        base: !0,
        br: !0,
        col: !0,
        command: !0,
        embed: !0,
        hr: !0,
        img: !0,
        input: !0,
        keygen: !0,
        link: !0,
        meta: !0,
        param: !0,
        source: !0,
        track: !0,
        wbr: !0
    };
    var Xc;

    function Yc() {
        if (void 0 === Xc) {
            var a = null,
                b = r.trustedTypes;
            if (b && b.createPolicy) {
                try {
                    a = b.createPolicy("goog#html", {
                        createHTML: Na,
                        createScript: Na,
                        createScriptURL: Na
                    })
                } catch (c) {
                    r.console && r.console.error(c.message)
                }
                Xc = a
            } else Xc = a
        }
        return Xc
    };
    var Zc = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g + ""
        }
    };

    function $c(a, b) {
        a = ad.exec(bd(a).toString());
        var c = a[3] || "";
        return cd(a[1] + dd("?", a[2] || "", b) + dd("#", c))
    }

    function bd(a) {
        return a instanceof Zc && a.constructor === Zc ? a.g : "type_error:TrustedResourceUrl"
    }

    function ed(a, b) {
        var c = zb(a);
        if (!fd.test(c)) throw Error("Invalid TrustedResourceUrl format: " + c);
        a = c.replace(gd, function(d, e) {
            if (!Object.prototype.hasOwnProperty.call(b, e)) throw Error('Found marker, "' + e + '", in format string, "' + c + '", but no valid label mapping found in args: ' + JSON.stringify(b));
            d = b[e];
            return d instanceof ub ? zb(d) : encodeURIComponent(String(d))
        });
        return cd(a)
    }
    var gd = /%{(\w+)}/g,
        fd = RegExp("^((https:)?//[0-9a-z.:[\\]-]+/|/[^/\\\\]|[^:/\\\\%]+/|[^:/\\\\%]*[?#]|about:blank#)", "i"),
        ad = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/,
        hd = {};

    function cd(a) {
        const b = Yc();
        a = b ? b.createScriptURL(a) : a;
        return new Zc(a, hd)
    }

    function dd(a, b, c) {
        if (null == c) return b;
        if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
        for (var d in c)
            if (Object.prototype.hasOwnProperty.call(c, d)) {
                var e = c[d];
                e = Array.isArray(e) ? e : [e];
                for (var f = 0; f < e.length; f++) {
                    var g = e[f];
                    null != g && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
                }
            }
        return b
    };
    var id = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g.toString()
        }
    };

    function jd(a) {
        return a instanceof id && a.constructor === id ? a.g : "type_error:SafeUrl"
    }
    var kd = /^data:(.*);base64,[a-z0-9+\/]+=*$/i,
        ld = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;

    function md(a) {
        if (a instanceof id) return a;
        a = String(a);
        ld.test(a) ? a = new id(a, nd) : (a = String(a).replace(/(%0A|%0D)/g, ""), a = a.match(kd) ? new id(a, nd) : null);
        return a
    }
    var nd = {},
        od = new id("about:invalid#zClosurez", nd);
    const pd = {};

    function qd(a) {
        return a instanceof rd && a.constructor === rd ? a.g : "type_error:SafeStyle"
    }

    function sd(a) {
        let b = "";
        for (let c in a)
            if (Object.prototype.hasOwnProperty.call(a, c)) {
                if (!/^[-_a-zA-Z0-9]+$/.test(c)) throw Error(`Name allows only [-_a-zA-Z0-9], got: ${c}`);
                let d = a[c];
                null != d && (d = Array.isArray(d) ? d.map(td).join(" ") : td(d), b += `${c}:${d};`)
            }
        return b ? new rd(b, pd) : ud
    }
    class rd {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g.toString()
        }
    }
    var ud = new rd("", pd);

    function td(a) {
        if (a instanceof id) return 'url("' + jd(a).replace(/</g, "%3c").replace(/[\\"]/g, "\\$&") + '")';
        if (a instanceof ub) a = zb(a);
        else {
            a = String(a);
            var b = a.replace(vd, "$1").replace(vd, "$1").replace(wd, "url");
            if (xd.test(b)) {
                if (b = !yd.test(a)) {
                    let c = b = !0;
                    for (let d = 0; d < a.length; d++) {
                        const e = a.charAt(d);
                        "'" == e && c ? b = !b : '"' == e && b && (c = !c)
                    }
                    b = b && c && zd(a)
                }
                a = b ? Ad(a) : "zClosurez"
            } else a = "zClosurez"
        }
        if (/[{;}]/.test(a)) throw new Ta("Value does not allow [{;}], got: %s.", [a]);
        return a
    }

    function zd(a) {
        let b = !0;
        const c = /^[-_a-zA-Z0-9]$/;
        for (let d = 0; d < a.length; d++) {
            const e = a.charAt(d);
            if ("]" == e) {
                if (b) return !1;
                b = !0
            } else if ("[" == e) {
                if (!b) return !1;
                b = !1
            } else if (!b && !c.test(e)) return !1
        }
        return b
    }
    const xd = RegExp("^[-+,.\"'%_!#/ a-zA-Z0-9\\[\\]]+$"),
        wd = RegExp("\\b(url\\([ \t\n]*)('[ -&(-\\[\\]-~]*'|\"[ !#-\\[\\]-~]*\"|[!#-&*-\\[\\]-~]*)([ \t\n]*\\))", "g"),
        vd = RegExp("\\b(calc|cubic-bezier|fit-content|hsl|hsla|linear-gradient|matrix|minmax|radial-gradient|repeat|rgb|rgba|(rotate|scale|translate)(X|Y|Z|3d)?|steps|var)\\([-+*/0-9a-zA-Z.%#\\[\\], ]+\\)", "g"),
        yd = /\/\*/;

    function Ad(a) {
        return a.replace(wd, (b, c, d, e) => {
            let f = "";
            d = d.replace(/^(['"])(.*)\1$/, (g, h, k) => {
                f = h;
                return k
            });
            b = (md(d) || od).toString();
            return c + f + b + f + e
        })
    };
    class Bd {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g.toString()
        }
    };
    const Cd = {};

    function Dd(a) {
        return a instanceof Ed && a.constructor === Ed ? a.g : "type_error:SafeHtml"
    }

    function Fd(a) {
        const b = Yc();
        a = b ? b.createHTML(a) : a;
        return new Ed(a, Cd)
    }

    function Gd(a) {
        if (!Hd.test(a)) throw Error("");
        if (a.toUpperCase() in Id) throw Error("");
    }

    function Jd(a, b, c) {
        var d = "";
        if (b)
            for (let g in b)
                if (Object.prototype.hasOwnProperty.call(b, g)) {
                    if (!Hd.test(g)) throw Error("");
                    var e = b[g];
                    if (null != e) {
                        var f = g;
                        if (e instanceof ub) e = zb(e);
                        else if ("style" == f.toLowerCase()) {
                            if (!Aa(e)) throw Error("");
                            e instanceof rd || (e = sd(e));
                            e = qd(e)
                        } else {
                            if (/^on/i.test(f)) throw Error("");
                            if (f.toLowerCase() in Kd)
                                if (e instanceof Zc) e = bd(e).toString();
                                else if (e instanceof id) e = jd(e);
                            else if ("string" === typeof e) e = (md(e) || od).toString();
                            else throw Error("");
                        }
                        f = `${f}="` + cc(String(e)) +
                            '"';
                        d += " " + f
                    }
                }
        b = `<${a}` + d;
        null == c ? c = [] : Array.isArray(c) || (c = [c]);
        !0 === Wc[a.toLowerCase()] ? b += ">" : (c = Ld(c), b += ">" + Dd(c).toString() + "</" + a + ">");
        return Fd(b)
    }

    function Md(a) {
        var b = Nd;
        b = b instanceof Ed ? b : Fd(cc(String(b)));
        const c = [],
            d = e => {
                Array.isArray(e) ? e.forEach(d) : (e = e instanceof Ed ? e : Fd(cc(String(e))), c.push(Dd(e).toString()))
            };
        a.forEach(d);
        return Fd(c.join(Dd(b).toString()))
    }

    function Ld(a) {
        return Md(Array.prototype.slice.call(arguments))
    }
    class Ed {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g.toString()
        }
    }
    const Hd = /^[a-zA-Z0-9-]+$/,
        Kd = {
            action: !0,
            cite: !0,
            data: !0,
            formaction: !0,
            href: !0,
            manifest: !0,
            poster: !0,
            src: !0
        },
        Id = {
            APPLET: !0,
            BASE: !0,
            EMBED: !0,
            IFRAME: !0,
            LINK: !0,
            MATH: !0,
            META: !0,
            OBJECT: !0,
            SCRIPT: !0,
            STYLE: !0,
            SVG: !0,
            TEMPLATE: !0
        };
    var Nd = new Ed(r.trustedTypes && r.trustedTypes.emptyHTML || "", Cd),
        Od = Fd("<br>");
    var Pd = Mb(function() {
        var a = document.createElement("div"),
            b = document.createElement("div");
        b.appendChild(document.createElement("div"));
        a.appendChild(b);
        b = a.firstChild.firstChild;
        a.innerHTML = Dd(Nd);
        return !b.parentElement
    });

    function Qd(a, b) {
        if (Pd())
            for (; a.lastChild;) a.removeChild(a.lastChild);
        a.innerHTML = Dd(b)
    }
    var Rd = /^[\w+/_-]+[=]{0,2}$/;

    function Ud(a, b, c) {
        return Math.min(Math.max(a, b), c)
    }

    function Vd(a) {
        return Array.prototype.reduce.call(arguments, function(b, c) {
            return b + c
        }, 0)
    }

    function Wd(a) {
        return Vd.apply(null, arguments) / arguments.length
    };

    function Xd(a, b) {
        this.x = void 0 !== a ? a : 0;
        this.y = void 0 !== b ? b : 0
    }
    Xd.prototype.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    Xd.prototype.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    Xd.prototype.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };

    function Yd(a, b) {
        this.width = a;
        this.height = b
    }

    function Zd(a, b) {
        return a == b ? !0 : a && b ? a.width == b.width && a.height == b.height : !1
    }
    ca = Yd.prototype;
    ca.aspectRatio = function() {
        return this.width / this.height
    };
    ca.isEmpty = function() {
        return !(this.width * this.height)
    };
    ca.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    ca.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    ca.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    function $d(a, b) {
        const c = {
            "&amp;": "&",
            "&lt;": "<",
            "&gt;": ">",
            "&quot;": '"'
        };
        let d;
        d = b ? b.createElement("div") : r.document.createElement("div");
        return a.replace(ae, function(e, f) {
            var g = c[e];
            if (g) return g;
            "#" == f.charAt(0) && (f = Number("0" + f.slice(1)), isNaN(f) || (g = String.fromCharCode(f)));
            g || (g = Fd(e + " "), Qd(d, g), g = d.firstChild.nodeValue.slice(0, -1));
            return c[e] = g
        })
    }
    var ae = /&([^;\s<&]+);?/g;

    function be(a) {
        let b = 0;
        for (let c = 0; c < a.length; ++c) b = 31 * b + a.charCodeAt(c) >>> 0;
        return b
    }

    function ce(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    }

    function de(a) {
        return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
            return c + d.toUpperCase()
        })
    };

    function ee(a) {
        return a ? new fe(ge(a)) : Sa || (Sa = new fe)
    }

    function he(a) {
        a = a.document;
        a = "CSS1Compat" == a.compatMode ? a.documentElement : a.body;
        return new Yd(a.clientWidth, a.clientHeight)
    }

    function ie(a) {
        var b = a.scrollingElement ? a.scrollingElement : Ec || "CSS1Compat" != a.compatMode ? a.body || a.documentElement : a.documentElement;
        a = je(a);
        return Ac && a.pageYOffset != b.scrollTop ? new Xd(b.scrollLeft, b.scrollTop) : new Xd(a.pageXOffset || b.scrollLeft, a.pageYOffset || b.scrollTop)
    }

    function je(a) {
        return a.parentWindow || a.defaultView
    }

    function ke(a, b) {
        b = String(b);
        "application/xhtml+xml" === a.contentType && (b = b.toLowerCase());
        return a.createElement(b)
    }

    function le(a, b) {
        var c = ke(a, "DIV");
        Ac ? (b = Ld(Od, b), Qd(c, b), c.removeChild(c.firstChild)) : Qd(c, b);
        if (1 == c.childNodes.length) c = c.removeChild(c.firstChild);
        else {
            for (a = a.createDocumentFragment(); c.firstChild;) a.appendChild(c.firstChild);
            c = a
        }
        return c
    }

    function ge(a) {
        return 9 == a.nodeType ? a : a.ownerDocument || a.document
    }
    var me = {
            SCRIPT: 1,
            STYLE: 1,
            HEAD: 1,
            IFRAME: 1,
            OBJECT: 1
        },
        ne = {
            IMG: " ",
            BR: "\n"
        };

    function oe(a) {
        var b = [];
        pe(a, b, !0);
        a = b.join("");
        a = a.replace(/ \xAD /g, " ").replace(/\xAD/g, "");
        a = a.replace(/\u200B/g, "");
        a = a.replace(/ +/g, " ");
        " " != a && (a = a.replace(/^\s*/, ""));
        return a
    }

    function pe(a, b, c) {
        if (!(a.nodeName in me))
            if (3 == a.nodeType) c ? b.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g, "")) : b.push(a.nodeValue);
            else if (a.nodeName in ne) b.push(ne[a.nodeName]);
        else
            for (a = a.firstChild; a;) pe(a, b, c), a = a.nextSibling
    }

    function qe(a, b, c) {
        if (!b && !c) return null;
        var d = b ? String(b).toUpperCase() : null;
        return re(a, function(e) {
            return (!d || e.nodeName == d) && (!c || "string" === typeof e.className && db(e.className.split(/\s+/), c))
        })
    }

    function re(a, b) {
        for (var c = 0; a;) {
            if (b(a)) return a;
            a = a.parentNode;
            c++
        }
        return null
    }

    function fe(a) {
        this.g = a || r.document || document
    }
    ca = fe.prototype;
    ca.xh = function(a) {
        var b = this.g;
        return "string" === typeof a ? b.getElementById(a) : a
    };
    ca.Jj = fe.prototype.xh;

    function se(a, b) {
        return ke(a.g, b)
    }

    function te(a, b) {
        return le(a.g, b)
    }
    ca.da = function() {
        return je(this.g)
    };
    ca.contains = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && 1 == b.nodeType) return a == b || a.contains(b);
        if ("undefined" != typeof a.compareDocumentPosition) return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };
    ca.xi = function(a) {
        var b, c = arguments.length;
        if (!c) return null;
        if (1 == c) return arguments[0];
        var d = [],
            e = Infinity;
        for (b = 0; b < c; b++) {
            for (var f = [], g = arguments[b]; g;) f.unshift(g), g = g.parentNode;
            d.push(f);
            e = Math.min(e, f.length)
        }
        f = null;
        for (b = 0; b < e; b++) {
            g = d[0][b];
            for (var h = 1; h < c; h++)
                if (g != d[h][b]) return f;
            f = g
        }
        return f
    };

    function ue() {
        return Zb && mc ? mc.mobile : !ve() && (y("iPod") || y("iPhone") || y("Android") || y("IEMobile"))
    }

    function ve() {
        return Zb && mc ? !mc.mobile && (y("iPad") || y("Android") || y("Silk")) : y("iPad") || y("Android") && !y("Mobile") || y("Silk")
    };
    var we = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function xe(a, b) {
        if (!b) return a;
        var c = a.indexOf("#");
        0 > c && (c = a.length);
        var d = a.indexOf("?");
        if (0 > d || d > c) {
            d = c;
            var e = ""
        } else e = a.substring(d + 1, c);
        a = [a.slice(0, d), e, a.slice(c)];
        c = a[1];
        a[1] = b ? c ? c + "&" + b : b : c;
        return a[0] + (a[1] ? "?" + a[1] : "") + a[2]
    }

    function ye(a, b, c) {
        if (Array.isArray(b))
            for (var d = 0; d < b.length; d++) ye(a, String(b[d]), c);
        else null != b && c.push(a + ("" === b ? "" : "=" + encodeURIComponent(String(b))))
    };

    function ze(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    class Ae {
        constructor(a) {
            this.Qi = a
        }
    }

    function Be(a) {
        return new Ae(b => b.substr(0, a.length + 1).toLowerCase() === a + ":")
    }
    const Ce = [Be("data"), Be("http"), Be("https"), Be("mailto"), Be("ftp"), new Ae(a => /^[^:]*([/?#]|$)/.test(a))];

    function De(a, b = Ce) {
        if (a instanceof id) return a;
        for (let c = 0; c < b.length; ++c) {
            const d = b[c];
            if (d instanceof Ae && d.Qi(a)) return new id(a, nd)
        }
    }

    function Ee(a) {
        a: {
            try {
                var b = new URL(a)
            } catch (c) {
                b = "https:";
                break a
            }
            b = b.protocol
        }
        if ("javascript:" !== b) return a
    };

    function Ke(a) {
        var b = De("#", Ce) || od;
        b = b instanceof id ? jd(b) : Ee(b);
        void 0 !== b && (a.href = b)
    };
    var Le = class {};
    class Me extends Le {
        constructor(a) {
            super();
            this.g = a
        }
        toString() {
            return this.g
        }
    };

    function Ne(a, b, c) {
        var d = [Oe `width`, Oe `height`];
        if (0 === d.length) throw Error("");
        d = d.map(f => {
            if (f instanceof Me) f = f.g;
            else throw Error("");
            return f
        });
        const e = b.toLowerCase();
        if (d.every(f => 0 !== e.indexOf(f))) throw Error(`Attribute "${b}" does not match any of the allowed prefixes.`);
        a.setAttribute(b, c)
    };

    function Pe(a, b = `unexpected value ${a}!`) {
        throw Error(b);
    };
    const Qe = "alternate author bookmark canonical cite help icon license modulepreload next prefetch dns-prefetch prerender preconnect preload prev search subresource".split(" ");

    function Re(a, b) {
        a.src = bd(b);
        (void 0) ? .Yn || (b = (b = (a.ownerDocument && a.ownerDocument.defaultView || window).document.querySelector ? .("script[nonce]")) ? b.nonce || b.getAttribute("nonce") || "" : "") && a.setAttribute("nonce", b)
    };

    function Se(a) {
        try {
            return !!a && null != a.location.href && Wb(a, "foo")
        } catch {
            return !1
        }
    }

    function Te(a, b = r) {
        b = Ue(b);
        let c = 0;
        for (; b && 40 > c++ && !a(b);) b = Ue(b)
    }

    function Ue(a) {
        try {
            const b = a.parent;
            if (b && b != a) return b
        } catch {}
        return null
    }

    function Ve(a) {
        return Se(a.top) ? a.top : null
    }

    function We(a, b) {
        const c = Xe("SCRIPT", a);
        Re(c, b);
        return (a = a.getElementsByTagName("script")[0]) && a.parentNode ? (a.parentNode.insertBefore(c, a), c) : null
    }

    function Ye(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    }

    function Ze() {
        if (!globalThis.crypto) return Math.random();
        try {
            const a = new Uint32Array(1);
            globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch {
            return Math.random()
        }
    }

    function $e(a, b) {
        if (a)
            for (const c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }

    function af(a) {
        const b = [];
        $e(a, function(c) {
            b.push(c)
        });
        return b
    }

    function bf(a) {
        const b = a.length;
        if (0 == b) return 0;
        let c = 305419896;
        for (let d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return 0 < c ? c : 4294967296 + c
    }
    var df = Mb(() => bb(["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"], cf) || 1E-4 > Math.random());
    const cf = a => kc(lc(), a);
    var ef = /^([0-9.]+)px$/,
        ff = /^(-?[0-9.]{1,30})$/;

    function gf(a) {
        if (!ff.test(a)) return null;
        a = Number(a);
        return isNaN(a) ? null : a
    }

    function hf(a) {
        return (a = ef.exec(a)) ? +a[1] : null
    }
    var jf = {
        lk: "allow-forms",
        mk: "allow-modals",
        nk: "allow-orientation-lock",
        pk: "allow-pointer-lock",
        qk: "allow-popups",
        rk: "allow-popups-to-escape-sandbox",
        sk: "allow-presentation",
        tk: "allow-same-origin",
        uk: "allow-scripts",
        vk: "allow-top-navigation",
        wk: "allow-top-navigation-by-user-activation"
    };
    const kf = Mb(() => af(jf));

    function lf() {
        var a = ["allow-top-navigation", "allow-modals", "allow-orientation-lock", "allow-presentation", "allow-pointer-lock"];
        const b = kf();
        return a.length ? Za(b, c => !db(a, c)) : b
    }

    function mf() {
        const a = Xe("IFRAME"),
            b = {};
        Va(kf(), c => {
            a.sandbox && a.sandbox.supports && a.sandbox.supports(c) && (b[c] = !0)
        });
        return b
    }
    var nf = (a, b) => {
            try {
                return !(!a.frames || !a.frames[b])
            } catch {
                return !1
            }
        },
        of = (a, b) => {
            for (let c = 0; 50 > c; ++c) {
                if (nf(a, b)) return a;
                if (!(a = Ue(a))) break
            }
            return null
        },
        pf = Mb(() => ue() ? 2 : ve() ? 1 : 0),
        A = (a, b) => {
            $e(b, (c, d) => {
                a.style.setProperty(d, c, "important")
            })
        },
        rf = (a, b) => {
            if ("length" in a.style) {
                a = a.style;
                const c = a.length;
                for (let d = 0; d < c; d++) {
                    const e = a[d];
                    b(a[e], e, a)
                }
            } else a = qf(a.style.cssText), $e(a, b)
        },
        qf = a => {
            const b = {};
            if (a) {
                const c = /\s*:\s*/;
                Va((a || "").split(/\s*;\s*/), d => {
                    if (d) {
                        var e = d.split(c);
                        d = e[0];
                        e = e[1];
                        d &&
                            e && (b[d.toLowerCase()] = e)
                    }
                })
            }
            return b
        },
        sf = a => {
            const b = /!\s*important/i;
            rf(a, (c, d) => {
                b.test(c) ? b.test(c) : a.style.setProperty(d, c, "important")
            })
        };
    const tf = {
            ["http://googleads.g.doubleclick.net"]: !0,
            ["http://pagead2.googlesyndication.com"]: !0,
            ["https://googleads.g.doubleclick.net"]: !0,
            ["https://pagead2.googlesyndication.com"]: !0
        },
        uf = /\.proxy\.(googleprod|googlers)\.com(:\d+)?$/,
        vf = /.*domain\.test$/,
        wf = /\.prod\.google\.com(:\d+)?$/;
    var xf = a => tf[a] || uf.test(a) || vf.test(a) || wf.test(a);
    let yf = [];
    const zf = () => {
        const a = yf;
        yf = [];
        for (const b of a) try {
            b()
        } catch {}
    };
    var Af = () => {
            var a = Math.random;
            return Math.floor(a() * 2 ** 52)
        },
        Bf = (a, b) => {
            if ("number" !== typeof a.goog_pvsid) try {
                Object.defineProperty(a, "goog_pvsid", {
                    value: Af(),
                    configurable: !1
                })
            } catch (c) {
                b && b.Ba(784, c)
            }
            a = Number(a.goog_pvsid);
            b && (!a || 0 >= a) && b.Ba(784, Error(`Invalid correlator, ${a}`));
            return a || -1
        },
        Cf = (a, b) => {
            "complete" === a.document.readyState ? (yf.push(b), 1 == yf.length && (window.Promise ? Promise.resolve().then(zf) : window.setImmediate ? setImmediate(zf) : setTimeout(zf, 0))) : a.addEventListener("load", b)
        },
        Df = (a,
            b) => new Promise(c => {
            setTimeout(() => void c(b), a)
        });

    function Xe(a, b = document) {
        return b.createElement(String(a).toLowerCase())
    }
    var Ef = a => {
            let b = a;
            for (; a && a != a.parent;) a = a.parent, Se(a) && (b = a);
            return b
        },
        Gf = a => v(Db) || xc() && ue() ? Ff(a) : 1,
        Ff = a => {
            var b = Ve(a);
            if (!b) return 1;
            a = 0 === pf();
            const c = !!b.document.querySelector('meta[name=viewport][content*="width=device-width"]'),
                d = b.innerWidth;
            b = b.outerWidth;
            if (0 === d) return 1;
            const e = Math.round(100 * (b / d + Number.EPSILON)) / 100;
            return 1 === e ? 1 : a || c ? e : Math.round(100 * (b / d / .4 + Number.EPSILON)) / 100
        };

    function Hf(a) {
        r.setTimeout(() => {
            throw a;
        }, 0)
    };
    yc();
    xc();
    wc();
    var If = {},
        Jf = null;

    function Kf(a) {
        var b = 3;
        void 0 === b && (b = 0);
        Lf();
        b = If[b];
        const c = Array(Math.floor(a.length / 3)),
            d = b[64] || "";
        let e = 0,
            f = 0;
        for (; e < a.length - 2; e += 3) {
            var g = a[e],
                h = a[e + 1],
                k = a[e + 2],
                l = b[g >> 2];
            g = b[(g & 3) << 4 | h >> 4];
            h = b[(h & 15) << 2 | k >> 6];
            k = b[k & 63];
            c[f++] = l + g + h + k
        }
        l = 0;
        k = d;
        switch (a.length - e) {
            case 2:
                l = a[e + 1], k = b[(l & 15) << 2] || d;
            case 1:
                a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
        }
        return c.join("")
    }

    function Mf(a) {
        for (var b = [], c = 0, d = 0; d < a.length; d++) {
            var e = a.charCodeAt(d);
            255 < e && (b[c++] = e & 255, e >>= 8);
            b[c++] = e
        }
        return Kf(b)
    }

    function Nf(a) {
        var b = [];
        Of(a, function(c) {
            b.push(c)
        });
        return b
    }

    function Of(a, b) {
        function c(k) {
            for (; d < a.length;) {
                var l = a.charAt(d++),
                    m = Jf[l];
                if (null != m) return m;
                if (!/^[\s\xa0]*$/.test(l)) throw Error("Unknown base64 encoding at char: " + l);
            }
            return k
        }
        Lf();
        for (var d = 0;;) {
            var e = c(-1),
                f = c(0),
                g = c(64),
                h = c(64);
            if (64 === h && -1 === e) break;
            b(e << 2 | f >> 4);
            64 != g && (b(f << 4 & 240 | g >> 2), 64 != h && b(g << 6 & 192 | h))
        }
    }

    function Lf() {
        if (!Jf) {
            Jf = {};
            for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++) {
                var d = a.concat(b[c].split(""));
                If[c] = d;
                for (var e = 0; e < d.length; e++) {
                    var f = d[e];
                    void 0 === Jf[f] && (Jf[f] = e)
                }
            }
        }
    };

    function Pf(a) {
        let b = "",
            c = 0;
        const d = a.length - 10240;
        for (; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
        b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
        return btoa(b)
    }
    const Qf = /[-_.]/g,
        Rf = {
            "-": "+",
            _: "/",
            ".": "="
        };

    function Sf(a) {
        return Rf[a] || ""
    }

    function Tf(a) {
        return null != a && a instanceof Uint8Array
    }
    let Uf;
    var Vf = {};
    let Wf;

    function Xf(a) {
        if (a !== Vf) throw Error("illegal external caller");
    }

    function Yf() {
        return Wf || (Wf = new mg(null, Vf))
    }
    var mg = class {
        constructor(a, b) {
            Xf(b);
            this.M = a;
            if (null != a && 0 === a.length) throw Error("ByteString should be constructed with non-empty values");
        }
        isEmpty() {
            return null == this.M
        }
    };
    var ng = !$b;
    let og = !$b;
    let pg = 0,
        qg = 0;

    function rg(a) {
        var b = 0 > a;
        a = Math.abs(a);
        var c = a >>> 0;
        a = Math.floor((a - c) / 4294967296);
        if (b) {
            b = c;
            c = ~a;
            b ? b = ~b + 1 : c += 1;
            const [d, e] = [b, c];
            a = e;
            c = d
        }
        pg = c >>> 0;
        qg = a >>> 0
    }

    function sg(a, b) {
        b >>>= 0;
        a >>>= 0;
        var c;
        2097151 >= b ? c = "" + (4294967296 * b + a) : c = "" + (BigInt(b) << BigInt(32) | BigInt(a));
        return c
    }

    function tg() {
        var a = pg,
            b = qg,
            c;
        b & 2147483648 ? c = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : c = sg(a, b);
        return c
    }

    function ug(a) {
        16 > a.length ? rg(Number(a)) : (a = BigInt(a), pg = Number(a & BigInt(4294967295)) >>> 0, qg = Number(a >> BigInt(32) & BigInt(4294967295)))
    };

    function vg(a) {
        return Array.prototype.slice.call(a)
    };
    var B = Symbol(),
        wg = Symbol(),
        xg = Symbol();

    function yg(a) {
        const b = a[B] | 0;
        1 !== (b & 1) && (Object.isFrozen(a) && (a = vg(a)), a[B] = b | 1)
    }

    function zg(a, b, c) {
        return c ? a | b : a & ~b
    }

    function Ag() {
        var a = [];
        a[B] |= 1;
        return a
    }

    function Bg(a) {
        a[B] |= 34;
        return a
    }

    function Cg(a) {
        a[B] |= 32;
        return a
    }

    function Dg(a, b) {
        b[B] = (a | 0) & -14591
    }

    function Eg(a, b) {
        b[B] = (a | 34) & -14557
    }

    function Fg(a) {
        a = a >> 14 & 1023;
        return 0 === a ? 536870912 : a
    };
    var Gg = {},
        Hg = {};

    function Ig(a) {
        return !(!a || "object" !== typeof a || a.Vi !== Hg)
    }

    function Jg(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    }
    let Kg, Lg = !$b;

    function Mg(a, b, c) {
        if (null != a)
            if ("string" === typeof a) a = a ? new mg(a, Vf) : Yf();
            else if (a.constructor !== mg)
            if (Tf(a)) {
                var d;
                c ? d = 0 == a.length ? Yf() : new mg(a, Vf) : d = a.length ? new mg(new Uint8Array(a), Vf) : Yf();
                a = d
            } else {
                if (!b) throw Error();
                a = void 0
            }
        return a
    }

    function Ng(a, b, c) {
        if (!Array.isArray(a) || a.length) return !1;
        const d = a[B] | 0;
        if (d & 1) return !0;
        if (!(b && (Array.isArray(b) ? b.includes(c) : b.has(c)))) return !1;
        a[B] = d | 1;
        return !0
    }
    var Og;
    const Pg = [];
    Pg[B] = 55;
    Og = Object.freeze(Pg);

    function Qg(a) {
        if (a & 2) throw Error();
    }
    class Rg {
        constructor(a, b, c) {
            this.j = 0;
            this.g = a;
            this.i = b;
            this.l = c
        }
        next() {
            if (this.j < this.g.length) {
                const a = this.g[this.j++];
                return {
                    done: !1,
                    value: this.i ? this.i.call(this.l, a) : a
                }
            }
            return {
                done: !0,
                value: void 0
            }
        }[Symbol.iterator]() {
            return new Rg(this.g, this.i, this.l)
        }
    }
    var Sg = {};
    class Tg {}
    class Ug {}
    Object.freeze(new Tg);
    Object.freeze(new Ug);
    let Vg;

    function Wg(a) {
        if (Vg) throw Error("");
        Vg = a
    }

    function Xg(a) {
        if (Vg) try {
            Vg(a)
        } catch (b) {
            throw b.cause = a, b;
        }
    }

    function Yg() {
        const a = Zg();
        Vg ? r.setTimeout(() => {
            Xg(a)
        }, 0) : Hf(a)
    }

    function $g(a) {
        a = Error(a);
        ze(a, "warning");
        Xg(a);
        return a
    }

    function Zg() {
        const a = Error();
        ze(a, "incident");
        return a
    };

    function ah(a) {
        if (null != a && "number" !== typeof a) throw Error(`Value of float/double field must be a number, found ${typeof a}: ${a}`);
        return a
    }

    function bh(a) {
        if ("boolean" !== typeof a) throw Error(`Expected boolean but got ${ya(a)}: ${a}`);
        return a
    }
    const ch = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function dh(a) {
        const b = typeof a;
        return "number" === b ? Number.isFinite(a) : "string" !== b ? !1 : ch.test(a)
    }

    function eh(a) {
        if (null != a) {
            if (!Number.isFinite(a)) throw $g("enum");
            a |= 0
        }
        return a
    }

    function fh(a) {
        return null == a ? a : Number.isFinite(a) ? a | 0 : void 0
    }

    function gh(a) {
        if ("number" !== typeof a) throw $g("int32");
        if (!Number.isFinite(a)) throw $g("int32");
        return a | 0
    }

    function hh(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return Number.isFinite(a) ? a | 0 : void 0
    }

    function ih(a) {
        if ("number" !== typeof a) throw $g("uint32");
        if (!Number.isFinite(a)) throw $g("uint32");
        return a >>> 0
    }

    function jh(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return Number.isFinite(a) ? a >>> 0 : void 0
    }

    function kh(a, b) {
        b = !!b;
        if (!dh(a)) throw $g("int64");
        "string" === typeof a ? a = lh(a) : b ? (a = Math.trunc(a), Number.isSafeInteger(a) ? a = String(a) : (b = String(a), mh(b) ? a = b : (rg(a), a = tg()))) : a = nh(a);
        return a
    }

    function oh(a) {
        return "-" === a[0] ? !1 : 20 > a.length ? !0 : 20 === a.length && 184467 > Number(a.substring(0, 6))
    }

    function mh(a) {
        return "-" === a[0] ? 20 > a.length ? !0 : 20 === a.length && -922337 < Number(a.substring(0, 7)) : 19 > a.length ? !0 : 19 === a.length && 922337 > Number(a.substring(0, 6))
    }

    function ph(a) {
        if (0 > a) {
            rg(a);
            const b = sg(pg, qg);
            a = Number(b);
            return Number.isSafeInteger(a) ? a : b
        }
        if (oh(String(a))) return a;
        rg(a);
        return 4294967296 * qg + (pg >>> 0)
    }

    function nh(a) {
        a = Math.trunc(a);
        if (!Number.isSafeInteger(a)) {
            rg(a);
            var b = pg,
                c = qg;
            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, 0 == b && (c = c + 1 >>> 0);
            b = 4294967296 * c + (b >>> 0);
            a = a ? -b : b
        }
        return a
    }

    function lh(a) {
        var b = Math.trunc(Number(a));
        if (Number.isSafeInteger(b)) return String(b);
        b = a.indexOf("."); - 1 !== b && (a = a.substring(0, b));
        mh(a) || (ug(a), a = tg());
        return a
    }

    function qh(a) {
        if (null == a) return a;
        if (dh(a)) {
            var b;
            "number" === typeof a ? b = nh(a) : b = lh(a);
            return b
        }
    }

    function rh(a, b) {
        b = !!b;
        if (!dh(a)) throw $g("uint64");
        "string" === typeof a ? (b = Math.trunc(Number(a)), Number.isSafeInteger(b) && 0 <= b ? a = String(b) : (b = a.indexOf("."), -1 !== b && (a = a.substring(0, b)), oh(a) || (ug(a), a = sg(pg, qg)))) : b ? (a = Math.trunc(a), 0 <= a && Number.isSafeInteger(a) ? a = String(a) : (b = String(a), oh(b) ? a = b : (rg(a), a = sg(pg, qg)))) : (a = Math.trunc(a), a = 0 <= a && Number.isSafeInteger(a) ? a : ph(a));
        return a
    }

    function sh(a) {
        return null == a ? a : rh(a)
    }

    function th(a) {
        if ("string" !== typeof a) throw Error();
        return a
    }

    function uh(a) {
        if (null != a && "string" !== typeof a) throw Error();
        return a
    }

    function vh(a) {
        return null == a || "string" === typeof a ? a : void 0
    }

    function wh(a, b, c, d) {
        if (null != a && "object" === typeof a && a.Ue === Gg) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? xh(b) : new b : void 0;
        let e = c = a[B] | 0;
        0 === e && (e |= d & 32);
        e |= d & 2;
        e !== c && (a[B] = e);
        return new b(a)
    }

    function xh(a) {
        var b = a[wg];
        if (b) return b;
        b = new a;
        Bg(b.W);
        return a[wg] = b
    }

    function yh(a, b, c) {
        return b ? th(a) : vh(a) ? ? (c ? "" : void 0)
    };
    const zh = (() => class extends Map {
        constructor() {
            super()
        }
    })();

    function Ah(a) {
        return a
    }

    function Bh(a) {
        if (a.Xc & 2) throw Error("Cannot mutate an immutable Map");
    }
    var Fh = class extends zh {
        constructor(a, b, c = Ah, d = Ah) {
            super();
            let e = a[B] | 0;
            e |= 64;
            this.Xc = a[B] = e;
            this.Wd = b;
            this.Cc = c || Ah;
            this.xf = this.Wd ? Ch : d || Ah;
            for (let f = 0; f < a.length; f++) {
                const g = a[f],
                    h = c(g[0], !1, !0);
                let k = g[1];
                b ? void 0 === k && (k = null) : k = d(g[1], !1, !0, void 0, void 0, e);
                super.set(h, k)
            }
        }
        jh(a = Dh) {
            return this.tf(a)
        }
        tf(a = Dh) {
            const b = [],
                c = super.entries();
            for (var d; !(d = c.next()).done;) d = d.value, d[0] = a(d[0]), d[1] = a(d[1]), b.push(d);
            return b
        }
        zc() {
            return this.size
        }
        clear() {
            Bh(this);
            super.clear()
        }
        delete(a) {
            Bh(this);
            return super.delete(this.Cc(a, !0, !1))
        }
        entries() {
            var a = this.yg();
            return new Rg(a, Eh, this)
        }
        keys() {
            return this.Ri()
        }
        values() {
            var a = this.yg();
            return new Rg(a, Fh.prototype.get, this)
        }
        forEach(a, b) {
            super.forEach((c, d) => {
                a.call(b, this.get(d), d, this)
            })
        }
        set(a, b) {
            Bh(this);
            a = this.Cc(a, !0, !1);
            return null == a ? this : null == b ? (super.delete(a), this) : super.set(a, this.xf(b, !0, !0, this.Wd, !1, this.Xc))
        }
        has(a) {
            return super.has(this.Cc(a, !1, !1))
        }
        get(a) {
            a = this.Cc(a, !1, !1);
            const b = super.get(a);
            if (void 0 !== b) {
                var c = this.Wd;
                return c ?
                    (c = this.xf(b, !1, !0, c, this.Uh, this.Xc), c !== b && super.set(a, c), c) : b
            }
        }
        yg() {
            return Array.from(super.keys())
        }
        Ri() {
            return super.keys()
        }[Symbol.iterator]() {
            return this.entries()
        }
    };
    Fh.prototype.toJSON = void 0;
    Fh.prototype.Vi = Hg;

    function Ch(a, b, c, d, e, f) {
        a = wh(a, d, c, f);
        e && (a = Gh(a));
        return a
    }

    function Dh(a) {
        return a
    }

    function Eh(a) {
        return [a, this.get(a)]
    };
    let Hh;

    function Ih(a, b) {
        Hh = b;
        a = new a(b);
        Hh = void 0;
        return a
    };

    function Jh(a, b) {
        return Kh(b)
    }

    function Kh(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a) {
                    if (Array.isArray(a)) return Lg || !Ng(a, void 0, 9999) ? a : void 0;
                    if (Tf(a)) return Pf(a);
                    if (a instanceof mg) {
                        const b = a.M;
                        return null == b ? "" : "string" === typeof b ? b : a.M = Pf(b)
                    }
                    if (a instanceof Fh) return a = a.jh(), ng || 0 !== a.length ? a : void 0
                }
        }
        return a
    };

    function Lh(a, b, c) {
        a = vg(a);
        var d = a.length;
        const e = b & 256 ? a[d - 1] : void 0;
        d += e ? -1 : 0;
        for (b = b & 512 ? 1 : 0; b < d; b++) a[b] = c(a[b]);
        if (e) {
            b = a[b] = {};
            for (const f in e) Object.prototype.hasOwnProperty.call(e, f) && (b[f] = c(e[f]))
        }
        return a
    }

    function Mh(a, b, c, d, e, f) {
        if (null != a) {
            if (Array.isArray(a)) a = e && 0 == a.length && (a[B] | 0) & 1 ? void 0 : f && (a[B] | 0) & 2 ? a : Nh(a, b, c, void 0 !== d, e, f);
            else if (Jg(a)) {
                const g = {};
                for (let h in a) Object.prototype.hasOwnProperty.call(a, h) && (g[h] = Mh(a[h], b, c, d, e, f));
                a = g
            } else a = b(a, d);
            return a
        }
    }

    function Nh(a, b, c, d, e, f) {
        const g = d || c ? a[B] | 0 : 0;
        d = d ? !!(g & 32) : void 0;
        a = vg(a);
        for (let h = 0; h < a.length; h++) a[h] = Mh(a[h], b, c, d, e, f);
        c && c(g, a);
        return a
    }

    function Oh(a) {
        return Mh(a, Ph, void 0, void 0, !1, !1)
    }

    function Ph(a) {
        return a.Ue === Gg ? a.toJSON() : a instanceof Fh ? a.jh(Oh) : Kh(a)
    };

    function Qh(a, b, c = Eg) {
        if (null != a) {
            if (a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = a[B] | 0;
                if (d & 2) return a;
                b && (b = 0 === d || !!(d & 32) && !(d & 64 || !(d & 16)));
                return b ? (a[B] = (d | 34) & -12293, a) : Nh(a, Qh, d & 4 ? Eg : c, !0, !1, !0)
            }
            a.Ue === Gg ? (c = a.W, d = c[B], a = d & 2 ? a : Ih(a.constructor, Rh(c, d, !0))) : a instanceof Fh && (c = Bg(a.tf(Qh)), a = new Fh(c, a.Wd, a.Cc, a.xf));
            return a
        }
    }

    function Sh(a) {
        const b = a.W;
        return Ih(a.constructor, Rh(b, b[B], !1))
    }

    function Rh(a, b, c) {
        const d = c || b & 2 ? Eg : Dg,
            e = !!(b & 32);
        a = Lh(a, b, f => Qh(f, e, d));
        a[B] = a[B] | 32 | (c ? 2 : 0);
        return a
    }

    function Gh(a) {
        const b = a.W,
            c = b[B];
        return c & 2 ? Ih(a.constructor, Rh(b, c, !1)) : a
    };

    function Th(a, b, c) {
        if (!(4 & b)) return !0;
        if (null == c) return !1;
        0 === c && (4096 & b || 8192 & b) && 5 > (a.constructor[xg] = (a.constructor[xg] | 0) + 1) && Yg();
        return 0 === c ? !1 : !(c & b)
    }

    function Uh(a, b) {
        a = a.W;
        return Vh(a, a[B], b)
    }

    function Vh(a, b, c, d) {
        if (-1 === c) return null;
        if (c >= Fg(b)) {
            if (b & 256) return a[a.length - 1][c]
        } else {
            var e = a.length;
            if (d && b & 256 && (d = a[e - 1][c], null != d)) return d;
            b = c + (+!!(b & 512) - 1);
            if (b < e) return a[b]
        }
    }

    function Wh(a, b, c) {
        const d = a.W;
        let e = d[B];
        Qg(e);
        Xh(d, e, b, c);
        return a
    }

    function Xh(a, b, c, d, e) {
        const f = Fg(b);
        if (c >= f || e) {
            let g = b;
            if (b & 256) e = a[a.length - 1];
            else {
                if (null == d) return g;
                e = a[f + (+!!(b & 512) - 1)] = {};
                g |= 256
            }
            e[c] = d;
            c < f && (a[c + (+!!(b & 512) - 1)] = void 0);
            g !== b && (a[B] = g);
            return g
        }
        a[c + (+!!(b & 512) - 1)] = d;
        b & 256 && (a = a[a.length - 1], c in a && delete a[c]);
        return b
    }

    function Yh(a, b, c) {
        return void 0 !== Zh(a, b, c, !1)
    }

    function $h(a, b) {
        a = a.W;
        let c = a[B];
        const d = Vh(a, c, b);
        var e = null == d || "number" === typeof d ? d : "NaN" === d || "Infinity" === d || "-Infinity" === d ? Number(d) : void 0;
        null != e && e !== d && Xh(a, c, b, e);
        return e
    }

    function ai(a, b) {
        a = Uh(a, b);
        return null == a || "boolean" === typeof a ? a : "number" === typeof a ? !!a : void 0
    }

    function bi(a, b, c, d, e, f, g) {
        const h = a.W;
        let k = h[B];
        d = 2 & k ? 1 : d;
        f = !!f;
        let l = ci(h, k, b, e);
        var m = l[B] | 0;
        if (Th(a, m, g)) {
            if (4 & m || Object.isFrozen(l)) l = vg(l), m = di(m, k, f), k = Xh(h, k, b, l, e);
            let p = a = 0;
            for (; a < l.length; a++) {
                const q = c(l[a]);
                null != q && (l[p++] = q)
            }
            p < a && (l.length = p);
            m = ei(m, k, f);
            m = zg(m, 20, !0);
            m = zg(m, 4096, !1);
            m = zg(m, 8192, !1);
            g && (m = zg(m, g, !0));
            l[B] = m;
            2 & m && Object.freeze(l)
        }
        fi(m) || (g = m, (c = 1 === d) ? m = zg(m, 2, !0) : f || (m = zg(m, 32, !1)), m !== g && (l[B] = m), c && Object.freeze(l));
        2 === d && fi(m) && (l = vg(l), m = di(m, k, f), l[B] = m, Xh(h,
            k, b, l, e));
        var n;
        f ? n = l : n = l;
        return n
    }

    function ci(a, b, c, d) {
        a = Vh(a, b, c, d);
        return Array.isArray(a) ? a : Og
    }

    function ei(a, b, c) {
        0 === a && (a = di(a, b, c));
        return a = zg(a, 1, !0)
    }

    function fi(a) {
        return !!(2 & a) && !!(4 & a) || !!(2048 & a)
    }
    let gi;

    function hi() {
        return gi ? ? (gi = new Fh(Bg([]), void 0, void 0, void 0, Sg))
    }

    function ii(a, b, c) {
        var d = ji,
            e = b & 2;
        let f = !1;
        if (null == c) {
            if (e) return hi();
            c = []
        } else if (c.constructor === Fh) {
            if (0 == (c.Xc & 2) || e) return c;
            c = c.tf()
        } else Array.isArray(c) ? f = !!((c[B] | 0) & 2) : c = [];
        if (e) {
            if (!c.length) return hi();
            f || (f = !0, Bg(c))
        } else if (f) {
            f = !1;
            e = vg(c);
            for (c = 0; c < e.length; c++) {
                const g = e[c] = vg(e[c]);
                Array.isArray(g[1]) && (g[1] = Bg(g[1]))
            }
            c = e
        }
        f || ((c[B] | 0) & 64 ? c[B] &= -33 : 32 & b && Cg(c));
        d = new Fh(c, d, yh, void 0);
        Xh(a, b, 14, d, !1);
        return d
    }

    function ki(a, b, c, d) {
        const e = a.W;
        let f = e[B];
        Qg(f);
        if (null == c) return Xh(e, f, b), a;
        let g = c[B] | 0,
            h = g;
        var k = !!(2 & g) || Object.isFrozen(c);
        const l = !k && !1;
        if (Th(a, g))
            for (g = 21, k && (c = vg(c), h = 0, g = di(g, f, !0)), k = 0; k < c.length; k++) c[k] = d(c[k]);
        l && (c = vg(c), h = 0, g = di(g, f, !0));
        g !== h && (c[B] = g);
        Xh(e, f, b, c);
        return a
    }

    function li(a, b, c, d) {
        const e = a.W;
        let f = e[B];
        Qg(f);
        Xh(e, f, b, ("0" === d ? 0 === Number(c) : c === d) ? void 0 : c);
        return a
    }

    function mi(a, b, c, d) {
        const e = a.W;
        let f = e[B];
        Qg(f);
        (c = ni(e, f, c)) && c !== b && null != d && (f = Xh(e, f, c));
        Xh(e, f, b, d);
        return a
    }

    function oi(a, b, c) {
        a = a.W;
        return ni(a, a[B], b) === c ? c : -1
    }

    function ni(a, b, c) {
        let d = 0;
        for (let e = 0; e < c.length; e++) {
            const f = c[e];
            null != Vh(a, b, f) && (0 !== d && (b = Xh(a, b, d)), d = f)
        }
        return d
    }

    function Zh(a, b, c, d) {
        a = a.W;
        let e = a[B];
        const f = Vh(a, e, c, d);
        b = wh(f, b, !1, e);
        b !== f && null != b && Xh(a, e, c, b, d);
        return b
    }

    function pi(a) {
        var b = qi;
        return (a = Zh(a, b, 1, !1)) ? a : xh(b)
    }

    function C(a, b, c) {
        b = Zh(a, b, c, !1);
        if (null == b) return b;
        a = a.W;
        let d = a[B];
        if (!(d & 2)) {
            const e = Gh(b);
            e !== b && (b = e, Xh(a, d, c, b, !1))
        }
        return b
    }

    function ri(a, b, c, d, e, f, g, h) {
        var k = !!(2 & b),
            l = k ? 1 : e;
        e = 1 === l;
        l = 2 === l;
        g = !!g;
        h && (h = !k);
        k = ci(a, b, d, f);
        var m = k[B] | 0;
        const n = !!(4 & m);
        if (!n) {
            m = ei(m, b, g);
            var p = k,
                q = b;
            const x = !!(2 & m);
            x && (q = zg(q, 2, !0));
            let z = !x,
                G = !0,
                E = 0,
                K = 0;
            for (; E < p.length; E++) {
                const H = wh(p[E], c, !1, q);
                if (H instanceof c) {
                    if (!x) {
                        const N = !!((H.W[B] | 0) & 2);
                        z && (z = !N);
                        G && (G = N)
                    }
                    p[K++] = H
                }
            }
            K < E && (p.length = K);
            m = zg(m, 4, !0);
            m = zg(m, 16, G);
            m = zg(m, 8, z);
            p[B] = m;
            x && Object.freeze(p)
        }
        c = !!(8 & m) || e && !k.length;
        if (h && !c) {
            fi(m) && (k = vg(k), m = di(m, b, g), b = Xh(a, b, d, k, f));
            h =
                k;
            c = m;
            for (p = 0; p < h.length; p++) m = h[p], q = Gh(m), m !== q && (h[p] = q);
            c = zg(c, 8, !0);
            c = zg(c, 16, !h.length);
            m = h[B] = c
        }
        fi(m) || (h = m, e ? m = zg(m, !k.length || 16 & m && (!n || 32 & m) ? 2 : 2048, !0) : g || (m = zg(m, 32, !1)), m !== h && (k[B] = m), e && Object.freeze(k));
        l && fi(m) && (k = vg(k), m = di(m, b, g), k[B] = m, Xh(a, b, d, k, f));
        return k
    }

    function D(a, b, c) {
        a = a.W;
        const d = a[B];
        return ri(a, d, b, c, 2, void 0, !1, !(2 & d))
    }

    function F(a, b, c) {
        null == c && (c = void 0);
        return Wh(a, b, c)
    }

    function I(a, b, c, d) {
        null == d && (d = void 0);
        return mi(a, b, c, d)
    }

    function si(a, b, c) {
        const d = a.W;
        let e = d[B];
        Qg(e);
        if (null == c) return Xh(d, e, b), a;
        let f = c[B] | 0,
            g = f;
        const h = !!(2 & f) || !!(2048 & f),
            k = h || Object.isFrozen(c);
        let l = !0,
            m = !0;
        for (let p = 0; p < c.length; p++) {
            var n = c[p];
            h || (n = !!((n.W[B] | 0) & 2), l && (l = !n), m && (m = n))
        }
        h || (f = zg(f, 5, !0), f = zg(f, 8, l), f = zg(f, 16, m));
        k && f !== g && (c = vg(c), g = 0, f = di(f, e, !0));
        f !== g && (c[B] = f);
        Xh(d, e, b, c);
        return a
    }

    function di(a, b, c) {
        a = zg(a, 2, !!(2 & b));
        a = zg(a, 32, !!(32 & b) && c);
        return a = zg(a, 2048, !1)
    }

    function ti(a, b, c, d, e, f, g) {
        a = a.W;
        const h = a[B];
        Qg(h);
        b = ri(a, h, c, b, 2, f, !0);
        c = null != d ? d : new c;
        if (g && ("number" !== typeof e || 0 > e || e > b.length)) throw Error();
        void 0 != e ? b.splice(e, g, c) : b.push(c);
        b[B] = (c.W[B] | 0) & 2 ? b[B] & -9 : b[B] & -17
    }

    function ui(a, b) {
        return hh(Uh(a, b))
    }

    function vi(a, b) {
        return qh(Uh(a, b))
    }

    function L(a, b) {
        return vh(Uh(a, b))
    }

    function M(a, b) {
        return fh(Uh(a, b))
    }

    function wi(a) {
        return a ? ? 0
    }

    function O(a, b, c = !1) {
        return ai(a, b) ? ? c
    }

    function xi(a, b) {
        return wi(ui(a, b))
    }

    function Qi(a, b) {
        return wi(vi(a, b))
    }

    function P(a, b) {
        return L(a, b) ? ? ""
    }

    function Ri(a, b) {
        return wi(M(a, b))
    }

    function Si(a, b, c, d) {
        return C(a, b, oi(a, d, c))
    }

    function Ti(a, b) {
        a = ui(a, b);
        return null == a ? void 0 : a
    }

    function Ui(a) {
        a = $h(a, 4);
        return null == a ? void 0 : a
    }

    function Vi(a, b, c) {
        return Wh(a, b, null == c ? c : bh(c))
    }

    function Wi(a, b, c) {
        return li(a, b, null == c ? c : bh(c), !1)
    }

    function Xi(a, b, c) {
        return Wh(a, b, null == c ? c : gh(c))
    }

    function Yi(a, b, c) {
        return li(a, b, null == c ? c : gh(c), 0)
    }

    function Zi(a, b, c) {
        return Wh(a, b, null == c ? c : kh(c))
    }

    function Q(a, b, c) {
        return li(a, b, null == c ? c : kh(c), "0")
    }

    function $i(a, b, c) {
        return Wh(a, b, uh(c))
    }

    function aj(a, b, c) {
        return li(a, b, uh(c), "")
    }

    function R(a, b, c) {
        return li(a, b, eh(c), 0)
    };

    function bj(a) {
        Kg = !0;
        try {
            return JSON.stringify(a.toJSON(), Jh)
        } finally {
            Kg = !1
        }
    }
    var S = class {
        constructor(a) {
            a: {
                null == a && (a = Hh);Hh = void 0;
                if (null == a) {
                    var b = 96;
                    a = []
                } else {
                    if (!Array.isArray(a)) throw Error();
                    b = a[B] | 0;
                    if (b & 64) break a;
                    var c = a;
                    b |= 64;
                    var d = c.length;
                    if (d && (--d, Jg(c[d]))) {
                        b |= 256;
                        c = d - (+!!(b & 512) - 1);
                        if (1024 <= c) throw Error();
                        b = b & -16760833 | (c & 1023) << 14
                    }
                }
                a[B] = b
            }
            this.W = a
        }
        toJSON() {
            if (Kg) var a = cj(this, this.W, !1);
            else a = Nh(this.W, Ph, void 0, void 0, !1, !1), a = cj(this, a, !0);
            return a
        }
        i() {
            const a = this.W,
                b = a[B];
            return b & 2 ? this : Ih(this.constructor, Rh(a, b, !0))
        }
    };
    S.prototype.Ue = Gg;

    function cj(a, b, c) {
        const d = a.constructor.P;
        var e = (c ? a.W : b)[B],
            f = Fg(e),
            g = !1;
        if (d && Lg) {
            if (!c) {
                b = vg(b);
                var h;
                if (b.length && Jg(h = b[b.length - 1]))
                    for (g = 0; g < d.length; g++)
                        if (d[g] >= f) {
                            Object.assign(b[b.length - 1] = {}, h);
                            break
                        }
                g = !0
            }
            f = b;
            c = !c;
            h = a.W[B];
            a = Fg(h);
            h = +!!(h & 512) - 1;
            var k;
            for (let E = 0; E < d.length; E++) {
                var l = d[E];
                if (l < a) {
                    l += h;
                    var m = f[l];
                    null == m ? f[l] = c ? Og : Ag() : c && m !== Og && yg(m)
                } else {
                    if (!k) {
                        var n = void 0;
                        f.length && Jg(n = f[f.length - 1]) ? k = n : f.push(k = {})
                    }
                    m = k[l];
                    null == k[l] ? k[l] = c ? Og : Ag() : c && m !== Og && yg(m)
                }
            }
        }
        k = b.length;
        if (!k) return b;
        let p, q;
        if (Jg(n = b[k - 1])) {
            a: {
                var x = n;f = {};c = !1;
                for (var z in x)
                    if (Object.prototype.hasOwnProperty.call(x, z)) {
                        a = x[z];
                        if (Array.isArray(a)) {
                            h = a;
                            if (!og && Ng(a, d, +z) || !ng && Ig(a) && 0 === a.size) a = null;
                            a != h && (c = !0)
                        }
                        null != a ? f[z] = a : c = !0
                    }
                if (c) {
                    for (let E in f) {
                        x = f;
                        break a
                    }
                    x = null
                }
            }
            x != n && (p = !0);k--
        }
        for (e = +!!(e & 512) - 1; 0 < k; k--) {
            z = k - 1;
            n = b[z];
            if (!(null == n || !og && Ng(n, d, z - e) || !ng && Ig(n) && 0 === n.size)) break;
            q = !0
        }
        if (!p && !q) return b;
        var G;
        g ? G = b : G = Array.prototype.slice.call(b, 0, k);
        b = G;
        g && (b.length = k);
        x && b.push(x);
        return b
    }

    function dj(a, b) {
        if (null == b) return new a;
        if (!Array.isArray(b)) throw Error("must be an array");
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error("arrays passed to jspb constructors must be mutable");
        b[B] |= 128;
        return Ih(a, Cg(b))
    };

    function ej(a, b) {
        const c = fj;
        fj = void 0;
        if (!b(a)) throw b = c ? c() + "\n" : "", Error(b + String(a));
    }
    const gj = a => null !== a && void 0 !== a;
    let fj = void 0;

    function hj(a) {
        return b => {
            if (null == b || "" == b) b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error(void 0);
                b = Ih(a, Cg(b))
            }
            return b
        }
    };

    function Oe(a) {
        return new Me(a[0].toLowerCase())
    };

    function ij(a) {
        var b = {};
        if (a instanceof Ed) return a;
        a = jj(String(a));
        b.ao && (a = a.replace(/(^|[\r\n\t ]) /g, "$1&#160;"));
        b.Zn && (a = a.replace(/(\r\n|\n|\r)/g, "<br>"));
        b.bo && (a = a.replace(/(\t+)/g, '<span style="white-space:pre">$1</span>'));
        return Fd(a)
    }

    function jj(a) {
        return a.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;")
    }

    function kj(a) {
        const b = ij("");
        return Fd(a.map(c => Dd(ij(c))).join(Dd(b).toString()))
    }
    const lj = /^[a-z][a-z\d-]*$/i,
        mj = "APPLET BASE EMBED IFRAME LINK MATH META OBJECT SCRIPT STYLE SVG TEMPLATE".split(" ");
    var nj = "AREA BR COL COMMAND HR IMG INPUT KEYGEN PARAM SOURCE TRACK WBR".split(" ");
    const oj = ["action", "formaction", "href"];

    function pj(a, b) {
        if (!lj.test("body")) throw Error("");
        if (-1 !== mj.indexOf("BODY")) throw Error("");
        let c = "<body";
        a && (c += qj(a));
        Array.isArray(b) || (b = void 0 === b ? [] : [b]); - 1 !== nj.indexOf("BODY") ? c += ">" : (a = kj(b.map(d => d instanceof Ed ? d : ij(String(d)))), c += ">" + a.toString() + "</body>");
        return Fd(c)
    }

    function qj(a) {
        var b = "";
        const c = Object.keys(a);
        for (let f = 0; f < c.length; f++) {
            var d = c[f],
                e = a[d];
            if (!lj.test(d)) throw Error("");
            if (void 0 !== e && null !== e) {
                if (/^on/i.test(d)) throw Error(""); - 1 !== oj.indexOf(d.toLowerCase()) && (e = e instanceof id ? e.toString() : Ee(String(e)) || "about:invalid#zClosurez");
                e = `${d}="${ij(String(e))}"`;
                b += " " + e
            }
        }
        return b
    };

    function rj(a) {
        const b = a.split(/\?|#/),
            c = /\?/.test(a) ? "?" + b[1] : "";
        return {
            path: b[0],
            params: c,
            hash: /#/.test(a) ? "#" + (c ? b[2] : b[1]) : ""
        }
    }

    function sj(a, ...b) {
        if (0 === b.length) return cd(a[0]);
        let c = a[0];
        for (let d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return cd(c)
    }

    function tj(a) {
        var b = sj `https://cse.google.com/cse.js`;
        b = rj(bd(b).toString());
        let c = b.params,
            d = c.length ? "&" : "?";
        a.forEach((e, f) => {
            e = e instanceof Array ? e : [e];
            for (let g = 0; g < e.length; g++) {
                const h = e[g];
                null !== h && void 0 !== h && (c += d + encodeURIComponent(f) + "=" + encodeURIComponent(String(h)), d = "&")
            }
        });
        return cd(b.path + c + b.hash)
    };

    function uj(a, ...b) {
        let c = a[0];
        for (let d = 0; d < a.length - 1; d++) c += String(b[d]) + a[d + 1];
        if (/[<>]/.test(c)) throw Error("Forbidden characters in style string: " + c);
        return new rd(c, pd)
    };
    sj `https://www.google.com/recaptcha/api2/aframe`;

    function vj(a) {
        var b = window;
        new Promise((c, d) => {
            function e() {
                f.onload = null;
                f.onerror = null;
                f.parentElement ? .removeChild(f)
            }
            const f = b.document.createElement("script");
            f.onload = () => {
                e();
                c()
            };
            f.onerror = () => {
                e();
                d(void 0)
            };
            f.type = "text/javascript";
            Re(f, a);
            "complete" !== b.document.readyState ? Tb(b, "load", () => {
                b.document.body.appendChild(f)
            }) : b.document.body.appendChild(f)
        })
    };
    async function wj(a) {
        var b = "https://pagead2.googlesyndication.com/getconfig/sodar" + `?sv=${200}&tid=${a.g}` + `&tv=${a.i}&st=` + `${a.hc}`;
        let c = void 0;
        try {
            c = await xj(b)
        } catch (g) {}
        if (c) {
            b = a.Bc || c.sodar_query_id;
            var d = void 0 !== c.rc_enable && a.j ? c.rc_enable : "n",
                e = void 0 === c.bg_snapshot_delay_ms ? "0" : c.bg_snapshot_delay_ms,
                f = void 0 === c.is_gen_204 ? "1" : c.is_gen_204;
            if (b && c.bg_hash_basename && c.bg_binary) return {
                context: a.l,
                Ph: c.bg_hash_basename,
                Oh: c.bg_binary,
                Ti: a.g + "_" + a.i,
                Bc: b,
                hc: a.hc,
                Dd: d,
                Ud: e,
                Bd: f
            }
        }
    }
    let xj = a => new Promise((b, c) => {
        const d = new XMLHttpRequest;
        d.onreadystatechange = () => {
            d.readyState === d.DONE && (200 <= d.status && 300 > d.status ? b(JSON.parse(d.responseText)) : c())
        };
        d.open("GET", a, !0);
        d.send()
    });
    async function yj(a) {
        var b = await wj(a);
        if (b) {
            a = window;
            let c = a.GoogleGcLKhOms;
            c && "function" === typeof c.push || (c = a.GoogleGcLKhOms = []);
            c.push({
                _ctx_: b.context,
                _bgv_: b.Ph,
                _bgp_: b.Oh,
                _li_: b.Ti,
                _jk_: b.Bc,
                _st_: b.hc,
                _rc_: b.Dd,
                _dl_: b.Ud,
                _g2_: b.Bd
            });
            if (b = a.GoogleDX5YKUSk) a.GoogleDX5YKUSk = void 0, b[1]();
            a = sj `https://tpc.googlesyndication.com/sodar/${"sodar2"}.js`;
            vj(a)
        }
    };

    function zj(a, b) {
        return aj(a, 1, b)
    }
    var Aj = class extends S {
        g() {
            return P(this, 1)
        }
    };

    function Bj(a, b) {
        return F(a, 5, b)
    }

    function Cj(a, b) {
        return aj(a, 3, b)
    }

    function Dj(a, b) {
        return Wi(a, 6, b)
    }
    var Ej = class extends S {
        constructor() {
            super()
        }
    };

    function Fj(a) {
        switch (a) {
            case 1:
                return "gda";
            case 2:
                return "gpt";
            case 3:
                return "ima";
            case 4:
                return "pal";
            case 5:
                return "xfad";
            case 6:
                return "dv3n";
            case 7:
                return "spa";
            default:
                return "unk"
        }
    }
    var Gj = class {
            constructor(a) {
                this.g = a.i;
                this.i = a.j;
                this.l = a.l;
                this.Bc = a.Bc;
                this.win = a.da();
                this.hc = a.hc;
                this.Dd = a.Dd;
                this.Ud = a.Ud;
                this.Bd = a.Bd;
                this.j = a.g
            }
        },
        Hj = class {
            constructor(a, b, c) {
                this.i = a;
                this.j = b;
                this.l = c;
                this.win = window;
                this.hc = "env";
                this.Dd = "n";
                this.Ud = "0";
                this.Bd = "1";
                this.g = !0
            }
            da() {
                return this.win
            }
            build() {
                return new Gj(this)
            }
        };

    function Ij(a) {
        var b = new Jj;
        return $i(b, 1, a)
    }

    function Kj(a, b) {
        return Zi(a, 2, b)
    }

    function Lj(a, b) {
        return $i(a, 3, b)
    }

    function Mj(a, b) {
        return $i(a, 4, b)
    }
    var Jj = class extends S {
        getValue() {
            return P(this, 1)
        }
        getVersion() {
            return Ri(this, 5)
        }
    };
    var Nj = class extends S {};
    Nj.P = [2, 3, 4];

    function Oj(a, b, c = null, d = !1, e = !1) {
        Pj(a, b, c, d, e)
    }

    function Pj(a, b, c, d, e = !1) {
        a.google_image_requests || (a.google_image_requests = []);
        const f = Xe("IMG", a.document);
        if (c || d) {
            const g = h => {
                c && c(h);
                d && eb(a.google_image_requests, f);
                Ub(f, "load", g);
                Ub(f, "error", g)
            };
            Tb(f, "load", g);
            Tb(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    }
    var Rj = (a, b) => {
            let c = `https://${"pagead2.googlesyndication.com"}/pagead/gen_204?id=${b}`;
            $e(a, (d, e) => {
                if (d || 0 === d) c += `&${e}=${encodeURIComponent(""+d)}`
            });
            Qj(c)
        },
        Qj = a => {
            var b = window;
            b.fetch ? b.fetch(a, {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }) : Oj(b, a, void 0, !1, !1)
        };
    var Sj = window;
    var Tj = class extends S {
        constructor() {
            super()
        }
    };
    Tj.P = [15];
    var Uj = class extends S {
        constructor() {
            super()
        }
        getCorrelator() {
            return Qi(this, 1)
        }
        setCorrelator(a) {
            return Q(this, 1, a)
        }
    };
    var Vj = class extends S {
        constructor() {
            super()
        }
    };

    function Wj(a) {
        this.g = a || {
            cookie: ""
        }
    }
    ca = Wj.prototype;
    ca.set = function(a, b, c) {
        let d, e, f, g = !1,
            h;
        "object" === typeof c && (h = c.co, g = c.eh || !1, f = c.domain || void 0, e = c.path || void 0, d = c.Fd);
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        void 0 === d && (d = -1);
        this.g.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (e ? ";path=" + e : "") + (0 > d ? "" : 0 == d ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + 1E3 * d)).toUTCString()) + (g ? ";secure" : "") + (null != h ? ";samesite=" + h : "")
    };
    ca.get = function(a, b) {
        const c = a + "=",
            d = (this.g.cookie || "").split(";");
        for (let e = 0, f; e < d.length; e++) {
            f = bc(d[e]);
            if (0 == f.lastIndexOf(c, 0)) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    ca.isEmpty = function() {
        return !this.g.cookie
    };
    ca.yc = function() {
        return this.g.cookie ? (this.g.cookie || "").split(";").length : 0
    };
    ca.clear = function() {
        var a = (this.g.cookie || "").split(";");
        const b = [];
        var c = [];
        let d, e;
        for (let f = 0; f < a.length; f++) e = bc(a[f]), d = e.indexOf("="), -1 == d ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (c = b.length - 1; 0 <= c; c--) a = b[c], this.get(a), this.set(a, "", {
            Fd: 0,
            path: void 0,
            domain: void 0
        })
    };

    function Xj(a, b = window) {
        if (O(a, 5)) try {
            return b.localStorage
        } catch {}
        return null
    }

    function Yj(a = window) {
        try {
            return a.localStorage
        } catch {
            return null
        }
    }

    function Zj(a) {
        return "null" !== a.origin
    }

    function ak(a, b, c) {
        b = O(b, 5) && Zj(c) ? c.document.cookie : null;
        return null === b ? null : (new Wj({
            cookie: b
        })).get(a) || ""
    }

    function bk(a, b, c, d, e) {
        O(b, 5) && Zj(c) && (b = new Wj(c.document), b.get(a), b.set(a, "", {
            Fd: 0,
            path: d,
            domain: e
        }))
    };
    let ck = null,
        dk = null;

    function ek() {
        if (null != ck) return ck;
        ck = !1;
        try {
            const a = Ve(r);
            a && -1 !== a.location.hash.indexOf("google_logging") && (ck = !0);
            Yj(r) ? .getItem("google_logging") && (ck = !0)
        } catch (a) {}
        return ck
    }

    function fk() {
        if (null != dk) return dk;
        dk = !1;
        try {
            const a = Ve(r),
                b = Yj(r);
            if (a && -1 !== a.location.hash.indexOf("auto_ads_logging") || b && b.getItem("auto_ads_logging")) dk = !0
        } catch (a) {}
        return dk
    }
    var gk = (a, b = []) => {
        let c = !1;
        r.google_logging_queue || (c = !0, r.google_logging_queue = []);
        r.google_logging_queue.push([a, b]);
        c && ek() && We(r.document, sj `https://pagead2.googlesyndication.com/pagead/js/logging_library.js`)
    };

    function hk(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    }
    ca = hk.prototype;
    ca.getWidth = function() {
        return this.right - this.left
    };
    ca.getHeight = function() {
        return this.bottom - this.top
    };

    function ik(a) {
        return new hk(a.top, a.right, a.bottom, a.left)
    }
    ca.contains = function(a) {
        return this && a ? a instanceof hk ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom : !1
    };

    function jk(a, b) {
        return a.left <= b.right && b.left <= a.right && a.top <= b.bottom && b.top <= a.bottom
    }
    ca.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    ca.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    ca.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };

    function kk(a, b, c, d) {
        this.left = a;
        this.top = b;
        this.width = c;
        this.height = d
    }

    function lk(a, b) {
        var c = Math.max(a.left, b.left),
            d = Math.min(a.left + a.width, b.left + b.width);
        if (c <= d) {
            var e = Math.max(a.top, b.top);
            a = Math.min(a.top + a.height, b.top + b.height);
            if (e <= a) return new kk(c, e, d - c, a - e)
        }
        return null
    }

    function mk(a, b) {
        var c = lk(a, b);
        if (!c || !c.height || !c.width) return [new kk(a.left, a.top, a.width, a.height)];
        c = [];
        var d = a.top,
            e = a.height,
            f = a.left + a.width,
            g = a.top + a.height,
            h = b.left + b.width,
            k = b.top + b.height;
        b.top > a.top && (c.push(new kk(a.left, a.top, a.width, b.top - a.top)), d = b.top, e -= b.top - a.top);
        k < g && (c.push(new kk(a.left, k, a.width, g - k)), e = k - d);
        b.left > a.left && c.push(new kk(a.left, d, b.left - a.left, e));
        h < f && c.push(new kk(h, d, f - h, e));
        return c
    }
    kk.prototype.contains = function(a) {
        return a instanceof Xd ? a.x >= this.left && a.x <= this.left + this.width && a.y >= this.top && a.y <= this.top + this.height : this.left <= a.left && this.left + this.width >= a.left + a.width && this.top <= a.top && this.top + this.height >= a.top + a.height
    };
    kk.prototype.ceil = function() {
        this.left = Math.ceil(this.left);
        this.top = Math.ceil(this.top);
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    kk.prototype.floor = function() {
        this.left = Math.floor(this.left);
        this.top = Math.floor(this.top);
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    kk.prototype.round = function() {
        this.left = Math.round(this.left);
        this.top = Math.round(this.top);
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    const nk = {
        "AMP-CAROUSEL": "ac",
        "AMP-FX-FLYING-CARPET": "fc",
        "AMP-LIGHTBOX": "lb",
        "AMP-STICKY-AD": "sa"
    };

    function ok(a = r) {
        let b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch {}
        return b ? .pageViewId && b ? .canonicalUrl ? b : null
    }

    function pk(a = ok()) {
        return a && a.mode ? +a.mode.version || null : null
    }

    function qk(a = ok()) {
        if (a && a.container) {
            a = a.container.split(",");
            const b = [];
            for (let c = 0; c < a.length; c++) b.push(nk[a[c]] || "x");
            return b.join()
        }
        return null
    }

    function rk() {
        var a = ok();
        return a && a.initialIntersection
    }

    function sk() {
        const a = rk();
        return a && Aa(a.rootBounds) ? new Yd(a.rootBounds.width, a.rootBounds.height) : null
    }

    function tk(a = ok()) {
        return a ? Se(a.master) ? a.master : null : null
    }

    function uk(a, b) {
        const c = a.ampInaboxIframes = a.ampInaboxIframes || [];
        let d = () => {},
            e = () => {};
        b && (c.push(b), e = () => {
            a.AMP && a.AMP.inaboxUnregisterIframe && a.AMP.inaboxUnregisterIframe(b);
            eb(c, b);
            d()
        });
        if (a.ampInaboxInitialized) return e;
        a.ampInaboxPendingMessages = a.ampInaboxPendingMessages || [];
        const f = g => {
            if (a.ampInaboxInitialized) g = !0;
            else {
                var h, k = "amp-ini-load" === g.data;
                a.ampInaboxPendingMessages && !k && (h = /^amp-(\d{15,20})?/.exec(g.data)) && (a.ampInaboxPendingMessages.push(g), g = h[1], a.ampInaboxInitialized ||
                    g && !/^\d{15,20}$/.test(g) || a.document.querySelector('script[src$="amp4ads-host-v0.js"]') || We(a.document, g ? sj `https://cdn.ampproject.org/rtv/${g}/amp4ads-host-v0.js` : sj `https://cdn.ampproject.org/amp4ads-host-v0.js`));
                g = !1
            }
            g && d()
        };
        c.google_amp_listener_added || (c.google_amp_listener_added = !0, Tb(a, "message", f), d = () => {
            Ub(a, "message", f)
        });
        return e
    };
    var vk = () => a => {
        a = {
            id: "unsafeurl",
            ctx: 638,
            url: a
        };
        var b = [];
        for (c in a) ye(c, a[c], b);
        var c = xe("https://pagead2.googlesyndication.com/pagead/gen_204", b.join("&"));
        navigator.sendBeacon && navigator.sendBeacon(c, "")
    };

    function wk(a, b, c) {
        if ("string" === typeof b)(b = xk(a, b)) && (a.style[b] = c);
        else
            for (var d in b) {
                c = a;
                var e = b[d],
                    f = xk(c, d);
                f && (c.style[f] = e)
            }
    }
    var yk = {};

    function xk(a, b) {
        var c = yk[b];
        if (!c) {
            var d = ce(b);
            c = d;
            void 0 === a.style[d] && (d = (Ec ? "Webkit" : Dc ? "Moz" : Ac ? "ms" : null) + de(d), void 0 !== a.style[d] && (c = d));
            yk[b] = c
        }
        return c
    }

    function zk(a, b) {
        var c = a.style[ce(b)];
        return "undefined" !== typeof c ? c : a.style[xk(a, b)] || ""
    }

    function Ak(a, b) {
        var c = ge(a);
        return c.defaultView && c.defaultView.getComputedStyle && (a = c.defaultView.getComputedStyle(a, null)) ? a[b] || a.getPropertyValue(b) || "" : ""
    }

    function Bk(a, b) {
        return Ak(a, b) || (a.currentStyle ? a.currentStyle[b] : null) || a.style && a.style[b]
    }

    function Ck(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    }

    function Dk(a) {
        var b = ge(a),
            c = new Xd(0, 0);
        var d = b ? ge(b) : document;
        d = !Ac || 9 <= Number(Oc) || "CSS1Compat" == ee(d).g.compatMode ? d.documentElement : d.body;
        if (a == d) return c;
        a = Ck(a);
        b = ie(ee(b).g);
        c.x = a.left + b.x;
        c.y = a.top + b.y;
        return c
    }

    function Ek(a) {
        var b = Fk;
        if ("none" != Bk(a, "display")) return b(a);
        var c = a.style,
            d = c.display,
            e = c.visibility,
            f = c.position;
        c.visibility = "hidden";
        c.position = "absolute";
        c.display = "inline";
        a = b(a);
        c.display = d;
        c.position = f;
        c.visibility = e;
        return a
    }

    function Fk(a) {
        var b = a.offsetWidth,
            c = a.offsetHeight,
            d = Ec && !b && !c;
        return (void 0 === b || d) && a.getBoundingClientRect ? (a = Ck(a), new Yd(a.right - a.left, a.bottom - a.top)) : new Yd(b, c)
    }

    function Gk(a, b) {
        if (/^\d+px?$/.test(b)) return parseInt(b, 10);
        var c = a.style.left,
            d = a.runtimeStyle.left;
        a.runtimeStyle.left = a.currentStyle.left;
        a.style.left = b;
        b = a.style.pixelLeft;
        a.style.left = c;
        a.runtimeStyle.left = d;
        return +b
    }

    function Hk(a, b) {
        return (b = a.currentStyle ? a.currentStyle[b] : null) ? Gk(a, b) : 0
    }
    var Ik = {
        thin: 2,
        medium: 4,
        thick: 6
    };

    function Jk(a, b) {
        if ("none" == (a.currentStyle ? a.currentStyle[b + "Style"] : null)) return 0;
        b = a.currentStyle ? a.currentStyle[b + "Width"] : null;
        return b in Ik ? Ik[b] : Gk(a, b)
    };
    var Kk = a => "number" === typeof a && 0 < a,
        Mk = (a, b) => {
            a = Lk(a);
            if (!a) return b;
            const c = b.slice(-1);
            return b + ("?" === c || "#" === c ? "" : "&") + a
        },
        Lk = a => Object.entries(Nk(a)).map(([b, c]) => `${b}=${encodeURIComponent(String(c))}`).join("&"),
        Nk = a => {
            const b = {};
            $e(a, (c, d) => {
                if (c || 0 === c || !1 === c) "boolean" === typeof c && (c = c ? 1 : 0), b[d] = c
            });
            return b
        },
        Ok = () => {
            try {
                return Sj.history.length
            } catch (a) {
                return 0
            }
        },
        Pk = a => {
            a = tk(ok(a)) || a;
            a.google_unique_id = (a.google_unique_id || 0) + 1
        },
        Qk = a => {
            a = a.google_unique_id;
            return "number" === typeof a ? a :
                0
        },
        Rk = a => {
            let b;
            b = 9 !== a.nodeType && a.id;
            a: {
                if (a && a.nodeName && a.parentElement) {
                    var c = a.nodeName.toString().toLowerCase();
                    const d = a.parentElement.childNodes;
                    let e = 0;
                    for (let f = 0; f < d.length; ++f) {
                        const g = d[f];
                        if (g.nodeName && g.nodeName.toString().toLowerCase() === c) {
                            if (a === g) {
                                c = "." + e;
                                break a
                            }++e
                        }
                    }
                }
                c = ""
            }
            return (a.nodeName && a.nodeName.toString().toLowerCase()) + (b ? "/" + b : "") + c
        },
        Sk = () => {
            if (!Sj) return !1;
            try {
                return !(!Sj.navigator.standalone && !Sj.top.navigator.standalone)
            } catch (a) {
                return !1
            }
        },
        Tk = a => (a = a.google_ad_format) ?
        0 < a.indexOf("_0ads") : !1,
        Uk = a => {
            let b = Number(a.google_ad_width),
                c = Number(a.google_ad_height);
            if (!(0 < b && 0 < c)) {
                a: {
                    try {
                        const e = String(a.google_ad_format);
                        if (e && e.match) {
                            const f = e.match(/(\d+)x(\d+)/i);
                            if (f) {
                                const g = parseInt(f[1], 10),
                                    h = parseInt(f[2], 10);
                                if (0 < g && 0 < h) {
                                    var d = {
                                        width: g,
                                        height: h
                                    };
                                    break a
                                }
                            }
                        }
                    } catch (e) {}
                    d = null
                }
                a = d;
                if (!a) return null;b = 0 < b ? b : a.width;c = 0 < c ? c : a.height
            }
            return {
                width: b,
                height: c
            }
        };
    class Vk {
        constructor(a, b) {
            this.error = a;
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror";
            this.meta = {}
        }
    };
    const Wk = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var Xk = class {
            constructor(a, b) {
                this.g = a;
                this.i = b
            }
        },
        Yk = class {
            constructor(a, b, c) {
                this.url = a;
                this.win = b;
                this.vg = !!c;
                this.depth = null
            }
        };
    let Zk = null;

    function $k() {
        if (null === Zk) {
            Zk = "";
            try {
                let a = "";
                try {
                    a = r.top.location.hash
                } catch (b) {
                    a = r.location.hash
                }
                if (a) {
                    const b = a.match(/\bdeid=([\d,]+)/);
                    Zk = b ? b[1] : ""
                }
            } catch (a) {}
        }
        return Zk
    };

    function al() {
        const a = r.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function bl() {
        const a = r.performance;
        return a && a.now ? a.now() : null
    };
    var cl = class {
        constructor(a, b) {
            var c = bl() || al();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    const dl = r.performance,
        el = !!(dl && dl.mark && dl.measure && dl.clearMarks),
        fl = Mb(() => {
            var a;
            if (a = el) a = $k(), a = !!a.indexOf && 0 <= a.indexOf("1337");
            return a
        });

    function gl(a) {
        a && dl && fl() && (dl.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), dl.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }

    function hl(a) {
        a.g = !1;
        a.i != a.j.google_js_reporting_queue && (fl() && Va(a.i, gl), a.i.length = 0)
    }

    function il(a, b) {
        if (!a.g) return b();
        const c = a.start("491", 3);
        let d;
        try {
            d = b()
        } catch (e) {
            throw gl(c), e;
        }
        a.end(c);
        return d
    }
    class jl {
        constructor(a) {
            this.i = [];
            this.j = a || r;
            let b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.i = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.g = fl() || (null != b ? b : 1 > Math.random())
        }
        start(a, b) {
            if (!this.g) return null;
            a = new cl(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            dl && fl() && dl.mark(b);
            return a
        }
        end(a) {
            if (this.g && "number" === typeof a.value) {
                a.duration = (bl() || al()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                dl && fl() && dl.mark(b);
                !this.g || 2048 < this.i.length ||
                    this.i.push(a)
            }
        }
    };

    function kl(a, b) {
        const c = {};
        c[a] = b;
        return [c]
    }

    function ll(a, b, c, d, e) {
        const f = [];
        $e(a, function(g, h) {
            (g = ml(g, b, c, d, e)) && f.push(h + "=" + g)
        });
        return f.join(b)
    }

    function ml(a, b, c, d, e) {
        if (null == a) return "";
        b = b || "&";
        c = c || ",$";
        "string" == typeof c && (c = c.split(""));
        if (a instanceof Array) {
            if (d = d || 0, d < c.length) {
                const f = [];
                for (let g = 0; g < a.length; g++) f.push(ml(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if ("object" == typeof a) return e = e || 0, 2 > e ? encodeURIComponent(ll(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function nl(a) {
        let b = 1;
        for (const c in a.i) b = c.length > b ? c.length : b;
        return 3997 - b - a.j.length - 1
    }

    function ol(a, b) {
        let c = "https://pagead2.googlesyndication.com" + b,
            d = nl(a) - b.length;
        if (0 > d) return "";
        a.g.sort(function(f, g) {
            return f - g
        });
        b = null;
        let e = "";
        for (let f = 0; f < a.g.length; f++) {
            const g = a.g[f],
                h = a.i[g];
            for (let k = 0; k < h.length; k++) {
                if (!d) {
                    b = null == b ? g : b;
                    break
                }
                let l = ll(h[k], a.j, ",$");
                if (l) {
                    l = e + l;
                    if (d >= l.length) {
                        d -= l.length;
                        c += l;
                        e = a.j;
                        break
                    }
                    b = null == b ? g : b
                }
            }
        }
        a = "";
        null != b && (a = e + "trn=" + b);
        return c + a
    }
    class pl {
        constructor() {
            this.j = "&";
            this.i = {};
            this.l = 0;
            this.g = []
        }
    };

    function ql(a) {
        let b = a.toString();
        a.name && -1 == b.indexOf(a.name) && (b += ": " + a.name);
        a.message && -1 == b.indexOf(a.message) && (b += ": " + a.message);
        a.stack && (b = rl(a.stack, b));
        return b
    }

    function rl(a, b) {
        try {
            -1 == a.indexOf(b) && (a = b + "\n" + a);
            let c;
            for (; a != c;) c = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
            return a.replace(RegExp("\n *", "g"), "\n")
        } catch (c) {
            return b
        }
    }
    var tl = class {
        constructor(a, b, c = null) {
            this.ua = a;
            this.A = b;
            this.i = c;
            this.g = null;
            this.j = !1;
            this.B = this.Ba
        }
        lf(a) {
            this.g = a
        }
        l(a) {
            this.j = a
        }
        Lc(a, b, c) {
            let d, e;
            try {
                this.i && this.i.g ? (e = this.i.start(a.toString(), 3), d = b(), this.i.end(e)) : d = b()
            } catch (f) {
                b = this.A;
                try {
                    gl(e), b = this.B(a, new Vk(f, {
                        message: ql(f)
                    }), void 0, c)
                } catch (g) {
                    this.Ba(217, g)
                }
                if (b) window.console ? .error ? .(f);
                else throw f;
            }
            return d
        }
        Oa(a, b, c, d) {
            return (...e) => this.Lc(a, () => b.apply(c, e), d)
        }
        Ba(a, b, c, d, e) {
            e = e || "jserror";
            let f;
            try {
                const J = new pl;
                var g = J;
                g.g.push(1);
                g.i[1] = kl("context", a);
                b.error && b.meta && b.id || (b = new Vk(b, {
                    message: ql(b)
                }));
                if (b.msg) {
                    g = J;
                    var h = b.msg.substring(0, 512);
                    g.g.push(2);
                    g.i[2] = kl("msg", h)
                }
                var k = b.meta || {};
                b = k;
                if (this.g) try {
                    this.g(b)
                } catch (ba) {}
                if (d) try {
                    d(b)
                } catch (ba) {}
                d = J;
                k = [k];
                d.g.push(3);
                d.i[3] = k;
                d = r;
                k = [];
                b = null;
                do {
                    var l = d;
                    if (Se(l)) {
                        var m = l.location.href;
                        b = l.document && l.document.referrer || null
                    } else m = b, b = null;
                    k.push(new Yk(m || "", l));
                    try {
                        d = l.parent
                    } catch (ba) {
                        d = null
                    }
                } while (d && l != d);
                for (let ba = 0, tb = k.length - 1; ba <= tb; ++ba) k[ba].depth =
                    tb - ba;
                l = r;
                if (l.location && l.location.ancestorOrigins && l.location.ancestorOrigins.length == k.length - 1)
                    for (m = 1; m < k.length; ++m) {
                        var n = k[m];
                        n.url || (n.url = l.location.ancestorOrigins[m - 1] || "", n.vg = !0)
                    }
                var p = k;
                let Ea = new Yk(r.location.href, r, !1);
                l = null;
                const Ya = p.length - 1;
                for (n = Ya; 0 <= n; --n) {
                    var q = p[n];
                    !l && Wk.test(q.url) && (l = q);
                    if (q.url && !q.vg) {
                        Ea = q;
                        break
                    }
                }
                q = null;
                const Eb = p.length && p[Ya].url;
                0 != Ea.depth && Eb && (q = p[Ya]);
                f = new Xk(Ea, q);
                if (f.i) {
                    p = J;
                    var x = f.i.url || "";
                    p.g.push(4);
                    p.i[4] = kl("top", x)
                }
                var z = {
                    url: f.g.url ||
                        ""
                };
                if (f.g.url) {
                    var G = f.g.url.match(we),
                        E = G[1],
                        K = G[3],
                        H = G[4];
                    x = "";
                    E && (x += E + ":");
                    K && (x += "//", x += K, H && (x += ":" + H));
                    var N = x
                } else N = "";
                E = J;
                z = [z, {
                    url: N
                }];
                E.g.push(5);
                E.i[5] = z;
                sl(this.ua, e, J, this.j, c)
            } catch (J) {
                try {
                    sl(this.ua, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: ql(J),
                        url: f && f.g.url
                    }, this.j, c)
                } catch (Ea) {}
            }
            return this.A
        }
        Pa(a, b, c) {
            b.catch(d => {
                d = d ? d : "unknown rejection";
                this.Ba(a, d instanceof Error ? d : Error(d), void 0, c || this.g || void 0)
            })
        }
    };
    var ul = a => "string" === typeof a,
        vl = a => void 0 === a;

    function wl() {
        var a = xl;
        return b => {
            for (const c in a)
                if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
            return !1
        }
    };
    var yl = class extends S {
        constructor() {
            super()
        }
    };

    function zl(a, b) {
        try {
            const c = d => [{
                [d.lh]: d.Dg
            }];
            return JSON.stringify([a.filter(d => d.Re).map(c), b.toJSON(), a.filter(d => !d.Re).map(c)])
        } catch (c) {
            return Al(c, b), ""
        }
    }

    function Al(a, b) {
        try {
            Rj({
                m: ql(a instanceof Error ? a : Error(String(a))),
                b: Ri(b, 1) || null,
                v: P(b, 2) || null
            }, "rcs_internal")
        } catch (c) {}
    }
    var Bl = class {
        constructor(a, b) {
            var c = new yl;
            a = R(c, 1, a);
            this.j = aj(a, 2, b).i()
        }
    };
    var Cl = class extends S {
        getValue() {
            return Ri(this, 1)
        }
    };

    function Dl(a) {
        var b = new El;
        return Wh(b, 1, eh(a))
    }
    var El = class extends S {
        getValue() {
            return Ri(this, 1)
        }
    };
    var Fl = class extends S {
        constructor() {
            super()
        }
        getValue() {
            return Ri(this, 1)
        }
    };

    function Gl(a, b) {
        return Q(a, 1, b)
    }

    function Hl(a, b) {
        return Q(a, 2, b)
    }

    function Il(a, b) {
        return Q(a, 3, b)
    }

    function Jl(a, b) {
        return Q(a, 4, b)
    }

    function Kl(a, b) {
        return Q(a, 5, b)
    }

    function Ll(a, b) {
        return li(a, 8, ah(b), 0)
    }

    function Ml(a, b) {
        return li(a, 9, ah(b), 0)
    }
    var Nl = class extends S {
        constructor() {
            super()
        }
    };

    function Ol(a, b) {
        return Q(a, 1, b)
    }

    function Pl(a, b) {
        return Q(a, 2, b)
    }
    var Ql = class extends S {};

    function Rl(a, b) {
        ti(a, 1, Ql, b)
    }
    var ji = class extends S {
        gh(a) {
            ti(this, 1, Ql, void 0, a, !1, 1);
            return this
        }
    };
    ji.P = [1];
    var Sl = class extends S {
        constructor() {
            super()
        }
    };

    function Tl(a, b) {
        return ki(a, 1, b, th)
    }

    function Ul(a, b) {
        return ki(a, 12, b, rh)
    }

    function Vl() {
        var a = new Wl,
            b = a.W,
            c = "irr",
            d = b[B];
        Qg(d);
        var e = d & 2;
        let f = Vh(b, d, 2);
        Array.isArray(f) || (f = Og);
        const g = !!(d & 32);
        let h = f[B] | 0;
        0 === h && g && !e ? (h |= 33, f[B] = h) : h & 1 || (h |= 1, f[B] = h);
        if (e) h & 2 || Bg(f), Object.freeze(f);
        else if (2 & h || 2048 & h) f = vg(f), e = 1, g && (e |= 32), f[B] = e, Xh(b, d, 2, f);
        b = f;
        d = b[B] | 0;
        c = th(c, !!(4 & d) && !!(4096 & d));
        b.push(c);
        return a
    }

    function Xl(a, b) {
        return Wi(a, 3, b)
    }

    function Yl(a, b) {
        return Wi(a, 4, b)
    }

    function Zl(a, b) {
        return Wi(a, 5, b)
    }

    function $l(a, b) {
        return Wi(a, 7, b)
    }

    function am(a, b) {
        return Wi(a, 8, b)
    }

    function bm(a, b) {
        return Q(a, 9, b)
    }

    function cm(a, b) {
        return si(a, 10, b)
    }

    function dm(a, b) {
        return ki(a, 11, b, kh)
    }
    var Wl = class extends S {
        constructor() {
            super()
        }
    };
    Wl.P = [1, 12, 2, 10, 11];

    function em(a) {
        var b = fm();
        F(a, 1, b)
    }

    function gm(a, b) {
        return Q(a, 2, b)
    }

    function hm(a, b) {
        return si(a, 3, b)
    }

    function im(a, b) {
        return si(a, 4, b)
    }

    function jm(a, b) {
        ti(a, 4, El, b);
        return a
    }

    function km(a, b) {
        return si(a, 5, b)
    }

    function lm(a, b) {
        return ki(a, 6, b, th)
    }

    function mm(a, b) {
        return Q(a, 7, b)
    }

    function nm(a, b) {
        F(a, 9, b)
    }

    function om(a, b) {
        return Wi(a, 10, b)
    }

    function pm(a, b) {
        return Wi(a, 11, b)
    }

    function qm(a, b) {
        return Wi(a, 12, b)
    }

    function rm(a) {
        var b = a.W;
        const c = b[B];
        a = c & 2;
        b = ii(b, c, Vh(b, c, 14));
        null == b ? a = b : (!a && ji && (b.Uh = !0), a = b);
        return a
    }
    var sm = class extends S {
        constructor() {
            super()
        }
        H(a) {
            ti(this, 3, Cl, void 0, a, !1, 1);
            return this
        }
        G(a) {
            return Q(this, 8, a)
        }
    };
    sm.P = [3, 4, 5, 15, 6];
    var tm = class extends S {
        constructor() {
            super()
        }
    };
    tm.P = [2];
    var um = class extends S {
        constructor() {
            super()
        }
    };
    var vm = class extends S {
            constructor() {
                super()
            }
        },
        wm = [1];

    function xm(a) {
        var b = new ym;
        return R(b, 1, a)
    }
    var ym = class extends S {
        constructor() {
            super()
        }
    };
    var zm = class extends S {
        constructor() {
            super()
        }
    };
    var Am = class extends S {
        constructor() {
            super()
        }
    };
    var Bm = class extends S {
        constructor() {
            super()
        }
    };
    var Cm = class extends S {
        constructor() {
            super()
        }
    };
    var Dm = class extends S {
        constructor() {
            super()
        }
        getContentUrl() {
            return P(this, 1)
        }
    };
    var Em = class extends S {
        constructor() {
            super()
        }
    };
    Em.P = [1];
    var Fm = class extends S {
        constructor() {
            super()
        }
    };

    function Gm() {
        var a = new Hm,
            b = new Fm;
        return I(a, 1, Im, b)
    }

    function kn() {
        var a = new Hm,
            b = new Fm;
        return I(a, 9, Im, b)
    }

    function ln() {
        var a = new Hm,
            b = new Fm;
        return I(a, 11, Im, b)
    }

    function mn() {
        var a = new Hm,
            b = new Fm;
        return I(a, 12, Im, b)
    }

    function nn() {
        var a = new Hm,
            b = new Fm;
        return I(a, 13, Im, b)
    }
    var Hm = class extends S {
            constructor() {
                super()
            }
        },
        Im = [1, 2, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13];
    var on = class extends S {
        constructor() {
            super()
        }
    };
    on.P = [1];
    var pn = class extends S {
        constructor() {
            super()
        }
    };
    pn.P = [2];
    var qn = class extends S {
        constructor() {
            super()
        }
    };
    var rn = class extends S {
        constructor() {
            super()
        }
    };

    function sn(a) {
        var b = new tn;
        return R(b, 1, a)
    }
    var tn = class extends S {
        constructor() {
            super()
        }
    };
    tn.P = [9];
    var un = class extends S {
        constructor() {
            super()
        }
    };
    var vn = class extends S {
        constructor() {
            super()
        }
    };
    vn.P = [2];
    var wn = class extends S {
        constructor() {
            super()
        }
    };
    var xn = class extends S {
            constructor() {
                super()
            }
        },
        yn = [4, 5];
    var zn = class extends S {
        constructor() {
            super()
        }
    };

    function An(a) {
        var b = new Bn;
        return Yi(b, 2, a)
    }
    var Bn = class extends S {
        constructor() {
            super()
        }
    };
    Bn.P = [3];
    var Cn = class extends S {
        constructor() {
            super()
        }
    };
    var Dn = class extends S {
        constructor() {
            super()
        }
    };
    var En = class extends S {
        constructor() {
            super()
        }
    };
    var Fn = class extends S {
        constructor() {
            super()
        }
    };
    var Gn = class extends S {
            constructor() {
                super()
            }
        },
        Hn = [2, 3];
    var In = class extends S {
            constructor() {
                super()
            }
        },
        Jn = [3, 4, 5, 6, 7, 8, 9, 11, 12, 13];
    var Kn = class extends S {
            constructor() {
                super()
            }
            ec(a) {
                return aj(this, 2, a)
            }
        },
        Ln = [4, 5, 6, 8, 9, 10, 11];
    var Mn = class extends S {
        constructor() {
            super()
        }
    };
    var Nn = class extends S {
        constructor() {
            super()
        }
    };
    Nn.P = [4, 5];
    var On = class extends S {
        constructor() {
            super()
        }
        getTagSessionCorrelator() {
            return Qi(this, 1)
        }
    };
    On.P = [2];
    var Pn = class extends S {
            constructor() {
                super()
            }
        },
        Qn = [4, 6];
    class Rn extends Bl {
        constructor() {
            super(...arguments)
        }
    }

    function Sn(a, ...b) {
        Tn(a, ...b.map(c => ({
            Re: !0,
            lh: 3,
            Dg: c.toJSON()
        })))
    }

    function Un(a, ...b) {
        Tn(a, ...b.map(c => ({
            Re: !0,
            lh: 7,
            Dg: c.toJSON()
        })))
    }
    var Vn = class extends Rn {};
    var Wn = (a, b) => {
        globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: 65536 > b.length,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(() => {})
    };

    function Tn(a, ...b) {
        try {
            a.C && 65536 <= zl(a.g.concat(b), a.j).length && Xn(a), a.l && !a.A && (a.A = !0, Yn(a.l, () => {
                Xn(a)
            })), a.g.push(...b), a.g.length >= a.B && Xn(a), a.g.length && null === a.i && (a.i = setTimeout(() => {
                Xn(a)
            }, a.F))
        } catch (c) {
            Al(c, a.j)
        }
    }

    function Xn(a) {
        null !== a.i && (clearTimeout(a.i), a.i = null);
        if (a.g.length) {
            var b = zl(a.g, a.j);
            a.G("https://pagead2.googlesyndication.com/pagead/ping?e=1", b);
            a.g = []
        }
    }
    var Zn = class extends Vn {
            constructor(a, b, c, d, e) {
                super(2, a);
                this.G = Wn;
                this.F = b;
                this.B = c;
                this.C = d;
                this.l = e;
                this.g = [];
                this.i = null;
                this.A = !1
            }
        },
        $n = class extends Zn {
            constructor(a, b = 1E3, c = 100, d = !1, e) {
                super(a, b, c, d && !0, e)
            }
        };

    function ao(a, b, c) {
        return b[a] || c
    };

    function bo(a, b) {
        a.g = (c, d) => ao(2, b, () => [])(c, 1, d);
        a.i = () => ao(3, b, () => [])(1)
    }
    class co {
        g() {
            return []
        }
        i() {
            return []
        }
    }

    function eo(a, b) {
        return u(co).g(a, b)
    }

    function fo() {
        return u(co).i()
    };

    function sl(a, b, c, d = !1, e) {
        if ((d ? a.g : Math.random()) < (e || .01)) try {
            let f;
            c instanceof pl ? f = c : (f = new pl, $e(c, (h, k) => {
                var l = f;
                const m = l.l++;
                h = kl(k, h);
                l.g.push(m);
                l.i[m] = h
            }));
            const g = ol(f, "/pagead/gen_204?id=" + b + "&");
            g && Oj(r, g)
        } catch (f) {}
    }

    function go(a, b) {
        0 <= b && 1 >= b && (a.g = b)
    }
    class ho {
        constructor() {
            this.g = Math.random()
        }
    };
    let io, jo;
    const ko = new jl(window);
    (a => {
        io = a ? ? new ho;
        "number" !== typeof window.google_srt && (window.google_srt = Math.random());
        go(io, window.google_srt);
        jo = new tl(io, !0, ko);
        jo.lf(() => {});
        jo.l(!0);
        "complete" == window.document.readyState ? window.google_measure_js_timing || hl(ko) : ko.g && Tb(window, "load", () => {
            window.google_measure_js_timing || hl(ko)
        })
    })();
    let lo = (new Date).getTime();
    var mo = {
        cm: 0,
        bm: 1,
        Yl: 2,
        Tl: 3,
        Zl: 4,
        Ul: 5,
        am: 6,
        Wl: 7,
        Xl: 8,
        Sl: 9,
        Vl: 10,
        dm: 11
    };
    var no = {
        fm: 0,
        gm: 1,
        em: 2
    };

    function oo(a, b) {
        return a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom
    }

    function po(a) {
        a = $a(a, b => new hk(b.top, b.right, b.bottom, b.left));
        a = qo(a);
        return {
            top: a.top,
            right: a.right,
            bottom: a.bottom,
            left: a.left
        }
    }

    function qo(a) {
        if (!a.length) throw Error("pso:box:m:nb");
        return ab(a.slice(1), (b, c) => {
            b.left = Math.min(b.left, c.left);
            b.top = Math.min(b.top, c.top);
            b.right = Math.max(b.right, c.right);
            b.bottom = Math.max(b.bottom, c.bottom);
            return b
        }, ik(a[0]))
    };
    var Rc = {
        Vm: 0,
        Hl: 1,
        Kl: 2,
        Il: 3,
        Jl: 4,
        Ql: 8,
        fn: 9,
        sm: 10,
        tm: 11,
        cn: 16,
        ul: 17,
        rl: 24,
        pm: 25,
        Ik: 26,
        Hk: 27,
        yh: 30,
        jm: 32,
        mm: 40,
        mn: 41,
        hn: 42
    };
    var ro = {
            overlays: 1,
            interstitials: 2,
            vignettes: 2,
            inserts: 3,
            immersives: 4,
            list_view: 5,
            full_page: 6,
            side_rails: 7
        },
        so = {
            [1]: 1,
            [2]: 1,
            [3]: 7,
            [4]: 7,
            [8]: 2,
            [27]: 3,
            [9]: 4,
            [30]: 5
        };
    var to = 728 * 1.38;

    function uo(a) {
        return a !== a.top ? 512 : 0
    }

    function vo(a, b = 420, c = !1) {
        return (a = wo(a, c)) ? a > b ? 32768 : 320 > a ? 65536 : 0 : 16384
    }

    function xo(a) {
        var b = wo(a);
        a = a.innerWidth;
        return (b = b && a ? b / a : 0) ? 1.05 < b ? 262144 : .95 > b ? 524288 : 0 : 131072
    }

    function yo(a) {
        return Math.max(0, zo(a, !0) - T(a))
    }

    function Ao(a) {
        a = a.document;
        let b = {};
        a && (b = "CSS1Compat" == a.compatMode ? a.documentElement : a.body);
        return b || {}
    }

    function T(a) {
        return Ao(a).clientHeight
    }

    function wo(a, b = !1) {
        const c = Ao(a).clientWidth;
        return b ? c * Gf(a) : c
    }

    function zo(a, b) {
        const c = Ao(a);
        return b ? (a = T(a), c.scrollHeight === a ? c.offsetHeight : c.scrollHeight) : c.offsetHeight
    }

    function Bo(a, b) {
        return Co(b) || 10 === b || !a.adCount ? !1 : 1 == b || 2 == b ? !(!a.adCount[1] && !a.adCount[2]) : (a = a.adCount[b]) ? 1 <= a : !1
    }

    function Do(a, b) {
        return a && a.source ? a.source === b || a.source.parent === b : !1
    }

    function Eo(a) {
        return void 0 === a.pageYOffset ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollTop : a.pageYOffset
    }

    function Fo(a) {
        return void 0 === a.pageXOffset ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollLeft : a.pageXOffset
    }

    function Go(a) {
        const b = {};
        let c;
        Array.isArray(a) ? c = a : a && a.key_value && (c = a.key_value);
        if (c)
            for (a = 0; a < c.length; a++) {
                const d = c[a];
                if ("key" in d && "value" in d) {
                    const e = d.value;
                    b[d.key] = null == e ? null : String(e)
                }
            }
        return b
    }

    function Ho(a, b, c, d) {
        sl(c, b, {
            c: d.data.substring(0, 500),
            u: a.location.href.substring(0, 500)
        }, !0, .1);
        return !0
    }

    function Io(a) {
        const b = {
            bottom: "auto",
            clear: "none",
            display: "inline",
            "float": "none",
            height: "auto",
            left: "auto",
            margin: 0,
            "margin-bottom": 0,
            "margin-left": 0,
            "margin-right": "0",
            "margin-top": 0,
            "max-height": "none",
            "max-width": "none",
            opacity: 1,
            overflow: "visible",
            padding: 0,
            "padding-bottom": 0,
            "padding-left": 0,
            "padding-right": 0,
            "padding-top": 0,
            position: "static",
            right: "auto",
            top: "auto",
            "vertical-align": "baseline",
            visibility: "visible",
            width: "auto",
            "z-index": "auto"
        };
        Va(Object.keys(b), c => {
            zk(a, c) || wk(a, c, b[c])
        });
        sf(a)
    }

    function Co(a) {
        return 26 === a || 27 === a || 40 === a || 41 === a
    };

    function Jo(a, b) {
        Ko(a).forEach(b, void 0)
    }

    function Ko(a) {
        for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
        return b
    };

    function Lo(a, b) {
        return void 0 !== a.g[Mo(b)]
    }

    function No(a) {
        const b = [];
        for (const c in a.g) void 0 !== a.g[c] && a.g.hasOwnProperty(c) && b.push(a.i[c]);
        return b
    }

    function Oo(a) {
        const b = [];
        for (const c in a.g) void 0 !== a.g[c] && a.g.hasOwnProperty(c) && b.push(a.g[c]);
        return b
    }
    const Po = class {
        constructor() {
            this.g = {};
            this.i = {}
        }
        set(a, b) {
            const c = Mo(a);
            this.g[c] = b;
            this.i[c] = a
        }
        get(a, b) {
            a = Mo(a);
            return void 0 !== this.g[a] ? this.g[a] : b
        }
        yc() {
            return No(this).length
        }
        clear() {
            this.g = {};
            this.i = {}
        }
    };

    function Mo(a) {
        return a instanceof Object ? String(Ba(a)) : a + ""
    };
    const Qo = class {
        constructor(a) {
            this.g = new Po;
            if (a)
                for (var b = 0; b < a.length; ++b) this.add(a[b])
        }
        add(a) {
            this.g.set(a, !0)
        }
        contains(a) {
            return Lo(this.g, a)
        }
    };
    const Ro = new Qo("IMG AMP-IMG IFRAME AMP-IFRAME HR EMBED OBJECT VIDEO AMP-VIDEO INPUT BUTTON SVG".split(" "));

    function So(a, {
        hb: b,
        bb: c,
        Gb: d
    }) {
        return d && c(b) ? b : (b = b.parentElement) ? To(a, {
            hb: b,
            bb: c,
            Gb: !0
        }) : null
    }

    function To(a, {
        hb: b,
        bb: c,
        Gb: d = !1
    }) {
        const e = Uo({
                hb: b,
                bb: c,
                Gb: d
            }),
            f = a.g.get(e);
        if (f) return f.element;
        b = So(a, {
            hb: b,
            bb: c,
            Gb: d
        });
        a.g.set(e, {
            element: b
        });
        return b
    }
    var Vo = class {
        constructor() {
            this.g = new Map
        }
    };

    function Uo({
        hb: a,
        bb: b,
        Gb: c
    }) {
        a = Ba(a);
        b = Ba(b);
        return `${a}:${b}:${c}`
    };

    function Wo(a) {
        Vb(a.document.body.offsetHeight)
    };

    function Xo(a) {
        a && "function" == typeof a.ma && a.ma()
    };

    function U() {
        this.B = this.B;
        this.G = this.G
    }
    U.prototype.B = !1;
    U.prototype.ma = function() {
        this.B || (this.B = !0, this.i())
    };

    function Yo(a, b) {
        Zo(a, Ka(Xo, b))
    }

    function Zo(a, b) {
        a.B ? b() : (a.G || (a.G = []), a.G.push(b))
    }
    U.prototype.i = function() {
        if (this.G)
            for (; this.G.length;) this.G.shift()()
    };

    function $o(a) {
        a.g.forEach((b, c) => {
            if (b.overrides.delete(a)) {
                b = Array.from(b.overrides.values()).pop() || b.originalValue;
                var d = a.element;
                b ? d.style.setProperty(c, b.value, b.priority) : d.style.removeProperty(c)
            }
        })
    }

    function ap(a, b, c) {
        c = {
            value: c,
            priority: "important"
        };
        var d = a.g.get(b);
        if (!d) {
            d = a.element;
            var e = d.style.getPropertyValue(b);
            d = {
                originalValue: e ? {
                    value: e,
                    priority: d.style.getPropertyPriority(b)
                } : null,
                overrides: new Map
            };
            a.g.set(b, d)
        }
        d.overrides.delete(a);
        d.overrides.set(a, c);
        a = a.element;
        c ? a.style.setProperty(b, c.value, c.priority) : a.style.removeProperty(b)
    }
    var bp = class extends U {
        constructor(a, b) {
            super();
            this.element = b;
            a = a.googTempStyleOverrideInfo = a.googTempStyleOverrideInfo || new Map;
            var c = a.get(b);
            c ? b = c : (c = new Map, a.set(b, c), b = c);
            this.g = b
        }
        i() {
            $o(this);
            super.i()
        }
    };

    function cp(a) {
        const b = new V(a.getValue());
        a.listen(c => b.g(c));
        return b
    }

    function dp(a, b) {
        const c = new V({
            first: a.M,
            second: b.M
        });
        a.listen(() => c.g({
            first: a.M,
            second: b.M
        }));
        b.listen(() => c.g({
            first: a.M,
            second: b.M
        }));
        return c
    }

    function ep(...a) {
        const b = [...a],
            c = () => b.every(f => f.M),
            d = new V(c()),
            e = () => {
                d.g(c())
            };
        b.forEach(f => f.listen(e));
        return fp(d)
    }

    function gp(...a) {
        const b = [...a],
            c = () => -1 !== b.findIndex(f => f.M),
            d = new V(c()),
            e = () => {
                d.g(c())
            };
        b.forEach(f => f.listen(e));
        return fp(d)
    }

    function fp(a, b = hp) {
        var c = a.M;
        const d = new V(a.M);
        a.listen(e => {
            b(e, c) || (c = e, d.g(e))
        });
        return d
    }

    function W(a, b, c) {
        return a.i(d => {
            d === b && c()
        })
    }

    function ip(a, b, c) {
        if (a.M === b) c();
        else {
            var d = {
                dd: null
            };
            d.dd = W(a, b, () => {
                d.dd && (d.dd(), d.dd = null);
                c()
            })
        }
    }

    function jp(a, b, c) {
        fp(a).listen(d => {
            d === b && c()
        })
    }

    function kp(a, b) {
        a.l && a.l();
        a.l = b.listen(c => a.g(c), !0)
    }

    function lp(a, b, c, d) {
        const e = new V(!1);
        var f = null;
        a = a.map(d);
        W(a, !0, () => {
            null === f && (f = b.setTimeout(() => {
                e.g(!0)
            }, c))
        });
        W(a, !1, () => {
            e.g(!1);
            null !== f && (b.clearTimeout(f), f = null)
        });
        return fp(e)
    }

    function mp(a) {
        return {
            listen: b => a.listen(b),
            getValue: () => a.M
        }
    }
    class V {
        constructor(a) {
            this.M = a;
            this.j = new Map;
            this.B = 1;
            this.l = null
        }
        listen(a, b = !1) {
            const c = this.B++;
            this.j.set(c, a);
            b && a(this.M);
            return () => {
                this.j.delete(c)
            }
        }
        i(a) {
            return this.listen(a, !0)
        }
        A() {
            return this.M
        }
        g(a) {
            this.M = a;
            this.j.forEach(b => {
                b(this.M)
            })
        }
        map(a) {
            const b = new V(a(this.M));
            this.listen(c => b.g(a(c)));
            return b
        }
    }

    function hp(a, b) {
        return a == b
    };

    function np(a) {
        return new op(a)
    }

    function pp(a, b) {
        Va(a.g, c => {
            c(b)
        })
    }
    var qp = class {
        constructor() {
            this.g = []
        }
    };
    class op {
        constructor(a) {
            this.g = a
        }
        listen(a) {
            this.g.g.push(a)
        }
        map(a) {
            const b = new qp;
            this.listen(c => pp(b, a(c)));
            return np(b)
        }
        delay(a, b) {
            const c = new qp;
            this.listen(d => {
                a.setTimeout(() => {
                    pp(c, d)
                }, b)
            });
            return np(c)
        }
    }

    function rp(...a) {
        const b = new qp;
        a.forEach(c => {
            c.listen(d => {
                pp(b, d)
            })
        });
        return np(b)
    };

    function sp(a) {
        return fp(dp(a.g, a.j).map(b => {
            var c = b.first;
            b = b.second;
            return null == c || null == b ? null : tp(c, b)
        }))
    }
    var vp = class {
        constructor(a) {
            this.i = a;
            this.g = new V(null);
            this.j = new V(null);
            this.l = new qp;
            this.C = b => {
                null == this.g.M && 1 == b.touches.length && this.g.g(b.touches[0])
            };
            this.A = b => {
                const c = this.g.M;
                null != c && (b = up(c, b.changedTouches), null != b && (this.g.g(null), this.j.g(null), pp(this.l, tp(c, b))))
            };
            this.B = b => {
                var c = this.g.M;
                null != c && (c = up(c, b.changedTouches), null != c && (this.j.g(c), b.preventDefault()))
            }
        }
    };

    function tp(a, b) {
        return {
            uh: b.pageX - a.pageX,
            wh: b.pageY - a.pageY
        }
    }

    function up(a, b) {
        if (null == b) return null;
        for (let c = 0; c < b.length; ++c)
            if (b[c].identifier == a.identifier) return b[c];
        return null
    };

    function wp(a) {
        return fp(dp(a.g, a.i).map(b => {
            var c = b.first;
            b = b.second;
            return null == c || null == b ? null : xp(c, b)
        }))
    }
    var yp = class {
        constructor(a, b) {
            this.l = a;
            this.A = b;
            this.g = new V(null);
            this.i = new V(null);
            this.j = new qp;
            this.G = c => {
                this.g.g(c)
            };
            this.B = c => {
                const d = this.g.M;
                null != d && (this.g.g(null), this.i.g(null), pp(this.j, xp(d, c)))
            };
            this.C = c => {
                null != this.g.M && (this.i.g(c), c.preventDefault())
            }
        }
    };

    function xp(a, b) {
        return {
            uh: b.screenX - a.screenX,
            wh: b.screenY - a.screenY
        }
    };
    var Bp = (a, b, c) => {
        const d = new zp(a, b, c);
        return () => Ap(d)
    };

    function Ap(a) {
        if (a.g) return !1;
        if (null == a.i) return Cp(a), !0;
        const b = a.i + a.A - (new Date).getTime();
        if (1 > b) return Cp(a), !0;
        Dp(a, b);
        return !0
    }

    function Cp(a) {
        a.i = (new Date).getTime();
        a.l()
    }

    function Dp(a, b) {
        a.g = !0;
        a.j.setTimeout(() => {
            a.g = !1;
            Cp(a)
        }, b)
    }
    class zp {
        constructor(a, b, c) {
            this.j = a;
            this.A = b;
            this.l = c;
            this.i = null;
            this.g = !1
        }
    };

    function Ep(a) {
        return Fp(wp(a.g), sp(a.i))
    }

    function Gp(a) {
        return rp(np(a.g.j), np(a.i.l))
    }
    var Hp = class {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
    };

    function Fp(a, b) {
        return dp(a, b).map(({
            first: c,
            second: d
        }) => c || d || null)
    };
    var Ip = class {
        constructor() {
            this.cache = new Map
        }
        getBoundingClientRect(a) {
            var b = this.cache.get(a);
            if (b) return b;
            b = a.getBoundingClientRect();
            this.cache.set(a, b);
            return b
        }
    };

    function Jp(a) {
        null == a.A && (a.A = new V(a.C.getBoundingClientRect()));
        return a.A
    }
    class Kp extends U {
        constructor(a, b) {
            super();
            this.j = a;
            this.C = b;
            this.F = !1;
            this.A = null;
            this.l = () => {
                Jp(this).g(this.C.getBoundingClientRect())
            }
        }
        g() {
            this.F || (this.F = !0, this.j.addEventListener("resize", this.l), this.j.addEventListener("scroll", this.l));
            return Jp(this)
        }
        i() {
            this.j.removeEventListener("resize", this.l);
            this.j.removeEventListener("scroll", this.l);
            super.i()
        }
    };

    function Lp(a, b) {
        return new Mp(a, b)
    }

    function Np(a) {
        a.win.requestAnimationFrame(() => {
            a.B || a.j.g(new Yd(a.element.offsetWidth, a.element.offsetHeight))
        })
    }

    function Op(a) {
        a.g || (a.g = !0, a.l.observe(a.element));
        return fp(a.j, Zd)
    }
    var Mp = class extends U {
        constructor(a, b) {
            super();
            this.win = a;
            this.element = b;
            this.g = !1;
            this.j = new V(new Yd(this.element.offsetWidth, this.element.offsetHeight));
            this.l = new ResizeObserver(() => {
                Np(this)
            })
        }
        i() {
            this.l.disconnect();
            super.i()
        }
    };

    function Pp(a, b) {
        return {
            top: a.g - b,
            right: a.j + a.i,
            bottom: a.g + b,
            left: a.j
        }
    }
    class Qp {
        constructor(a, b, c) {
            this.j = a;
            this.g = b;
            this.i = c
        }
        zc() {
            return this.i
        }
    };

    function Rp(a, b) {
        a = a.getBoundingClientRect();
        return new Sp(a.top + Eo(b), a.bottom - a.top)
    }

    function Tp(a) {
        return new Sp(Math.round(a.g), Math.round(a.i))
    }
    class Sp {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
        getHeight() {
            return this.i
        }
    };
    var Vp = (a, b) => {
        const c = a.google_pso_loaded_fonts || (a.google_pso_loaded_fonts = []),
            d = new Qo(c);
        b = b.filter(e => !d.contains(e));
        b.length && (Up(a, b), ib(c, b))
    };

    function Up(a, b) {
        for (const f of b) {
            b = Xe("LINK", a.document);
            b.type = "text/css";
            var c = sj `//fonts.googleapis.com/css`,
                d = vk(),
                e = b;
            c = $c(c, {
                family: f
            });
            if (c instanceof Zc) d = c;
            else a: {
                if (c instanceof id) {
                    d = c;
                    break a
                }
                const g = De(c, Ce) || od;g === od && d(c);d = g
            }
            e.rel = "stylesheet";
            if (kc("stylesheet", "stylesheet")) {
                e.href = bd(d).toString();
                a: if (d = (e.ownerDocument && e.ownerDocument.defaultView || r).document, d.querySelector) {
                    if ((d = d.querySelector('style[nonce],link[rel="stylesheet"][nonce]')) && (d = d.nonce || d.getAttribute("nonce")) &&
                        Rd.test(d)) break a;
                    d = ""
                } else d = "";
                d && e.setAttribute("nonce", d)
            } else {
                if (d instanceof Zc) d = bd(d).toString();
                else if (d instanceof id) d = jd(d);
                else {
                    if (!(d instanceof id)) {
                        d = String(d);
                        b: {
                            c = void 0;
                            try {
                                c = new URL(d)
                            } catch (g) {
                                c = "https:";
                                break b
                            }
                            c = c.protocol
                        }
                        "javascript:" === c && (d = "about:invalid#zClosurez");
                        d = new id(d, nd)
                    }
                    d = jd(d)
                }
                e.href = d
            }
            a.document.head.appendChild(b)
        }
    };

    function Wp(a, b) {
        a.F ? b(a.l) : a.j.push(b)
    }

    function Xp(a, b) {
        a.F = !0;
        a.l = b;
        a.j.forEach(c => {
            c(a.l)
        });
        a.j = []
    }
    class Yp extends U {
        constructor(a) {
            super();
            this.g = a;
            this.j = [];
            this.F = !1;
            this.C = this.l = null;
            this.H = Bp(a, 1E3, () => {
                if (null != this.C) {
                    var b = zo(this.g, !0) - this.C;
                    1E3 < b && Xp(this, b)
                }
            });
            this.A = null
        }
        L(a, b) {
            null == a ? (this.C = a = zo(this.g, !0), this.g.addEventListener("scroll", this.H), null != b && b(a)) : this.A = this.g.setTimeout(() => {
                this.L(void 0, b)
            }, a)
        }
        i() {
            null != this.A && this.g.clearTimeout(this.A);
            this.g.removeEventListener("scroll", this.H);
            this.j = [];
            this.l = null;
            super.i()
        }
    };
    var Zp = (a, b) => a.reduce((c, d) => c.concat(b(d)), []);
    class $p {
        constructor(a = 1) {
            this.g = a
        }
        next() {
            var a = 48271 * this.g % 2147483647;
            this.g = 0 > 2147483647 * a ? a + 2147483647 : a;
            return this.g / 2147483647
        }
    };

    function aq(a, b, c) {
        const d = [];
        for (const e of a.g) b(e) ? d.push(e) : c(e);
        return new bq(d)
    }

    function cq(a) {
        return a.g.slice(0)
    }

    function dq(a, b = 1) {
        a = cq(a);
        const c = new $p(b);
        rb(a, () => c.next());
        return new bq(a)
    }
    const bq = class {
        constructor(a) {
            this.g = a.slice(0)
        }
        forEach(a) {
            this.g.forEach((b, c) => void a(b, c, this))
        }
        filter(a) {
            return new bq(Za(this.g, a))
        }
        apply(a) {
            return new bq(a(cq(this)))
        }
        sort(a) {
            return new bq(cq(this).sort(a))
        }
        get(a) {
            return this.g[a]
        }
        add(a) {
            const b = cq(this);
            b.push(a);
            return new bq(b)
        }
    };
    class eq {
        constructor(a) {
            this.g = new Qo(a)
        }
        contains(a) {
            return this.g.contains(a)
        }
    };

    function fq(a) {
        return new gq({
            value: a
        }, null)
    }

    function hq(a) {
        return new gq(null, a)
    }

    function iq(a) {
        try {
            return fq(a())
        } catch (b) {
            return hq(b)
        }
    }

    function jq(a) {
        return null != a.g ? a.getValue() : null
    }

    function kq(a, b) {
        null != a.g && b(a.getValue());
        return a
    }

    function lq(a, b) {
        null != a.g || b(a.i);
        return a
    }
    class gq {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
        getValue() {
            return this.g.value
        }
        map(a) {
            return null != this.g ? (a = a(this.getValue()), a instanceof gq ? a : fq(a)) : this
        }
    };
    class mq {
        constructor() {
            this.g = new Po
        }
        set(a, b) {
            let c = this.g.get(a);
            c || (c = new Qo, this.g.set(a, c));
            c.add(b)
        }
    };

    function nq(a) {
        return !a
    }

    function oq(a) {
        return b => {
            for (const c of a) c(b)
        }
    };

    function pq(a) {
        return null !== a
    };
    var qq = class extends S {
        getId() {
            return L(this, 3)
        }
    };
    qq.P = [4];
    class rq {
        constructor(a, {
            Kf: b,
            Ah: c,
            Li: d,
            Yg: e
        }) {
            this.A = a;
            this.j = c;
            this.l = new bq(b || []);
            this.i = e;
            this.g = d
        }
    };
    var sq = a => {
            var b = a.split("~").filter(c => 0 < c.length);
            a = new Po;
            for (const c of b) b = c.indexOf("."), -1 == b ? a.set(c, "") : a.set(c.substring(0, b), c.substring(b + 1));
            return a
        },
        uq = a => {
            var b = tq(a);
            a = [];
            for (let c of b) b = String(c.oc), a.push(c.Ab + "." + (20 >= b.length ? b : b.slice(0, 19) + "_"));
            return a.join("~")
        };
    const tq = a => {
            const b = [],
                c = a.l;
            c && c.g.length && b.push({
                Ab: "a",
                oc: vq(c)
            });
            null != a.j && b.push({
                Ab: "as",
                oc: a.j
            });
            null != a.g && b.push({
                Ab: "i",
                oc: String(a.g)
            });
            null != a.i && b.push({
                Ab: "rp",
                oc: String(a.i)
            });
            b.sort(function(d, e) {
                return d.Ab.localeCompare(e.Ab)
            });
            b.unshift({
                Ab: "t",
                oc: wq(a.A)
            });
            return b
        },
        wq = a => {
            switch (a) {
                case 0:
                    return "aa";
                case 1:
                    return "ma";
                default:
                    throw Error("Invalid slot type" + a);
            }
        },
        vq = a => {
            a = cq(a).map(xq);
            a = JSON.stringify(a);
            return bf(a)
        },
        xq = a => {
            const b = {};
            null != L(a, 7) && (b.q = L(a, 7));
            null != ui(a,
                2) && (b.o = ui(a, 2));
            null != ui(a, 5) && (b.p = ui(a, 5));
            return b
        };

    function yq() {
        var a = new zq;
        return Wh(a, 2, eh(1))
    }
    var zq = class extends S {
        g() {
            return M(this, 1)
        }
        setLocation(a) {
            return Wh(this, 1, eh(a))
        }
    };

    function Aq(a) {
        const b = [].slice.call(arguments).filter(Jb(e => null === e));
        if (!b.length) return null;
        let c = [],
            d = {};
        b.forEach(e => {
            c = c.concat(e.Sf || []);
            d = Object.assign(d, e.Ac())
        });
        return new Bq(c, d)
    }

    function Cq(a) {
        switch (a) {
            case 1:
                return new Bq(null, {
                    google_ad_semantic_area: "mc"
                });
            case 2:
                return new Bq(null, {
                    google_ad_semantic_area: "h"
                });
            case 3:
                return new Bq(null, {
                    google_ad_semantic_area: "f"
                });
            case 4:
                return new Bq(null, {
                    google_ad_semantic_area: "s"
                });
            default:
                return null
        }
    }

    function Dq(a) {
        return null == a ? null : new Bq(null, {
            google_ml_rank: a
        })
    }

    function Eq(a) {
        return null == a ? null : new Bq(null, {
            google_placement_id: uq(a)
        })
    }

    function Fq({
        fi: a,
        ui: b = null
    }) {
        if (null == a) return null;
        a = {
            google_daaos_ts: a
        };
        null != b && (a.google_erank = b + 1);
        return new Bq(null, a)
    }
    class Bq {
        constructor(a, b) {
            this.Sf = a;
            this.g = b
        }
        Ac() {
            return this.g
        }
    };
    var Gq = class extends S {};
    var Hq = class extends S {};
    var Iq = class extends S {};
    var Jq = class extends S {};
    var Kq = class extends S {
        A() {
            return L(this, 2)
        }
        l() {
            return L(this, 5)
        }
        g() {
            return D(this, Jq, 3)
        }
        Nb() {
            return ui(this, 4)
        }
        j() {
            return $h(this, 6)
        }
        B() {
            return Yh(this, Iq, 7)
        }
    };
    Kq.P = [3];
    var Lq = class extends S {};
    var Mq = class extends S {};
    var Nq = class extends S {
        constructor() {
            super()
        }
    };
    var Oq = class extends S {
        g() {
            return M(this, 3)
        }
        Nb() {
            return vi(this, 4)
        }
        j() {
            return ai(this, 6)
        }
    };
    var Pq = class extends S {};
    var Qq = class extends S {};
    var Rq = class extends S {
        ja() {
            return C(this, qq, 1)
        }
        g() {
            return M(this, 2)
        }
    };
    var Sq = class extends S {};
    var Tq = class extends S {};
    var Uq = class extends S {
            getName() {
                return L(this, 4)
            }
        },
        Vq = [1, 2, 3];
    var Wq = class extends S {
        g() {
            return C(this, Oq, 10)
        }
    };
    Wq.P = [2, 5, 6, 11];
    var Xq = class extends S {
        g() {
            return ai(this, 2)
        }
        j() {
            return ai(this, 3)
        }
    };
    var Yq = class extends S {
        g() {
            return vi(this, 1)
        }
    };
    var Zq = class extends S {};
    var $q = class extends S {
        g() {
            return Ri(this, 1)
        }
        j() {
            return P(this, 3)
        }
        l() {
            return P(this, 4)
        }
    };
    var ar = class extends S {
        j() {
            return Qi(this, 1)
        }
        g() {
            return Qi(this, 1)
        }
    };
    var br = class extends S {
        g() {
            return P(this, 1)
        }
        j() {
            return P(this, 2)
        }
        A() {
            return P(this, 3)
        }
        l() {
            return P(this, 4)
        }
    };
    var cr = class extends S {
        j() {
            return C(this, $q, 8)
        }
        l() {
            return C(this, $q, 9)
        }
        B() {
            return C(this, br, 4)
        }
        g() {
            return C(this, ar, 5)
        }
        A() {
            return P(this, 10)
        }
        C() {
            return O(this, 12)
        }
        G() {
            return O(this, 14)
        }
    };
    var dr = class extends S {
        l() {
            return O(this, 1)
        }
        A() {
            return O(this, 3)
        }
        j() {
            return O(this, 4)
        }
        g() {
            return O(this, 5)
        }
    };
    var er = class extends S {
        j() {
            return C(this, br, 5)
        }
        g() {
            return C(this, ar, 6)
        }
        A() {
            return P(this, 8)
        }
        B() {
            return O(this, 9)
        }
        C() {
            return O(this, 11)
        }
        l() {
            return C(this, dr, 12)
        }
    };

    function fr() {
        var a = new gr;
        a = $i(a, 1, "Toggle toolbar expansion");
        a = $i(a, 2, "Toggle privacy and legal settings display");
        return $i(a, 3, "Dismiss privacy and legal settings display")
    }
    var gr = class extends S {};
    var hr = class extends S {
        g() {
            return C(this, gr, 1)
        }
    };
    var ir = class extends S {};
    ir.P = [2];
    var jr = class extends S {};
    var kr = class extends S {
        g() {
            return D(this, jr, 1)
        }
    };
    kr.P = [1];
    var lr = class extends S {
        setProperty(a) {
            return $i(this, 1, a)
        }
        getValue() {
            return L(this, 2)
        }
    };
    var mr = class extends S {};
    mr.P = [3, 4];
    var nr = class extends S {};
    var or = class extends S {
        ja() {
            return C(this, qq, 1)
        }
        g() {
            return M(this, 2)
        }
    };
    or.P = [6, 7, 9, 10, 11];
    var pr = class extends S {};
    pr.P = [4];
    var qr = class extends S {};
    var rr = class extends S {
        g() {
            return bi(this, 6, vh, 2)
        }
    };
    rr.P = [6];
    var sr = class extends S {
        Ke() {
            return Yh(this, qr, 2)
        }
    };
    var tr = class extends S {
        g() {
            return Qi(this, 1)
        }
    };
    var ur = class extends S {};
    var wr = class extends S {
            g() {
                return Si(this, ur, 2, vr)
            }
        },
        vr = [1, 2];
    var xr = class extends S {
        g() {
            return C(this, wr, 3)
        }
    };
    var yr = class extends S {};
    var zr = class extends S {
        g() {
            return D(this, yr, 1)
        }
    };
    zr.P = [1];
    var Ar = class extends S {
        g() {
            return bi(this, 1, vh, 2)
        }
        j() {
            return C(this, xr, 3)
        }
    };
    Ar.P = [1, 4];

    function Br(a) {
        return C(a, Hq, 13)
    }

    function Cr(a) {
        return C(a, Mq, 15)
    }
    var Dr = class extends S {},
        Er = hj(Dr);
    Dr.P = [1, 2, 5, 7];
    var Fr = class extends S {},
        Gr = hj(Fr);

    function Hr(a) {
        try {
            const b = a.localStorage.getItem("google_ama_settings");
            return b ? Gr(b) : null
        } catch (b) {
            return null
        }
    }

    function Ir(a, b) {
        if (void 0 !== a.ze) {
            var c = Hr(b);
            c || (c = new Fr);
            void 0 !== a.ze && Vi(c, 2, a.ze);
            a = Date.now() + 864E5;
            Number.isFinite(a) && Zi(c, 1, Math.round(a));
            c = bj(c);
            try {
                b.localStorage.setItem("google_ama_settings", c)
            } catch (d) {}
        } else if ((c = Hr(b)) && vi(c, 1) < Date.now()) try {
            b.localStorage.removeItem("google_ama_settings")
        } catch (d) {}
    };
    var Jr = {
            Wa: "ama_success",
            Qa: .1,
            Ta: !0,
            Xa: !0
        },
        Kr = {
            Wa: "ama_failure",
            Qa: .1,
            Ta: !0,
            Xa: !0
        },
        Lr = {
            Wa: "ama_coverage",
            Qa: .1,
            Ta: !0,
            Xa: !0
        },
        Mr = {
            Wa: "ama_opt",
            Qa: .1,
            Ta: !0,
            Xa: !1
        },
        Nr = {
            Wa: "ama_auto_rs",
            Qa: 1,
            Ta: !0,
            Xa: !1
        },
        Or = {
            Wa: "ama_auto_prose",
            Qa: 1,
            Ta: !0,
            Xa: !1
        },
        Pr = {
            Wa: "ama_improv",
            Qa: .1,
            Ta: !0,
            Xa: !1
        },
        Qr = {
            Wa: "ama_constraints",
            Qa: 0,
            Ta: !0,
            Xa: !0
        };

    function Rr(a, b, c) {
        var d = 0 === a.i ? a.g.j() : a.g.l(),
            e = a.j,
            f = T(a.win),
            g = a.g.g() ? .g() || 0;
        a: switch (d ? .g()) {
            case 1:
                d = "AUTO_PROSE_TOP_ANCHOR";
                break a;
            case 2:
                d = "AUTO_PROSE_BOTTOM_ANCHOR";
                break a;
            default:
                d = "UNKNOWN_POSITION"
        }
        a: switch (a.i) {
            case 0:
                a = "DESKTOP";
                break a;
            case 2:
                a = "MOBILE";
                break a;
            default:
                a = "OTHER_VIEWPORT"
        }
        Sr(e, Or, { ...c,
            evt: b,
            vh: f,
            eid: g,
            pos: d,
            vpt: a
        })
    }

    function Tr(a, b) {
        Rr(a, "place", {
            sts: b
        })
    }
    var Ur = class {
        constructor(a, b, c) {
            this.win = a;
            this.j = b;
            this.g = c;
            this.i = pf()
        }
    };
    var Vr = {},
        Wr = {},
        Xr = {},
        Yr = {},
        Zr = {};

    function $r() {
        throw Error("Do not instantiate directly");
    }
    $r.prototype.Uf = null;
    $r.prototype.Ma = function() {
        return this.content
    };
    $r.prototype.toString = function() {
        return this.content
    };

    function as(a) {
        if (a.Vf !== Vr) throw Error("Sanitized content was not of kind HTML.");
        return Fd(a.toString())
    }

    function bs() {
        $r.call(this)
    }
    Ma(bs, $r);
    bs.prototype.Vf = Vr;

    function cs(a, b) {
        return null != a && a.Vf === b
    };

    function ds(a) {
        if (null != a) switch (a.Uf) {
            case 1:
                return 1;
            case -1:
                return -1;
            case 0:
                return 0
        }
        return null
    }

    function es(a) {
        return cs(a, Vr) ? a : a instanceof Ed ? fs(Dd(a).toString()) : fs(String(String(a)).replace(gs, hs), ds(a))
    }
    var fs = function(a) {
        function b(c) {
            this.content = c
        }
        b.prototype = a.prototype;
        return function(c, d) {
            c = new b(String(c));
            void 0 !== d && (c.Uf = d);
            return c
        }
    }(bs);

    function is(a) {
        return a.replace(/<\//g, "<\\/").replace(/\]\]>/g, "]]\\>")
    }

    function js(a) {
        return cs(a, Vr) ? String(String(a.Ma()).replace(ks, "").replace(ls, "&lt;")).replace(ms, hs) : String(a).replace(gs, hs)
    }

    function ns(a) {
        a = String(a);
        const b = (d, e, f) => {
            const g = Math.min(e.length - f, d.length);
            for (let k = 0; k < g; k++) {
                var h = e[f + k];
                if (d[k] !== ("A" <= h && "Z" >= h ? h.toLowerCase() : h)) return !1
            }
            return !0
        };
        for (var c = 0; - 1 != (c = a.indexOf("<", c));) {
            if (b("\x3c/script", a, c) || b("\x3c!--", a, c)) return "zSoyz";
            c += 1
        }
        return a
    }

    function os(a) {
        if (null == a) return " null ";
        if (cs(a, Wr)) return a.Ma();
        switch (typeof a) {
            case "boolean":
            case "number":
                return " " + a + " ";
            default:
                return "'" + String(String(a)).replace(ps, qs) + "'"
        }
    }

    function X(a) {
        cs(a, Zr) ? a = is(a.Ma()) : null == a ? a = "" : a instanceof rd ? a = is(qd(a)) : a instanceof Bd ? a = is(a instanceof Bd && a.constructor === Bd ? a.g : "type_error:SafeStyleSheet") : (a = String(a), a = rs.test(a) ? a : "zSoyz");
        return a
    }
    const ss = {
        "\x00": "&#0;",
        "\t": "&#9;",
        "\n": "&#10;",
        "\v": "&#11;",
        "\f": "&#12;",
        "\r": "&#13;",
        " ": "&#32;",
        '"': "&quot;",
        "&": "&amp;",
        "'": "&#39;",
        "-": "&#45;",
        "/": "&#47;",
        "<": "&lt;",
        "=": "&#61;",
        ">": "&gt;",
        "`": "&#96;",
        "\u0085": "&#133;",
        "\u00a0": "&#160;",
        "\u2028": "&#8232;",
        "\u2029": "&#8233;"
    };

    function hs(a) {
        return ss[a]
    }
    const ts = {
        "\x00": "\\x00",
        "\b": "\\x08",
        "\t": "\\t",
        "\n": "\\n",
        "\v": "\\x0b",
        "\f": "\\f",
        "\r": "\\r",
        '"': "\\x22",
        $: "\\x24",
        "&": "\\x26",
        "'": "\\x27",
        "(": "\\x28",
        ")": "\\x29",
        "*": "\\x2a",
        "+": "\\x2b",
        ",": "\\x2c",
        "-": "\\x2d",
        ".": "\\x2e",
        "/": "\\/",
        ":": "\\x3a",
        "<": "\\x3c",
        "=": "\\x3d",
        ">": "\\x3e",
        "?": "\\x3f",
        "[": "\\x5b",
        "\\": "\\\\",
        "]": "\\x5d",
        "^": "\\x5e",
        "{": "\\x7b",
        "|": "\\x7c",
        "}": "\\x7d",
        "\u0085": "\\x85",
        "\u2028": "\\u2028",
        "\u2029": "\\u2029"
    };

    function qs(a) {
        return ts[a]
    }
    const us = {
        "\x00": "%00",
        "\u0001": "%01",
        "\u0002": "%02",
        "\u0003": "%03",
        "\u0004": "%04",
        "\u0005": "%05",
        "\u0006": "%06",
        "\u0007": "%07",
        "\b": "%08",
        "\t": "%09",
        "\n": "%0A",
        "\v": "%0B",
        "\f": "%0C",
        "\r": "%0D",
        "\u000e": "%0E",
        "\u000f": "%0F",
        "\u0010": "%10",
        "\u0011": "%11",
        "\u0012": "%12",
        "\u0013": "%13",
        "\u0014": "%14",
        "\u0015": "%15",
        "\u0016": "%16",
        "\u0017": "%17",
        "\u0018": "%18",
        "\u0019": "%19",
        "\u001a": "%1A",
        "\u001b": "%1B",
        "\u001c": "%1C",
        "\u001d": "%1D",
        "\u001e": "%1E",
        "\u001f": "%1F",
        " ": "%20",
        '"': "%22",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "<": "%3C",
        ">": "%3E",
        "\\": "%5C",
        "{": "%7B",
        "}": "%7D",
        "\u007f": "%7F",
        "\u0085": "%C2%85",
        "\u00a0": "%C2%A0",
        "\u2028": "%E2%80%A8",
        "\u2029": "%E2%80%A9",
        "\uff01": "%EF%BC%81",
        "\uff03": "%EF%BC%83",
        "\uff04": "%EF%BC%84",
        "\uff06": "%EF%BC%86",
        "\uff07": "%EF%BC%87",
        "\uff08": "%EF%BC%88",
        "\uff09": "%EF%BC%89",
        "\uff0a": "%EF%BC%8A",
        "\uff0b": "%EF%BC%8B",
        "\uff0c": "%EF%BC%8C",
        "\uff0f": "%EF%BC%8F",
        "\uff1a": "%EF%BC%9A",
        "\uff1b": "%EF%BC%9B",
        "\uff1d": "%EF%BC%9D",
        "\uff1f": "%EF%BC%9F",
        "\uff20": "%EF%BC%A0",
        "\uff3b": "%EF%BC%BB",
        "\uff3d": "%EF%BC%BD"
    };

    function vs(a) {
        return us[a]
    }
    const gs = /[\x00\x22\x26\x27\x3c\x3e]/g,
        ms = /[\x00\x22\x27\x3c\x3e]/g,
        ws = /[\x00\x09-\x0d \x22\x26\x27\x2d\/\x3c-\x3e`\x85\xa0\u2028\u2029]/g,
        xs = /[\x00\x09-\x0d \x22\x27\x2d\/\x3c-\x3e`\x85\xa0\u2028\u2029]/g,
        ps = /[\x00\x08-\x0d\x22\x26\x27\/\x3c-\x3e\x5b-\x5d\x7b\x7d\x85\u2028\u2029]/g,
        ys = /[\x00- \x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,
        rs = /^(?!-*(?:expression|(?:moz-)?binding))(?:(?:[.#]?-?(?:[_a-z0-9-]+)(?:-[_a-z0-9-]+)*-?|(?:calc|cubic-bezier|drop-shadow|hsl|hsla|hue-rotate|invert|linear-gradient|max|min|rgb|rgba|rotate|rotateZ|translate|translate3d|translateX|translateY|var)\((?:[-\u0020\t,+.!#%_0-9a-zA-Z]|(?:calc|cubic-bezier|drop-shadow|hsl|hsla|hue-rotate|invert|linear-gradient|max|min|rgb|rgba|rotate|rotateZ|translate|translate3d|translateX|translateY|var)\([-\u0020\t,+.!#%_0-9a-zA-Z]+\))+\)|[-+]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:e-?[0-9]+)?(?:[a-z]{1,4}|%)?|!important)(?:\s*[,\u0020]\s*|$))*$/i,
        zs =
        /^[^&:\/?#]*(?:[\/?#]|$)|^https?:|^ftp:|^data:image\/[a-z0-9+-]+;base64,[a-z0-9+\/]+=*$|^blob:/i,
        ks = /<(?:!|\/?([a-zA-Z][a-zA-Z0-9:\-]*))(?:[^>'"]|"[^"]*"|'[^']*')*>/g,
        ls = /</g;

    function As(a) {
        a = void 0 === a ? "white" : a;
        return fs('<svg width="' + js(18) + '" height="' + js(18) + '" viewBox="0 0 ' + js(18) + " " + js(18) + '"><path fill-rule="evenodd" clip-rule="evenodd" d="M11.76 10.27L17.49 16L16 17.49L10.27 11.76C9.2 12.53 7.91 13 6.5 13C2.91 13 0 10.09 0 6.5C0 2.91 2.91 0 6.5 0C10.09 0 13 2.91 13 6.5C13 7.91 12.53 9.2 11.76 10.27ZM6.5 2C4.01 2 2 4.01 2 6.5C2 8.99 4.01 11 6.5 11C8.99 11 11 8.99 11 6.5C11 4.01 8.99 2 6.5 2Z" fill=' + (cs(a, Vr) ? String(String(a.Ma()).replace(ks, "").replace(ls,
            "&lt;")).replace(xs, hs) : String(a).replace(ws, hs)) + " /></svg>")
    };
    /* 
     
     
     Copyright Mathias Bynens <http://mathiasbynens.be/> 
     
     Permission is hereby granted, free of charge, to any person obtaining 
     a copy of this software and associated documentation files (the 
     "Software"), to deal in the Software without restriction, including 
     without limitation the rights to use, copy, modify, merge, publish, 
     distribute, sublicense, and/or sell copies of the Software, and to 
     permit persons to whom the Software is furnished to do so, subject to 
     the following conditions: 
     
     The above copyright notice and this permission notice shall be 
     included in all copies or substantial portions of the Software. 
     
     THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, 
     EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
     MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
     NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE 
     LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION 
     OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION 
     WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
    */
    const Bs = Math.floor;
    var Cs = /^xn--/,
        Ds = /[\x2E\u3002\uFF0E\uFF61]/g;
    const Es = {
        Fm: "Overflow: input needs wider integers to process",
        Bm: "Illegal input >= 0x80 (not a basic code point)",
        lm: "Invalid input"
    };

    function Fs(a) {
        throw RangeError(Es[a]);
    }

    function Gs(a, b) {
        const c = a.split("@");
        let d = "";
        1 < c.length && (d = c[0] + "@", a = c[1]);
        a = a.replace(Ds, ".");
        a = a.split(".").map(b).join(".");
        return d + a
    }

    function Hs(a) {
        return Gs(a, b => {
            if (Cs.test(b) && 4 < b.length) {
                b = b.slice(4).toLowerCase();
                const h = [],
                    k = b.length;
                let l = 0,
                    m = 128;
                var c = 72,
                    d = b.lastIndexOf("-");
                0 > d && (d = 0);
                for (var e = 0; e < d; ++e) 128 <= b.charCodeAt(e) && Fs("Illegal input >= 0x80 (not a basic code point)"), h.push(b.charCodeAt(e));
                for (d = 0 < d ? d + 1 : 0; d < k;) {
                    e = l;
                    for (let n = 1, p = 36;; p += 36) {
                        d >= k && Fs("Invalid input");
                        var f = b.charCodeAt(d++);
                        f = 10 > f - 48 ? f - 22 : 26 > f - 65 ? f - 65 : 26 > f - 97 ? f - 97 : 36;
                        (36 <= f || f > Bs((2147483647 - l) / n)) && Fs("Overflow: input needs wider integers to process");
                        l += f * n;
                        var g = p <= c ? 1 : p >= c + 26 ? 26 : p - c;
                        if (f < g) break;
                        f = 36 - g;
                        n > Bs(2147483647 / f) && Fs("Overflow: input needs wider integers to process");
                        n *= f
                    }
                    f = h.length + 1;
                    c = l - e;
                    g = 0;
                    c = 0 == e ? Bs(c / 700) : c >> 1;
                    for (c += Bs(c / f); 455 < c; g += 36) c = Bs(c / 35);
                    c = Bs(g + 36 * c / (c + 38));
                    Bs(l / f) > 2147483647 - m && Fs("Overflow: input needs wider integers to process");
                    m += Bs(l / f);
                    l %= f;
                    h.splice(l++, 0, m)
                }
                b = String.fromCodePoint.apply(null, h)
            }
            return b
        })
    };
    const Is = new ub(vb, "558153351");

    function Js(a, b, c) {
        var d = a.Na.contentWindow;
        const e = !a.A && "number" === typeof a.g;
        a.B ? (b = {
            action: "search",
            searchTerm: b,
            rsToken: c
        }, e && (b.experimentId = a.g), d.postMessage(b, "https://www.gstatic.com")) : (d = d.google.search.cse.element.getElement(a.C), c = {
            rsToken: c,
            hostName: a.host
        }, e && (c.afsExperimentId = a.g), d.execute(b, void 0, c))
    }

    function Ks(a, b) {
        if (a.F) {
            const c = a.Na.contentDocument ? .getElementById("prose-empty-serp-container");
            b && c && Tb(b, "input", () => {
                c.style.display = "none"
            })
        }
    }
    var Ls = class {
        constructor(a, b, c, d, e, f, g, h, k, l, m = !1, n = !1, p = !1) {
            this.Na = a;
            this.j = b;
            this.C = c;
            this.i = d;
            this.I = e;
            this.host = f.host;
            this.origin = f.origin;
            this.l = g;
            this.G = h;
            this.g = k;
            this.H = m;
            this.B = l;
            this.F = n;
            this.A = p
        }
        L() {
            this.Na.setAttribute("id", "prose-iframe");
            this.Na.setAttribute("width", "100%");
            this.Na.setAttribute("height", "100%");
            var a = uj `box-sizing:border-box;border:unset;`;
            this.Na.style.cssText = qd(a);
            a = "https://www.google.com/s2/favicons?sz=64&domain_url=" + encodeURIComponent(this.host);
            var b = De(a,
                Ce) || od;
            var c = Hs(this.host.startsWith("www.") ? this.host.slice(4) : this.host);
            a = this.C;
            var d = this.i,
                e = this.I;
            const f = this.host;
            c = this.G.replace("${website}", c);
            const g = this.F;
            var h = fs,
                k = "<style>.cse-favicon {display: block; float: left; height: 16px; position: absolute; left: 15px; width: 16px;}.cse-header {font-size: 16px; font-family: Arial; margin-left: 35px; margin-top: 6px; margin-bottom: unset; line-height: 16px;}.gsc-search-box {max-width: 520px !important;}.gsc-input {padding-right: 0 !important;}.gsc-input-box {border-radius: 16px 0 0 16px !important;}.gsc-search-button-v2 {border-left: 0 !important; border-radius: 0 16px 16px 0 !important; min-height: 30px !important; margin-left: 0 !important;}.gsc-cursor-page, .gsc-cursor-next-page, .gsc-cursor-numbered-page {color: #1a73e8 !important;}.gsc-cursor-chevron {fill: #1a73e8 !important;}.gsc-cursor-box {text-align: center !important;}.gsc-cursor-current-page {color: #000 !important;}.gcsc-find-more-on-google-root, .gcsc-find-more-on-google {display: none !important;}.prose-container {max-width: 652px;}#prose-empty-serp-container {display: flex; flex-direction: column; align-items: center; padding: 0; gap: 52px; position: relative; width: 248px; height: 259px; margin: auto; top: 100px;}#prose-empty-serp-icon-image {display: flex; flex-direction: row; justify-content: center; align-items: center; padding: 30px; gap: 10px; width: 124px; height: 124px; border-radius: 62px; flex: none; order: 1; flex-grow: 0; position: absolute; top: 0;}#prose-empty-serp-text-container {display: flex; flex-direction: column; align-items: center; padding: 0; gap: 19px; width: 248px; height: 83px; flex: none; order: 2; align-self: stretch; flex-grow: 0; position: absolute; top: 208px;}#prose-empty-serp-text-div {display: flex; flex-direction: column; align-items: flex-start; padding: 0; gap: 11px; width: 248px; height: 83px; flex: none; order: 0; align-self: stretch; flex-grow: 0;}#prose-empty-serp-supporting-text {width: 248px; height: 40px; font-family: 'Arial'; font-style: normal; font-weight: 400; font-size: 14px; line-height: 20px; text-align: center; letter-spacing: 0.2px; color: #202124; flex: none; order: 1; align-self: stretch; flex-grow: 0;}</style>" +
                (this.H ? '<script>window.__gcse={initializationCallback:function(){top.postMessage({action:"init",adChannel:"' + String(e).replace(ps, qs) + '"},top.location.origin);}};\x3c/script>' : "") + '<div class="prose-container"><img class="cse-favicon" src="';
            cs(b, Xr) || cs(b, Yr) ? b = String(b).replace(ys, vs) : b instanceof id ? b = String(jd(b)).replace(ys, vs) : b instanceof Zc ? b = String(bd(b).toString()).replace(ys, vs) : (b = String(b), b = zs.test(b) ? b.replace(ys, vs) : "about:invalid#zSoyz");
            a = h(k + js(b) + '" alt="' + js(f) + ' icon"><p class="cse-header"><strong>' +
                es(c) + '</strong></p><div class="gcse-search" data-gname="' + js(a) + '" data-adclient="' + js(d) + '" data-adchannel="' + js(e) + '" data-as_sitesearch="' + js(f) + '" data-personalizedAds="false"></div></div>' + (g ? "<div id=\"prose-empty-serp-container\"><img id='prose-empty-serp-icon-image' src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTI0IiBoZWlnaHQ9IjEyNCIgdmlld0JveD0iMCAwIDEyNCAxMjQiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIxMjQiIGhlaWdodD0iMTI0IiByeD0iNjIiIGZpbGw9IiNGMUYzRjQiLz4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik02OS4zNiA2NS4zODY3TDg0LjY0IDgwLjY2NjdMODAuNjY2NyA4NC42NEw2NS4zODY3IDY5LjM2QzYyLjUzMzMgNzEuNDEzMyA1OS4wOTMzIDcyLjY2NjcgNTUuMzMzMyA3Mi42NjY3QzQ1Ljc2IDcyLjY2NjcgMzggNjQuOTA2NyAzOCA1NS4zMzMzQzM4IDQ1Ljc2IDQ1Ljc2IDM4IDU1LjMzMzMgMzhDNjQuOTA2NyAzOCA3Mi42NjY3IDQ1Ljc2IDcyLjY2NjcgNTUuMzMzM0M3Mi42NjY3IDU5LjA5MzMgNzEuNDEzMyA2Mi41MzMzIDY5LjM2IDY1LjM4NjdaTTU1LjMzMzMgNDMuMzMzM0M0OC42OTMzIDQzLjMzMzMgNDMuMzMzMyA0OC42OTMzIDQzLjMzMzMgNTUuMzMzM0M0My4zMzMzIDYxLjk3MzMgNDguNjkzMyA2Ny4zMzMzIDU1LjMzMzMgNjcuMzMzM0M2MS45NzMzIDY3LjMzMzMgNjcuMzMzMyA2MS45NzMzIDY3LjMzMzMgNTUuMzMzM0M2Ny4zMzMzIDQ4LjY5MzMgNjEuOTczMyA0My4zMzMzIDU1LjMzMzMgNDMuMzMzM1oiIGZpbGw9IiM5QUEwQTYiLz4KPC9zdmc+Cg==' alt=''><div id='prose-empty-serp-text-container'><div id='prose-empty-serp-text-div'><div id='prose-empty-serp-supporting-text'>Search this website by entering a keyword.</div></div></div></div>" :
                    ""));
            a = as(a);
            this.B ? (a = this.Na, d = ed(new ub(vb, "https://www.gstatic.com/prose/protected/%{version}/iframe.html?cx=%{cxId}&host=%{host}&hl=%{lang}&lrh=%{lrh}&client=%{client}&origin=%{origin}"), {
                version: Is,
                cxId: this.j,
                host: this.host,
                lang: this.l,
                lrh: this.G,
                client: this.i,
                origin: this.origin
            }), a.src = bd(d).toString()) : (d = new Map([
                    ["cx", this.j],
                    ["language", this.l]
                ]), this.A && (e = Array.isArray(this.g) ? this.g : [this.g], e.length && d.set("fexp", e.join())), e = tj(d), d = {}, e = `<script src="${jj(bd(e).toString())}"`, d.async &&
                (e += " async"), d.di && (e += ` custom-element="${jj(d.di)}"`), d.defer && (e += " defer"), d.id && (e += ` id="${jj(d.id)}"`), d.nonce && (e += ` nonce="${jj(d.nonce)}"`), d.type && (e += ` type="${jj(d.type)}"`), d = Fd(e + ">\x3c/script>"), a = pj({
                    style: uj `margin:${0};`
                }, [a, d]), this.Na.srcdoc = Dd(a))
        }
    };

    function Ms(a) {
        var b = [];
        Jo(a.getElementsByTagName("p"), function(c) {
            100 <= Ns(c) && b.push(c)
        });
        return b
    }

    function Ns(a) {
        if (3 == a.nodeType) return a.length;
        if (1 != a.nodeType || "SCRIPT" == a.tagName) return 0;
        var b = 0;
        Jo(a.childNodes, function(c) {
            b += Ns(c)
        });
        return b
    }

    function Os(a) {
        return 0 == a.length || isNaN(a[0]) ? a : "\\" + (30 + parseInt(a[0], 10)) + " " + a.substring(1)
    }

    function Ps(a, b) {
        if (null == a.g) return b;
        switch (a.g) {
            case 1:
                return b.slice(1);
            case 2:
                return b.slice(0, b.length - 1);
            case 3:
                return b.slice(1, b.length - 1);
            case 0:
                return b;
            default:
                throw Error("Unknown ignore mode: " + a.g);
        }
    }
    const Qs = class {
        constructor(a, b, c, d) {
            this.l = a;
            this.i = b;
            this.j = c;
            this.g = d
        }
        query(a) {
            var b = [];
            try {
                b = a.querySelectorAll(this.l)
            } catch (f) {}
            if (!b.length) return [];
            a = hb(b);
            a = Ps(this, a);
            "number" === typeof this.i && (b = this.i, 0 > b && (b += a.length), a = 0 <= b && b < a.length ? [a[b]] : []);
            if ("number" === typeof this.j) {
                b = [];
                for (var c = 0; c < a.length; c++) {
                    var d = Ms(a[c]),
                        e = this.j;
                    0 > e && (e += d.length);
                    0 <= e && e < d.length && b.push(d[e])
                }
                a = b
            }
            return a
        }
        toString() {
            return JSON.stringify({
                nativeQuery: this.l,
                occurrenceIndex: this.i,
                paragraphIndex: this.j,
                ignoreMode: this.g
            })
        }
    };

    function Rs(a) {
        if (1 != a.nodeType) var b = !1;
        else if (b = "INS" == a.tagName) a: {
            b = ["adsbygoogle-placeholder"];a = a.className ? a.className.split(/\s+/) : [];
            for (var c = {}, d = 0; d < a.length; ++d) c[a[d]] = !0;
            for (d = 0; d < b.length; ++d)
                if (!c[b[d]]) {
                    b = !1;
                    break a
                }
            b = !0
        }
        return b
    }

    function Ss(a) {
        return Ko(a.querySelectorAll("ins.adsbygoogle-ablated-ad-slot"))
    };
    var Ts = new t(1310, !0),
        Us = new t(1277, !0),
        Vs = new t(1308, !0),
        Ws = new t(1275, !0),
        Xs = new t(1311, !0),
        Ys = new Ab(1130, 100),
        Zs = new t(1270, !0),
        $s = new Ab(1032, 200),
        at = new Bb(14),
        bt = new Ab(1224, .01),
        ct = new t(1260),
        dt = new t(1239),
        et = new t(1196),
        ft = new t(1160),
        gt = new t(316),
        ht = new t(1290),
        it = new t(1312),
        jt = new t(334),
        kt = new Ab(1263, -1),
        lt = new Ab(54),
        mt = new Ab(1265, -1),
        nt = new Ab(1264, -1),
        ot = new t(1291),
        pt = new t(1267, !0),
        qt = new t(1268, !0),
        rt = new t(1266),
        st = new t(313),
        tt = new Ab(66, -1),
        ut = new Ab(65, -1),
        vt = new t(1256),
        wt = new t(369),
        xt = new t(1241, !0),
        yt = new t(368),
        zt = new t(1300, !0),
        At = new Cb(1273, ["en", "de"]),
        Bt = new t(1223, !0),
        Ct = new Cb(1261, ["44786015", "44786016"]),
        Dt = new t(1309),
        Et = new t(1289),
        Ft = new t(1282),
        Gt = new t(1250),
        Ht = new t(1151),
        It = new Ab(1072, .75),
        Jt = new t(290),
        Kt = new t(1222),
        Lt = new t(1238),
        Mt = new t(1237),
        Nt = new Bb(1307),
        Ot = new Ab(572636916, 25),
        Pt = new Ab(595730437),
        Qt = new Ab(579884443),
        Rt = new Ab(566560958, 3E4),
        St = new Ab(508040914, 100),
        Tt = new Ab(547455356, 49),
        Ut = new t(595118933),
        Vt = new t(566279275),
        Wt =
        new t(566279276),
        Xt = new t(583331697, !0),
        Yt = new t(595118932),
        Zt = new Cb(556791602, ["1", "2", "4", "6"]),
        $t = new t(45614877),
        au = new t(561639568, !0),
        bu = new t(566560957),
        cu = new Bb(589752731),
        du = new Bb(589752730),
        eu = new t(579884441),
        fu = new Ab(571329679),
        gu = new t(556739145),
        hu = new Ab(572636915, 150),
        iu = new Ab(579884442),
        ju = new Ab(595645509, .3),
        ku = new Ab(561668774, .1),
        lu = new t(598587325),
        mu = new t(554474127),
        nu = new t(550910941),
        ou = new t(506914611),
        pu = new t(597181299),
        qu = new t(598633105),
        ru = new t(595989603),
        su =
        new Ab(469675170, 3E4),
        tu = new t(160889229),
        uu = new t(506852289),
        vu = new t(1120),
        wu = new t(597181300),
        xu = new t(586386407, !0),
        yu = new t(573506525, !0),
        zu = new t(573506524, !0),
        Au = new t(562896595),
        Bu = new t(586643641, !0),
        Cu = new Ab(592337179),
        Du = new t(570863962, !0),
        Eu = new Bb(570879859, "control_1.d"),
        Fu = new Ab(570863961, 50),
        Gu = new t(570879858, !0),
        Hu = new t(570804360),
        Iu = new Bb(1166),
        Ju = new t(1E4),
        Ku = new t(562874197),
        Lu = new t(562874196),
        Mu = new t(555237685, !0),
        Nu = new t(45460956),
        Ou = new t(45414947, !0),
        Pu = new Ab(472785970,
            500),
        Qu = new t(45545710),
        Ru = new t(439828594),
        Su = new t(483962503),
        Tu = new t(506738118),
        Uu = new t(77),
        Vu = new t(78),
        Wu = new t(83),
        Xu = new t(80),
        Yu = new t(76),
        Zu = new t(84),
        $u = new t(1973),
        av = new t(188),
        bv = new t(485990406);

    function cv(a, b) {
        a = se(new fe(a), "DIV");
        const c = a.style;
        c.width = "100%";
        c.height = "auto";
        c.clear = b ? "both" : "none";
        return a
    }

    function dv(a, b, c) {
        switch (c) {
            case 0:
                b.parentNode && b.parentNode.insertBefore(a, b);
                break;
            case 3:
                if (c = b.parentNode) {
                    var d = b.nextSibling;
                    if (d && d.parentNode != c)
                        for (; d && 8 == d.nodeType;) d = d.nextSibling;
                    c.insertBefore(a, d)
                }
                break;
            case 1:
                b.insertBefore(a, b.firstChild);
                break;
            case 2:
                b.appendChild(a)
        }
        Rs(b) && (b.setAttribute("data-init-display", b.style.display), b.style.display = "block")
    }

    function ev(a) {
        if (a && a.parentNode) {
            const b = a.parentNode;
            b.removeChild(a);
            Rs(b) && (b.style.display = b.getAttribute("data-init-display") || "none")
        }
    };
    var gv = (a, b, c, d = 0) => {
            var e = fv(b, c, d);
            if (e.L) {
                for (c = b = e.L; c = e.ud(c);) b = c;
                e = {
                    anchor: b,
                    position: e.Ld
                }
            } else e = {
                anchor: b,
                position: c
            };
            a["google-ama-order-assurance"] = d;
            dv(a, e.anchor, e.position)
        },
        hv = (a, b, c, d = 0) => {
            v(st) ? gv(a, b, c, d) : dv(a, b, c)
        };

    function fv(a, b, c) {
        const d = f => {
                f = iv(f);
                return null == f ? !1 : c < f
            },
            e = f => {
                f = iv(f);
                return null == f ? !1 : c > f
            };
        switch (b) {
            case 0:
                return {
                    L: jv(a.previousSibling, d),
                    ud: f => jv(f.previousSibling, d),
                    Ld: 0
                };
            case 2:
                return {
                    L: jv(a.lastChild, d),
                    ud: f => jv(f.previousSibling, d),
                    Ld: 0
                };
            case 3:
                return {
                    L: jv(a.nextSibling, e),
                    ud: f => jv(f.nextSibling, e),
                    Ld: 3
                };
            case 1:
                return {
                    L: jv(a.firstChild, e),
                    ud: f => jv(f.nextSibling, e),
                    Ld: 3
                }
        }
        throw Error("Un-handled RelativePosition: " + b);
    }

    function iv(a) {
        return a.hasOwnProperty("google-ama-order-assurance") ? a["google-ama-order-assurance"] : null
    }

    function jv(a, b) {
        return a && b(a) ? a : null
    };
    var kv = (a, b) => {
            try {
                const c = b.document.documentElement.getBoundingClientRect(),
                    d = a.getBoundingClientRect();
                return {
                    x: d.left - c.left,
                    y: d.top - c.top
                }
            } catch (c) {
                return null
            }
        },
        lv = (a, b) => {
            const c = 40 === a.google_reactive_ad_format,
                d = 16 === a.google_reactive_ad_format;
            return !!a.google_ad_resizable && (!a.google_reactive_ad_format || c) && !d && !!b.navigator && /iPhone|iPod|iPad|Android|BlackBerry/.test(b.navigator.userAgent) && b === b.top
        },
        mv = (a, b, c) => {
            a = a.style;
            "rtl" == b ? a.marginRight = c : a.marginLeft = c
        };
    const nv = (a, b, c) => {
        a = kv(b, a);
        return "rtl" == c ? -a.x : a.x
    };
    var ov = (a, b) => {
            b = b.parentElement;
            return b ? (a = Ye(b, a)) ? a.direction : "" : ""
        },
        pv = (a, b, c) => {
            if (0 !== nv(a, b, c)) {
                mv(b, c, "0px");
                var d = nv(a, b, c);
                mv(b, c, -1 * d + "px");
                a = nv(a, b, c);
                0 !== a && a !== d && mv(b, c, d / (a - d) * d + "px")
            }
        };
    const qv = RegExp("(^| )adsbygoogle($| )");

    function rv(a, b) {
        for (let c = 0; c < b.length; c++) {
            const d = b[c],
                e = ce(d.property);
            a[e] = d.value
        }
    }

    function sv(a, b, c, d, e, f) {
        a = tv(a, e);
        a.wa.setAttribute("data-ad-format", d ? d : "auto");
        uv(a, b, c, f);
        return a
    }

    function vv(a, b, c = null) {
        a = tv(a, {});
        uv(a, b, null, c);
        return a
    }

    function uv(a, b, c, d) {
        var e = [];
        if (d = d && d.Sf) a.pb.className = d.join(" ");
        a = a.wa;
        a.className = "adsbygoogle";
        a.setAttribute("data-ad-client", b);
        c && a.setAttribute("data-ad-slot", c);
        e.length && a.setAttribute("data-ad-channel", e.join("+"))
    }

    function tv(a, b) {
        const c = cv(a, b.clearBoth || !1);
        var d = c.style;
        d.textAlign = "center";
        b.Kd && rv(d, b.Kd);
        a = se(new fe(a), "INS");
        d = a.style;
        d.display = "block";
        d.margin = "auto";
        d.backgroundColor = "transparent";
        b.uf && (d.marginTop = b.uf);
        b.ke && (d.marginBottom = b.ke);
        b.kc && rv(d, b.kc);
        c.appendChild(a);
        return {
            pb: c,
            wa: a
        }
    }

    function wv(a, b, c) {
        b.dataset.adsbygoogleStatus = "reserved";
        b.className += " adsbygoogle-noablate";
        const d = {
            element: b
        };
        c = c && c.Ac();
        if (b.hasAttribute("data-pub-vars")) {
            try {
                c = JSON.parse(b.getAttribute("data-pub-vars"))
            } catch (e) {
                return
            }
            b.removeAttribute("data-pub-vars")
        }
        c && (d.params = c);
        (a.adsbygoogle = a.adsbygoogle || []).push(d)
    }

    function xv(a) {
        const b = Ss(a.document);
        Va(b, function(c) {
            const d = yv(a, c);
            var e;
            if (e = d) {
                e = (e = kv(c, a)) ? e.y : 0;
                const f = T(a);
                e = !(e < f)
            }
            e && (c.setAttribute("data-pub-vars", JSON.stringify(d)), c.removeAttribute("height"), c.style.removeProperty("height"), c.removeAttribute("width"), c.style.removeProperty("width"), wv(a, c))
        })
    }

    function yv(a, b) {
        b = b.getAttribute("google_element_uid");
        a = a.google_sv_map;
        if (!b || !a || !a[b]) return null;
        a = a[b];
        b = {};
        for (let c in sb) a[sb[c]] && (b[sb[c]] = a[sb[c]]);
        return b
    };
    class zv {
        constructor() {
            var a = sj `https://pagead2.googlesyndication.com/pagead/js/err_rep.js`;
            this.g = null;
            this.i = !1;
            this.A = Math.random();
            this.j = this.Ba;
            this.B = a
        }
        lf(a) {
            this.g = a
        }
        l(a) {
            this.i = a
        }
        Ba(a, b, c = .01, d, e = "jserror") {
            if ((this.i ? this.A : Math.random()) > c) return !1;
            b.error && b.meta && b.id || (b = new Vk(b, {
                context: a,
                id: e
            }));
            if (d || this.g) b.meta = {}, this.g && this.g(b.meta), d && d(b.meta);
            r.google_js_errors = r.google_js_errors || [];
            r.google_js_errors.push(b);
            r.error_rep_loaded || (We(r.document, this.B), r.error_rep_loaded = !0);
            return !1
        }
        Lc(a, b, c) {
            try {
                return b()
            } catch (d) {
                if (!this.j(a, d, .01, c, "jserror")) throw d;
            }
        }
        Oa(a, b, c, d) {
            return (...e) => this.Lc(a, () => b.apply(c, e), d)
        }
        Pa(a, b, c) {
            b.catch(d => {
                d = d ? d : "unknown rejection";
                this.Ba(a, d instanceof Error ? d : Error(d), void 0, c || this.g || void 0)
            })
        }
    };
    const Av = (a, b) => {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        2048 > b.length && b.push(a)
    };
    var Bv = (a, b, c, d, e = !1) => {
            const f = d || window,
                g = "undefined" !== typeof queueMicrotask;
            return function() {
                e && g && queueMicrotask(() => {
                    f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1;
                    f.google_rum_task_id_counter += 1
                });
                const h = bl();
                let k, l = 3;
                try {
                    k = b.apply(this, arguments)
                } catch (m) {
                    l = 13;
                    if (!c) throw m;
                    c(a, m)
                } finally {
                    f.google_measure_js_timing && h && Av({
                        label: a.toString(),
                        value: h,
                        duration: (bl() || 0) - h,
                        type: l,
                        ...(e && g && {
                            taskId: f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1
                        })
                    }, f)
                }
                return k
            }
        },
        Cv = (a, b, c, d = !1) => Bv(a, b, (e, f) => {
            (new zv).Ba(e, f)
        }, c, d);

    function Dv(a, b, c) {
        return Bv(a, b, void 0, c, !0).apply()
    }

    function Ev(a, b) {
        return Cv(754, a, b, !0).apply()
    }

    function Fv(a) {
        if (!a) return null;
        var b = L(a, 7);
        if (L(a, 1) || a.getId() || 0 < bi(a, 4, vh, 2).length) {
            var c = L(a, 3),
                d = L(a, 1),
                e = bi(a, 4, vh, 2);
            b = ui(a, 2);
            var f = ui(a, 5);
            a = Gv(M(a, 6));
            var g = "";
            d && (g += d);
            c && (g += "#" + Os(c));
            if (e)
                for (c = 0; c < e.length; c++) g += "." + Os(e[c]);
            b = (e = g) ? new Qs(e, b, f, a) : null
        } else b = b ? new Qs(b, ui(a, 2), ui(a, 5), Gv(M(a, 6))) : null;
        return b
    }
    var Hv = {
        1: 1,
        2: 2,
        3: 3,
        0: 0
    };

    function Gv(a) {
        return null == a ? a : Hv[a]
    }

    function Iv(a) {
        for (var b = [], c = 0; c < a.length; c++) {
            var d = L(a[c], 1),
                e = L(a[c], 2);
            if (d && null != e) {
                var f = {};
                f.property = d;
                f.value = e;
                b.push(f)
            }
        }
        return b
    }

    function Jv(a, b) {
        var c = {};
        a && (c.uf = L(a, 1), c.ke = L(a, 2), c.clearBoth = !!ai(a, 3));
        b && (c.Kd = Iv(D(b, lr, 3)), a = D(b, lr, 4), c.kc = Iv(a));
        return c
    }
    var Kv = {
            1: 0,
            2: 1,
            3: 2,
            4: 3
        },
        Lv = {
            0: 1,
            1: 2,
            2: 3,
            3: 4
        };
    const Mv = ["-webkit-text-fill-color"];

    function Nv(a) {
        if (Cc) {
            {
                const c = Ye(a.document.body, a);
                if (c) {
                    a = {};
                    var b = c.length;
                    for (let d = 0; d < b; ++d) a[c[d]] = "initial";
                    a = Ov(a)
                } else a = Pv()
            }
        } else a = Pv();
        return a
    }
    var Pv = () => {
        const a = {
            all: "initial"
        };
        Va(Mv, b => {
            a[b] = "unset"
        });
        return a
    };

    function Ov(a) {
        Va(Mv, b => {
            delete a[b]
        });
        return a
    };

    function Qv(a, b) {
        const c = a.document.createElement("div");
        A(c, Nv(a));
        a = c.attachShadow({
            mode: "open"
        });
        b && c.classList.add(b);
        return {
            Ua: c,
            shadowRoot: a
        }
    };

    function Rv({
        ic: a,
        Jb: b,
        Xb: c,
        jc: d,
        Kb: e,
        Yb: f
    }) {
        const g = [];
        for (let n = 0; n < f; n++)
            for (let p = 0; p < c; p++) {
                var h = p,
                    k = c - 1,
                    l = n,
                    m = f - 1;
                g.push({
                    x: a + (0 === k ? 0 : h / k) * (b - a),
                    y: d + (0 === m ? 0 : l / m) * (e - d)
                })
            }
        return g
    }

    function Sv(a, b) {
        a.hasOwnProperty("_goog_efp_called_") || (a._goog_efp_called_ = a.elementFromPoint(b.x, b.y));
        return a.elementFromPoint(b.x, b.y)
    };

    function Tv(a, b) {
        for (const c of b)
            if (b = Uv(a, c)) return b;
        return null
    }

    function Vv(a, {
        Si: b,
        Cj: c,
        width: d,
        height: e
    }) {
        b = Rv({
            ic: b,
            Jb: b + d,
            Xb: 10,
            jc: c,
            Kb: c + e,
            Yb: 10
        });
        return Tv(a, b)
    }

    function Wv(a, b) {
        var c = Rv({
            ic: b.left,
            Jb: b.right,
            Xb: 10,
            jc: b.top,
            Kb: b.bottom,
            Yb: 10
        });
        b = new Set;
        for (const d of c)(c = Uv(a, d)) && b.add(c);
        return b
    }

    function Xv(a, b, c) {
        if ("fixed" !== Bk(b, "position")) return null;
        var d = "GoogleActiveViewInnerContainer" === b.getAttribute("class") || 1 >= Ek(b).width && 1 >= Ek(b).height || a.g.oi && !a.g.oi(b) ? !0 : !1;
        a.g.hg && a.g.hg(b, c, d);
        return d ? null : b
    }

    function Uv(a, b) {
        var c = Sv(a.K.document, b);
        if (c) {
            var d;
            if (!(d = Xv(a, c, b))) a: {
                d = a.K.document;
                for (c = c.offsetParent; c && c !== d.body; c = c.offsetParent) {
                    const e = Xv(a, c, b);
                    if (e) {
                        d = e;
                        break a
                    }
                }
                d = null
            }
            a = d || null
        } else a = null;
        return a
    }
    var Yv = class {
        constructor(a, b = {}) {
            this.K = a;
            this.g = b
        }
    };

    function Zv(a) {
        a.google_reactive_ads_global_state ? (null == a.google_reactive_ads_global_state.sideRailProcessedFixedElements && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new Set), null == a.google_reactive_ads_global_state.sideRailAvailableSpace && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new Map), null == a.google_reactive_ads_global_state.sideRailPlasParam && (a.google_reactive_ads_global_state.sideRailPlasParam = new Map)) : a.google_reactive_ads_global_state = new $v;
        return a.google_reactive_ads_global_state
    }
    class $v {
        constructor() {
            this.wasPlaTagProcessed = !1;
            this.wasReactiveAdConfigReceived = {};
            this.adCount = {};
            this.wasReactiveAdVisible = {};
            this.stateForType = {};
            this.reactiveTypeEnabledInAsfe = {};
            this.wasReactiveTagRequestSent = !1;
            this.reactiveTypeDisabledByPublisher = {};
            this.tagSpecificState = {};
            this.messageValidationEnabled = !1;
            this.floatingAdsStacking = new aw;
            this.sideRailProcessedFixedElements = new Set;
            this.sideRailAvailableSpace = new Map;
            this.sideRailPlasParam = new Map
        }
    }
    var aw = class {
        constructor() {
            this.maxZIndexRestrictions = {};
            this.nextRestrictionId = 0;
            this.maxZIndexListeners = []
        }
    };

    function bw(a, b) {
        return new cw(a, b)
    }

    function dw(a) {
        const b = ew(a);
        Va(a.g.maxZIndexListeners, c => c(b))
    }

    function ew(a) {
        a = af(a.g.maxZIndexRestrictions);
        return a.length ? Math.min.apply(null, a) : null
    }

    function fw(a, b) {
        fb(a.g.maxZIndexListeners, c => c === b)
    }
    class gw {
        constructor(a) {
            this.g = Zv(a).floatingAdsStacking
        }
    }

    function hw(a) {
        if (null == a.g) {
            var b = a.i,
                c = a.j;
            const d = b.g.nextRestrictionId++;
            b.g.maxZIndexRestrictions[d] = c;
            dw(b);
            a.g = d
        }
    }

    function iw(a) {
        if (null != a.g) {
            var b = a.i;
            delete b.g.maxZIndexRestrictions[a.g];
            dw(b);
            a.g = null
        }
    }
    class cw {
        constructor(a, b) {
            this.i = a;
            this.j = b;
            this.g = null
        }
    };

    function jw(a) {
        a = a.activeElement;
        const b = a ? .shadowRoot;
        return b ? jw(b) || a : a
    }

    function kw(a, b) {
        return lw(b, a.document.body).flatMap(c => mw(c))
    }

    function lw(a, b) {
        var c = a;
        for (a = []; c && c !== b;) {
            a.push(c);
            let e;
            var d;
            (d = c.parentElement) || (c = c.getRootNode(), d = (null == (e = c.mode && c.host ? c : null) ? void 0 : e.host) || null);
            c = d
        }
        return c !== b ? [] : a
    }

    function mw(a) {
        const b = a.parentElement;
        return b ? Array.from(b.children).filter(c => c !== a) : []
    };

    function nw(a) {
        null !== a.g && (a.g.si.forEach(b => {
            b.inert = !1
        }), a.g.lj ? .focus(), a.g = null)
    }

    function ow(a, b) {
        nw(a);
        const c = jw(a.win.document);
        b = kw(a.win, b).filter(d => !d.inert);
        b.forEach(d => {
            d.inert = !0
        });
        a.g = {
            lj: c,
            si: b
        }
    }
    var pw = class {
        constructor(a) {
            this.win = a;
            this.g = null
        }
        Vd() {
            nw(this)
        }
    };

    function qw(a) {
        return new rw(a, new bp(a, a.document.body), new bp(a, a.document.documentElement), new bp(a, a.document.documentElement))
    }

    function sw(a) {
        ap(a.j, "scroll-behavior", "auto");
        const b = tw(a.win);
        b.activePageScrollPreventers.add(a);
        null === b.previousWindowScroll && (b.previousWindowScroll = a.win.scrollY);
        ap(a.g, "position", "fixed");
        ap(a.g, "top", `${-b.previousWindowScroll}px`);
        ap(a.g, "width", "100%");
        ap(a.g, "overflow-x", "hidden");
        ap(a.g, "overflow-y", "hidden");
        ap(a.i, "overflow-x", "hidden");
        ap(a.i, "overflow-y", "hidden")
    }

    function gx(a) {
        $o(a.g);
        $o(a.i);
        const b = tw(a.win);
        b.activePageScrollPreventers.delete(a);
        0 === b.activePageScrollPreventers.size && (a.win.scrollTo(0, b.previousWindowScroll || 0), b.previousWindowScroll = null);
        $o(a.j)
    }
    var rw = class {
        constructor(a, b, c, d) {
            this.win = a;
            this.g = b;
            this.i = c;
            this.j = d
        }
    };

    function tw(a) {
        return a.googPageScrollPreventerInfo = a.googPageScrollPreventerInfo || {
            previousWindowScroll: null,
            activePageScrollPreventers: new Set
        }
    }

    function hx(a) {
        return a.googPageScrollPreventerInfo && 0 < a.googPageScrollPreventerInfo.activePageScrollPreventers.size ? !0 : !1
    };

    function ix(a, b) {
        return jx(`#${a}`, b)
    }

    function kx(a, b) {
        return jx(`.${a}`, b)
    }

    function jx(a, b) {
        b = b.querySelector(a);
        if (!b) throw Error(`Element (${a}) does not exist`);
        return b
    };

    function lx(a, b) {
        b = Qv(a, b);
        a.document.body.appendChild(b.Ua);
        return b
    }

    function mx(a, b) {
        const c = new V(b.M);
        jp(b, !0, () => void c.g(!0));
        jp(b, !1, () => {
            a.setTimeout(() => {
                b.M || c.g(!1)
            }, 700)
        });
        return fp(c)
    };

    function nx(a) {
        const b = a.wc;
        var c = a.Rd,
            d = a.vc;
        const e = a.lc,
            f = a.Of,
            g = a.ge,
            h = a.Ja;
        a = "<style>#hd-drawer-container {position: fixed; left: 0; top: 0; width: 100vw; height: 100%; overflow: hidden; z-index: " + X(a.zIndex) + "; pointer-events: none;}#hd-drawer-container.hd-revealed {pointer-events: auto;}#hd-modal-background {position: absolute; left: 0; bottom: 0; background-color: black; transition: opacity .5s ease-in-out; width: 100%; height: 100%; opacity: 0;}.hd-revealed > #hd-modal-background {opacity: 0.5;}#hd-drawer {position: absolute; top: 0; height: 100%; width: " +
            X(b) + "; background-color: white; display: flex; flex-direction: column; box-sizing: border-box; padding-bottom: ";
        c = c ? h ? 20 : 16 : 0;
        a += X(c) + "px; transition: transform " + X(g) + "s ease-in-out;" + (d ? "left: 0; border-top-right-radius: " + X(c) + "px; border-bottom-right-radius: " + X(c) + "px; transform: translateX(-100%);" : "right: 0; border-top-left-radius: " + X(c) + "px; border-bottom-left-radius: " + X(c) + "px; transform: translateX(100%);") + "}.hd-revealed > #hd-drawer {transform: translateY(0);}#hd-control-bar {" + (h ?
                "height: 24px;" : "padding: 5px;") + "}.hd-control-button {border: none; background: none; cursor: pointer;" + (h ? "" : "padding: 5px;") + "}#hd-back-arrow-button {" + (d ? "float: right;" : "float: left;") + "}#hd-close-button {" + (d ? "float: left;" : "float: right;") + '}#hd-content-container {flex-grow: 1; overflow: auto;}#hd-content-container::-webkit-scrollbar * {background: transparent;}.hd-hidden {visibility: hidden;}</style><div id="hd-drawer-container" class="hd-hidden" aria-modal="true" role="dialog" tabindex="0"><div id="hd-modal-background"></div><div id="hd-drawer"><div id="hd-control-bar"><button id="hd-back-arrow-button" class="hd-control-button hd-hidden" aria-label="' +
            js(f) + '">';
        d = h ? "#5F6368" : "#444746";
        a += '<svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" fill="' + js(d) + '"><path d="m12 20-8-8 8-8 1.425 1.4-5.6 5.6H20v2H7.825l5.6 5.6Z"/></svg></button><button id="hd-close-button" class="hd-control-button" aria-label="' + js(e) + '"><svg xmlns="http://www.w3.org/2000/svg" height="24" width="24" fill="' + js(d) + '"><path d="M6.4 19 5 17.6 10.6 12 5 6.4 6.4 5 12 10.6 17.6 5 19 6.4 13.4 12 19 17.6 17.6 19 12 13.4Z"/></svg></button></div><div id="hd-content-container"></div></div></div>';
        return fs(a)
    };

    function ox(a) {
        a = a.top;
        if (!a) return null;
        try {
            var b = a.history
        } catch (c) {
            b = null
        }
        b = b && b.pushState && "function" === typeof b.pushState ? b : null;
        if (!b) return null;
        if (a.googNavStack) return a.googNavStack;
        b = new px(a, b);
        b.L();
        return b ? a.googNavStack = b : null
    }

    function qx(a, b) {
        return b ? b.googNavStackId === a.j ? b : null : null
    }

    function rx(a, b) {
        for (let c = b.length - 1; 0 <= c; --c) {
            const d = 0 === c;
            a.K.requestAnimationFrame(() => void b[c].uj({
                isFinal: d
            }))
        }
    }

    function sx(a, b) {
        b = kb(a.stack, b, (c, d) => c - d.og.googNavStackStateId);
        if (0 <= b) return a.stack.splice(b, a.stack.length - b);
        b = -b - 1;
        return a.stack.splice(b, a.stack.length - b)
    }
    class px extends U {
        constructor(a, b) {
            super();
            this.K = a;
            this.g = b;
            this.stack = [];
            this.j = 1E9 * Math.random() >>> 0;
            this.A = 0;
            this.l = c => {
                (c = qx(this, c.state)) ? rx(this, sx(this, c.googNavStackStateId + .5)): rx(this, this.stack.splice(0, this.stack.length))
            }
        }
        pushEvent() {
            const a = {
                    googNavStackId: this.j,
                    googNavStackStateId: this.A++
                },
                b = new Promise(c => {
                    this.stack.push({
                        uj: c,
                        og: a
                    })
                });
            this.g.pushState(a, "");
            return {
                navigatedBack: b,
                triggerNavigateBack: () => {
                    const c = sx(this, a.googNavStackStateId);
                    var d;
                    if (d = 0 < c.length) {
                        d = c[0].og;
                        const e = qx(this, this.g.state);
                        d = e && e.googNavStackId === d.googNavStackId && e.googNavStackStateId === d.googNavStackStateId
                    }
                    d && this.g.go(-c.length);
                    rx(this, c)
                }
            }
        }
        L() {
            this.K.addEventListener("popstate", this.l)
        }
        i() {
            this.K.removeEventListener("popstate", this.l);
            super.i()
        }
    };

    function tx(a) {
        return (a = ox(a)) ? new ux(a) : null
    }

    function vx(a) {
        if (!a.g) {
            var {
                navigatedBack: b,
                triggerNavigateBack: c
            } = a.l.pushEvent();
            a.g = c;
            b.then(() => {
                a.g && !a.B && (a.g = null, pp(a.j))
            })
        }
    }
    var ux = class extends U {
        constructor(a) {
            super();
            this.l = a;
            this.j = new qp;
            this.g = null
        }
    };

    function wx(a, b, c) {
        var d = c.xe ? null : new pw(a);
        const e = bw(new gw(a), c.zIndex - 1);
        b = xx(a, b, c);
        d = new yx(a, b, d, c.ub, qw(a), e);
        d.L();
        (c.ld || void 0 === c.ld) && zx(d);
        c.rb && ((a = tx(a)) ? Ax(d, a, c.Ye) : c.Ye ? .(Error("Unable to create closeNavigator")));
        return d
    }

    function zx(a) {
        a.A = b => {
            "Escape" === b.key && a.g.M && a.collapse()
        };
        a.win.document.body.addEventListener("keydown", a.A)
    }

    function Ax(a, b, c) {
        jp(a.g, !0, () => {
            try {
                vx(b)
            } catch (d) {
                c ? .(d)
            }
        });
        jp(a.g, !1, () => {
            try {
                b.g && (b.g(), b.g = null)
            } catch (d) {
                c ? .(d)
            }
        });
        np(b.j).listen(() => void a.collapse());
        Yo(a, b)
    }

    function Bx(a) {
        if (a.B) throw Error("Accessing domItems after disposal");
        return a.C
    }

    function Cx(a) {
        a.win.setTimeout(() => {
            a.g.M && Bx(a).Ka.focus()
        }, 500)
    }

    function Dx(a) {
        const {
            Xe: b,
            Wh: c
        } = Bx(a);
        b.addEventListener("click", () => void a.collapse());
        c.addEventListener("click", () => void a.collapse())
    }

    function Ex(a) {
        jp(a.j, !1, () => {
            Bx(a).Ka.classList.add("hd-hidden")
        })
    }
    var yx = class extends U {
        constructor(a, b, c, d = !0, e, f) {
            super();
            this.win = a;
            this.C = b;
            this.l = c;
            this.ub = d;
            this.g = new V(!1);
            this.j = mx(a, this.g);
            jp(this.j, !0, () => {
                sw(e);
                hw(f)
            });
            jp(this.j, !1, () => {
                gx(e);
                iw(f)
            })
        }
        show({
            cg: a = !1
        } = {}) {
            if (this.B) throw Error("Cannot show drawer after disposal");
            Bx(this).Ka.classList.remove("hd-hidden");
            Wo(this.win);
            Bx(this).Ka.classList.add("hd-revealed");
            this.g.g(!0);
            this.l && (ow(this.l, Bx(this).gb.Ua), this.ub && Cx(this));
            a && jp(this.j, !1, () => {
                this.ma()
            })
        }
        collapse() {
            Bx(this).Ka.classList.remove("hd-revealed");
            this.g.g(!1);
            this.l ? .Vd()
        }
        isVisible() {
            return this.j
        }
        L() {
            Dx(this);
            Ex(this)
        }
        i() {
            this.A && this.win.document.body.removeEventListener("keydown", this.A);
            const a = this.C.gb.Ua,
                b = a.parentNode;
            b && b.removeChild(a);
            this.l ? .Vd();
            super.i()
        }
    };

    function xx(a, b, c) {
        const d = lx(a, c.ye),
            e = d.shadowRoot;
        e.appendChild(te(new fe(a.document), as(nx({
            wc: c.wc,
            Rd: c.Rd ? ? !0,
            vc: c.vc || !1,
            lc: c.lc,
            Of: c.Of || "",
            zIndex: c.zIndex,
            ge: .5,
            Ja: c.Ja || !1
        }))));
        const f = ix("hd-drawer-container", e);
        c.De ? .i(g => {
            f.setAttribute("aria-label", g)
        });
        c = ix("hd-content-container", e);
        c.appendChild(b);
        Wo(a);
        return {
            Ka: f,
            Xe: ix("hd-modal-background", e),
            re: c,
            Wh: ix("hd-close-button", e),
            Rn: ix("hd-back-arrow-button", e),
            gb: d
        }
    };

    function Fx(a) {
        const b = a.fj,
            c = a.Ai;
        var d = a.ge;
        const e = a.Ja;
        a = "<style>#ved-drawer-container {position:  fixed; left: 0; top: 0; width: 100vw; height: 100%; overflow: hidden; z-index: " + X(a.zIndex) + "; pointer-events: none;}#ved-drawer-container.ved-revealed {pointer-events: auto;}#ved-modal-background {position: absolute; left: 0; bottom: 0; background-color: black; transition: opacity .5s ease-in-out; width: 100%; height: 100%; opacity: 0;}.ved-revealed > #ved-modal-background {opacity: 0.5;}#ved-ui-revealer {position: absolute; left: 0; bottom: 0; width: 100%; height: " +
            X(c) + "%; transition: transform " + X(d) + "s ease-in-out; transform: translateY(100%);}#ved-ui-revealer.ved-no-animation {transition-property: none;}.ved-revealed > #ved-ui-revealer {transform: translateY(0);}#ved-scroller-container {position: absolute; left: 0; bottom: 0; width: 100%; height: 100%; clip-path: inset(0 0 -50px 0 round ";
        d = e ? 20 : 28;
        a += X(d) + "px);}#ved-scroller {position: relative; width: 100%; height: 100%; overflow-y: scroll; -ms-overflow-style: none; scrollbar-width: none; overflow-y: scroll; overscroll-behavior: none; scroll-snap-type: y mandatory;}#ved-scroller.ved-scrolling-paused {overflow: hidden;}#ved-scroller.ved-no-snap {scroll-snap-type: none;}#ved-scroller::-webkit-scrollbar {display: none;}#ved-scrolled-stack {width: 100%; height: 100%; overflow: visible;}#ved-scrolled-stack.ved-with-background {background-color: white;}.ved-snap-point-top {scroll-snap-align: start;}.ved-snap-point-bottom {scroll-snap-align: end;}#ved-fully-closed-anchor {height: " +
            X(b / c * 100) + "%;}.ved-with-background #ved-fully-closed-anchor {background-color: white;}#ved-partially-extended-anchor {height: " + X((c - b) / c * 100) + "%;}.ved-with-background #ved-partially-extended-anchor {background-color: white;}#ved-moving-handle-holder {scroll-snap-stop: always;}.ved-with-background #ved-moving-handle-holder {background-color: white;}#ved-fixed-handle-holder {position: absolute; left: 0; top: 0; width: 100%;}#ved-visible-scrolled-items {display: flex; flex-direction: column; min-height: " +
            X(b / c * 100) + "%;}#ved-content-background {width: 100%; flex-grow: 1; padding-top: 1px; margin-top: -1px; background-color: white;}#ved-content-sizer {overflow: hidden; width: 100%; height: 100%;}#ved-content-container {width: 100%;}#ved-over-scroll-block {display: flex; flex-direction: column; position: absolute; bottom: 0; left: 0; width: 100%; height: " + X(b / c * 100) + "%; pointer-events: none;}#ved-over-scroll-handle-spacer {height: " + X(80) + "px;}#ved-over-scroll-background {flex-grow: 1; background-color: white;}.ved-handle {align-items: flex-end; border-radius: " +
            X(d) + "px " + X(d) + "px 0 0; background: white; display: flex; height: " + X(30) + "px; justify-content: center; cursor: grab;}.ved-handle-icon {" + (e ? "background: #dadce0; width: 50px;" : "background: #747775; opacity: 0.4; width: 32px;") + 'border-radius: 2px; height: 4px; margin-bottom: 8px;}.ved-hidden {visibility: hidden;}</style><div id="ved-drawer-container" class="ved-hidden" aria-modal="true" role="dialog" tabindex="0"><div id="ved-modal-background"></div><div id="ved-ui-revealer"><div id="ved-over-scroll-block" class="ved-hidden"><div id=\'ved-over-scroll-handle-spacer\'></div><div id=\'ved-over-scroll-background\'></div></div><div id="ved-scroller-container"><div id="ved-scroller"><div id="ved-scrolled-stack"><div id="ved-fully-closed-anchor" class="ved-snap-point-top"></div><div id="ved-partially-extended-anchor" class="ved-snap-point-top"></div><div id="ved-visible-scrolled-items"><div id="ved-moving-handle-holder" class="ved-snap-point-top">' +
            Gx("ved-moving-handle") + '</div><div id="ved-content-background"><div id="ved-content-sizer" class="ved-snap-point-bottom"><div id="ved-content-container"></div></div></div></div></div></div></div><div id="ved-fixed-handle-holder" class="ved-hidden">' + Gx("ved-fixed-handle") + "</div></div></div>";
        return fs(a)
    }

    function Gx(a) {
        return fs('<div class="ved-handle" id="' + js(a) + '"><div class="ved-handle-icon"></div></div>')
    };

    function Hx(a) {
        return Ep(a.g).map(b => b ? Ix(a, b) : 0)
    }

    function Ix(a, b) {
        switch (a.direction) {
            case 0:
                return Jx(-b.wh);
            case 1:
                return Jx(-b.uh);
            default:
                throw Error(`Unhandled direction: ${a.direction}`);
        }
    }

    function Kx(a) {
        return Gp(a.g).map(b => Ix(a, b))
    }
    var Lx = class {
        constructor(a) {
            this.g = a;
            this.direction = 0
        }
    };

    function Jx(a) {
        return 0 === a ? 0 : a
    };

    function Y(a) {
        if (a.B) throw Error("Accessing domItems after disposal");
        return a.C
    }

    function Mx(a) {
        a.win.setTimeout(() => {
            a.g.M && Y(a).Ka.focus()
        }, 500)
    }

    function Nx(a) {
        Y(a).Ka.classList.remove("ved-hidden");
        Wo(a.win);
        const {
            qa: b,
            eb: c
        } = Y(a);
        c.getBoundingClientRect().top <= b.getBoundingClientRect().top || Ox(a);
        Y(a).Ka.classList.add("ved-revealed");
        a.g.g(!0);
        a.j && (ow(a.j, Y(a).gb.Ua), a.ub && Mx(a))
    }

    function Px(a) {
        return mx(a.win, a.g)
    }

    function Qx(a, b) {
        const c = new V(b());
        np(a.H).listen(() => void c.g(b()));
        return fp(c)
    }

    function Rx(a) {
        const {
            qa: b,
            Jd: c
        } = Y(a);
        return Qx(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top)
    }

    function Sx(a) {
        const {
            qa: b,
            Jd: c
        } = Y(a);
        return Qx(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top - 1)
    }

    function Tx(a) {
        const {
            qa: b
        } = Y(a);
        return Qx(a, () => b.scrollTop === b.scrollHeight - b.clientHeight)
    }

    function Ux(a) {
        return gp(Rx(a), Tx(a))
    }

    function Vx(a) {
        const {
            qa: b,
            eb: c
        } = Y(a);
        return Qx(a, () => c.getBoundingClientRect().top < b.getBoundingClientRect().top - 1)
    }

    function Ox(a) {
        Y(a).eb.classList.add("ved-snap-point-top");
        var b = Wx(a, Y(a).eb);
        Y(a).qa.scrollTop = b;
        Xx(a)
    }

    function Yx(a) {
        W(Rx(a), !0, () => {
            const {
                ig: b,
                Nc: c
            } = Y(a);
            b.classList.remove("ved-hidden");
            c.classList.add("ved-with-background")
        });
        W(Rx(a), !1, () => {
            const {
                ig: b,
                Nc: c
            } = Y(a);
            b.classList.add("ved-hidden");
            c.classList.remove("ved-with-background")
        })
    }

    function Zx(a) {
        const b = Lp(a.win, Y(a).re);
        Op(b).i(() => void $x(a));
        Yo(a, b)
    }

    function ay(a) {
        W(by(a), !0, () => {
            Y(a).Pg.classList.remove("ved-hidden")
        });
        W(by(a), !1, () => {
            Y(a).Pg.classList.add("ved-hidden")
        })
    }

    function cy(a) {
        const b = () => void pp(a.F),
            {
                Xe: c,
                eb: d,
                zi: e
            } = Y(a);
        c.addEventListener("click", b);
        d.addEventListener("click", b);
        e.addEventListener("click", b);
        jp(dy(a), !0, b)
    }

    function ey(a) {
        jp(Px(a), !1, () => {
            Ox(a);
            Y(a).Ka.classList.add("ved-hidden")
        })
    }

    function Xx(a) {
        ip(a.l, !1, () => void pp(a.H))
    }

    function $x(a) {
        if (!a.l.M) {
            var {
                Wf: b,
                re: c
            } = Y(a), d = c.getBoundingClientRect().height;
            d = Math.max(fy(a), d);
            a.l.g(!0);
            var e = gy(a);
            b.style.setProperty("height", `${d}px`);
            e();
            a.win.requestAnimationFrame(() => {
                a.win.requestAnimationFrame(() => {
                    a.l.g(!1)
                })
            })
        }
    }

    function by(a) {
        const {
            qa: b,
            eb: c
        } = Y(a);
        return Qx(a, () => c.getBoundingClientRect().top <= b.getBoundingClientRect().top)
    }

    function dy(a) {
        return ep(a.A.map(nq), hy(a))
    }

    function hy(a) {
        return Qx(a, () => 0 === Y(a).qa.scrollTop)
    }

    function Wx(a, b) {
        ({
            Nc: a
        } = Y(a));
        a = a.getBoundingClientRect().top;
        return b.getBoundingClientRect().top - a
    }

    function iy(a, b) {
        a.A.g(!0);
        const {
            Nc: c,
            qa: d
        } = Y(a);
        d.scrollTop = 0;
        d.classList.add("ved-scrolling-paused");
        c.style.setProperty("margin-top", `-${b}px`);
        return () => void jy(a, b)
    }

    function jy(a, b) {
        const {
            Nc: c,
            qa: d
        } = Y(a);
        c.style.removeProperty("margin-top");
        d.classList.remove("ved-scrolling-paused");
        Y(a).qa.scrollTop = b;
        Xx(a);
        a.A.g(!1)
    }

    function gy(a) {
        const b = Y(a).qa.scrollTop;
        iy(a, b);
        return () => void jy(a, b)
    }

    function fy(a) {
        const {
            qa: b,
            Jd: c,
            Wf: d,
            eb: e
        } = Y(a);
        a = b.getBoundingClientRect();
        const f = c.getBoundingClientRect();
        var g = d.getBoundingClientRect();
        const h = e.getBoundingClientRect();
        g = g.top - f.top;
        return Math.max(a.height - h.height - g, Math.min(a.height, a.bottom - f.top) - g)
    }
    var ky = class extends U {
        constructor(a, b, c, d, e = !0) {
            super();
            this.win = a;
            this.C = b;
            this.I = c;
            this.j = d;
            this.ub = e;
            this.F = new qp;
            this.H = new qp;
            this.g = new V(!1);
            this.A = new V(!1);
            this.l = new V(!1)
        }
        L() {
            Ox(this);
            Yx(this);
            Zx(this);
            ay(this);
            cy(this);
            ey(this);
            Y(this).qa.addEventListener("scroll", () => void Xx(this))
        }
        i() {
            const a = this.C.gb.Ua,
                b = a.parentNode;
            b && b.removeChild(a);
            this.j ? .Vd();
            super.i()
        }
    };

    function ly(a, b, c) {
        const d = lx(a, c.ye),
            e = d.shadowRoot;
        e.appendChild(te(new fe(a.document), as(Fx({
            fj: 100 * c.cf,
            Ai: 100 * c.He,
            zIndex: c.zIndex,
            ge: .5,
            Ja: c.Ja || !1
        }))));
        const f = ix("ved-drawer-container", e);
        c.De ? .i(g => {
            f.setAttribute("aria-label", g)
        });
        c = ix("ved-content-container", e);
        c.appendChild(b);
        Wo(a);
        return {
            Ka: f,
            Xe: ix("ved-modal-background", e),
            mh: ix("ved-ui-revealer", e),
            qa: ix("ved-scroller", e),
            Nc: ix("ved-scrolled-stack", e),
            zi: ix("ved-fully-closed-anchor", e),
            eb: ix("ved-partially-extended-anchor", e),
            Wf: ix("ved-content-sizer",
                e),
            re: c,
            Xn: ix("ved-moving-handle", e),
            Jd: ix("ved-moving-handle-holder", e),
            yi: ix("ved-fixed-handle", e),
            ig: ix("ved-fixed-handle-holder", e),
            Pg: ix("ved-over-scroll-block", e),
            gb: d
        }
    };

    function my(a, b, c) {
        var d = bw(new gw(a), c.zIndex - 1);
        b = ly(a, b, c);
        const e = c.xe ? null : new pw(a);
        var f = b.yi;
        f = new Hp(new yp(a, f), new vp(f));
        var g = f.g;
        g.A.addEventListener("mousedown", g.G);
        g.l.addEventListener("mouseup", g.B);
        g.l.addEventListener("mousemove", g.C, {
            passive: !1
        });
        g = f.i;
        g.i.addEventListener("touchstart", g.C);
        g.i.addEventListener("touchend", g.A);
        g.i.addEventListener("touchmove", g.B, {
            passive: !1
        });
        b = new ky(a, b, new Lx(f), e, c.ub);
        b.L();
        d = new ny(a, b, qw(a), d);
        Yo(d, b);
        d.L();
        c.rb && ((a = tx(a)) ? oy(d, a, c.Ye) :
            c.Ye ? .(Error("Unable to create closeNavigator")));
        return d
    }

    function oy(a, b, c) {
        jp(a.g.g, !0, () => {
            try {
                vx(b)
            } catch (d) {
                c ? .(d)
            }
        });
        jp(a.g.g, !1, () => {
            try {
                b.g && (b.g(), b.g = null)
            } catch (d) {
                c ? .(d)
            }
        });
        np(b.j).listen(() => void a.collapse());
        Yo(a, b)
    }

    function py(a) {
        jp(ep(Ux(a.g), Vx(a.g)), !0, () => {
            Y(a.g).eb.classList.remove("ved-snap-point-top")
        });
        W(Sx(a.g), !0, () => {
            Y(a.g).qa.classList.add("ved-no-snap")
        });
        W(Sx(a.g), !1, () => {
            Y(a.g).qa.classList.remove("ved-no-snap")
        });
        jp(Sx(a.g), !1, () => {
            var b = a.g;
            var c = Y(b).Jd;
            c = iy(b, Wx(b, c));
            b.win.setTimeout(c, 100)
        })
    }

    function qy(a) {
        const b = a.g.I;
        Hx(b).listen(c => {
            c = -c;
            if (0 < c) {
                const {
                    mh: d
                } = Y(a.g);
                d.classList.add("ved-no-animation");
                d.style.setProperty("transform", `translateY(${c}px)`)
            } else({
                mh: c
            } = Y(a.g)), c.classList.remove("ved-no-animation"), c.style.removeProperty("transform")
        });
        Kx(b).listen(c => {
            30 < -c && a.collapse()
        })
    }
    var ny = class extends U {
        constructor(a, b, c, d) {
            super();
            this.win = a;
            this.g = b;
            jp(Px(b), !0, () => {
                sw(c);
                hw(d)
            });
            jp(Px(b), !1, () => {
                gx(c);
                iw(d)
            })
        }
        show({
            cg: a = !1
        } = {}) {
            if (this.B) throw Error("Cannot show drawer after disposal");
            Nx(this.g);
            a && jp(Px(this.g), !1, () => {
                this.ma()
            })
        }
        collapse() {
            var a = this.g;
            Y(a).Ka.classList.remove("ved-revealed");
            a.g.g(!1);
            a.j ? .Vd()
        }
        isVisible() {
            return Px(this.g)
        }
        L() {
            np(this.g.F).listen(() => {
                this.collapse()
            });
            py(this);
            qy(this);
            Wo(this.win)
        }
    };
    var ry = class {
        constructor(a, b, c) {
            this.position = a;
            this.Cb = b;
            this.Le = c
        }
    };

    function sy(a, b) {
        this.start = a < b ? a : b;
        this.end = a < b ? b : a
    }
    sy.prototype.zc = function() {
        return this.end - this.start
    };

    function ty(a, b, c) {
        var d = T(a);
        d = new ry(b.dc.Ig(b.nb), b.Cb + 2 * b.nb, Math.min(d, b.Gd) - b.dc.rd() + 2 * b.nb);
        d = d.position.Xf(a, d.Cb, d.Le);
        var e = wo(a),
            f = T(a);
        c = uy(a, new hk(Ud(d.top, 0, f - 1), Ud(d.right, 0, e - 1), Ud(d.bottom, 0, f - 1), Ud(d.left, 0, e - 1)), c);
        f = vy(c);
        let g = d.top;
        e = [];
        for (let h = 0; h < f.length; h++) f[h].start > g && e.push(new sy(g, f[h].start)), g = f[h].end;
        g < d.bottom && e.push(new sy(g, d.bottom));
        a = T(a);
        d = [];
        for (f = e.length - 1; 0 <= f; f--) d.push(new sy(a - e[f].end, a - e[f].start));
        a: {
            for (const h of d)
                if (a = h.start + b.nb, a > b.dc.rd() +
                    b.Se ? a = null : (d = Math.min(h.end - b.nb, b.Gd) - a, a = d < b.Ve ? null : {
                        position: b.dc.th(a),
                        Hc: d
                    }), a) {
                    b = a;
                    break a
                }
            b = null
        }
        return {
            je: b,
            Qn: c
        }
    }

    function uy(a, b, c) {
        const d = Wv(new Yv(a), b);
        c.forEach(e => void d.delete(e));
        return d
    }

    function vy(a) {
        return Array.from(a).map(wy).sort((b, c) => b.start - c.start)
    }

    function wy(a) {
        a = a.getBoundingClientRect();
        return new sy(a.top, a.bottom)
    };

    function xy({
        ca: a,
        ta: b
    }) {
        return new yy(a, b)
    }
    var yy = class {
        constructor(a, b) {
            this.ca = a;
            this.ta = b
        }
        Ig(a) {
            return new yy(this.ca - a, this.ta - a)
        }
        Xf(a, b, c) {
            a = T(a) - this.ca - c;
            return new hk(a, this.ta + b, a + c, this.ta)
        }
        Lf(a) {
            a.bottom = `${this.ca}px`;
            a.left = `${this.ta}px`;
            a.right = ""
        }
        kg() {
            return 0
        }
        rd() {
            return this.ca
        }
        th(a) {
            return new yy(a, this.ta)
        }
    };

    function zy({
        ca: a,
        Ea: b
    }) {
        return new Ay(a, b)
    }
    var Ay = class {
        constructor(a, b) {
            this.ca = a;
            this.Ea = b
        }
        Ig(a) {
            return new Ay(this.ca - a, this.Ea - a)
        }
        Xf(a, b, c) {
            var d = wo(a);
            a = T(a) - this.ca - c;
            d = d - this.Ea - b;
            return new hk(a, d + b, a + c, d)
        }
        Lf(a) {
            a.bottom = `${this.ca}px`;
            a.right = `${this.Ea}px`;
            a.left = ""
        }
        kg() {
            return 1
        }
        rd() {
            return this.ca
        }
        th(a) {
            return new Ay(a, this.Ea)
        }
    };

    function By(a) {
        const b = a.ti,
            c = a.Yh,
            d = a.Rh,
            e = a.zj,
            f = a.Sh;
        a = a.Qh;
        return fs('<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Google+Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"/><link href="https://fonts.googleapis.com/css?family=Google+Sans+Text:400,500,700" rel="stylesheet"><style>.ft-styless-button {border: none; background: none; user-select: none; cursor: pointer; border-radius: ' + X(16) + "px;}.ft-container {position: fixed;}.ft-menu {position: absolute; bottom: 0; display: flex; flex-direction: column; justify-content: center; align-items: center; box-shadow: 0 4px 8px 3px rgba(60, 64, 67, 0.15), 0 1px 3px rgba(60, 64, 67, 0.3); min-height: " +
            X(d) + "px;}.ft-menu:not(.ft-multiple-buttons *) {transition: padding 0.25s 0.25s, margin 0.25s 0.25s, border-radius 0.25s 0.25s, background-color 0s 0.5s; padding: 0; margin: " + X(a) + "px; border-radius: " + X(16) + "px; background-color: rgba(255, 255, 255, 0);}.ft-multiple-buttons .ft-menu {transition: margin 0.25s, padding 0.25s, border-radius 0.25s 0.25s, background-color 0s; padding: " + X(a) + "px; margin: 0; border-radius: " + X(16 + a) + "px; background-color: rgba(255, 255, 255, 1);}.ft-left-pos .ft-menu {left: 0;}.ft-right-pos .ft-menu {right: 0;}.ft-container.ft-hidden {transition: opacity 0.25s, visibility 0.5s 0s; opacity: 0; visibility: hidden;}.ft-container:not(.ft-hidden) {transition: opacity 0.25s, bottom 0.5s ease; opacity: 1;}.google-symbols {font-size: 26px; color: #3c4043;}.ft-button-holder {display: flex; flex-direction: column; justify-content: center; align-items: center; padding: 0;}.ft-flip-vertically {transform: scaleY(-1);}.ft-expand-toggle {width: " +
            X(d) + "px; height: " + X(d) + "px;}.ft-collapsed .ft-expand-icon {transition: transform 0.25s; transform: rotate(180deg);}.ft-expand-icon:not(.ft-collapsed *) {transition: transform 0.25s; transform: rotate(0deg);}.ft-button {position: relative; height: " + X(d) + "px; margin-bottom: " + X(f) + "px; transform: margin 0.25s 0.25s;}.ft-button.ft-last-button {margin-bottom: 0;}.ft-button > button {position: relative; height: " + X(d) + "px; width: " + X(d) + "px; margin: 0; padding: 0; border: none;}.ft-button > button > * {position: relative;}.ft-button .ft-highlighter {position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); height: " +
            X(d - 6) + "px; width: " + X(d - 6) + "px; border-radius: " + X(d / 2) + "px; background-color: #d2e3fc; opacity: 0; transition: opacity 0.25s;}.ft-button.ft-highlighted .ft-highlighter {opacity: 1;}.ft-button-corner-info {display: none;}.ft-button.ft-show-corner-info .ft-button-corner-info {position: absolute; left: -5px; top: 4px; background: #b3261e; border: 1.5px solid #ffffff; box-shadow: 0 1px 2px rgba(60, 64, 67, 0.3), 0 1px 3px 1px rgba(60, 64, 67, 0.15); border-radius: 100px; color: ffffff; font-family: 'Google Sans Text'; font-style: normal; font-weight: 700; font-size: 11px; line-height: 14px; min-width: 16px; height: 16px; display: flex; flex-direction: row; justify-content: center; align-items: center;}.ft-separator {display: block; width: 100%; height: " +
            X(e) + "px;}.ft-separator > span {display: block; width: 28px; margin: 0 auto 10px auto; height: 0; border-bottom: 1px solid #dadce0;}.ft-expand-toggle-container {height: " + X(d) + "px;}.ft-hidden {transition: opacity 0.25s, visibility 0.5s 0s; opacity: 0; visibility: hidden;}:not(.ft-hidden) {transition: opacity 0.25s; opacity: 1;}.ft-collapsed .ft-collapsible, .ft-collapsible.ft-collapsed, .ft-expand-toggle-container.ft-collapsed {transition: opacity 0.25s, margin 0.25s 0.25s, height 0.25s 0.25s, overflow 0.25s 0s, visibility 1s 0s; height: 0; opacity: 0; overflow: hidden; visibility: hidden; margin: 0;}.ft-collapsible:not(.ft-collapsed *):not(.ft-collapsed), .ft-expand-toggle-container:not(.ft-collapsed) {transition: margin 0.25s, height 0.25s, opacity 0.25s 0.25s; opacity: 1;}.ft-symbol-font-load-test {position: fixed; left: -1000px; top: -1000px; font-size: 26px; visibility: hidden;}.ft-reg-bubble {position: absolute; bottom: 0; padding: 10px 10px 0 10px; background: #fff; box-shadow: 0 4px 8px 3px rgba(60, 64, 67, 0.15), 0 1px 3px rgba(60, 64, 67, 0.3); border-radius: " +
            X(16) + "px; max-width: calc(90vw - " + X(2 * d) + "px); width: 300px; height: 200px;}.ft-left-pos .ft-reg-bubble {left: " + X(d + 10 + a) + "px;}.ft-right-pos .ft-reg-bubble {right: " + X(d + 10 + a) + "px;}.ft-collapsed .ft-reg-bubble, .ft-reg-bubble.ft-collapsed {transition: width 0.25s ease-in 0.25s, height 0.25s ease-in 0.25s, opacity 0.05s linear 0.45s, overflow 0s 0.25s, visibility 0s 0.5s; width: 0; overflow: hidden; opacity: 0; visibility: hidden;}.ft-collapsed .ft-reg-bubble, .ft-reg-bubble.ft-no-messages {height: 0 !important;}.ft-reg-bubble:not(.ft-collapsed *):not(.ft-collapsed) {transition: width 0.25s ease-out, height 0.25s ease-out, opacity 0.05s linear;}.ft-reg-bubble-content {display: flex; flex-direction: row; max-width: calc(90vw - " +
            X(2 * d) + 'px); width: 300px;}.ft-collapsed .ft-reg-bubble-content {transition: opacity 0.25s; opacity: 0;}.ft-reg-bubble-content:not(.ft-collapsed *) {transition: opacity 0.25s 0.25s; opacity: 1;}.ft-reg-message-holder {flex-grow: 1; display: flex; flex-direction: column; height: auto;}.ft-reg-controls {flex-grow: 0; padding-left: 5px;}.ft-reg-bubble-close-icon {font-size: 16px;}.ft-reg-message {font-family: \'Google Sans Text\'; font-style: normal; font-weight: 400; font-size: 12px; line-height: 14px; padding-bottom: 5px; margin-bottom: 5px; border-bottom: 1px solid #dadce0;}.ft-reg-message:last-of-type {border-bottom: none;}.ft-reg-message-button {border: none; background: none; font-family: \'Google Sans Text\'; color: #0b57d0; font-weight: 500; font-size: 14px; line-height: 22px; cursor: pointer; margin: 0; padding: 0;}.ft-display-none {display: none;}</style><toolbar id="ft-floating-toolbar" class="ft-container ft-hidden"><div class="ft-menu"><div class="ft-button-holder"></div><div class="ft-separator ft-collapsible ft-collapsed"><span></span></div><div class="ft-bottom-button-holder"></div><div class="ft-expand-toggle-container"><button class="ft-expand-toggle ft-styless-button" aria-controls="ft-floating-toolbar" aria-label="' +
            js(b) + '"><span class="google-symbols ft-expand-icon" aria-hidden="true">expand_more</span></button></div></div><div id="ft-reg-bubble" class="ft-reg-bubble ft-collapsed ft-no-messages"><div class="ft-reg-bubble-content"><div class="ft-reg-message-holder"></div><div class="ft-reg-controls"><button class="ft-reg-bubble-close ft-styless-button" aria-controls="ft-reg-bubble" aria-label="' + js(c) + '"><span class="google-symbols ft-reg-bubble-close-icon" aria-hidden="true">close</span></button></div></div></div></toolbar><span inert class="ft-symbol-font-load-test"><span class="ft-symbol-reference google-symbols" aria-hidden="true">keyboard_double_arrow_right</span><span class="ft-text-reference" aria-hidden="true">keyboard_double_arrow_right</span></span>')
    }

    function Cy(a) {
        const b = a.googleIconName,
            c = a.backgroundColorCss,
            d = a.iconColorCss;
        return fs('<div class="ft-button ft-collapsible ft-collapsed ft-last-button"><button class="ft-styless-button" aria-label="' + js(a.ariaLabel) + '" style="background-color: ' + js(X(c)) + '"><span class="ft-highlighter"></span><span class="google-symbols" style="color: ' + js(X(d)) + '" aria-hidden="true">' + es(b) + '</span></button><span class="ft-button-corner-info"></span></div>')
    };
    const Dy = ["Google Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200", "Google Sans Text:400,500,700"];

    function Ey(a, b) {
        a = new Fy(a, b, Gy(a, b));
        a.L();
        return a
    }

    function Hy() {
        var {
            nc: a
        } = {
            nc: 2
        };
        return 1 < a ? 50 : 120
    }

    function Iy(a, b, c) {
        0 === Jy(a) && b.classList.remove("ft-collapsed");
        Ky(b, c);
        Wo(a.win);
        b.classList.remove("ft-collapsed");
        Ly(a);
        return () => void My(a, b, c)
    }

    function Ny(a) {
        0 === Oy(a.g.na.Hd).length ? (a.l.M ? .oj(), a.l.g(null), a.g.na.Ke.g(!1), a.g.na.ug.g(!1), a.g.na.Oe.g(!1)) : (a.g.na.Ke.g(!0), Py(a))
    }

    function Qy(a, {
        Bh: b = 0,
        Pn: c = 0
    }) {
        b = Math.max(Oy(a.g.Hb).length + b, 0);
        c = Math.max(Oy(a.g.mb).length + c, 0);
        const d = b + c;
        let e = 50 * d;
        0 < b && 0 < c && (e += 11);
        e += 10 * Math.max(0, d - 1);
        d >= a.j.nc && (e += 60);
        1 < d && (e += 10);
        return e
    }

    function Jy(a) {
        const b = a.g.mb;
        return Oy(a.g.Hb).length + Oy(b).length
    }

    function Ly(a) {
        const b = a.g.mb,
            c = a.g.separator;
        0 < Oy(a.g.Hb).length && 0 < Oy(b).length ? c.classList.remove("ft-collapsed") : c.classList.add("ft-collapsed");
        Jy(a) >= a.j.nc ? a.g.tg.g(!0) : a.g.tg.g(!1);
        1 < Jy(a) ? a.g.ng.g(!0) : a.g.ng.g(!1);
        0 < Jy(a) ? a.g.isVisible.g(!0) : a.g.isVisible.g(!1);
        Ry(a);
        Sy(a)
    }

    function My(a, b, c) {
        b.classList.contains("ft-removing") || (b.classList.add("ft-removing"), b.classList.add("ft-collapsed"), Ly(a), a.win.setTimeout(() => {
            c.removeChild(b)
        }, 750))
    }

    function Ry(a) {
        const b = Oy(a.g.Hb).concat(Oy(a.g.mb));
        b.forEach(c => {
            c.classList.remove("ft-last-button")
        });
        Jy(a) >= a.j.nc || b[b.length - 1] ? .classList.add("ft-last-button")
    }

    function Sy(a) {
        const b = Oy(a.g.Hb).concat(Oy(a.g.mb)).filter(c => !c.classList.contains("ft-reg-button"));
        a.F.g(0 < b.length)
    }

    function Ty(a) {
        Jo(a.g.na.Hd.children, b => {
            const c = a.g.na.Pd;
            My(a, b, a.g.na.Hd);
            const d = c.get(b);
            c.delete(b);
            d ? .isDismissed.g(!0)
        });
        Ny(a)
    }

    function Py(a) {
        if (!a.l.M) {
            var b = Uy(a.win, {
                googleIconName: "verified_user",
                ariaLabel: P(a.j.La, 2),
                orderingIndex: 0,
                onClick: () => {
                    a.g.na.ug.g(!a.g.na.isVisible.M);
                    for (const [, c] of a.g.na.Pd) c.xg = !0;
                    a.g.na.Oe.g(!1)
                },
                backgroundColorCss: "#fff"
            });
            b.Zc.classList.add("ft-reg-button");
            Iy(a, b.Zc, a.g.mb);
            kp(b.Pi, a.g.na.isVisible);
            a.l.g({
                Tn: b,
                oj: () => void My(a, b.Zc, a.g.mb)
            })
        }
    }

    function Vy(a) {
        var b = a.g.na.Oe,
            c = b.g;
        a: {
            for ([, d] of a.g.na.Pd)
                if (a = d, a.showUnlessUserInControl && !a.xg) {
                    var d = !0;
                    break a
                }
            d = !1
        }
        c.call(b, d)
    }

    function Wy(a) {
        a.g.na.Xh.listen(() => {
            Ty(a)
        })
    }
    var Fy = class extends U {
        constructor(a, b, c) {
            super();
            this.win = a;
            this.j = b;
            this.g = c;
            this.l = new V(null);
            this.F = new V(!1)
        }
        addButton(a) {
            a = Uy(this.win, a);
            return Iy(this, a.Zc, this.g.Hb)
        }
        addRegulatoryMessage(a) {
            const b = this.g.na.Hd,
                c = Xy(this.win, a);
            Ky(c.Cg, b);
            this.g.na.Pd.set(c.Cg, c);
            Ny(this);
            return {
                showUnlessUserInControl: () => {
                    c.showUnlessUserInControl = !0;
                    Vy(this)
                },
                hideUnlessUserInControl: () => {
                    c.showUnlessUserInControl = !1;
                    Vy(this)
                },
                isDismissed: mp(c.isDismissed)
            }
        }
        H() {
            return fp(this.l.map(a => null != a))
        }
        C() {
            return fp(this.F)
        }
        A() {
            return [this.g.container]
        }
        i() {
            const a =
                this.g.gb.Ua;
            a.parentNode ? .removeChild(a);
            super.i()
        }
        L() {
            Vp(this.win, Dy);
            kp(this.g.Fj, this.j.Ic);
            this.win.document.body.appendChild(this.g.gb.Ua);
            Wy(this)
        }
    };

    function Gy(a, b) {
        const c = Qv(a),
            d = c.shadowRoot;
        d.appendChild(te(new fe(a.document), as(By({
            ti: P(b.La, 1),
            Yh: P(b.La, 3),
            Rh: 50,
            zj: 11,
            Sh: 10,
            Qh: 5
        }))));
        const e = kx("ft-container", d),
            f = kx("ft-expand-toggle", d),
            g = kx("ft-expand-toggle-container", d),
            h = new V(null);
        h.i(p => {
            e.style.zIndex = String(p ? ? 2147483647)
        });
        const k = new V(!0);
        W(k, !0, () => {
            e.classList.remove("ft-collapsed");
            f.setAttribute("aria-expanded", "true")
        });
        W(k, !1, () => {
            e.classList.add("ft-collapsed");
            f.setAttribute("aria-expanded", "false")
        });
        f.addEventListener("click",
            () => {
                k.g(!k.M)
            });
        const l = new V(!1);
        W(l, !0, () => {
            g.classList.remove("ft-collapsed");
            e.classList.add("ft-toolbar-collapsible")
        });
        W(l, !1, () => {
            g.classList.add("ft-collapsed");
            e.classList.remove("ft-toolbar-collapsible");
            k.g(!0)
        });
        const m = new V(!1);
        W(m, !0, () => {
            e.classList.add("ft-multiple-buttons")
        });
        W(m, !1, () => {
            e.classList.remove("ft-multiple-buttons")
        });
        b.position.i(p => {
            if (p) {
                p.Lf(e.style);
                p = p.kg();
                switch (p) {
                    case 0:
                        e.classList.add("ft-left-pos");
                        e.classList.remove("ft-right-pos");
                        break;
                    case 1:
                        e.classList.add("ft-right-pos");
                        e.classList.remove("ft-left-pos");
                        break;
                    default:
                        throw Error(`Unknown HorizontalAnchoring: ${p}`);
                }
                Wo(a)
            }
        });
        const n = new V(!1);
        b = ep(Yy(a, d), n, b.position.map(p => null !== p));
        W(b, !0, () => {
            e.classList.remove("ft-hidden")
        });
        W(b, !1, () => {
            e.classList.add("ft-hidden")
        });
        b = Zy(a, kx("ft-reg-bubble", d));
        return {
            container: e,
            Hb: kx("ft-button-holder", d),
            mb: kx("ft-bottom-button-holder", d),
            separator: kx("ft-separator", d),
            gb: c,
            Fj: h,
            Wn: k,
            tg: l,
            ng: m,
            isVisible: n,
            na: b
        }
    }

    function Zy(a, b) {
        const c = new V(!1),
            d = new V(!1),
            e = gp(c, d);
        W(e, !0, () => {
            b.classList.remove("ft-collapsed")
        });
        W(e, !1, () => {
            b.classList.add("ft-collapsed")
        });
        const f = new V(!1);
        W(f, !0, () => {
            b.classList.remove("ft-no-messages")
        });
        W(f, !1, () => {
            b.classList.add("ft-no-messages")
        });
        const g = kx("ft-reg-bubble-close", b),
            h = new qp;
        g.addEventListener("click", () => {
            pp(h)
        });
        const k = kx("ft-reg-message-holder", b);
        Op(Lp(a, k)).i(() => {
            b.style.height = `${k.offsetHeight}px`
        });
        return {
            Hd: k,
            ug: c,
            Oe: d,
            isVisible: e,
            Ke: f,
            Pd: new Map,
            Xh: np(h)
        }
    }

    function Uy(a, b) {
        const c = te(new fe(a.document), as(Cy({
            googleIconName: b.googleIconName,
            ariaLabel: b.ariaLabel,
            backgroundColorCss: b.backgroundColorCss || "#e2eaf6",
            iconColorCss: b.iconColorCss || "#3c4043"
        })));
        if (void 0 !== b.cornerNumber) {
            const d = Ud(Math.round(b.cornerNumber), 0, 99);
            kx("ft-button-corner-info", c).appendChild(a.document.createTextNode(String(d)));
            c.classList.add("ft-show-corner-info")
        }
        c.orderingIndex = b.orderingIndex;
        b.onClick && jx("BUTTON", c).addEventListener("click", b.onClick);
        a = new V(!1);
        W(a, !0, () => {
            c.classList.add("ft-highlighted")
        });
        W(a, !1, () => {
            c.classList.remove("ft-highlighted")
        });
        return {
            Zc: c,
            Pi: a
        }
    }

    function Xy(a, b) {
        a = new fe(a.document);
        var c = fs('<div class="ft-reg-message"><button class="ft-reg-message-button"></button><div class="ft-reg-message-info"></div></div>');
        a = te(a, as(c));
        c = kx("ft-reg-message-button", a);
        b.regulatoryMessage.actionButton ? (c.appendChild(b.regulatoryMessage.actionButton.buttonText), c.addEventListener("click", b.regulatoryMessage.actionButton.onClick)) : c.classList.add("ft-display-none");
        c = kx("ft-reg-message-info", a);
        b.regulatoryMessage.informationText ? c.appendChild(b.regulatoryMessage.informationText) :
            c.classList.add("ft-display-none");
        a.orderingIndex = b.orderingIndex;
        return {
            Cg: a,
            showUnlessUserInControl: !1,
            xg: !1,
            isDismissed: new V(!1)
        }
    }

    function Ky(a, b) {
        a: {
            var c = Array.from(b.children);
            for (let d = 0; d < c.length; ++d)
                if (c[d].orderingIndex >= a.orderingIndex) {
                    c = d;
                    break a
                }
            c = c.length
        }
        b.insertBefore(a, b.childNodes[c] || null)
    }

    function Oy(a) {
        return Array.from(a.children).filter(b => !b.classList.contains("ft-removing"))
    }

    function Yy(a, b) {
        const c = new V(!1),
            d = kx("ft-symbol-font-load-test", b);
        b = kx("ft-symbol-reference", d);
        const e = kx("ft-text-reference", d),
            f = Lp(a, b);
        ip(Op(f).map(g => 0 < g.width && g.width < e.offsetWidth / 2), !0, () => {
            c.g(!0);
            d.parentNode ? .removeChild(d);
            f.ma()
        });
        return c
    };

    function $y(a) {
        const b = new qp,
            c = Bp(a, 2500, () => void pp(b));
        return new az(a, () => void bz(a, () => void c()), np(b))
    }

    function cz(a) {
        const b = new MutationObserver(() => {
            a.g()
        });
        b.observe(a.win.document.documentElement, {
            childList: !0,
            subtree: !0,
            attributes: !0,
            attributeFilter: ["class", "style"]
        });
        Zo(a, () => void b.disconnect())
    }

    function dz(a) {
        a.win.addEventListener("resize", a.g);
        Zo(a, () => void a.win.removeEventListener("resize", a.g))
    }
    var az = class extends U {
        constructor(a, b, c) {
            super();
            this.win = a;
            this.g = b;
            this.l = c;
            this.j = !1
        }
    };

    function bz(a, b) {
        b();
        a.setTimeout(b, 1500)
    };

    function ez(a) {
        return a.g[a.g.length - 1]
    }
    var gz = class {
        constructor() {
            this.j = fz;
            this.g = [];
            this.i = new Set
        }
        add(a) {
            if (this.i.has(a)) return !1;
            const b = kb(this.g, a, this.j);
            this.g.splice(0 <= b ? b : -b - 1, 0, a);
            this.i.add(a);
            return !0
        }
        first() {
            return this.g[0]
        }
        has(a) {
            return this.i.has(a)
        }
        delete(a) {
            fb(this.g, b => b === a);
            return this.i.delete(a)
        }
        clear() {
            this.i.clear();
            return this.g.splice(0, this.g.length)
        }
        size() {
            return this.g.length
        }
    };

    function hz(a) {
        var b = a.Hc.M;
        let c;
        for (; a.j.ci() > b && (c = a.i.first());) {
            var d = a,
                e = c;
            iz(d, e);
            d.g.add(e)
        }
        for (;
            (d = ez(a.g)) && a.j.Fi() <= b;) jz(a, d);
        for (;
            (d = ez(a.g)) && (c = a.i.first()) && d.priority > c.priority;) b = a, e = c, iz(b, e), b.g.add(e), jz(a, d)
    }

    function jz(a, b) {
        a.g.delete(b);
        a.i.add(b) && (b.vf = a.j.addButton(b.buttonSpec));
        b.isInToolbar.g(!0)
    }

    function iz(a, b) {
        b.vf && b.vf();
        b.vf = void 0;
        a.i.delete(b);
        b.isInToolbar.g(!1)
    }
    var kz = class {
        constructor(a, b) {
            this.Hc = a;
            this.j = b;
            this.g = new gz;
            this.i = new gz;
            this.l = 0;
            this.Hc.listen(() => void hz(this))
        }
        addButton(a) {
            const b = {
                buttonSpec: a.buttonSpec,
                priority: a.priority,
                Bf: this.l++,
                isInToolbar: new V(!1)
            };
            this.g.add(b);
            hz(this);
            return {
                isInToolbar: mp(fp(b.isInToolbar)),
                removeCallback: () => {
                    iz(this, b);
                    this.g.delete(b);
                    hz(this)
                }
            }
        }
    };

    function fz(a, b) {
        return a.priority === b.priority ? b.Bf - a.Bf : a.priority - b.priority
    };

    function lz(a) {
        a = new mz(a);
        a.L();
        return a
    }

    function nz(a) {
        if (!hx(a.win)) {
            if (a.j.M) {
                const b = Eo(a.win);
                if (b > a.g + 100 || b < a.g - 100) a.j.g(!1), a.g = yo(a.win)
            }
            a.l && a.win.clearTimeout(a.l);
            a.l = a.win.setTimeout(() => void oz(a), 200)
        }
    }

    function oz(a) {
        if (!hx(a.win)) {
            var b = yo(a.win);
            a.g && a.g > b && (a.g = b);
            b = Eo(a.win);
            b >= a.g - 100 && (a.g = Math.max(a.g, b), a.j.g(!0))
        }
    }
    var mz = class extends U {
        constructor(a) {
            super();
            this.win = a;
            this.j = new V(!1);
            this.g = 0;
            this.l = null;
            this.A = () => void nz(this)
        }
        L() {
            this.win.addEventListener("scroll", this.A);
            this.g = yo(this.win);
            oz(this)
        }
        i() {
            this.win.removeEventListener("scroll", this.A);
            this.j.g(!1);
            super.i()
        }
    };

    function pz(a) {
        if (!a.g) {
            const b = lz(a.win);
            a.g = fp(b.j);
            Yo(a, b)
        }
        return a.g
    }

    function qz(a, b) {
        const c = pz(a),
            d = a.j.addRegulatoryMessage(b.messageSpec),
            e = W(c, !0, () => void d.showUnlessUserInControl()),
            f = W(c, !1, () => void d.hideUnlessUserInControl());
        W(cp(d.isDismissed), !0, () => {
            e();
            f()
        })
    }
    var rz = class extends U {
        constructor(a, b) {
            super();
            this.win = a;
            this.j = b;
            this.g = null
        }
        addRegulatoryMessage(a) {
            ip(pz(this), !0, () => void qz(this, a))
        }
    };

    function sz(a, b) {
        a.googFloatingToolbarManager || (a.googFloatingToolbarManager = new tz(a, b));
        return a.googFloatingToolbarManager
    }

    function uz(a) {
        a.g || (a.g = vz(a.win, a.Lb, a.Ic), Yo(a, a.g.Mb), Yo(a, a.g.Xg), wz(a), xz(a, a.g.Mb));
        return a.g
    }

    function yz(a) {
        var b = [];
        a.g ? .Mb ? .C().A() ? (b.push(() => zz(a)), b.push(() => Az(a))) : (b.push(() => Az(a)), b.push(() => zz(a)));
        a.g ? .Mb ? .H() ? .A() && b.push(() => {
            const c = T(a.win);
            return {
                position: xy({
                    ca: Math.floor(c / 3),
                    ta: 10
                }),
                Hc: 0
            }
        });
        for (const c of b)
            if (b = c()) return b;
        return null
    }

    function wz(a) {
        null === a.Ic.M && a.g ? .position.g(yz(a))
    }

    function xz(a, b) {
        const c = $y(a.win);
        c.j || (cz(c), dz(c), c.j = !0);
        c.l.listen(() => void wz(a));
        Yo(a, c);
        b.H().listen(() => void wz(a));
        b.C().listen(() => void wz(a));
        a.Ic.listen(() => void wz(a))
    }

    function zz(a) {
        var b = a.win;
        const c = T(a.win);
        return ty(b, {
            dc: zy({
                ca: 50,
                Ea: 10
            }),
            Se: Math.floor(c / 3),
            Cb: 60,
            Ve: Hy(),
            Gd: Math.floor(c / 2),
            nb: 20
        }, [...(a.g ? .Mb.A() ? ? []), a.win.document.body]).je
    }

    function Az(a) {
        var b = a.win;
        const c = T(a.win);
        return ty(b, {
            dc: xy({
                ca: 50,
                ta: 10
            }),
            Se: Math.floor(c / 3),
            Cb: 60,
            Ve: Hy(),
            Gd: Math.floor(c / 2),
            nb: 40
        }, [...(a.g ? .Mb.A() ? ? []), a.win.document.body]).je
    }
    class tz extends U {
        constructor(a, b) {
            super();
            this.win = a;
            this.Lb = b;
            this.g = null;
            this.Ic = Bz(this.win, this)
        }
        addButton(a) {
            return uz(this).aj.addButton(a)
        }
        addRegulatoryMessage(a) {
            uz(this).Xg.addRegulatoryMessage(a)
        }
    }

    function vz(a, b, c) {
        const d = new V(null),
            e = Ey(a, {
                nc: 2,
                position: d.map(f => f ? .position ? ? null),
                La: b,
                Ic: c
            });
        b = new kz(d.map(f => f ? .Hc || 0), {
            addButton: f => e.addButton(f),
            ci: () => Qy(e, {}),
            Fi: () => Qy(e, {
                Bh: 1
            })
        });
        a = new rz(a, {
            addRegulatoryMessage: f => e.addRegulatoryMessage(f)
        });
        return {
            Mb: e,
            position: d,
            aj: b,
            Xg: a
        }
    }

    function Bz(a, b) {
        const c = new gw(a),
            d = new V(null),
            e = f => void d.g(f);
        Zo(b, () => {
            fw(c, e)
        });
        c.g.maxZIndexListeners.push(e);
        d.g(ew(c));
        return d
    };

    function Cz(a) {
        return sz(a.win, a.La)
    }
    var Dz = class {
        constructor(a, b) {
            this.win = a;
            this.La = b
        }
    };

    function Ez(a) {
        if (a.H) {
            var b = Cz(new Dz(a.g, a.H)).addButton({
                buttonSpec: {
                    googleIconName: "search",
                    ariaLabel: a.Ha,
                    orderingIndex: 0,
                    onClick: () => {
                        Fz(a)
                    }
                },
                priority: 0
            });
            ip(cp(b.isInToolbar), !0, () => {
                Gz(a)
            });
            a.g.setTimeout(() => {
                b.isInToolbar.getValue() || Tr(a.j, "pfmsb")
            }, 5E3);
            Hz(a)
        } else Iz(a)
    }

    function Iz(a) {
        var b = Jz(a);
        b = Vv(new Yv(a.g), b);
        b ? .className.startsWith("adsbygoogle") ? Tr(a.j, "pfeaa") : b ? Tr(a.j, "pfeofe") : (a.Z.appendChild(a.B.Ua), a.B.shadowRoot.appendChild(le(document, (() => {
            if (a.l) {
                var c = Kz(a),
                    d = {
                        backgroundColor: c.backgroundColor,
                        Pb: c.Pb,
                        offsetTop: c.Lg,
                        Ze: c.Kg,
                        zIndex: 2147483643
                    };
                c = d.zIndex;
                var e = d.bj,
                    f = d.offsetTop,
                    g = d.Ze,
                    h = d.backgroundColor;
                d = d.Pb;
                e = void 0 === e ? 16 : e;
                g = void 0 === g ? 2 : g;
                d = void 0 === d ? "white" : d;
                h = "<style>.autoprose-search-button {background: " + X(void 0 === h ? "#000" : h) + "; border-radius: ";
                h += X(24) + "px;" + (f ? "top: " + X(f) + "%;" : "bottom: " + X(g) + "%;") + "border-width: 0; box-shadow: 0 0 10px rgba(0, 0, 0, 0.35); cursor: pointer; height: " + X(48) + "px; position: fixed; right: " + X(e) + "px; width: 48px; z-index: " + X(c) + ';}.autoprose-search-icon {position: relative;}</style><button class="autoprose-search-button"><div class="autoprose-search-icon">' + As(d) + "</div></button>";
                c = fs(h);
                return as(c)
            }
            c = Kz(a);
            var k = {
                yj: c.xj,
                backgroundColor: c.backgroundColor,
                Pb: c.Pb,
                offsetTop: c.Lg,
                Ze: c.Kg,
                zIndex: 2147483643
            };
            c = k.yj;
            f = k.zIndex;
            g = k.bj;
            h = k.offsetTop;
            d = k.Ze;
            e = k.backgroundColor;
            k = k.Pb;
            g = void 0 === g ? 16 : g;
            d = void 0 === d ? 2 : d;
            k = void 0 === k ? "white" : k;
            e = "<style>.autoprose-search-button {align-items: center; background: " + X(void 0 === e ? "#000" : e) + "; border-radius: ";
            e += X(24) + "px; border-width: 0;" + (h ? "top: " + X(h) + "%;" : "bottom: " + X(d) + "%;") + "box-shadow: 0 0 10px rgba(0, 0, 0, 0.35); cursor: pointer; display: flex; height: " + X(48) + "px; line-height: 1; padding: 0 20px; position: fixed; right: " + X(g) + "px; z-index: " + X(f) +
                ";}.autoprose-search-text {color: " + X(k) + '; font-family: Google Sans, Roboto, sans-serif; font-size: 16px; margin: 10px; user-select: none;}</style><button class="autoprose-search-button"><div class="autoprose-search-icon">' + As(k) + '</div><div class="autoprose-search-text">' + es(c) + "</div></button>";
            c = fs(e);
            return as(c)
        })())), (b = Lz(a)) ? (Gz(a), Tb(b, "click", () => {
            Fz(a)
        })) : Tr(a.j, "pfmsb"), Hz(a))
    }

    function Fz(a) {
        a.I || (Dv(1139, () => a.G.L(), a.g), a.I = !0);
        Rr(a.j, "click", {});
        Mz(a)
    }

    function Gz(a) {
        Rr(a.j, "place", {
            sts: "ok"
        });
        Nz(a)
    }

    function Hz(a) {
        a.l && jp(a.C.isVisible(), !1, () => {
            a.i.contentDocument.activeElement.blur()
        })
    }

    function Jz(a) {
        let b;
        b = a.l ? 50 : 150;
        var c = a.g.innerHeight;
        const d = a.F ? 20 : 2;
        c = 2 === a.A ? .g() ? (100 - d) / 100 * c : .2 * c;
        return {
            Si: a.g.innerWidth - 16 - b,
            Cj: c,
            width: b,
            height: 50
        }
    }

    function Kz(a) {
        const b = a.A ? .j() || void 0,
            c = a.A ? .l() || void 0;
        let d, e;
        2 === a.A ? .g() ? e = a.F ? 20 : 2 : d = 20;
        return {
            backgroundColor: b,
            Pb: c,
            Lg: d,
            Kg: e,
            xj: a.va
        }
    }

    function Lz(a) {
        const b = a.B.shadowRoot.querySelectorAll(".autoprose-search-button")[0];
        return b ? b : a.B.shadowRoot.querySelectorAll(".autoprose-searchbox")[0]
    }

    function Nz(a) {
        Tb(a.g.top, "message", b => {
            b.data && "init" === b.data.action && "AutoProseVariant" === b.data.adChannel && (b = Oz(a), Ks(a.G, b), Pz(a), Qz(a))
        })
    }

    function Mz(a) {
        Pz(a);
        a.C.show();
        Qz(a)
    }

    function Oz(a) {
        if (a = a.i.contentDocument ? .getElementsByTagName("input")[0]) return a;
        console.warn("searchbox missing");
        return null
    }

    function Pz(a) {
        const b = new ResizeObserver(async d => {
                a.i.height = 0;
                await new Promise(e => a.g.requestAnimationFrame(e));
                a.i.height = d[0].target.scrollHeight
            }),
            c = () => {
                const d = a.i.contentDocument ? .documentElement;
                d ? b.observe(d) : (console.warn("iframe body missing"), setTimeout(c, 1E3))
            };
        c()
    }

    function Qz(a) {
        a.C.isVisible() && Oz(a) ? .focus({
            preventScroll: !0
        })
    }
    var Rz = class {
        constructor(a, b, c, d, e, f, g, h) {
            this.g = a;
            this.l = (this.ga = h) ? 500 > this.g.innerWidth : 2 === pf();
            this.F = !!e ? .C();
            this.Va = !!e ? .G();
            this.I = !1;
            this.Z = c;
            this.B = Qv(this.g);
            this.j = d;
            c = e ? .B();
            this.pa = c ? .g() || "en";
            this.Ra = c ? .j() || "Search results from ${website}";
            this.va = c ? .A() || "Search";
            this.Ha = c ? .l() || "Open AutoSearch";
            this.T = b.replace("ca", "partner");
            this.O = new fe(window.document);
            this.i = se(this.O, "IFRAME");
            this.G = new Ls(this.i, e ? .A() || "", "auto-prose", this.T, "AutoProseVariant", a.location, this.pa, this.Ra,
                f, !1, !0, !0);
            a = this.i;
            this.C = this.l ? my(this.g, a, {
                cf: .95,
                He: .95,
                zIndex: 2147483645,
                rb: !0,
                ld: !0,
                ub: !1,
                Ja: !0
            }) : wx(this.g, a, {
                wc: "min(65vw, 768px)",
                lc: "",
                vc: !1,
                zIndex: 2147483645,
                rb: !0,
                ld: !0,
                ub: !1,
                Rd: !1,
                Ja: !0
            });
            this.A = this.l ? e ? .l() : e ? .j();
            this.H = g
        }
        L() {
            this.Va ? Ez(this) : Iz(this)
        }
    };

    function Sz(a, b) {
        for (var c = 0; c < b.length; c++) a.xa(b[c]);
        return a
    }

    function Tz(a, b) {
        a.j = a.j ? a.j : b;
        return a
    }
    class Uz {
        constructor(a) {
            this.C = {};
            this.C.c = a;
            this.A = [];
            this.j = null;
            this.B = [];
            this.F = 0
        }
        ec(a) {
            this.C.wpc = a;
            return this
        }
        xa(a) {
            for (var b = 0; b < this.A.length; b++)
                if (this.A[b] == a) return this;
            this.A.push(a);
            return this
        }
        l(a) {
            var b = Tc(this.C);
            0 < this.F && (b.t = this.F);
            b.err = this.A.join();
            b.warn = this.B.join();
            this.j && (b.excp_n = this.j.name, b.excp_m = this.j.message && this.j.message.substring(0, 512), b.excp_s = this.j.stack && rl(this.j.stack, ""));
            b.w = 0 < a.innerWidth ? a.innerWidth : null;
            b.h = 0 < a.innerHeight ? a.innerHeight : null;
            return b
        }
    };
    let Vz, Wz;
    const Xz = new jl(r);
    ((a, b = !0) => {
        Vz = a || new ho;
        "number" !== typeof r.google_srt && (r.google_srt = Math.random());
        go(Vz, r.google_srt);
        Wz = new tl(Vz, b, Xz);
        Wz.l(!0);
        "complete" == r.document.readyState ? r.google_measure_js_timing || hl(Xz) : Xz.g && Tb(r, "load", () => {
            r.google_measure_js_timing || hl(Xz)
        })
    })();
    var Yz = (a, b) => Wz.Lc(a, b),
        Zz = (a, b) => Wz.Oa(a, b),
        $z = (a, b, c) => {
            const d = fo();
            !b.eid && d.length && (b.eid = d.toString());
            sl(Vz, a, b, !0, c)
        },
        aA = (a, b) => Wz.Ba(a, b, void 0, void 0),
        bA = (a, b, c) => {
            Wz.Pa(a, b, c)
        };

    function Sr(a, b, c) {
        let d = b.Qa;
        b.Xa && v(vt) && (d = 1, "r" in c && (c.r += "F"));
        0 >= d || (!b.Ta || "pvc" in c || (c.pvc = Bf(a.g)), $z(b.Wa, c, d))
    }

    function cA(a, b, c) {
        c = c.l(a.g);
        b.Ta && (c.pvc = Bf(a.g));
        0 <= b.Qa && (c.r = b.Qa, Sr(a, b, c))
    }
    var dA = class {
        constructor(a) {
            this.g = a
        }
    };

    function eA(a) {
        const b = a.i ? .g() ? .j() || 0,
            c = a.j.document,
            d = c.createElement("div");
        d.classList.add("auto-prose-wrapper");
        c.body.appendChild(d);
        Dv(1138, () => (new Rz(a.j, a.A, d, a.l, a.i, b, C(a.g, hr, 33) ? .g() ? .i() ? ? null, C(a.g, Xq, 25) ? .g() || !1)).L(), a.j)
    }
    async function fA(a) {
        await new Promise(b => {
            setTimeout(() => {
                b(eA(a))
            })
        })
    }
    var gA = class {
        constructor(a, b, c, d) {
            this.j = a;
            this.g = c;
            this.i = C(this.g, cr, 31);
            this.l = new Ur(a, b, this.i || new cr);
            this.A = d
        }
    };

    function hA(a, b) {
        Sr(a.i, Nr, { ...b,
            evt: "place",
            vh: T(a.win),
            eid: a.g.g() ? .g() || 0,
            hl: a.g.j() ? .g() || ""
        })
    }

    function iA(a, b, c) {
        b = {
            sts: b
        };
        c && (b.excp_n = c.name, b.excp_m = c.message && c.message.substring(0, 512), b.excp_s = c.stack && rl(c.stack, "") || "");
        hA(a, b)
    }
    var jA = class {
        constructor(a, b, c) {
            this.win = a;
            this.i = b;
            this.g = c
        }
    };
    var kA = class {
        constructor(a) {
            this.g = a
        }
        Ma(a) {
            const b = a.document.createElement("div");
            A(b, Nv(a));
            A(b, {
                width: "100%",
                "max-width": "1000px",
                margin: "auto"
            });
            b.appendChild(this.g);
            const c = a.document.createElement("div");
            A(c, Nv(a));
            A(c, {
                width: "100%",
                "text-align": "center",
                display: "block",
                padding: "5px 5px 2px",
                "box-sizing": "border-box",
                "background-color": "#FFF"
            });
            c.appendChild(b);
            return c
        }
    };
    var mA = (a, b, c) => {
        if (!b || !c) return !1;
        var d = b.parentElement;
        const e = c.parentElement;
        if (!d || !e || d != e) return !1;
        d = 0;
        for (b = b.nextSibling; 10 > d && b;) {
            if (b == c) return !0;
            if (lA(a, b)) break;
            b = b.nextSibling;
            d++
        }
        return !1
    };
    const lA = (a, b) => {
        if (3 == b.nodeType) return 3 == b.nodeType ? (b = b.data, a = kc(b, "&") ? $d(b, a.document) : b, a = /\S/.test(a)) : a = !1, a;
        if (1 == b.nodeType) {
            var c = a.getComputedStyle(b);
            if ("0" == c.opacity || "none" == c.display || "hidden" == c.visibility) return !1;
            if ((c = b.tagName) && Ro.contains(c.toUpperCase())) return !0;
            b = b.childNodes;
            for (c = 0; c < b.length; c++)
                if (lA(a, b[c])) return !0
        }
        return !1
    };
    var nA = a => {
        if (460 <= a) return a = Math.min(a, 1200), Math.ceil(800 > a ? a / 4 : 200);
        a = Math.min(a, 600);
        return 420 >= a ? Math.ceil(a / 1.2) : Math.ceil(a / 1.91) + 130
    };
    const oA = class {
        constructor() {
            this.g = {
                clearBoth: !0
            }
        }
        i(a, b, c, d) {
            return sv(d.document, a, null, null, this.g, b)
        }
        j(a) {
            return nA(Math.min(a.screen.width || 0, a.screen.height || 0))
        }
    };
    const pA = class {
        constructor(a) {
            this.g = a
        }
        i(a, b, c, d) {
            return sv(d.document, a, null, null, this.g, b)
        }
        j() {
            return null
        }
    };
    class qA {
        constructor(a) {
            this.i = a
        }
        g(a) {
            a = Math.floor(a.zc());
            const b = nA(a);
            return new Bq(["ap_container"], {
                google_reactive_ad_format: 27,
                google_responsive_auto_format: 16,
                google_max_num_ads: 1,
                google_ad_type: this.i,
                google_ad_format: a + "x" + b,
                google_ad_width: a,
                google_ad_height: b
            })
        }
    };
    const rA = class {
        constructor(a, b) {
            this.l = a;
            this.j = b
        }
        i() {
            return this.l
        }
        g() {
            return this.j
        }
    };
    const sA = class {
        constructor(a) {
            this.g = a
        }
        i(a, b, c, d) {
            var e = 0 < D(this.g, mr, 9).length ? D(this.g, mr, 9)[0] : null,
                f = Jv(C(this.g, nr, 3), e);
            if (!e) return null;
            if (e = L(e, 1)) {
                d = d.document;
                var g = c.tagName;
                c = se(new fe(d), g);
                c.style.clear = f.clearBoth ? "both" : "none";
                "A" == g && (c.style.display = "block");
                c.style.padding = "0px";
                c.style.margin = "0px";
                f.Kd && rv(c.style, f.Kd);
                d = se(new fe(d), "INS");
                f.kc && rv(d.style, f.kc);
                c.appendChild(d);
                f = {
                    pb: c,
                    wa: d
                };
                f.wa.setAttribute("data-ad-type", "text");
                f.wa.setAttribute("data-native-settings-key",
                    e);
                uv(f, a, null, b);
                a = f
            } else a = null;
            return a
        }
        j() {
            var a = 0 < D(this.g, mr, 9).length ? D(this.g, mr, 9)[0] : null;
            if (!a) return null;
            a = D(a, lr, 3);
            for (var b = 0; b < a.length; b++) {
                var c = a[b];
                if ("height" == L(c, 1) && 0 < parseInt(L(c, 2), 10)) return parseInt(L(c, 2), 10)
            }
            return null
        }
    };
    const tA = class {
        constructor(a) {
            this.g = a
        }
        i(a, b, c, d) {
            if (!this.g) return null;
            const e = this.g.google_ad_format || null,
                f = this.g.google_ad_slot || null;
            if (c = c.style) {
                var g = [];
                for (let h = 0; h < c.length; h++) {
                    const k = c.item(h);
                    "width" !== k && "height" !== k && g.push({
                        property: k,
                        value: c.getPropertyValue(k)
                    })
                }
                c = {
                    kc: g
                }
            } else c = {};
            a = sv(d.document, a, f, e, c, b);
            a.wa.setAttribute("data-pub-vars", JSON.stringify(this.g));
            return a
        }
        j() {
            return this.g ? parseInt(this.g.google_ad_height, 10) || null : null
        }
        Ac() {
            return this.g
        }
    };
    class uA {
        constructor(a) {
            this.i = a
        }
        g() {
            return new Bq([], {
                google_ad_type: this.i,
                google_reactive_ad_format: 26,
                google_ad_format: "fluid"
            })
        }
    };
    const vA = class {
        constructor(a, b) {
            this.l = a;
            this.j = b
        }
        g() {
            return this.j
        }
        i(a) {
            a = this.l.query(a.document);
            return 0 < a.length ? a[0] : null
        }
    };

    function wA(a, b, c) {
        const d = [];
        for (let q = 0; q < a.length; q++) {
            var e = a[q];
            var f = q,
                g = b,
                h = c,
                k = e.ja();
            if (k) {
                var l = Fv(k);
                if (l) {
                    var m = M(e, 2);
                    m = Kv[m];
                    var n = void 0 === m ? null : m;
                    if (null === n) e = null;
                    else {
                        m = (m = C(e, nr, 3)) ? ai(m, 3) : null;
                        l = new vA(l, n);
                        n = bi(e, 10, fh, 2).slice(0);
                        null != ui(k, 5) && n.push(1);
                        var p = h ? h : {};
                        h = ui(e, 12);
                        k = Yh(e, zq, 4) ? C(e, zq, 4) : null;
                        1 == M(e, 8) ? (p = p.Mh || null, e = new xA(l, new pA(Jv(C(e, nr, 3), null)), p, m, 0, n, k, g, f, h, e)) : e = 2 == M(e, 8) ? new xA(l, new sA(e), p.Mi || new uA("text"), m, 1, n, k, g, f, h, e) : null
                    }
                } else e = null
            } else e =
                null;
            null !== e && d.push(e)
        }
        return d
    }

    function yA(a) {
        return a.A
    }

    function zA(a) {
        return a.va
    }

    function AA(a) {
        return v(et) ? (a.O || (a.O = a.F.i(a.j)), a.O) : a.F.i(a.j)
    }

    function BA(a) {
        var b = a.H;
        a = a.j.document.createElement("div");
        v(et) ? a.className = "google-auto-placed-ad-placeholder" : a.className = "google-auto-placed";
        var c = a.style;
        c.textAlign = "center";
        c.width = "100%";
        c.height = "0px";
        c.clear = b ? "both" : "none";
        return a
    }

    function CA(a) {
        return a.C instanceof tA ? a.C.Ac() : null
    }

    function DA(a, b, c) {
        Lo(a.I, b) || a.I.set(b, []);
        a.I.get(b).push(c)
    }

    function EA(a, b) {
        a.A = !0;
        v(et) && (a.i && ev(a.i), a.i = null);
        null != b && a.Z.push(b)
    }

    function FA(a) {
        return cv(a.j.document, a.H || !1)
    }

    function GA(a) {
        return a.C.j(a.j)
    }

    function HA(a, b = null, c = null) {
        return new xA(a.F, b || a.C, c || a.T, a.H, a.Rb, a.Dc, a.Td, a.j, a.pa, a.G, a.l, a.B, a.ga)
    }
    class xA {
        constructor(a, b, c, d, e, f, g, h, k, l = null, m = null, n = null, p = null) {
            this.F = a;
            this.C = b;
            this.T = c;
            this.H = d;
            this.Rb = e;
            this.Dc = f;
            this.Td = g ? g : new zq;
            this.j = h;
            this.pa = k;
            this.G = l;
            this.l = m;
            (a = !m) || (a = !(m.ja() && null != ui(m.ja(), 5)));
            this.va = !a;
            this.B = n;
            this.ga = p;
            this.Z = [];
            this.A = !1;
            this.I = new Po;
            this.O = this.i = null
        }
        da() {
            return this.j
        }
        g() {
            return this.F.g()
        }
    };

    function IA(a, b, c, d, e, f) {
        const g = yq();
        return new xA(new rA(c, e), new oA, new qA(a), !0, 2, [], g, d, null, null, null, b, f)
    }

    function JA(a, b, c, d, e) {
        const f = yq();
        return new xA(new rA(b, d), new pA({
            clearBoth: !0
        }), null, !0, 2, [], f, c, null, null, null, a, e)
    };
    var KA = class {
        constructor(a, b, c) {
            this.articleStructure = a;
            this.element = b;
            this.win = c
        }
        da() {
            return this.win
        }
        A(a) {
            return IA(a, this.articleStructure, this.element, this.win, 3, null)
        }
        j() {
            return JA(this.articleStructure, this.element, this.win, 3, null)
        }
    };
    const LA = {
        TABLE: {
            sc: new eq([1, 2])
        },
        THEAD: {
            sc: new eq([0, 3, 1, 2])
        },
        TBODY: {
            sc: new eq([0, 3, 1, 2])
        },
        TR: {
            sc: new eq([0, 3, 1, 2])
        },
        TD: {
            sc: new eq([0, 3])
        }
    };

    function MA(a, b, c, d) {
        const e = c.childNodes;
        c = c.querySelectorAll(b);
        b = [];
        for (const f of c) c = Ua(e, f), 0 > c || b.push(new NA(a, [f], c, f, 3, oe(f).trim(), d));
        return b
    }

    function OA(a, b, c) {
        let d = [];
        const e = [],
            f = b.childNodes,
            g = f.length;
        let h = 0,
            k = "";
        for (let n = 0; n < g; n++) {
            var l = f[n];
            if (1 == l.nodeType || 3 == l.nodeType) {
                if (1 != l.nodeType) var m = null;
                else "BR" == l.tagName ? m = l : (m = c.getComputedStyle(l).getPropertyValue("display"), m = "inline" == m || "inline-block" == m ? null : l);
                m ? (d.length && k && e.push(new NA(a, d, n - 1, m, 0, k, c)), d = [], h = n + 1, k = "") : (d.push(l), l = oe(l).trim(), k += l && k ? " " + l : l)
            }
        }
        d.length && k && e.push(new NA(a, d, h, b, 2, k, c));
        return e
    }

    function PA(a, b) {
        return a.g - b.g
    }
    class NA {
        constructor(a, b, c, d, e, f, g) {
            this.l = a;
            this.gd = b.slice(0);
            this.g = c;
            this.Xd = d;
            this.Yd = e;
            this.B = f;
            this.i = g
        }
        da() {
            return this.i
        }
        A(a) {
            return IA(a, this.l, this.Xd, this.i, this.Yd, this.g)
        }
        j() {
            return JA(this.l, this.Xd, this.i, this.Yd, this.g)
        }
    };

    function QA(a) {
        return gb(a.B ? OA(a.i, a.g, a.j) : [], a.A ? MA(a.i, a.A, a.g, a.j) : []).filter(b => {
            var c = b.Xd.tagName;
            c ? (c = LA[c.toUpperCase()], b = null != c && c.sc.contains(b.Yd)) : b = !1;
            return !b
        })
    }
    class RA {
        constructor(a, b, c) {
            this.g = a;
            this.A = b.ed;
            this.B = b.gg;
            this.i = b.articleStructure;
            this.j = c;
            this.l = b.Jf
        }
    };

    function SA(a, b) {
        if (!b) return !1;
        const c = Ba(b),
            d = a.g.get(c);
        if (null != d) return d;
        if (1 == b.nodeType && ("UL" == b.tagName || "OL" == b.tagName) && "none" != a.i.getComputedStyle(b).getPropertyValue("list-style-type")) return a.g.set(c, !0), !0;
        b = SA(a, b.parentNode);
        a.g.set(c, b);
        return b
    }

    function TA(a, b) {
        return bb(b.gd, c => SA(a, c))
    }
    class UA {
        constructor(a) {
            this.g = new Po;
            this.i = a
        }
    };
    class VA {
        constructor(a, b) {
            this.l = a;
            this.g = [];
            this.i = [];
            this.j = b
        }
    };
    var XA = (a, {
            sg: b = !1,
            mf: c = !1,
            Gg: d = c || v(dt) ? 2 : 3,
            kf: e = null
        } = {}) => {
            a = QA(a);
            return WA(a, {
                sg: b,
                mf: c,
                Gg: d,
                kf: e
            })
        },
        WA = (a, {
            sg: b = !1,
            mf: c = !1,
            Gg: d = c || v(dt) ? 2 : 3,
            kf: e = null
        } = {}) => {
            if (2 > d) throw Error("minGroupSize should be at least 2, found " + d);
            var f = a.slice(0);
            f.sort(PA);
            a = [];
            b = new VA(b, e);
            for (const g of f) {
                e = {
                    Md: g,
                    zd: 51 > g.B.length ? !1 : null != b.j ? !TA(b.j, g) : !0
                };
                if (b.l || e.zd) b.g.length ? (f = b.g[b.g.length - 1].Md, f = mA(f.da(), f.gd[f.gd.length - 1], e.Md.gd[0])) : f = !0, f ? (b.g.push(e), e.zd && b.i.push(e.Md)) : (b.g = [e], b.i = e.zd ? [e.Md] : []);
                if (b.i.length >= d) {
                    e = b;
                    f = c || v(dt) ? 0 : 1;
                    if (0 > f || f >= e.i.length) e = null;
                    else {
                        for (f = e.i[f]; e.g.length && !e.g[0].zd;) e.g.shift();
                        e.g.shift();
                        e.i.shift();
                        e = f
                    }
                    e && a.push(e)
                }
            }
            return a
        };
    var ZA = (a, b, c = !1) => {
            a = YA(a, b);
            const d = new UA(b);
            return Zp(a, e => XA(e, {
                mf: c,
                kf: d
            }))
        },
        $A = (a, b) => {
            a = YA(a, b);
            const c = new UA(b);
            return Zp(a, d => {
                if (d.l) {
                    var e = d.i;
                    var f = d.j;
                    d = d.g.querySelectorAll(d.l);
                    var g = [];
                    for (var h of d) g.push(new KA(e, h, f));
                    e = g
                } else e = [];
                d = e.slice(0);
                if (d.length) {
                    e = [];
                    f = d[0];
                    for (g = 1; g < d.length; g++) {
                        const m = d[g];
                        h = f;
                        b: {
                            if (h.element.hasAttributes())
                                for (l of h.element.attributes)
                                    if ("style" === l.name.toLowerCase() && l.value.toLowerCase().includes("background-image")) {
                                        var k = !0;
                                        break b
                                    }
                            k =
                            h.element.tagName;k = "IMG" === k || "SVG" === k
                        }(k || 1 < h.element.textContent.length) && !SA(c, f.element) && mA(m.da(), f.element, m.element) && e.push(f);
                        f = m
                    }
                    var l = e
                } else l = [];
                return l
            })
        },
        YA = (a, b) => {
            const c = new Po;
            a.forEach(d => {
                var e = Fv(C(d, qq, 1));
                if (e) {
                    var f = e.toString();
                    Lo(c, f) || c.set(f, {
                        articleStructure: d,
                        Fh: e,
                        ed: null,
                        gg: !1,
                        Jf: null
                    });
                    e = c.get(f);
                    (f = (f = C(d, qq, 2)) ? L(f, 7) : null) ? e.ed = e.ed ? e.ed + "," + f : f: e.gg = !0;
                    d = C(d, qq, 4);
                    e.Jf = d ? L(d, 7) : null
                }
            });
            return Oo(c).map(d => {
                const e = d.Fh.query(b.document);
                return e.length ? new RA(e[0],
                    d, b) : null
            }).filter(d => null != d)
        };
    var aB = a => a ? .google_ad_slot ? fq(new rq(1, {
            Ah: a.google_ad_slot
        })) : hq(Error("Missing dimension when creating placement id")),
        cB = a => {
            switch (a.Rb) {
                case 0:
                case 1:
                    var b = a.l;
                    null == b ? a = null : (a = b.ja(), null == a ? a = null : (b = M(b, 2), a = null == b ? null : new rq(0, {
                        Kf: [a],
                        Yg: b
                    })));
                    return null != a ? fq(a) : hq(Error("Missing dimension when creating placement id"));
                case 2:
                    return a = bB(a), null != a ? fq(a) : hq(Error("Missing dimension when creating placement id"));
                default:
                    return hq(Error("Invalid type: " + a.Rb))
            }
        };
    const bB = a => {
        if (null == a || null == a.B) return null;
        const b = C(a.B, qq, 1),
            c = C(a.B, qq, 2);
        if (null == b || null == c) return null;
        const d = a.ga;
        if (null == d) return null;
        a = a.g();
        return null == a ? null : new rq(0, {
            Kf: [b, c],
            Li: d,
            Yg: Lv[a]
        })
    };

    function dB(a) {
        const b = CA(a.ha);
        return (b ? aB(b) : cB(a.ha)).map(c => uq(c))
    }

    function eB(a) {
        a.g = a.g || dB(a);
        return a.g
    }

    function fB(a, b) {
        if (a.ha.A) throw Error("AMA:AP:AP");
        hv(b, a.ja(), a.ha.g());
        EA(a.ha, b)
    }
    const gB = class {
        constructor(a, b, c) {
            this.ha = a;
            this.i = b;
            this.ka = c;
            this.g = null
        }
        ja() {
            return this.i
        }
        fill(a, b) {
            var c = this.ha;
            (a = c.C.i(a, b, this.i, c.j)) && fB(this, a.pb);
            return a
        }
    };

    function hB(a, b) {
        return Ev(() => {
            if (v(et)) {
                var c = [],
                    d = [];
                for (var e = 0; e < a.length; e++) {
                    var f = a[e],
                        g = AA(f);
                    if (g) {
                        if (!f.i && !f.A) {
                            var h = null;
                            try {
                                var k = AA(f);
                                if (k) {
                                    h = BA(f);
                                    hv(h, k, f.g());
                                    var l = h
                                } else l = null
                            } catch (q) {
                                throw ev(h), q;
                            }
                            f.i = l
                        }(h = f.i) && d.push({
                            jj: f,
                            anchorElement: g,
                            wi: h
                        })
                    }
                }
                if (0 < d.length)
                    for (l = Eo(b), k = Fo(b), e = 0; e < d.length; e++) {
                        const {
                            jj: q,
                            anchorElement: x,
                            wi: z
                        } = d[e];
                        f = iB(z, k, l);
                        c.push(new gB(q, x, f))
                    }
                l = c
            } else {
                l = [];
                k = [];
                try {
                    const q = [];
                    for (let x = 0; x < a.length; x++) {
                        var m = a[x],
                            n = AA(m);
                        n && q.push({
                            Rg: m,
                            anchorElement: n
                        })
                    }
                    for (n =
                        0; n < q.length; n++) {
                        m = k;
                        g = m.push; {
                            var p = q[n];
                            const x = p.anchorElement,
                                z = p.Rg,
                                G = BA(z);
                            try {
                                hv(G, x, z.g()), h = G
                            } catch (E) {
                                throw ev(G), E;
                            }
                        }
                        g.call(m, h)
                    }
                    c = Eo(b);
                    d = Fo(b);
                    for (g = 0; g < k.length; g++) e = iB(k[g], d, c), f = q[g], l.push(new gB(f.Rg, f.anchorElement, e))
                } finally {
                    for (c = 0; c < k.length; c++) ev(k[c])
                }
            }
            return l
        }, b)
    }

    function iB(a, b, c) {
        a = a.getBoundingClientRect();
        return new Qp(a.left + b, a.top + c, a.right - a.left)
    };
    const jB = {
            1: "0.5vp",
            2: "300px"
        },
        kB = {
            1: 700,
            2: 1200
        },
        lB = {
            [1]: {
                ih: "3vp",
                qf: "1vp",
                hh: "0.3vp"
            },
            [2]: {
                ih: "900px",
                qf: "300px",
                hh: "90px"
            }
        };

    function mB(a, b, c) {
        var d = nB(a),
            e = T(a) || kB[d],
            f = void 0;
        c && (f = (c = (c = oB(D(c, Kq, 2), d)) ? C(c, Iq, 7) : void 0) ? pB(c, e) : void 0);
        c = f;
        f = nB(a);
        a = T(a) || kB[f];
        const g = qB(lB[f].qf, a);
        a = null === g ? rB(f, a) : new sB(g, g, tB(g, 8), 8, .3, c);
        c = qB(lB[d].ih, e);
        f = qB(lB[d].qf, e);
        d = qB(lB[d].hh, e);
        e = a.j;
        c && d && f && void 0 !== b && (e = .5 >= b ? f + (1 - 2 * b) * (c - f) : d + (2 - 2 * b) * (f - d));
        return new sB(e, e, tB(e, a.i), a.i, a.l, a.g)
    }

    function uB(a, b) {
        const c = a.Nb();
        a = $h(a, 5);
        return null == c || null == a ? b : new sB(a, 0, [], c, 1)
    }

    function vB(a, b) {
        const c = nB(a);
        a = T(a) || kB[c];
        if (!b) return rB(c, a);
        if (b = oB(D(b, Kq, 2), c))
            if (b = wB(b, a)) return b;
        return rB(c, a)
    }

    function xB(a) {
        const b = nB(a);
        a = T(a) || kB[b];
        return rB(b, a)
    }

    function yB(a, b) {
        let c = {
            Jc: a.j,
            wb: a.B
        };
        for (let d of a.A) d.adCount <= b && (c = d.Oc);
        return c
    }

    function zB(a, b, c) {
        var d = ai(b, 2);
        b = C(b, Kq, 1);
        var e = nB(c);
        var f = T(c) || kB[e];
        c = qB(b ? .A(), f) ? ? a.j;
        e = qB(b ? .l(), f) ? ? a.B;
        d = d ? [] : AB(b ? .g(), f) ? ? a.A;
        const g = b ? .Nb() ? ? a.i,
            h = b ? .j() ? ? a.l;
        a = (b ? .B() ? pB(C(b, Iq, 7), f) : null) ? ? a.g;
        return new sB(c, e, d, g, h, a)
    }

    function BB(a, b) {
        var c = nB(b);
        const d = new Lq,
            e = new Kq;
        let f = !1;
        var g = w(kt);
        0 <= g && (Xi(e, 4, g), f = !0);
        g = null;
        1 === c ? (c = w(nt), 0 <= c && (g = c + "vp")) : (c = w(mt), 0 <= c && (g = c + "px"));
        null !== g && ($i(e, 2, g), f = !0);
        c = v(pt) ? "0px" : null;
        null !== c && ($i(e, 5, c), f = !0);
        if (v(rt)) Vi(d, 2, !0), f = !0;
        else if (null !== c || null !== g) {
            const m = [];
            for (const n of a.A) {
                var h = m,
                    k = h.push;
                var l = new Jq;
                l = Xi(l, 1, n.adCount);
                l = $i(l, 3, c ? ? n.Oc.wb + "px");
                l = $i(l, 2, g ? ? n.Oc.Jc + "px");
                k.call(h, l)
            }
            si(e, 3, m)
        }
        return f ? (F(d, 1, e), zB(a, d, b)) : a
    }
    class sB {
        constructor(a, b, c, d, e, f) {
            this.j = a;
            this.B = b;
            this.A = c.sort((g, h) => g.adCount - h.adCount);
            this.i = d;
            this.l = e;
            this.g = f
        }
        Nb() {
            return this.i
        }
    }

    function oB(a, b) {
        for (let c of a)
            if (M(c, 1) == b) return c;
        return null
    }

    function AB(a, b) {
        if (void 0 === a) return null;
        const c = [];
        for (let d of a) {
            a = ui(d, 1);
            const e = qB(L(d, 2), b);
            if ("number" !== typeof a || null === e) return null;
            c.push({
                adCount: a,
                Oc: {
                    Jc: e,
                    wb: qB(L(d, 3), b)
                }
            })
        }
        return c
    }

    function wB(a, b) {
        const c = qB(L(a, 2), b),
            d = qB(L(a, 5), b);
        if (null === c) return null;
        const e = ui(a, 4);
        if (null == e) return null;
        var f = a.g();
        f = AB(f, b);
        if (null === f) return null;
        const g = C(a, Iq, 7);
        b = g ? pB(g, b) : void 0;
        return new sB(c, d, f, e, $h(a, 6), b)
    }

    function rB(a, b) {
        a = qB(jB[a], b);
        return v(ht) ? new sB(null === a ? Infinity : a, null, [], 8, .3) : new sB(null === a ? Infinity : a, null, [], 3, null)
    }

    function qB(a, b) {
        if (!a) return null;
        const c = parseFloat(a);
        return isNaN(c) ? null : a.endsWith("px") ? c : a.endsWith("vp") ? c * b : null
    }

    function nB(a) {
        a = 900 <= wo(a);
        return ue() && !a ? 1 : 2
    }

    function tB(a, b) {
        if (4 > b) return [];
        const c = Math.ceil(b / 2);
        return [{
            adCount: c,
            Oc: {
                Jc: 2 * a,
                wb: 2 * a
            }
        }, {
            adCount: c + Math.ceil((b - c) / 2),
            Oc: {
                Jc: 3 * a,
                wb: 3 * a
            }
        }]
    }

    function pB(a, b) {
        const c = qB(L(a, 2), b) || 0,
            d = ui(a, 3) || 1;
        return {
            Hg: c,
            Bg: d,
            mc: qB(L(a, 1), b) || 0
        }
    };

    function CB(a, b, c) {
        return oo({
            top: a.g.top - (c + 1),
            right: a.g.right + (c + 1),
            bottom: a.g.bottom + (c + 1),
            left: a.g.left - (c + 1)
        }, b.g)
    }

    function DB(a) {
        if (!a.length) return null;
        const b = po(a.map(c => c.g));
        a = a.reduce((c, d) => c + d.i, 0);
        return new EB(b, a)
    }
    class EB {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
    };

    function FB(a = null) {
        ({
            googletag: a
        } = a ? ? window);
        return a ? .apiReady ? a : void 0
    };
    var LB = (a, b) => {
        var c = hb(b.document.querySelectorAll(".google-auto-placed"));
        const d = GB(b),
            e = HB(b),
            f = IB(b),
            g = JB(b),
            h = hb(b.document.querySelectorAll("ins.adsbygoogle-ablated-ad-slot")),
            k = hb(b.document.querySelectorAll("div.googlepublisherpluginad")),
            l = hb(b.document.querySelectorAll("html > ins.adsbygoogle"));
        let m = [].concat(hb(b.document.querySelectorAll("iframe[id^=aswift_],iframe[id^=google_ads_frame]")), hb(b.document.querySelectorAll("body ins.adsbygoogle")));
        b = [];
        for (const [n, p] of [
                [a.wd, c],
                [a.Qb,
                    d
                ],
                [a.Ji, e],
                [a.xd, f],
                [a.yd, g],
                [a.Hi, h],
                [a.Ii, k],
                [a.Ki, l]
            ]) !1 === n ? b = b.concat(p) : m = m.concat(p);
        a = KB(m);
        c = KB(b);
        a = a.slice(0);
        for (const n of c)
            for (c = 0; c < a.length; c++)(n.contains(a[c]) || a[c].contains(n)) && a.splice(c, 1);
        return a
    };
    const MB = a => {
            const b = FB(a);
            return b ? Za($a(b.pubads().getSlots(), c => a.document.getElementById(c.getSlotElementId())), c => null != c) : null
        },
        GB = a => hb(a.document.querySelectorAll("ins.adsbygoogle[data-anchor-shown],ins.adsbygoogle[data-anchor-status]")),
        HB = a => hb(a.document.querySelectorAll("ins.adsbygoogle[data-ad-format=autorelaxed]")),
        IB = a => (MB(a) || hb(a.document.querySelectorAll("div[id^=div-gpt-ad]"))).concat(hb(a.document.querySelectorAll("iframe[id^=google_ads_iframe]"))),
        JB = a => hb(a.document.querySelectorAll("div.trc_related_container,div.OUTBRAIN,div[id^=rcjsload],div[id^=ligatusframe],div[id^=crt-],iframe[id^=cto_iframe],div[id^=yandex_], div[id^=Ya_sync],iframe[src*=adnxs],div.advertisement--appnexus,div[id^=apn-ad],div[id^=amzn-native-ad],iframe[src*=amazon-adsystem],iframe[id^=ox_],iframe[src*=openx],img[src*=openx],div[class*=adtech],div[id^=adtech],iframe[src*=adtech],div[data-content-ad-placement=true],div.wpcnt div[id^=atatags-]"));
    var KB = a => {
        const b = [];
        for (const c of a) {
            a = !0;
            for (let d = 0; d < b.length; d++) {
                const e = b[d];
                if (e.contains(c)) {
                    a = !1;
                    break
                }
                if (c.contains(e)) {
                    a = !1;
                    b[d] = c;
                    break
                }
            }
            a && b.push(c)
        }
        return b
    };
    var NB = Wz.Oa(453, LB),
        OB;
    OB = Wz.Oa(454, (a, b) => {
        const c = hb(b.document.querySelectorAll(".google-auto-placed")),
            d = GB(b),
            e = HB(b),
            f = IB(b),
            g = JB(b),
            h = hb(b.document.querySelectorAll("ins.adsbygoogle-ablated-ad-slot")),
            k = hb(b.document.querySelectorAll("div.googlepublisherpluginad"));
        b = hb(b.document.querySelectorAll("html > ins.adsbygoogle"));
        return KB([].concat(!0 === a.wd ? c : [], !0 === a.Qb ? d : [], !0 === a.Ji ? e : [], !0 === a.xd ? f : [], !0 === a.yd ? g : [], !0 === a.Hi ? h : [], !0 === a.Ii ? k : [], !0 === a.Ki ? b : []))
    });

    function PB(a, b, c) {
        const d = QB(a);
        b = RB(d, b, c);
        return new SB(a, d, b)
    }

    function TB(a) {
        return 1 < (a.bottom - a.top) * (a.right - a.left)
    }

    function UB(a) {
        return a.g.map(b => b.box)
    }

    function VB(a) {
        return a.g.reduce((b, c) => b + c.box.bottom - c.box.top, 0)
    }
    class SB {
        constructor(a, b, c) {
            this.j = a;
            this.g = b.slice(0);
            this.l = c.slice(0);
            this.i = null
        }
    }

    function QB(a) {
        const b = NB({
                Qb: !1
            }, a),
            c = Fo(a),
            d = Eo(a);
        return b.map(e => {
            const f = e.getBoundingClientRect();
            return (e = !!e.className && kc(e.className, "google-auto-placed")) || TB(f) ? {
                box: {
                    top: f.top + d,
                    right: f.right + c,
                    bottom: f.bottom + d,
                    left: f.left + c
                },
                On: e ? 1 : 0
            } : null
        }).filter(Jb(e => null === e))
    }

    function RB(a, b, c) {
        return void 0 != b && a.length <= (void 0 != c ? c : 8) ? WB(a, b) : $a(a, d => new EB(d.box, 1))
    }

    function WB(a, b) {
        a = $a(a, d => new EB(d.box, 1));
        const c = [];
        for (; 0 < a.length;) {
            let d = a.pop(),
                e = !0;
            for (; e;) {
                e = !1;
                for (let f = 0; f < a.length; f++)
                    if (CB(d, a[f], b)) {
                        d = DB([d, a[f]]);
                        Array.prototype.splice.call(a, f, 1);
                        e = !0;
                        break
                    }
            }
            c.push(d)
        }
        return c
    };

    function XB(a, b, c) {
        const d = Pp(c, b);
        return !bb(a, e => oo(e, d))
    }

    function YB(a, b, c, d, e) {
        e = e.ka;
        const f = Pp(e, b),
            g = Pp(e, c),
            h = Pp(e, d);
        return !bb(a, k => oo(k, g) || oo(k, f) && !oo(k, h))
    }

    function ZB(a, b, c, d) {
        const e = UB(a);
        if (XB(e, b, d.ka)) return !0;
        if (!YB(e, b, c.Hg, c.mc, d)) return !1;
        const f = new EB(Pp(d.ka, 0), 1);
        a = Za(a.l, g => CB(g, f, c.mc));
        b = ab(a, (g, h) => g + h.i, 1);
        return 0 === a.length || b > c.Bg ? !1 : !0
    };
    var $B = (a, b) => {
        const c = [];
        let d = a;
        for (a = () => {
                c.push({
                    anchor: d.anchor,
                    position: d.position
                });
                return d.anchor == b.anchor && d.position == b.position
            }; d;) {
            switch (d.position) {
                case 1:
                    if (a()) return c;
                    d.position = 2;
                case 2:
                    if (a()) return c;
                    if (d.anchor.firstChild) {
                        d = {
                            anchor: d.anchor.firstChild,
                            position: 1
                        };
                        continue
                    } else d.position = 3;
                case 3:
                    if (a()) return c;
                    d.position = 4;
                case 4:
                    if (a()) return c
            }
            for (; d && !d.anchor.nextSibling && d.anchor.parentNode != d.anchor.ownerDocument.body;) {
                d = {
                    anchor: d.anchor.parentNode,
                    position: 3
                };
                if (a()) return c;
                d.position = 4;
                if (a()) return c
            }
            d && d.anchor.nextSibling ? d = {
                anchor: d.anchor.nextSibling,
                position: 1
            } : d = null
        }
        return c
    };

    function aC(a, b) {
        const c = new mq,
            d = new Qo;
        b.forEach(e => {
            if (Si(e, Sq, 1, Vq)) {
                e = Si(e, Sq, 1, Vq);
                if (C(e, Rq, 1) && C(e, Rq, 1).ja() && C(e, Rq, 2) && C(e, Rq, 2).ja()) {
                    const g = bC(a, C(e, Rq, 1).ja()),
                        h = bC(a, C(e, Rq, 2).ja());
                    if (g && h)
                        for (var f of $B({
                                anchor: g,
                                position: M(C(e, Rq, 1), 2)
                            }, {
                                anchor: h,
                                position: M(C(e, Rq, 2), 2)
                            })) c.set(Ba(f.anchor), f.position)
                }
                C(e, Rq, 3) && C(e, Rq, 3).ja() && (f = bC(a, C(e, Rq, 3).ja())) && c.set(Ba(f), M(C(e, Rq, 3), 2))
            } else Si(e, Tq, 2, Vq) ? cC(a, Si(e, Tq, 2, Vq), c) : Si(e, Qq, 3, Vq) && dC(a, Si(e, Qq, 3, Vq), d)
        });
        return new eC(c,
            d)
    }
    class eC {
        constructor(a, b) {
            this.i = a;
            this.g = b
        }
    }
    const cC = (a, b, c) => {
            C(b, Rq, 2) ? (b = C(b, Rq, 2), (a = bC(a, b.ja())) && c.set(Ba(a), M(b, 2))) : C(b, qq, 1) && (a = fC(a, C(b, qq, 1))) && a.forEach(d => {
                d = Ba(d);
                c.set(d, 1);
                c.set(d, 4);
                c.set(d, 2);
                c.set(d, 3)
            })
        },
        dC = (a, b, c) => {
            C(b, qq, 1) && (a = fC(a, C(b, qq, 1))) && a.forEach(d => {
                c.add(Ba(d))
            })
        },
        bC = (a, b) => (a = fC(a, b)) && 0 < a.length ? a[0] : null,
        fC = (a, b) => (b = Fv(b)) ? b.query(a) : null;
    var gC = class {
        constructor() {
            this.g = Af();
            this.i = 0
        }
    };

    function hC(a, b, c) {
        switch (c) {
            case 2:
            case 3:
                break;
            case 1:
            case 4:
                b = b.parentElement;
                break;
            default:
                throw Error("Unknown RelativePosition: " + c);
        }
        for (c = []; b;) {
            if (iC(b)) return !0;
            if (a.g.has(b)) break;
            c.push(b);
            b = b.parentElement
        }
        c.forEach(d => a.g.add(d));
        return !1
    }

    function jC(a) {
        a = kC(a);
        return a.has("all") || a.has("after")
    }

    function lC(a) {
        a = kC(a);
        return a.has("all") || a.has("before")
    }

    function kC(a) {
        return (a = a && a.getAttribute("data-no-auto-ads")) ? new Set(a.split("|")) : new Set
    }

    function iC(a) {
        const b = kC(a);
        return a && ("AUTO-ADS-EXCLUSION-AREA" === a.tagName || b.has("inside") || b.has("all"))
    }
    var mC = class {
        constructor() {
            this.g = new Set;
            this.i = new gC
        }
    };

    function nC(a) {
        return function(b) {
            return hB(b, a)
        }
    }

    function oC(a) {
        const b = T(a);
        return b ? Ka(pC, b + Eo(a)) : Gb
    }

    function qC(a, b, c) {
        if (0 > a) throw Error("ama::ead:nd");
        if (Infinity === a) return Gb;
        const d = UB(c || PB(b));
        return e => XB(d, a, e.ka)
    }

    function rC(a, b, c, d) {
        if (0 > a || 0 > b.Hg || 0 > b.Bg || 0 > b.mc) throw Error("ama::ead:nd");
        return Infinity === a ? Gb : e => ZB(d || PB(c, b.mc), a, b, e)
    }

    function sC(a) {
        if (!a.length) return Gb;
        const b = new eq(a);
        return c => b.contains(c.Rb)
    }

    function tC(a) {
        return function(b) {
            for (let c of b.Dc)
                if (-1 < a.indexOf(c)) return !1;
            return !0
        }
    }

    function uC(a) {
        return a.length ? function(b) {
            const c = b.Dc;
            return a.some(d => -1 < c.indexOf(d))
        } : Hb
    }

    function vC(a, b) {
        if (0 >= a) return Hb;
        const c = Ao(b).scrollHeight - a;
        return function(d) {
            return d.ka.g <= c
        }
    }

    function wC(a) {
        const b = {};
        a && a.forEach(c => {
            b[c] = !0
        });
        return function(c) {
            return !b[M(c.Td, 2) || 0]
        }
    }

    function xC(a) {
        return a.length ? b => a.includes(M(b.Td, 1) || 0) : Hb
    }

    function yC(a, b) {
        const c = aC(a, b);
        return function(d) {
            var e = d.ja();
            d = Lv[d.ha.g()];
            var f = c.i,
                g = Ba(e);
            f = f.g.get(g);
            if (!(f = f ? f.contains(d) : !1)) a: {
                if (c.g.contains(Ba(e))) switch (d) {
                    case 2:
                    case 3:
                        f = !0;
                        break a;
                    default:
                        f = !1;
                        break a
                }
                for (e = e.parentElement; e;) {
                    if (c.g.contains(Ba(e))) {
                        f = !0;
                        break a
                    }
                    e = e.parentElement
                }
                f = !1
            }
            return !f
        }
    }

    function zC() {
        const a = new mC;
        return function(b) {
            var c = b.ja(),
                d = Lv[b.ha.g()];
            a: switch (d) {
                case 1:
                    b = jC(c.previousElementSibling) || lC(c);
                    break a;
                case 4:
                    b = jC(c) || lC(c.nextElementSibling);
                    break a;
                case 2:
                    b = lC(c.firstElementChild);
                    break a;
                case 3:
                    b = jC(c.lastElementChild);
                    break a;
                default:
                    throw Error("Unknown RelativePosition: " + d);
            }
            c = hC(a, c, d);
            d = a.i;
            $z("ama_exclusion_zone", {
                typ: b ? c ? "siuex" : "siex" : c ? "suex" : "noex",
                cor: d.g,
                num: d.i++,
                dvc: pf()
            }, .1);
            return !(b || c)
        }
    }
    const pC = (a, b) => b.ka.g >= a,
        AC = (a, b, c) => {
            c = c.ka.zc();
            return a <= c && c <= b
        };

    function BC(a, b, c, d, e) {
        var f = CC({
            oh: e.rh
        }, DC(a, b), a);
        if (0 === f.length) {
            var g = !!C(b, kr, 6) ? .g() ? .length;
            f = C(b, er, 28) ? .l() ? .g() && g ? CC({
                oh: !0
            }, EC(a, b), a) : f
        }
        if (0 === f.length) return iA(d, "pfno"), [];
        b = f;
        a = e.nd ? FC(a, b, c) : {
            lb: b,
            od: null
        };
        const {
            lb: h,
            od: k
        } = a;
        f = h;
        return 0 === f.length && k ? (iA(d, k), []) : [f[e.rh ? 0 : Math.floor(f.length / 2)]]
    }

    function FC(a, b, c) {
        c = c ? D(c, Uq, 5) : [];
        const d = yC(a.document, c),
            e = zC();
        b = b.filter(f => d(f));
        if (0 === b.length) return {
            lb: [],
            od: "pfaz"
        };
        b = b.filter(f => e(f));
        return 0 === b.length ? {
            lb: [],
            od: "pfet"
        } : {
            lb: b,
            od: null
        }
    }

    function GC(a, b) {
        return a.ka.g - b.ka.g
    }

    function DC(a, b) {
        const c = C(b, kr, 6);
        if (!c) return [];
        b = C(b, er, 28) ? .l();
        return (b ? .j() ? $A(c.g(), a) : ZA(c.g(), a, !!b ? .l())).map(d => d.j())
    }

    function EC(a, b) {
        b = D(b, or, 1) || [];
        return wA(b, a, {}).filter(c => !c.Dc.includes(6))
    }

    function CC(a, b, c) {
        b = hB(b, c);
        if (a.oh) {
            const d = oC(c);
            b = b.filter(e => d(e))
        }
        return b.sort(GC)
    };

    function HC(a, b) {
        return 2 === pf() ? my(a.win, b, {
            cf: .95,
            He: .95,
            zIndex: 2147483645,
            rb: !0,
            Ja: !0
        }) : wx(a.win, b, {
            wc: "min(65vw, 768px)",
            lc: "",
            vc: !1,
            zIndex: 2147483645,
            rb: !0,
            Rd: !1,
            Ja: !0
        })
    }

    function IC(a) {
        ((d, e) => {
            d[e] = d[e] || function() {
                (d[e].q = d[e].q || []).push(arguments)
            };
            d[e].t = (new Date).getTime()
        })(a.win, "_googCsa");
        const b = a.pa.map(d => ({
                container: d,
                relatedSearches: 5
            })),
            c = {
                pubId: a.H,
                styleId: "5134551505",
                hl: a.ga,
                fexp: a.F,
                channel: "AutoRsVariant",
                resultsPageBaseUrl: "http://google.com",
                resultsPageQueryParam: "q",
                relatedSearchTargeting: "content",
                relatedSearchResultClickedCallback: a.Db.bind(a),
                relatedSearchUseResultCallback: !0,
                cx: a.I
            };
        a.va && (c.adLoadedCallback = a.Ha.bind(a));
        a.l && a.C instanceof
        Array && (c.fexp = a.C.join(","));
        a.win._googCsa("relatedsearch", c, b)
    }

    function JC(a) {
        a.win.addEventListener("message", b => {
            "https://www.gstatic.com" === b.origin && "resize" === b.data.action && (a.g.style.height = `${Math.ceil(b.data.height)+1}px`)
        })
    }
    var KC = class extends U {
        constructor(a, b, c, d, e, f, g, h, k = () => {}) {
            super();
            this.win = a;
            this.pa = b;
            this.Z = e;
            this.F = f;
            this.A = h;
            this.Va = k;
            this.ga = d ? .g() || "en";
            this.Ra = d ? .j() || "Search results from ${website}";
            this.va = v(xt);
            this.H = c.replace("ca", "partner");
            this.O = new fe(a.document);
            this.g = se(this.O, "IFRAME");
            this.I = g.i ? g.g : "9d449ff4a772956c6";
            this.C = (this.l = v(Dt)) ? fo().concat(this.F) : this.F;
            this.j = new Ls(this.g, this.I, "auto-rs-prose", this.H, "AutoRsVariant", a.location, this.ga, this.Ra, this.C, this.A, this.l);
            this.T =
                HC(this, this.g);
            Yo(this, this.T)
        }
        L() {
            0 !== this.pa.length && (this.va || Dv(1075, () => {
                this.j.L()
            }, this.win), Dv(1076, () => {
                const a = se(this.O, "SCRIPT");
                Re(a, sj `https://www.google.com/adsense/search/async-ads.js`);
                this.win.document.head.appendChild(a)
            }, this.win), IC(this), hA(this.Z, {
                sts: "ok"
            }), this.A && JC(this))
        }
        Ha(a, b) {
            b ? Dv(1075, () => {
                this.j.L()
            }, this.win) : (this.Va(), iA(this.Z, "pfns"))
        }
        Db(a, b) {
            Js(this.j, a, b);
            (() => {
                if (!this.A) {
                    const c = new ResizeObserver(async e => {
                            this.g.height = "0";
                            await new Promise(f => {
                                this.win.requestAnimationFrame(f)
                            });
                            this.g.height = e[0].target.scrollHeight.toString()
                        }),
                        d = () => {
                            const e = this.g.contentDocument ? .documentElement;
                            e ? c.observe(e) : (console.warn("iframe body missing"), setTimeout(d, 1E3))
                        };
                    d()
                }
                this.T.show()
            })()
        }
    };
    var LC = class {
        constructor(a, b) {
            this.i = a;
            this.g = b
        }
    };

    function MC(a) {
        const b = FA(a.l.ha),
            c = a.B.Ma(a.G, () => a.i());
        b.appendChild(c);
        a.A && (b.className = a.A);
        return {
            ni: b,
            bi: c
        }
    }
    class NC {
        constructor(a, b, c, d) {
            this.G = a;
            this.l = b;
            this.B = c;
            this.A = d || null;
            this.g = null;
            this.j = new V(null)
        }
        L() {
            const a = MC(this);
            this.g = a.ni;
            fB(this.l, this.g);
            this.j.g(a.bi)
        }
        i() {
            this.g && this.g.parentNode && this.g.parentNode.removeChild(this.g);
            this.g = null;
            this.j.g(null)
        }
        C() {
            return this.j
        }
    };
    async function OC(a) {
        await new Promise(b => {
            setTimeout(() => {
                try {
                    PC(a)
                } catch (c) {
                    iA(a.i, "pfere", c)
                }
                b()
            })
        })
    }

    function PC(a) {
        if ((!a.nd || !QC(a.config, a.X, a.i)) && RC(a.g ? .j(), a.i)) {
            var b = BC(a.win, a.config, a.X, a.i, {
                rh: !!a.g ? .l() ? .A(),
                nd: a.nd
            });
            b = SC(b, a.win);
            var c = Object.keys(b),
                d = Object.values(b),
                e = a.g ? .g() ? .g() || 0,
                f = TC(a.g),
                g = !!a.g ? .B();
            if (!C(a.config, Xq, 25) ? .g()) {
                var h = () => {
                    d.forEach(k => {
                        k.i()
                    })
                };
                Dv(1074, () => {
                    (new KC(a.win, c, a.webPropertyCode, a.g ? .j(), a.i, e, f, g, h)).L()
                }, a.win)
            }
        }
    }
    var UC = class {
        constructor(a, b, c, d, e, f) {
            this.win = a;
            this.config = c;
            this.webPropertyCode = d;
            this.X = e;
            this.nd = f;
            this.i = new jA(a, b, C(this.config, er, 28) || new er);
            this.g = C(this.config, er, 28)
        }
    };

    function QC(a, b, c) {
        a = C(a, er, 28) ? .g() ? .g() || 0;
        const d = u(Xb).g(Ct.g, Ct.defaultValue);
        return d && d.includes(a.toString()) ? !1 : 0 === (b ? bi(b, 2, fh, 2) : []).length ? (iA(c, "pfeu"), !0) : !1
    }

    function RC(a, b) {
        const c = u(Xb).g(At.g, At.defaultValue);
        return c && 0 !== c.length && !c.includes((a ? .g() || "").toString()) ? (iA(b, "pflna"), !1) : !0
    }

    function SC(a, b) {
        const c = {};
        for (let e = 0; e < a.length; e++) {
            var d = a[e];
            const f = "autors-container-" + e.toString(),
                g = b.document.createElement("div");
            g.setAttribute("id", f);
            d = new NC(b, d, new kA(g), "autors-widget");
            d.L();
            c[f] = d
        }
        return c
    }

    function TC(a) {
        return new LC(a ? .C() || !1, a ? .A() || "")
    };
    var VC = (a, b) => {
        const c = [];
        C(a, pr, 18) && c.push(2);
        b.X && c.push(0);
        C(a, er, 28) && 1 == Ri(C(a, er, 28), 1) && c.push(1);
        C(a, cr, 31) && 1 == Ri(C(a, cr, 31), 1) && c.push(5);
        C(a, Zq, 32) && c.push(6);
        C(a, sr, 34) && O(C(a, sr, 34), 3) && c.push(7);
        return c
    };

    function WC(a, b) {
        const c = se(ee(a), "IMG");
        XC(a, c);
        c.src = "https://www.gstatic.com/adsense/autoads/icons/gpp_good_24px_grey_800.svg";
        A(c, {
            margin: "0px 12px 0px 8px",
            width: "24px",
            height: "24px",
            cursor: null == b ? "auto" : "pointer"
        });
        b && c.addEventListener("click", d => {
            b();
            d.stopPropagation()
        });
        return c
    }

    function YC(a, b) {
        const c = b.document.createElement("button");
        XC(b, c);
        A(c, {
            display: "inline",
            "line-height": "24px",
            cursor: "pointer"
        });
        c.appendChild(b.document.createTextNode(a.i));
        c.addEventListener("click", d => {
            a.j();
            d.stopPropagation()
        });
        return c
    }

    function ZC(a, b, c) {
        const d = se(ee(b), "IMG");
        d.src = "https://www.gstatic.com/adsense/autoads/icons/arrow_left_24px_grey_800.svg";
        d.setAttribute("aria-label", a.l);
        XC(b, d);
        A(d, {
            margin: "0px 12px 0px 8px",
            width: "24px",
            height: "24px",
            cursor: "pointer"
        });
        d.addEventListener("click", e => {
            c();
            e.stopPropagation()
        });
        return d
    }

    function $C(a) {
        const b = a.document.createElement("ins");
        XC(a, b);
        A(b, {
            "float": "left",
            display: "inline-flex",
            padding: "8px 0px",
            "background-color": "#FFF",
            "border-radius": "0px 20px 20px 0px",
            "box-shadow": "0px 1px 2px 0px rgba(60,64,67,0.3), 0px 1px 3px 1px rgba(60,64,67,0.15)"
        });
        return b
    }
    class aD {
        constructor(a, b, c) {
            this.i = a;
            this.l = b;
            this.j = c;
            this.g = new V(!1)
        }
        Ma(a, b, c, d) {
            const e = WC(a, d),
                f = WC(a),
                g = YC(this, a),
                h = ZC(this, a, c);
            a = $C(a);
            a.appendChild(e);
            a.appendChild(f);
            a.appendChild(g);
            a.appendChild(h);
            this.g.listen(k => {
                A(e, {
                    display: k ? "none" : "inline"
                });
                A(f, {
                    display: k ? "inline" : "none"
                });
                k ? (A(g, {
                        "line-height": "24px",
                        "max-width": "100vw",
                        opacity: "1",
                        transition: "line-height 0s 50ms, max-width 50ms, opacity 50ms 50ms"
                    }), A(h, {
                        margin: "0px 12px 0px 8px",
                        opacity: 1,
                        width: "24px",
                        transition: "margin 100ms 50ms, opacity 50ms 50ms, width 100ms 50ms"
                    })) :
                    (A(g, {
                        "line-height": "0px",
                        "max-width": "0vw",
                        opacity: "0",
                        transition: "line-height 0s 50ms, max-width 50ms 50ms, opacity 50ms"
                    }), A(h, {
                        margin: "0",
                        opacity: "0",
                        width: "0",
                        transition: "margin 100ms, opacity 50ms, width 100ms"
                    }))
            }, !0);
            return a
        }
        jg() {
            return 40
        }
        Ng() {
            this.g.g(!1);
            return 0
        }
        Og() {
            this.g.g(!0)
        }
    }

    function XC(a, b) {
        A(b, Nv(a));
        A(b, {
            "font-family": "Arial,sans-serif",
            "font-weight": "bold",
            "font-size": "14px",
            "letter-spacing": "0.2px",
            color: "#3C4043",
            "user-select": "none"
        })
    };

    function bD(a, b) {
        const c = b.document.createElement("button");
        cD(a, b, c);
        b = {
            width: "100%",
            "text-align": "center",
            display: "block",
            padding: "8px 0px",
            "background-color": a.i
        };
        a.g && (b["border-top"] = a.g, b["border-bottom"] = a.g);
        A(c, b);
        c.addEventListener("click", d => {
            a.B();
            d.stopPropagation()
        });
        return c
    }

    function dD(a, b, c, d) {
        const e = b.document.createElement("div");
        A(e, Nv(b));
        A(e, {
            "align-items": "center",
            "background-color": a.i,
            display: "flex",
            "justify-content": "center"
        });
        const f = b.document.createElement("span");
        f.appendChild(b.document.createTextNode(d));
        A(f, Nv(b));
        A(f, {
            "font-family": "Arial,sans-serif",
            "font-size": "12px",
            padding: "8px 0px"
        });
        b = b.matchMedia("(min-width: 768px)");
        d = g => {
            g.matches ? (A(e, {
                    "flex-direction": "row"
                }), a.g && A(e, {
                    "border-top": a.g,
                    "border-bottom": a.g
                }), A(f, {
                    "margin-left": "8px",
                    "text-align": "start"
                }),
                A(c, {
                    border: "0",
                    "margin-right": "8px",
                    width: "auto"
                })) : (A(e, {
                border: "0",
                "flex-direction": "column"
            }), A(f, {
                "margin-left": "0",
                "text-align": "center"
            }), A(c, {
                "margin-right": "0",
                width: "100%"
            }), a.g && A(c, {
                "border-top": a.g,
                "border-bottom": a.g
            }))
        };
        d(b);
        b.addEventListener("change", d);
        e.appendChild(c);
        e.appendChild(f);
        return e
    }

    function cD(a, b, c) {
        A(c, Nv(b));
        A(c, {
            "font-family": "Arial,sans-serif",
            "font-weight": a.C,
            "font-size": "14px",
            "letter-spacing": "0.2px",
            color: a.G,
            "user-select": "none",
            cursor: "pointer"
        })
    }
    class eD {
        constructor(a, b, c, d, e, f = null, g = null, h = null) {
            this.A = a;
            this.B = b;
            this.G = c;
            this.i = d;
            this.C = e;
            this.l = f;
            this.g = g;
            this.j = h
        }
        Ma(a) {
            const b = a.document.createElement("div");
            cD(this, a, b);
            A(b, {
                display: "inline-flex",
                padding: "8px 0px",
                "background-color": this.i
            });
            if (this.l) {
                var c = se(ee(a), "IMG");
                c.src = this.l;
                cD(this, a, c);
                A(c, {
                    margin: "0px 8px 0px 0px",
                    width: "24px",
                    height: "24px"
                })
            } else c = null;
            c && b.appendChild(c);
            c = a.document.createElement("span");
            cD(this, a, c);
            A(c, {
                "line-height": "24px"
            });
            c.appendChild(a.document.createTextNode(this.A));
            b.appendChild(c);
            c = bD(this, a);
            c.appendChild(b);
            return this.j ? dD(this, a, c, this.j) : c
        }
    };

    function fD(a, b) {
        b = b.filter(c => 5 === C(c, zq, 4) ? .g() && 1 === M(c, 8));
        b = wA(b, a);
        a = hB(b, a);
        a.sort((c, d) => d.ka.g - c.ka.g);
        return a[0] || null
    };

    function gD({
        K: a,
        We: b,
        Te: c,
        Rf: d,
        ua: e,
        Vh: f,
        Dj: g
    }) {
        let h = 0;
        try {
            h |= uo(a);
            const k = Math.min(a.screen.width || 0, a.screen.height || 0);
            h |= k ? 320 > k ? 8192 : 0 : 2048;
            h |= a.navigator && hD(a.navigator.userAgent) ? 1048576 : 0;
            h = b ? h | iD(a, b, g) : h | (a.innerHeight >= a.innerWidth ? 0 : 8);
            h |= vo(a, c, g);
            g || (h |= xo(a))
        } catch {
            h |= 32
        }
        switch (d) {
            case 2:
                jD(a, e) && (h |= 16777216);
                break;
            case 1:
                kD(a, e) && (h |= 16777216)
        }
        f && lD(a, e) && (h |= 16777216);
        return h
    }

    function hD(a) {
        return /Android 2/.test(a) || /iPhone OS [34]_/.test(a) || /Windows Phone (?:OS )?[67]/.test(a) || /MSIE.*Windows NT/.test(a) || /Windows NT.*Trident/.test(a)
    }
    var jD = (a, b = null) => {
            const c = Rv({
                ic: 0,
                Jb: a.innerWidth,
                Xb: 3,
                jc: 0,
                Kb: Math.min(Math.round(a.innerWidth / 320 * 50), mD) + 15,
                Yb: 3
            });
            return null != Tv(nD(a, b), c)
        },
        kD = (a, b = null) => {
            const c = a.innerWidth,
                d = a.innerHeight,
                e = Math.min(Math.round(a.innerWidth / 320 * 50), mD) + 15,
                f = Rv({
                    ic: 0,
                    Jb: c,
                    Xb: 3,
                    jc: d - e,
                    Kb: d,
                    Yb: 3
                });
            25 < e && f.push({
                x: c - 25,
                y: d - 25
            });
            return null != Tv(nD(a, b), f)
        };

    function lD(a, b = null) {
        return null != oD(a, b)
    }

    function oD(a, b = null) {
        var c = a.innerHeight;
        c = Rv({
            ic: 0,
            Jb: a.innerWidth,
            Xb: 10,
            jc: c - 66,
            Kb: c,
            Yb: 10
        });
        return Tv(nD(a, b), c)
    }

    function pD(a, b) {
        var c = v(Ts);
        a: {
            const e = a.innerWidth,
                f = a.innerHeight;
            let g = f;
            for (; g > b;) {
                var d = Rv({
                    ic: 0,
                    Jb: e,
                    Xb: 9,
                    jc: g - b,
                    Kb: g,
                    Yb: 9
                });
                d = Tv(nD(a), d);
                if (!d) {
                    a = f - g;
                    break a
                }
                g = c ? Math.min(d.getBoundingClientRect().top - 1, g - 1) : d.getBoundingClientRect().top - 1
            }
            a = null
        }
        return a
    }

    function nD(a, b = null) {
        return new Yv(a, {
            hg: qD(a, b)
        })
    }

    function qD(a, b = null) {
        if (b) return (c, d, e) => {
            sl(b, "ach_evt", {
                tn: c.tagName,
                id: c.getAttribute("id") ? ? "",
                cls: c.getAttribute("class") ? ? "",
                ign: String(e),
                pw: a.innerWidth,
                ph: a.innerHeight,
                x: d.x,
                y: d.y
            }, !0, 1)
        }
    }

    function iD(a, b, c = !1) {
        const d = a.innerHeight;
        return (c ? Gf(a) * d : d) >= b ? 0 : 1024
    }
    const mD = 90 * 1.38;

    function rD(a) {
        a.g || (a.g = sD(a));
        A(a.g, {
            display: "block"
        });
        a.A.Og();
        a.j.g(a.B)
    }

    function tD(a) {
        const b = a.A.Ng();
        switch (b) {
            case 0:
                a.j.g(a.B);
                break;
            case 1:
                a.g && (A(a.g, {
                    display: "none"
                }), a.j.g(null));
                break;
            default:
                throw Error("Unhandled OnHideOutcome: " + b);
        }
    }

    function sD(a) {
        var b = pD(a.l, a.A.jg() + 60);
        b = null == b ? 30 : b + 30;
        const c = a.l.document.createElement("div");
        A(c, Nv(a.l));
        A(c, {
            position: "fixed",
            left: "0px",
            bottom: b + "px",
            width: "100vw",
            "text-align": "center",
            "z-index": 2147483642,
            display: "none",
            "pointer-events": "none"
        });
        a.B = a.A.Ma(a.l, () => a.i(), () => {
            a.G.ma();
            tD(a)
        }, () => {
            a.G.ma();
            rD(a)
        });
        c.appendChild(a.B);
        a.F && (c.className = a.F);
        a.l.document.body.appendChild(c);
        return c
    }
    class uD {
        constructor(a, b, c) {
            this.l = a;
            this.A = b;
            this.B = null;
            this.j = new V(null);
            this.F = c || null;
            this.G = lz(a);
            this.g = null
        }
        L() {
            const a = fp(this.G.j);
            W(a, !0, () => void rD(this));
            jp(a, !1, () => void tD(this))
        }
        i() {
            this.g && this.g.parentNode && this.g.parentNode.removeChild(this.g);
            this.g = null;
            this.G.ma();
            this.j.g(null)
        }
        C() {
            return this.j
        }
    };

    function vD(a) {
        a.G.g(0);
        null != a.l && (a.l.i(), a.l = null);
        null != a.j && (a.j.i(), a.j = null)
    }

    function wD(a) {
        a.j = new uD(a.B, a.I, a.F);
        a.j.L();
        kp(a.A, a.j.C());
        a.G.g(2)
    }
    class xD {
        constructor(a, b, c, d, e) {
            this.B = a;
            this.H = b;
            this.O = c;
            this.I = d;
            this.F = e;
            this.G = new V(0);
            this.A = new V(null);
            this.j = this.l = this.g = null
        }
        L() {
            this.H ? (this.l = new NC(this.B, this.H, this.O, this.F), this.l.L(), kp(this.A, this.l.C()), this.G.g(1), null == this.g && (this.g = new Yp(this.B), this.g.L(2E3)), Wp(this.g, () => {
                vD(this);
                wD(this)
            })) : wD(this)
        }
        i() {
            vD(this);
            this.g && (this.g.ma(), this.g = null)
        }
        C() {
            return this.A
        }
    };
    var yD = (a, b, c, d, e) => {
        a = new xD(a, fD(a, e), new eD(b, d, "#FFF", "#4A4A4A", "normal"), new aD(b, c, d), "google-dns-link-placeholder");
        a.L();
        return a
    };
    var zD = a => a.googlefc = a.googlefc || {},
        AD = a => {
            a = a.googlefc = a.googlefc || {};
            return a.ccpa = a.ccpa || {}
        };

    function BD(a) {
        var b = AD(a.g);
        if (CD(b.getInitialCcpaStatus(), b.InitialCcpaStatusEnum)) {
            var c = b.getLocalizedDnsText();
            b = b.getLocalizedDnsCollapseText();
            null != c && null != b && (a.i = yD(a.g, c, b, () => DD(a), a.l))
        }
    }

    function ED(a) {
        const b = zD(a.g);
        AD(a.g).overrideDnsLink = !0;
        b.callbackQueue = b.callbackQueue || [];
        b.callbackQueue.push({
            INITIAL_CCPA_DATA_READY: () => BD(a)
        })
    }

    function DD(a) {
        hw(a.j);
        AD(a.g).openConfirmationDialog(b => {
            b && a.i && (a.i.i(), a.i = null);
            iw(a.j)
        })
    }
    class FD {
        constructor(a, b, c) {
            this.g = a;
            this.j = bw(b, 2147483643);
            this.l = c;
            this.i = null
        }
    }

    function CD(a, b) {
        switch (a) {
            case b.CCPA_DOES_NOT_APPLY:
            case b.OPTED_OUT:
                return !1;
            case b.NOT_OPTED_OUT:
                return !0;
            default:
                return !0
        }
    };

    function GD(a) {
        const b = a.document.createElement("ins");
        HD(a, b);
        A(b, {
            display: "flex",
            padding: "8px 0px",
            width: "100%"
        });
        return b
    }

    function ID(a, b, c, d) {
        const e = se(ee(a), "IMG");
        e.src = b;
        d && e.setAttribute("aria-label", d);
        HD(a, e);
        A(e, {
            margin: "0px 12px 0px 8px",
            width: "24px",
            height: "24px",
            cursor: "pointer"
        });
        e.addEventListener("click", f => {
            c();
            f.stopPropagation()
        });
        return e
    }

    function JD(a, b) {
        const c = b.document.createElement("span");
        HD(b, c);
        A(c, {
            "line-height": "24px",
            cursor: "pointer"
        });
        c.appendChild(b.document.createTextNode(a.l));
        c.addEventListener("click", d => {
            a.i();
            d.stopPropagation()
        });
        return c
    }

    function KD(a, b) {
        const c = b.document.createElement("span");
        c.appendChild(b.document.createTextNode(a.j));
        A(c, Nv(b));
        A(c, {
            "border-top": "11px solid #ECEDED",
            "font-family": "Arial,sans-serif",
            "font-size": "12px",
            "line-height": "1414px",
            padding: "8px 32px",
            "text-align": "center"
        });
        return c
    }

    function LD(a) {
        const b = a.document.createElement("div");
        A(b, Nv(a));
        A(b, {
            "align-items": "flex-start",
            "background-color": "#FFF",
            "border-radius": "0px 20px 20px 0px",
            "box-shadow": "0px 1px 3px 1px rgba(60,64,67,0.5)",
            display: "inline-flex",
            "flex-direction": "column",
            "float": "left"
        });
        return b
    }
    class MD {
        constructor(a, b, c, d) {
            this.l = a;
            this.A = b;
            this.j = c;
            this.i = d;
            this.g = new V(!1)
        }
        Ma(a, b, c, d) {
            c = GD(a);
            const e = ID(a, "https://www.gstatic.com/adsense/autoads/icons/gpp_good_24px_grey_800.svg", d),
                f = ID(a, "https://www.gstatic.com/adsense/autoads/icons/gpp_good_24px_grey_800.svg", this.i),
                g = JD(this, a),
                h = ID(a, "https://www.gstatic.com/adsense/autoads/icons/close_24px_grey_700.svg", b, this.A);
            A(h, {
                "margin-left": "auto"
            });
            c.appendChild(e);
            c.appendChild(f);
            c.appendChild(g);
            c.appendChild(h);
            const k = KD(this, a);
            a = LD(a);
            a.appendChild(c);
            a.appendChild(k);
            this.g.listen(l => {
                A(e, {
                    display: l ? "none" : "inline"
                });
                A(f, {
                    display: l ? "inline" : "none"
                });
                l ? (A(g, {
                        "line-height": "24px",
                        "max-width": "100vw",
                        opacity: "1",
                        transition: "line-height 0s 50ms, max-width 50ms, opacity 50ms 50ms"
                    }), A(h, {
                        "margin-right": "12px",
                        opacity: 1,
                        width: "24px",
                        transition: "margin 50ms, opacity 50ms 50ms, width 50ms"
                    }), A(k, {
                        "border-width": "1px",
                        "line-height": "14px",
                        "max-width": "100vw",
                        opacity: "1",
                        padding: "8px 32px",
                        transition: "border-width 0s 50ms, line-height 0s 50ms, max-width 50ms, opacity 50ms 50ms, padding 50ms"
                    })) :
                    (A(g, {
                        "line-height": "0px",
                        "max-width": "0vw",
                        opacity: "0",
                        transition: "line-height 0s 50ms, max-width 50ms 50ms, opacity 50ms"
                    }), A(h, {
                        "margin-right": "0",
                        opacity: "0",
                        width: "0",
                        transition: "margin 50ms 50ms, opacity 50ms, width 50ms 50ms"
                    }), A(k, {
                        "border-width": "0px",
                        "line-height": "0px",
                        "max-width": "0vw",
                        opacity: "0",
                        padding: "0",
                        transition: "border-width 0s 50ms, line-height 0s 50ms, max-width 50ms 50ms, opacity 50ms, padding 50ms 50ms"
                    }))
            }, !0);
            return a
        }
        jg() {
            return 71
        }
        Ng() {
            this.g.g(!1);
            return 0
        }
        Og() {
            this.g.g(!0)
        }
    }

    function HD(a, b) {
        A(b, Nv(a));
        A(b, {
            "font-family": "Arial,sans-serif",
            "font-weight": "bold",
            "font-size": "14px",
            "letter-spacing": "0.2px",
            color: "#1A73E8",
            "user-select": "none"
        })
    };
    var ND = class extends S {
        constructor() {
            super()
        }
    };

    function OD(a) {
        PD(a.i, b => {
            var c = a.l,
                d = b.vj,
                e = b.Zh,
                f = b.Hh;
            b = b.showRevocationMessage;
            (new xD(c, fD(c, a.j), new eD(d, b, "#1A73E8", "#FFF", "bold", "https://www.gstatic.com/adsense/autoads/icons/gpp_good_24px_blue_600.svg", "2px solid #ECEDED", f), new MD(d, e, f, b), "google-revocation-link-placeholder")).L()
        }, () => {
            iw(a.g)
        })
    }
    class QD {
        constructor(a, b, c, d) {
            this.l = a;
            this.g = bw(b, 2147483643);
            this.j = c;
            this.i = d
        }
    };
    var RD = a => {
        if (!a || null == M(a, 1)) return !1;
        a = M(a, 1);
        switch (a) {
            case 1:
                return !0;
            case 2:
                return !1;
            default:
                throw Error("Unhandled AutoConsentUiStatus: " + a);
        }
    };

    function SD(a) {
        if (!0 !== a.i.adsbygoogle_ama_fc_has_run) {
            var b = !1;
            RD(a.g) && (b = new QD(a.i, a.A, a.l || D(a.g, or, 4), a.j), hw(b.g), OD(b), b = !0);
            var c;
            a: if ((c = a.g) && null != M(c, 3)) switch (c = M(c, 3), c) {
                case 1:
                    c = !0;
                    break a;
                case 2:
                    c = !1;
                    break a;
                default:
                    throw Error("Unhandled AutoCcpaUiStatus: " + c);
            } else c = !1;
            c && (ED(new FD(a.i, a.A, a.l || D(a.g, or, 4))), b = !0);
            c = (c = a.g) ? !0 === ai(c, 5) : !1;
            var d = a.g;
            d = (d ? !0 === ai(d, 6) : !1) || v(Ht);
            c && (b = !0);
            b && (b = new ND, b = Vi(b, 1, c && d), a.j.start(b), a.i.adsbygoogle_ama_fc_has_run = !0)
        }
    }
    class TD {
        constructor(a, b, c, d, e) {
            this.i = a;
            this.j = b;
            this.g = c;
            this.A = d;
            this.l = e || null
        }
    };

    function UD(a, b, c, d, e, f) {
        try {
            const g = a.g,
                h = Xe("SCRIPT", g);
            h.async = !0;
            Re(h, b);
            g.head.appendChild(h);
            h.addEventListener("load", () => {
                e();
                d && g.head.removeChild(h)
            });
            h.addEventListener("error", () => {
                0 < c ? UD(a, b, c - 1, d, e, f) : (d && g.head.removeChild(h), f())
            })
        } catch (g) {
            f()
        }
    }

    function VD(a, b, c = () => {}, d = () => {}) {
        UD(ee(a), b, 0, !1, c, d)
    };

    function WD(a = null) {
        a = a || r;
        return a.googlefc || (a.googlefc = {})
    };
    Sc(mo).map(a => Number(a));
    Sc(no).map(a => Number(a));
    const XD = r.URL;

    function YD(a) {
        var b = (new XD(a.location.href)).searchParams;
        a = b.get("fcconsent");
        b = b.get("fc");
        return "alwaysshow" === b ? b : "alwaysshow" === a ? a : null
    }

    function ZD(a) {
        const b = ["ab", "gdpr", "consent", "ccpa", "monetization"];
        return (a = (new XD(a.location.href)).searchParams.get("fctype")) && -1 !== b.indexOf(a) ? a : null
    };
    var $D = (a, b) => {
        const c = a.document,
            d = () => {
                if (!a.frames[b])
                    if (c.body) {
                        const e = Xe("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };
    var aE = hj(class extends S {});

    function bE(a) {
        if (a.g) return a.g;
        a.I && a.I(a.l) ? a.g = a.l : a.g = of (a.l, a.O);
        return a.g ? ? null
    }

    function cE(a) {
        a.C || (a.C = b => {
            try {
                var c = a.H ? a.H(b) : void 0;
                if (c) {
                    var d = c.df,
                        e = a.F.get(d);
                    e && (e.ij || a.F.delete(d), e.xb ? .(e.hi, c.payload))
                }
            } catch (f) {}
        }, Tb(a.l, "message", a.C))
    }

    function dE(a, b, c) {
        if (bE(a))
            if (a.g === a.l)(b = a.A.get(b)) && b(a.g, c);
            else {
                var d = a.j.get(b);
                if (d && d.Sb) {
                    cE(a);
                    var e = ++a.T;
                    a.F.set(e, {
                        xb: d.xb,
                        hi: d.Ec(c),
                        ij: "addEventListener" === b
                    });
                    a.g.postMessage(d.Sb(c, e), "*")
                }
            }
    }
    var eE = class extends U {
        constructor(a, b, c, d) {
            super();
            this.O = b;
            this.I = c;
            this.H = d;
            this.A = new Map;
            this.T = 0;
            this.j = new Map;
            this.F = new Map;
            this.C = void 0;
            this.l = a
        }
        i() {
            delete this.g;
            this.A.clear();
            this.j.clear();
            this.F.clear();
            this.C && (Ub(this.l, "message", this.C), delete this.C);
            delete this.l;
            delete this.H;
            super.i()
        }
    };
    const fE = (a, b) => {
            const c = {
                cb: d => {
                    d = aE(d);
                    b.callback({
                        ob: d
                    })
                }
            };
            b.spsp && (c.spsp = b.spsp);
            a = a.googlefc || (a.googlefc = {});
            a.__fci = a.__fci || [];
            a.__fci.push(b.command, c)
        },
        gE = {
            Ec: a => a.callback,
            Sb: (a, b) => ({
                __fciCall: {
                    callId: b,
                    command: a.command,
                    spsp: a.spsp || void 0
                }
            }),
            xb: (a, b) => {
                a({
                    ob: b
                })
            }
        };

    function hE(a) {
        a = aE(a.data.__fciReturn);
        return {
            payload: a,
            df: Qi(a, 1)
        }
    }

    function iE(a, b = !1) {
        if (b) return !1;
        a.j || (a.g = !!bE(a.caller), a.j = !0);
        return a.g
    }

    function jE(a) {
        return new Promise(b => {
            iE(a) && dE(a.caller, "getDataWithCallback", {
                command: "loaded",
                callback: c => {
                    b(c.ob)
                }
            })
        })
    }

    function kE(a, b) {
        iE(a) && dE(a.caller, "getDataWithCallback", {
            command: "prov",
            spsp: bj(b),
            callback: () => {}
        })
    }
    var lE = class extends U {
        constructor(a) {
            super();
            this.g = this.j = !1;
            this.caller = new eE(a, "googlefcPresent", void 0, hE);
            this.caller.A.set("getDataWithCallback", fE);
            this.caller.j.set("getDataWithCallback", gE)
        }
        i() {
            this.caller.ma();
            super.i()
        }
    };
    const mE = a => {
        void 0 !== a.addtlConsent && "string" !== typeof a.addtlConsent && (a.addtlConsent = void 0);
        void 0 !== a.gdprApplies && "boolean" !== typeof a.gdprApplies && (a.gdprApplies = void 0);
        return void 0 !== a.tcString && "string" !== typeof a.tcString || void 0 !== a.listenerId && "number" !== typeof a.listenerId ? 2 : a.cmpStatus && "error" !== a.cmpStatus ? 0 : 3
    };

    function nE(a) {
        if (!1 === a.gdprApplies) return !0;
        void 0 === a.internalErrorState && (a.internalErrorState = mE(a));
        return "error" === a.cmpStatus || 0 !== a.internalErrorState ? a.internalBlockOnErrors ? (Rj({
            e: String(a.internalErrorState)
        }, "tcfe"), !1) : !0 : "loaded" !== a.cmpStatus || "tcloaded" !== a.eventStatus && "useractioncomplete" !== a.eventStatus ? !1 : !0
    }

    function oE(a) {
        var b = {};
        return nE(a) ? !1 === a.gdprApplies || "tcunavailable" === a.tcString || void 0 === a.gdprApplies && !b.Vn || "string" !== typeof a.tcString || !a.tcString.length ? !0 : pE(a, "1") : !1
    }

    function pE(a, b) {
        a: {
            if (a.publisher && a.publisher.restrictions) {
                var c = a.publisher.restrictions[b];
                if (void 0 !== c) {
                    c = c["755"];
                    break a
                }
            }
            c = void 0
        }
        if (0 === c) return !1;a.purpose && a.vendor ? (c = a.vendor.consents, (c = !(!c || !c["755"])) && "1" === b && a.purposeOneTreatment && "CH" === a.publisherCC ? b = !0 : (c && (a = a.purpose.consents, c = !(!a || !a[b])), b = c)) : b = !0;
        return b
    }

    function qE(a) {
        var b = ["3", "4"];
        return !1 === a.gdprApplies ? !0 : b.every(c => pE(a, c))
    }

    function rE(a) {
        if (a.g) return a.g;
        a.g = of (a.j, "__tcfapiLocator");
        return a.g
    }

    function sE(a) {
        return "function" === typeof a.j.__tcfapi || null != rE(a)
    }

    function tE(a, b, c, d) {
        c || (c = () => {});
        if ("function" === typeof a.j.__tcfapi) a = a.j.__tcfapi, a(b, 2, c, d);
        else if (rE(a)) {
            uE(a);
            const e = ++a.H;
            a.C[e] = c;
            a.g && a.g.postMessage({
                __tcfapiCall: {
                    command: b,
                    version: 2,
                    callId: e,
                    parameter: d
                }
            }, "*")
        } else c({}, !1)
    }

    function vE(a, b) {
        let c = {
            internalErrorState: 0,
            internalBlockOnErrors: a.A
        };
        const d = Nb(() => b(c));
        let e = 0; - 1 !== a.F && (e = setTimeout(() => {
            e = 0;
            c.tcString = "tcunavailable";
            c.internalErrorState = 1;
            d()
        }, a.F));
        tE(a, "addEventListener", f => {
            f && (c = f, c.internalErrorState = mE(c), c.internalBlockOnErrors = a.A, nE(c) ? (0 != c.internalErrorState && (c.tcString = "tcunavailable"), tE(a, "removeEventListener", null, c.listenerId), (f = e) && clearTimeout(f), d()) : ("error" === c.cmpStatus || 0 !== c.internalErrorState) && (f = e) && clearTimeout(f))
        })
    }

    function uE(a) {
        a.l || (a.l = b => {
            try {
                var c = ("string" === typeof b.data ? JSON.parse(b.data) : b.data).__tcfapiReturn;
                a.C[c.callId](c.returnValue, c.success)
            } catch (d) {}
        }, Tb(a.j, "message", a.l))
    }
    class wE extends U {
        constructor(a, b = {}) {
            super();
            this.j = a;
            this.g = null;
            this.C = {};
            this.H = 0;
            this.F = b.timeoutMs ? ? 500;
            this.A = b.Nh ? ? !1;
            this.l = null
        }
        i() {
            this.C = {};
            this.l && (Ub(this.j, "message", this.l), delete this.l);
            delete this.C;
            delete this.j;
            delete this.g;
            super.i()
        }
        addEventListener(a) {
            let b = {
                internalBlockOnErrors: this.A
            };
            const c = Nb(() => a(b));
            let d = 0; - 1 !== this.F && (d = setTimeout(() => {
                b.tcString = "tcunavailable";
                b.internalErrorState = 1;
                c()
            }, this.F));
            const e = (f, g) => {
                clearTimeout(d);
                f ? (b = f, b.internalErrorState = mE(b),
                    b.internalBlockOnErrors = this.A, g && 0 === b.internalErrorState || (b.tcString = "tcunavailable", g || (b.internalErrorState = 3))) : (b.tcString = "tcunavailable", b.internalErrorState = 3);
                a(b)
            };
            try {
                tE(this, "addEventListener", e)
            } catch (f) {
                b.tcString = "tcunavailable", b.internalErrorState = 3, d && (clearTimeout(d), d = 0), c()
            }
        }
        removeEventListener(a) {
            a && a.listenerId && tE(this, "removeEventListener", null, a.listenerId)
        }
    };

    function PD(a, b, c) {
        const d = WD(a.g);
        d.callbackQueue = d.callbackQueue || [];
        d.callbackQueue.push({
            CONSENT_DATA_READY: () => {
                const e = WD(a.g),
                    f = new wE(a.g);
                sE(f) && vE(f, g => {
                    300 === g.cmpId && g.tcString && "tcunavailable" !== g.tcString && b({
                        vj: e.getDefaultConsentRevocationText(),
                        Zh: e.getDefaultConsentRevocationCloseText(),
                        Hh: e.getDefaultConsentRevocationAttestationText(),
                        showRevocationMessage: () => e.showRevocationMessage()
                    })
                });
                c()
            }
        })
    }

    function xE(a, b) {
        var c = YD(a.g);
        const d = ZD(a.g);
        c = yE(a.i, {
            fc: c,
            fctype: d
        });
        VD(a.g, c, () => {}, () => {});
        b && kE(new lE(a.g), b)
    }

    function yE(a, b) {
        b = { ...b,
            ers: 2
        };
        return $c(ed(new ub(vb, "https://fundingchoicesmessages.google.com/i/%{id}"), {
            id: a
        }), b)
    }
    class zE {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
        start(a) {
            if (this.g === this.g.top) try {
                $D(this.g, "googlefcPresent"), xE(this, a)
            } catch (b) {}
        }
    };
    const AE = new Set(["ARTICLE", "SECTION"]);
    var BE = class {
        constructor(a) {
            this.g = a
        }
    };

    function CE(a, b) {
        return Array.from(b.classList).map(c => `${a}=${c}`)
    }

    function DE(a) {
        return 0 < a.classList.length
    }

    function EE(a) {
        return AE.has(a.tagName)
    };
    var FE = class {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
    };

    function GE(a) {
        return Aa(a) && 1 == a.nodeType && "FIGURE" == a.tagName ? a : (a = a.parentNode) ? GE(a) : null
    };
    var HE = a => {
        var b = a.src;
        const c = a.getAttribute("data-src") || a.getAttribute("data-lazy-src");
        (b && b.startsWith("data:") && c ? c : b || c) ? (a.getAttribute("srcset"), b = (b = GE(a)) ? (b = b.getElementsByTagName("figcaption")[0]) ? b.textContent : null : null, a = new FE(a, b || a.getAttribute("alt") || null)) : a = null;
        return a
    };
    var IE = class {
        constructor() {
            this.map = new Map
        }
        clear() {
            this.map.clear()
        }
        delete(a, b) {
            const c = this.map.get(a);
            return c ? (b = c.delete(b), 0 === c.size && this.map.delete(a), b) : !1
        }
        get(a) {
            return [...(this.map.get(a) ? ? [])]
        }
        keys() {
            return this.map.keys()
        }
        add(a, b) {
            let c = this.map.get(a);
            c || this.map.set(a, c = new Set);
            c.add(b)
        }
        get size() {
            let a = 0;
            for (const b of this.map.values()) a += b.size;
            return a
        }
        values() {
            const a = this.map;
            return function*() {
                for (const b of a.values()) yield* b
            }()
        }[Symbol.iterator]() {
            const a = this.map;
            return function*() {
                for (const [b,
                        c
                    ] of a) {
                    const d = b,
                        e = c;
                    for (const f of e) yield [d, f]
                }
            }()
        }
    };

    function JE(a) {
        return [a[0],
            [...a[1]]
        ]
    };

    function KE(a) {
        return Array.from(LE(a).map.values()).filter(b => 3 <= b.size).map(b => [...b])
    }

    function ME(a, b) {
        return b.every(c => {
            var d = a.g.getBoundingClientRect(c.g);
            if (d = 50 <= d.height && d.width >= a.A) {
                var e = a.g.getBoundingClientRect(c.g);
                d = a.l;
                e = new sy(e.left, e.right);
                d = Math.max(d.start, e.start) <= Math.min(d.end, e.end)
            }
            return d && null === To(a.j, {
                hb: c.g,
                bb: NE,
                Gb: !0
            })
        })
    }

    function OE(a) {
        return KE(a).sort(PE).find(b => ME(a, b)) || []
    }

    function LE(a) {
        return QE(Array.from(a.win.document.getElementsByTagName("IMG")).map(HE).filter(pq), b => {
            var c = [...CE("CLASS_NAME", b.g)],
                d = b.g.parentElement;
            d = [...(d ? CE("PARENT_CLASS_NAME", d) : [])];
            var e = b.g.parentElement ? .parentElement;
            e = [...(e ? CE("GRANDPARENT_CLASS_NAME", e) : [])];
            var f = (f = To(a.i.g, {
                hb: b.g,
                bb: DE
            })) ? CE("NEAREST_ANCESTOR_CLASS_NAME", f) : [];
            return [...c, ...d, ...e, ...f, ...(b.i ? ["HAS_CAPTION=true"] : []), ...(To(a.i.g, {
                hb: b.g,
                bb: EE
            }) ? ["ARTICLE_LIKE_ANCESTOR=true"] : [])]
        })
    }
    var RE = class {
        constructor(a, b, c, d, e) {
            var f = new Ip;
            this.win = a;
            this.l = b;
            this.A = c;
            this.g = f;
            this.j = d;
            this.i = e
        }
    };

    function QE(a, b) {
        const c = new IE;
        for (const d of a)
            for (const e of b(d)) c.add(e, d);
        return c
    }

    function NE(a) {
        return "A" === a.tagName && a.hasAttribute("href")
    }

    function PE(a, b) {
        return b.length - a.length
    };

    function SE(a) {
        const b = a.l.parentNode;
        if (!b) throw Error("Image not in the DOM");
        const c = TE(a.j),
            d = UE(a.j);
        c.appendChild(d);
        b.insertBefore(c, a.l.nextSibling);
        a.A.g().i(e => {
            var f = a.j;
            const g = d.getBoundingClientRect(),
                h = g.top - e.top,
                k = g.left - e.left,
                l = g.width - e.width;
            e = g.height - e.height;
            1 > Math.abs(h) && 1 > Math.abs(k) && 1 > Math.abs(l) && 1 > Math.abs(e) || (f = f.getComputedStyle(d), A(d, {
                top: parseInt(f.top, 10) - h + "px",
                left: parseInt(f.left, 10) - k + "px",
                width: parseInt(f.width, 10) - l + "px",
                height: parseInt(f.height, 10) - e + "px"
            }))
        });
        return d
    }

    function VE(a) {
        a.g || (a.g = SE(a));
        return a.g
    }
    var WE = class extends U {
        constructor(a, b, c) {
            super();
            this.j = a;
            this.l = b;
            this.A = c;
            this.g = null
        }
        i() {
            if (this.g) {
                var a = this.g;
                const b = a.parentNode;
                b && b.removeChild(a);
                this.g = null
            }
            super.i()
        }
    };

    function UE(a) {
        const b = a.document.createElement("div");
        A(b, Nv(a));
        A(b, {
            position: "absolute",
            left: "0",
            top: "0",
            width: "0",
            height: "0",
            "pointer-events": "none"
        });
        return b
    }

    function TE(a) {
        const b = a.document.createElement("div");
        A(b, Nv(a));
        A(b, {
            position: "relative",
            width: "0",
            height: "0"
        });
        return b
    };

    function XE(a) {
        const b = new V(a.dataset.adStatus || null);
        (new MutationObserver(() => {
            b.g(a.dataset.adStatus || null)
        })).observe(a, {
            attributes: !0
        });
        return fp(b)
    };
    const YE = ["Google Material Icons", "Roboto"];

    function ZE({
        win: a,
        Aa: b,
        Gi: c,
        webPropertyCode: d,
        La: e,
        ba: f
    }) {
        const g = new Kp(a, c);
        c = new WE(a, c, g);
        Yo(c, g);
        a = new $E(a, d, e, b, c, f);
        Yo(a, c);
        a.L()
    }
    var $E = class extends U {
        constructor(a, b, c, d, e, f) {
            super();
            this.win = a;
            this.webPropertyCode = b;
            this.La = c;
            this.Aa = d;
            this.j = e;
            this.ba = f;
            this.g = new V(!1)
        }
        L() {
            const a = aF(this.win, this.webPropertyCode, this.La);
            VE(this.j).appendChild(a.ri);
            wv(this.win, a.wa);
            XE(a.wa).i(b => {
                if (null !== b) {
                    switch (b) {
                        case "unfilled":
                            this.ma();
                            break;
                        case "filled":
                            this.g.g(!0);
                            break;
                        default:
                            this.ba ? .reportError("Unhandled AdStatus: " + String(b)), this.ma()
                    }
                    this.ba ? .rj(this.Aa, b)
                }
            });
            ip(this.g, !0, () => void a.Oi.g(!0));
            a.ki.listen(() => void this.ma());
            a.ji.listen(() => void this.ba ? .pj(this.Aa))
        }
    };

    function aF(a, b, c) {
        const d = new V(!1),
            e = a.document.createElement("div");
        A(e, Nv(a));
        A(e, {
            position: "absolute",
            top: "50%",
            left: "0",
            transform: "translateY(-50%)",
            width: "100%",
            height: "100%",
            overflow: "hidden",
            "background-color": "rgba(0, 0, 0, 0.75)",
            opacity: "0",
            transition: "opacity 0.25s ease-in-out",
            "box-sizing": "border-box",
            padding: "40px 5px 5px 5px"
        });
        W(d, !0, () => void A(e, {
            opacity: "1"
        }));
        W(d, !1, () => void A(e, {
            opacity: "0"
        }));
        const f = a.document.createElement("div");
        A(f, Nv(a));
        A(f, {
            display: "block",
            width: "100%",
            height: "100%"
        });
        e.appendChild(f);
        const {
            zh: g,
            Ni: h
        } = bF(a, b);
        f.appendChild(g);
        e.appendChild(cF(a, P(c, 1)));
        b = dF(a, P(c, 2));
        e.appendChild(b.Th);
        b.pe.listen(() => void d.g(!1));
        return {
            Oi: d,
            ri: e,
            wa: h,
            ji: b.pe,
            ki: b.pe.delay(a, 450)
        }
    }

    function cF(a, b) {
        const c = a.document.createElement("div");
        A(c, Nv(a));
        A(c, {
            position: "absolute",
            top: "10px",
            width: "100%",
            color: "white",
            "font-family": "Roboto",
            "font-size": "12px",
            "line-height": "16px",
            "text-align": "center"
        });
        c.appendChild(a.document.createTextNode(b));
        return c
    }

    function dF(a, b) {
        const c = a.document.createElement("button");
        c.setAttribute("aria-label", b);
        A(c, Nv(a));
        A(c, {
            position: "absolute",
            top: "10px",
            right: "10px",
            display: "block",
            cursor: "pointer",
            width: "24px",
            height: "24px",
            "font-size": "24px",
            "user-select": "none",
            color: "white"
        });
        b = a.document.createElement("gm-icon");
        b.className = "google-material-icons";
        b.appendChild(a.document.createTextNode("close"));
        c.appendChild(b);
        const d = new qp;
        c.addEventListener("click", () => void pp(d));
        return {
            Th: c,
            pe: np(d)
        }
    }

    function bF(a, b) {
        a = sv(a.document, b, null, null, {});
        return {
            zh: a.pb,
            Ni: a.wa
        }
    };

    function eF({
        target: a,
        threshold: b = 0
    }) {
        const c = new fF;
        c.L(a, b);
        return c
    }
    var fF = class extends U {
        constructor() {
            super();
            this.g = new V(!1)
        }
        L(a, b) {
            const c = new IntersectionObserver(d => {
                for (const e of d)
                    if (e.target === a) {
                        this.g.g(e.isIntersecting);
                        break
                    }
            }, {
                threshold: b
            });
            c.observe(a);
            Zo(this, () => void c.disconnect())
        }
    };

    function gF(a) {
        const b = hF(a.win, Ti(a.g, 2) ? ? 250, Ti(a.g, 3) ? ? 300);
        let c = 1;
        return OE(a.l).map(d => ({
            Aa: c++,
            image: d,
            ib: b(d)
        }))
    }

    function iF(a, b) {
        const c = eF({
            target: b.image.g,
            threshold: Ui(a.g) ? ? .8
        });
        a.j.push(c);
        ip(lp(c.g, a.win, Ti(a.g, 5) ? ? 3E3, d => d), !0, () => {
            if (a.i < (Ti(a.g, 1) ? ? 1)) {
                ZE({
                    win: a.win,
                    Aa: b.Aa,
                    Gi: b.image.g,
                    webPropertyCode: a.webPropertyCode,
                    La: a.La,
                    ba: a.ba
                });
                a.i++;
                if (!(a.i < (Ti(a.g, 1) ? ? 1)))
                    for (; a.j.length;) a.j.pop() ? .ma();
                a.ba ? .qj(b.Aa)
            }
        })
    }

    function jF(a) {
        const b = gF(a);
        b.filter(kF).forEach(c => void iF(a, c));
        a.ba ? .sj(b.map(c => ({
            Aa: c.Aa,
            ib: c.ib
        })))
    }
    var lF = class {
        constructor(a, b, c, d, e, f) {
            this.win = a;
            this.webPropertyCode = b;
            this.g = c;
            this.La = d;
            this.l = e;
            this.ba = f;
            this.j = [];
            this.i = 0
        }
    };

    function kF(a) {
        return 0 === a.ib.rejectionReasons.length
    }

    function hF(a, b, c) {
        const d = T(a);
        return e => {
            e = e.g.getBoundingClientRect();
            const f = [];
            e.width < b && f.push(1);
            e.height < c && f.push(2);
            e.top <= d && f.push(3);
            return {
                Cb: e.width,
                Le: e.height,
                li: e.top - d,
                rejectionReasons: f
            }
        }
    };

    function mF(a, b) {
        a.Aa = b;
        return a
    }
    var nF = class {
        constructor(a, b, c, d, e) {
            this.A = a;
            this.webPropertyCode = b;
            this.hostname = c;
            this.j = d;
            this.l = e;
            this.errorMessage = this.i = this.Aa = this.g = null
        }
    };

    function oF(a, b) {
        return new nF(b, a.webPropertyCode, a.hostname, a.i, a.l)
    }

    function pF(a, b, c) {
        var d = a.j++;
        null === a.g ? (a.g = al(), a = 0) : a = al() - a.g;
        var e = b.A,
            f = b.webPropertyCode,
            g = b.hostname,
            h = b.j,
            k = b.l.map(encodeURIComponent).join(",");
        if (b.g) {
            var l = {
                imcnt: b.g.length
            };
            var m = Math.min(b.g.length, 10);
            for (let n = 0; n < m; n++) {
                const p = `im${n}`;
                l[`${p}_id`] = b.g[n].Aa;
                l[`${p}_s_w`] = b.g[n].ib.Cb;
                l[`${p}_s_h`] = b.g[n].ib.Le;
                l[`${p}_s_dbf`] = b.g[n].ib.li;
                0 < b.g[n].ib.rejectionReasons.length && (l[`${p}_s_rej`] = b.g[n].ib.rejectionReasons.join(","))
            }
        } else l = null;
        $z("abg::imovad", {
            typ: e,
            wpc: f,
            hst: g,
            pvsid: h,
            peid: k,
            rate: c,
            num: d,
            tim: a,
            ...(null === b.Aa ? {} : {
                imid: b.Aa
            }),
            ...(null === b.i ? {} : {
                astat: b.i
            }),
            ...(null === b.errorMessage ? {} : {
                errm: b.errorMessage
            }),
            ...l
        }, c)
    }
    var qF = class {
        constructor(a, b, c, d) {
            this.webPropertyCode = a;
            this.hostname = b;
            this.i = c;
            this.l = d;
            this.j = 0;
            this.g = null
        }
        sj(a) {
            var b = oF(this, "fndi");
            b.g = a;
            pF(this, b, 0 < a.length ? 1 : .1)
        }
        qj(a) {
            a = mF(oF(this, "adpl"), a);
            pF(this, a, 1)
        }
        rj(a, b) {
            a = mF(oF(this, "adst"), a);
            a.i = b;
            pF(this, a, 1)
        }
        pj(a) {
            a = mF(oF(this, "adis"), a);
            pF(this, a, 1)
        }
        reportError(a) {
            var b = oF(this, "err");
            b.errorMessage = a;
            pF(this, b, .1)
        }
    };

    function rF(a, b, c) {
        return (a = Cr(a)) && ai(a, 11) ? c.map(d => d.j()) : c.map(d => d.A(b))
    };
    var sF = class extends S {
        getHeight() {
            return xi(this, 2)
        }
    };

    function tF(a, b) {
        return Xi(a, 1, b)
    }

    function uF(a, b) {
        return si(a, 2, b)
    }
    var vF = class extends S {};
    vF.P = [2];
    var wF = class extends S {
        constructor() {
            super()
        }
    };
    wF.P = [5];
    var xF = class extends S {
            constructor() {
                super()
            }
        },
        yF = [1, 2];
    const zF = new Set([7, 1]);
    var AF = class {
        constructor() {
            this.j = new IE;
            this.l = []
        }
        g(a, b) {
            zF.has(b) || lq(kq(eB(a), c => void this.j.add(c, b)), c => void this.l.push(c))
        }
        i(a, b) {
            for (const c of a) this.g(c, b)
        }
    };

    function BF(a) {
        return new Bq(["pedestal_container"], {
            google_reactive_ad_format: 30,
            google_phwr: 2.189,
            google_ad_width: Math.floor(a),
            google_ad_format: "autorelaxed",
            google_full_width_responsive: !0,
            google_enable_content_recommendations: !0,
            google_content_recommendation_ui_type: "pedestal"
        })
    }
    class CF {
        g(a) {
            return BF(Math.floor(a.zc()))
        }
    };
    var DF = class extends S {
        constructor() {
            super()
        }
    };

    function EF(a, b) {
        var c = b.adClient;
        if ("string" !== typeof c || !c) return !1;
        a.Zd = c;
        a.j = !!b.adTest;
        c = b.pubVars;
        Aa(c) && (a.D = c);
        if (Array.isArray(b.fillMessage) && 0 < b.fillMessage.length) {
            a.B = {};
            for (const d of b.fillMessage) a.B[d.key] = d.value
        }
        a.l = b.adWidth;
        a.i = b.adHeight;
        Kk(a.l) && Kk(a.i) || $z("rctnosize", b);
        return !0
    }
    var FF = class {
        constructor() {
            this.B = this.D = this.j = this.Zd = null;
            this.i = this.l = 0
        }
        C() {
            return !0
        }
    };

    function GF(a) {
        try {
            a.setItem("__storage_test__", "__storage_test__");
            const b = a.getItem("__storage_test__");
            a.removeItem("__storage_test__");
            return "__storage_test__" === b
        } catch (b) {
            return !1
        }
    }

    function HF(a, b = []) {
        const c = Date.now();
        return Za(b, d => c - d < 1E3 * a)
    }

    function IF(a, b) {
        try {
            const c = a.getItem("__lsv__");
            if (!c) return [];
            let d;
            try {
                d = JSON.parse(c)
            } catch (e) {}
            if (!Array.isArray(d) || bb(d, e => !Number.isInteger(e))) return a.removeItem("__lsv__"), [];
            d = HF(b, d);
            d.length || a ? .removeItem("__lsv__");
            return d
        } catch (c) {
            return null
        }
    }

    function JF(a, b) {
        return 0 >= b || null == a || !GF(a) ? null : IF(a, b)
    };
    var KF = (a, b, c) => {
        let d = 0;
        try {
            d |= uo(a);
            d |= xo(a);
            d |= vo(a);
            d |= a.innerHeight >= a.innerWidth ? 0 : 8;
            d |= a.navigator && /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
            var e;
            if (e = b) {
                var f = JF(c, 3600);
                e = !(f && 1 > f.length)
            }
            e && (d |= 134217728);
            v(Fb) && (d |= 128)
        } catch (g) {
            d |= 32
        }
        return d
    };
    var LF = class extends FF {
        constructor() {
            super(...arguments);
            this.A = !1;
            this.g = null
        }
        C(a) {
            this.A = !!a.enableAma;
            if (a = a.amaConfig) try {
                var b = Er(a)
            } catch (c) {
                b = null
            } else b = null;
            this.g = b;
            return !0
        }
    };
    const MF = {};

    function NF(a, b, c) {
        let d = OF(a, c, b);
        if (!d) return !0;
        let e = -1;
        const f = c.C.Nb();
        for (; d.ac && d.ac.length;) {
            const h = d.ac.shift();
            var g = GA(h.ha);
            const k = h.ka.g,
                l = !!c.j.nf || !!c.j.wf || c.Ya() || !!c.j.Yf || v(qt) || k > e;
            g = !g || g <= d.Yc;
            if (!l) c.B ? .g(h, 20);
            else if (!g) c.B ? .g(h, 18);
            else if (PF(c, h, {
                    Ed: d.Yc
                })) {
                e = k;
                if (d.Tc.g.length + 1 >= f) return c.B ? .i(d.ac, 19), !0;
                d = OF(a, c, b);
                if (!d) return !0
            }
        }
        return c.l
    }
    const OF = (a, b, c) => {
        var d = b.C.Nb(),
            e = b.C.l,
            f = b.C;
        f = PB(b.da(), f.g ? f.g.mc : void 0, d);
        if (f.g.length >= d) return b.B ? .i(QF(b, f, {
            types: a
        }, c), 19), null;
        e ? (d = f.i || (f.i = Ao(f.j).scrollHeight || null), e = !d || 0 > d ? -1 : f.i * e - VB(f)) : e = void 0;
        const g = (d = null == e || 50 <= e) ? QF(b, f, {
            types: a
        }, c) : null;
        d || b.B ? .i(QF(b, f, {
            types: a
        }, c), 18);
        return {
            Tc: f,
            Yc: e,
            ac: g
        }
    };
    MF[2] = Ka(function(a, b) {
        a = QF(b, PB(b.da()), {
            types: a,
            Eb: xB(b.da())
        }, 2);
        if (0 == a.length) return !0;
        for (var c = 0; c < a.length; c++)
            if (PF(b, a[c])) return !0;
        return b.l ? (b.A.push(11), !0) : !1
    }, [0]);
    MF[5] = Ka(NF, [0], 5);
    MF[10] = Ka(function(a, b) {
        a = [];
        const c = b.Ha;
        c.includes(3) && a.push(2);
        c.includes(1) && a.push(0);
        c.includes(2) && !v(ft) && a.push(1);
        return NF(a, 10, b)
    }, 10);
    MF[3] = function(a) {
        if (!a.l) return !1;
        var b = QF(a, PB(a.da()), {
            types: [0],
            Eb: xB(a.da())
        }, 3);
        if (0 == b.length) return !0;
        for (var c = b.length - 1; 0 <= c; c--)
            if (PF(a, b[c])) return !0;
        a.A.push(11);
        return !0
    };
    const RF = a => {
            var b;
            a.j.qh ? b = v(ht) ? new sB(0, null, [], 8, .3) : new sB(0, null, [], 3, null) : b = xB(a.da());
            return {
                types: [0],
                Eb: b
            }
        },
        TF = a => {
            const b = a.da().document.body.getBoundingClientRect().width;
            SF(a, BF(b))
        },
        VF = (a, b) => {
            var c = RF(a);
            c.tj = [5];
            c = QF(a, PB(a.da()), c, 8);
            UF(a, c.reverse(), b)
        },
        UF = (a, b, c) => {
            for (const d of b)
                if (b = c.g(d.ka), PF(a, d, {
                        ae: b
                    })) return !0;
            return !1
        };
    MF[8] = function(a) {
        var b = a.da().document;
        if ("complete" != b.readyState) return b.addEventListener("readystatechange", () => MF[8](a), {
            once: !0
        }), !0;
        if (!a.l) return !1;
        if (!a.Cd()) return !0;
        b = RF(a);
        b.gf = [2, 4, 5];
        b = QF(a, PB(a.da()), b, 8);
        const c = new CF;
        if (UF(a, b, c)) return !0;
        if (a.j.fg) switch (a.j.Qg || 0) {
            case 1:
                VF(a, c);
                break;
            default:
                TF(a)
        }
        return !0
    };
    MF[6] = Ka(NF, [2], 6);
    MF[7] = Ka(NF, [1], 7);
    MF[9] = function(a) {
        const b = OF([0, 2], a, 9);
        if (!b || !b.ac) return a.A.push(17), a.l;
        for (const d of b.ac) {
            var c = a.j.Ge || null;
            null == c ? c = null : (c = HA(d.ha, new WF, new XF(c, a.da())), c = new gB(c, d.ja(), d.ka));
            if (c && !(GA(c.ha) > b.Yc) && PF(a, c, {
                    Ed: b.Yc,
                    ne: !0
                })) return a = c.ha.Z, EA(d.ha, 0 < a.length ? a[0] : null), !0
        }
        a.A.push(17);
        return a.l
    };
    class WF {
        i(a, b, c, d) {
            return vv(d.document, a, b)
        }
        j(a) {
            return T(a) || 0
        }
    };
    var YF = class {
        constructor(a, b, c) {
            this.i = a;
            this.g = b;
            this.Tc = c
        }
        Da(a) {
            return this.g ? rC(this.i, this.g, a, this.Tc) : qC(this.i, a, this.Tc)
        }
        ya() {
            return this.g ? 16 : 9
        }
    };
    var ZF = class {
        constructor(a) {
            this.be = a
        }
        Da(a) {
            return yC(a.document, this.be)
        }
        ya() {
            return 11
        }
    };
    var $F = class {
        constructor(a) {
            this.wb = a
        }
        Da(a) {
            return vC(this.wb, a)
        }
        ya() {
            return 13
        }
    };
    var aG = class {
        Da(a) {
            return oC(a)
        }
        ya() {
            return 12
        }
    };
    var bG = class {
        constructor(a) {
            this.uc = a
        }
        Da() {
            return tC(this.uc)
        }
        ya() {
            return 2
        }
    };
    var cG = class {
        constructor(a) {
            this.g = a
        }
        Da() {
            return wC(this.g)
        }
        ya() {
            return 3
        }
    };
    var dG = class {
        Da() {
            return zC()
        }
        ya() {
            return 17
        }
    };
    var eG = class {
        constructor(a) {
            this.g = a
        }
        Da() {
            return sC(this.g)
        }
        ya() {
            return 1
        }
    };
    var fG = class {
        Da() {
            return Jb(yA)
        }
        ya() {
            return 7
        }
    };
    var gG = class {
        constructor(a) {
            this.gf = a
        }
        Da() {
            return uC(this.gf)
        }
        ya() {
            return 6
        }
    };
    var hG = class {
        constructor(a) {
            this.g = a
        }
        Da() {
            return xC(this.g)
        }
        ya() {
            return 5
        }
    };
    var iG = class {
        constructor(a, b) {
            this.minWidth = a;
            this.maxWidth = b
        }
        Da() {
            return Ka(AC, this.minWidth, this.maxWidth)
        }
        ya() {
            return 10
        }
    };
    var jG = class {
        constructor(a) {
            this.l = a.i.slice(0);
            this.i = a.g.slice(0);
            this.j = a.j;
            this.A = a.l;
            this.g = a.A
        }
    };

    function kG(a) {
        var b = new lG;
        b.A = a;
        b.i.push(new eG(a));
        return b
    }

    function mG(a, b) {
        a.i.push(new gG(b));
        return a
    }

    function nG(a, b) {
        a.i.push(new bG(b));
        return a
    }

    function oG(a, b) {
        a.i.push(new hG(b));
        return a
    }

    function pG(a, b) {
        a.i.push(new cG(b));
        return a
    }

    function qG(a) {
        a.i.push(new fG);
        return a
    }

    function rG(a) {
        a.g.push(new aG);
        return a
    }

    function sG(a, b = 0, c, d) {
        a.g.push(new YF(b, c, d));
        return a
    }

    function tG(a, b = 0, c = Infinity) {
        a.g.push(new iG(b, c));
        return a
    }

    function uG(a) {
        a.g.push(new dG);
        return a
    }

    function vG(a, b = 0) {
        a.g.push(new $F(b));
        return a
    }

    function wG(a, b) {
        a.j = b;
        return a
    }
    var lG = class {
        constructor() {
            this.j = 0;
            this.l = !1;
            this.i = [].slice(0);
            this.g = [].slice(0)
        }
        build() {
            return new jG(this)
        }
    };
    class XF {
        constructor(a, b) {
            this.i = a;
            this.j = b
        }
        g() {
            var a = this.i,
                b = this.j;
            const c = a.D || {};
            c.google_ad_client = a.Zd;
            c.google_ad_height = T(b) || 0;
            c.google_ad_width = wo(b) || 0;
            c.google_reactive_ad_format = 9;
            b = new DF;
            b = Vi(b, 1, a.A);
            a.g && F(b, 2, a.g);
            c.google_rasc = bj(b);
            a.j && (c.google_adtest = "on");
            return new Bq(["fsi_container"], c)
        }
    };
    var xG = uq(new rq(0, {})),
        yG = uq(new rq(1, {})),
        zG = a => a === xG || a === yG;

    function AG(a, b, c) {
        Lo(a.g, b) || a.g.set(b, []);
        a.g.get(b).push(c)
    }
    class BG {
        constructor() {
            this.g = new Po
        }
    };

    function CG(a, b) {
        b && (a.g.apv = L(b, 4), Yh(b, Yq, 23) && (a.g.sat = "" + vi(C(b, Yq, 23), 1)));
        return a
    }

    function DG(a, b) {
        a.g.afm = b.join(",");
        return a
    }
    var EG = class extends Uz {
        constructor(a) {
            super(a);
            this.g = {}
        }
        H(a) {
            this.g.a = a.join(",");
            return this
        }
        G(a) {
            null != a && (this.g.allp = a);
            return this
        }
        gh(a) {
            if (a) {
                const b = [];
                for (const c of No(a))
                    if (0 < a.get(c).length) {
                        const d = a.get(c)[0];
                        b.push("(" + [c, d.lb, d.sh].join() + ")")
                    }
                this.g.fd = b.join(",")
            }
            return this
        }
        l(a) {
            try {
                this.g.su = a.location.hostname
            } catch (b) {
                this.g.su = "_ex"
            }
            a = super.l(a);
            Vc(a, this.g);
            return a
        }
    };

    function FG(a) {
        return null == a ? null : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function GG(a, b, c, d = 30) {
        c.length <= d ? a[b] = HG(c) : (a[b] = HG(c.slice(0, d)), a[b + "_c"] = c.length.toString())
    }

    function HG(a) {
        const b = 0 < a.length && "string" === typeof a[0];
        a = a.map(c => c ? .toString() ? ? "null");
        b && (a = a.map(c => ma(c, "replaceAll").call(c, "~", "")));
        return a.join("~")
    }

    function IG(a) {
        return null == a ? "null" : "string" === typeof a ? a : "boolean" === typeof a ? a ? "1" : "0" : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function JG(a, b) {
        a.i.op = IG(b)
    }

    function KG(a, b, c) {
        GG(a.i, "fap", b);
        a.i.fad = IG(c)
    }

    function LG(a, b, c) {
        GG(a.i, "fmp", b);
        a.i.fmd = IG(c)
    }

    function MG(a, b, c) {
        GG(a.i, "vap", b);
        a.i.vad = IG(c)
    }

    function NG(a, b, c) {
        GG(a.i, "vmp", b);
        a.i.vmd = IG(c)
    }

    function OG(a, b, c) {
        GG(a.i, "pap", b);
        a.i.pad = IG(c)
    }

    function PG(a, b, c) {
        GG(a.i, "pmp", b);
        a.i.pmd = IG(c)
    }

    function QG(a, b) {
        GG(a.i, "psq", b)
    }
    var RG = class extends EG {
        constructor(a) {
            super(0);
            Object.assign(this, a);
            this.i = {};
            this.errors = []
        }
        l(a) {
            a = super.l(a);
            Object.assign(a, this.i);
            0 < this.errors.length && (a.e = HG(this.errors));
            return a
        }
    };

    function SG(a, b, c) {
        const d = b.ha;
        Lo(a.g, d) || a.g.set(d, new TG(jq(eB(b)) ? ? ""));
        c(a.g.get(d))
    }

    function UG(a, b) {
        SG(a, b, c => {
            c.g = !0
        })
    }

    function VG(a, b) {
        SG(a, b, c => {
            c.i = !0
        })
    }

    function WG(a, b) {
        SG(a, b, c => {
            c.j = !0
        });
        a.I.push(b.ha)
    }

    function XG(a, b, c) {
        SG(a, b, d => {
            d.Tb = c
        })
    }

    function YG(a, b, c) {
        const d = [];
        let e = 0;
        for (const f of c.filter(b)) zG(f.Tb ? ? "") ? ++e : (b = a.i.get(f.Tb ? ? "", null), d.push(b));
        return {
            list: d.sort((f, g) => (f ? ? -1) - (g ? ? -1)),
            Ub: e
        }
    }

    function ZG(a, b) {
        JG(b, a.i.yc());
        var c = Oo(a.g).filter(f => 0 === (f.zb.startsWith(xG) ? 0 : 1)),
            d = Oo(a.g).filter(f => 1 === (f.zb.startsWith(xG) ? 0 : 1)),
            e = YG(a, f => f.g, c);
        KG(b, e.list, e.Ub);
        e = YG(a, f => f.g, d);
        LG(b, e.list, e.Ub);
        e = YG(a, f => f.i, c);
        MG(b, e.list, e.Ub);
        e = YG(a, f => f.i, d);
        NG(b, e.list, e.Ub);
        c = YG(a, f => f.j, c);
        OG(b, c.list, c.Ub);
        d = YG(a, f => f.j, d);
        PG(b, d.list, d.Ub);
        QG(b, a.I.map(f => a.g.get(f) ? .Tb).map(f => a.i.get(f) ? ? null))
    }

    function fm() {
        var a = u($G);
        if (!a.A) return Vl();
        const b = dm(cm(bm(am($l(Zl(Yl(Xl(Ul(Tl(new Wl, a.A ? ? []), a.H ? ? []), a.B), a.G), a.F), a.O), a.T), a.C ? ? 0), Oo(a.g).map(c => {
            var d = new Sl;
            d = aj(d, 1, c.zb);
            var e = a.i.get(c.Tb ? ? "", -1);
            d = Q(d, 2, e);
            d = Wi(d, 3, c.g);
            return Wi(d, 4, c.i)
        })), a.I.map(c => a.g.get(c) ? .Tb).map(c => a.i.get(c) ? ? -1));
        null != a.j && Wi(b, 6, a.j);
        null != a.l && li(b, 13, sh(a.l), "0");
        return b
    }
    var $G = class {
        constructor() {
            this.l = this.H = this.A = null;
            this.F = this.G = !1;
            this.j = null;
            this.T = this.B = this.O = !1;
            this.C = null;
            this.i = new Po;
            this.g = new Po;
            this.I = []
        }
    };
    class TG {
        constructor(a) {
            this.j = this.i = this.g = !1;
            this.Tb = null;
            this.zb = a
        }
    };
    class aH {
        constructor(a = 0) {
            this.g = a
        }
    };
    class bH {
        constructor(a) {
            this.i = a;
            this.g = -1
        }
    };

    function cH(a) {
        let b = 0;
        for (; a;)(!b || a.previousElementSibling || a.nextElementSibling) && b++, a = a.parentElement;
        return b
    };

    function dH(a, b) {
        const c = a.H.filter(d => No(d.jd).every(e => d.jd.get(e) === b.get(e)));
        return 0 === c.length ? (a.i.push(19), null) : c.reduce((d, e) => d.jd.yc() > e.jd.yc() ? d : e, c[0])
    }

    function eH(a, b) {
        b = eB(b);
        if (null == b.g) return a.i.push(18), null;
        b = b.getValue();
        if (Lo(a.j, b)) return a.j.get(b);
        var c = sq(b);
        c = dH(a, c);
        a.j.set(b, c);
        return c
    }
    var fH = class {
        constructor(a) {
            this.g = a;
            this.j = new Po;
            this.H = (C(a, zr, 2) ? .g() || []).map(b => {
                const c = sq(P(b, 1)),
                    d = Qi(b, 2);
                return {
                    jd: c,
                    Vg: d,
                    zb: P(b, 1)
                }
            });
            this.i = []
        }
        F() {
            const a = u($G);
            var b = this.l();
            a.A = b;
            b = this.B();
            a.H = b;
            b = this.A();
            null != b && (a.l = b);
            b = !!this.g.j() ? .g() ? .g();
            a.F = b;
            b = new Po;
            for (const c of C(this.g, zr, 2) ? .g() ? ? []) b.set(P(c, 1), Qi(c, 2));
            a.i = b
        }
        C() {
            return [...this.i]
        }
        l() {
            return [...this.g.g()]
        }
        B() {
            return [...bi(this.g, 4, qh, 2, void 0, void 0, 0)]
        }
        A() {
            return C(this.g, tr, 5) ? .g() ? ? null
        }
        G(a) {
            const b = eH(this,
                a);
            null != b ? .zb && XG(u($G), a, b.zb)
        }
        I(a) {
            const b = w(It) || 0;
            if (0 == a.length || 0 == b) return !0;
            const c = (new bq(a)).filter(d => {
                d = eH(this, d) ? .zb || "";
                return "" != d && !(d === xG || d === yG)
            });
            return b <= c.g.length / a.length
        }
    };

    function gH(a, b) {
        return 0 == b.g.length ? b : b.sort((c, d) => (eH(a.g, c) ? .Vg ? ? Number.MAX_VALUE) - (eH(a.g, d) ? .Vg ? ? Number.MAX_VALUE))
    }

    function hH(a, b) {
        var c = b.ka.g,
            d = Math,
            e = d.min;
        const f = b.ja(),
            g = b.ha.g();
        c += 200 * e.call(d, 20, 0 == g || 3 == g ? cH(f.parentElement) : cH(f));
        d = a.j;
        0 > d.g && (d.g = Ao(d.i).scrollHeight || 0);
        d = d.g - b.ka.g;
        c += 1E3 < d ? 0 : 2 * (1E3 - d);
        a = a.i;
        b = b.ja();
        return c + ("string" === typeof b.className && 0 <= b.className.indexOf("adsbygoogle-ablated-ad-slot") ? a.g : 0)
    }

    function iH(a, b) {
        return 0 == b.g.length ? b : b.sort((c, d) => hH(a, c) - hH(a, d))
    }

    function jH(a, b) {
        return b.sort((c, d) => {
            const e = c.ha.G,
                f = d.ha.G;
            var g;
            null == e || null == f ? g = null == e && null == f ? hH(a, c) - hH(a, d) : null == e ? 1 : -1 : g = e - f;
            return g
        })
    }
    class kH {
        constructor(a, b = 0, c = null) {
            this.j = new bH(a);
            this.i = new aH(b);
            this.g = c && new fH(c)
        }
    };

    function lH(a, b, c = 0, d) {
        var e = a.i;
        for (var f of b.l) e = aq(e, f.Da(a.j), mH(f.ya(), c));
        f = e = e.apply(nC(a.j));
        for (const g of b.i) f = aq(f, g.Da(a.j), oq([nH(g.ya(), c), h => {
            d ? .g(h, g.ya())
        }]));
        switch (b.j) {
            case 1:
                f = iH(a.g, f);
                break;
            case 2:
                f = jH(a.g, f);
                break;
            case 3:
                const g = u($G);
                f = gH(a.g, f);
                e.forEach(h => {
                    UG(g, h);
                    a.g.g ? .G(h)
                });
                f.forEach(h => VG(g, h))
        }
        b.A && (f = dq(f, be(a.j.location.href + a.j.localStorage.google_experiment_mod)));
        1 === b.g ? .length && AG(a.l, b.g[0], {
            lb: e.g.length,
            sh: f.g.length
        });
        return cq(f)
    }
    class oH {
        constructor(a, b, c = 0, d = null) {
            this.i = new bq(a);
            this.g = new kH(b, c, d);
            this.j = b;
            this.l = new BG
        }
        A() {
            this.i.forEach(a => {
                a.i && ev(a.i);
                a.i = null
            })
        }
    }
    const mH = (a, b) => c => DA(c, b, a),
        nH = (a, b) => c => DA(c.ha, b, a);

    function pH(a, b, c, d) {
        a: {
            switch (b) {
                case 0:
                    a = qH(rH(c), a);
                    break a;
                case 3:
                    a = qH(c, a);
                    break a;
                case 2:
                    var e = c.lastChild;
                    a = qH(e ? 1 == e.nodeType ? e : rH(e) : null, a);
                    break a
            }
            a = !1
        }
        if (d = !a && !(!d && 2 == b && !sH(c))) b = 1 == b || 2 == b ? c : c.parentNode,
        d = !(b && !Rs(b) && 0 >= b.offsetWidth);
        return d
    }

    function qH(a, b) {
        if (!a) return !1;
        a = Ye(a, b);
        if (!a) return !1;
        a = a.cssFloat || a.styleFloat;
        return "left" == a || "right" == a
    }

    function rH(a) {
        for (a = a.previousSibling; a && 1 != a.nodeType;) a = a.previousSibling;
        return a ? a : null
    }

    function sH(a) {
        return !!a.nextSibling || !!a.parentNode && sH(a.parentNode)
    };
    var tH = !Ac && !wc();

    function uH(a) {
        if (/-[a-z]/.test("adFormat")) return null;
        if (tH && a.dataset) {
            if (yc() && !("adFormat" in a.dataset)) return null;
            a = a.dataset.adFormat;
            return void 0 === a ? null : a
        }
        return a.getAttribute("data-" + "adFormat".replace(/([A-Z])/g, "-$1").toLowerCase())
    };
    var vH = (a, b, c) => {
            if (!b) return null;
            const d = ke(document, "INS");
            d.id = "google_pedestal_container";
            d.style.width = "100%";
            d.style.zIndex = "-1";
            if (c) {
                var e = a.getComputedStyle(c),
                    f = "";
                if (e && "static" != e.position) {
                    var g = c.parentNode.lastElementChild;
                    for (f = e.position; g && g != c;) {
                        if ("none" != a.getComputedStyle(g).display) {
                            f = a.getComputedStyle(g).position;
                            break
                        }
                        g = g.previousElementSibling
                    }
                }
                if (c = f) d.style.position = c
            }
            b.appendChild(d);
            if (d) {
                var h = a.document;
                f = h.createElement("div");
                f.style.width = "100%";
                f.style.height =
                    "2000px";
                c = T(a);
                e = h.body.scrollHeight;
                a = a.innerHeight;
                g = h.body.getBoundingClientRect().bottom;
                d.appendChild(f);
                var k = f.getBoundingClientRect().top;
                h = h.body.getBoundingClientRect().top;
                d.removeChild(f);
                f = e;
                e <= a && 0 < c && 0 < g && (f = g - h);
                a = k - h >= .8 * f
            } else a = !1;
            return a ? d : (b.removeChild(d), null)
        },
        wH = a => {
            const b = a.document.body;
            var c = vH(a, b, null);
            if (c) return c;
            if (a.document.body) {
                c = Math.floor(a.document.body.getBoundingClientRect().width);
                for (var d = [{
                        element: a.document.body,
                        depth: 0,
                        height: 0
                    }], e = -1, f = null; 0 < d.length;) {
                    const h =
                        d.pop(),
                        k = h.element;
                    var g = h.height;
                    0 < h.depth && g > e && (e = g, f = k);
                    if (5 > h.depth)
                        for (g = 0; g < k.children.length; g++) {
                            const l = k.children[g],
                                m = l.getBoundingClientRect().width;
                            (null == m || null == c ? 0 : m >= .9 * c && m <= 1.01 * c) && d.push({
                                element: l,
                                depth: h.depth + 1,
                                height: l.getBoundingClientRect().height
                            })
                        }
                }
                c = f
            } else c = null;
            return c ? vH(a, c.parentNode || b, c) : null
        },
        yH = a => {
            let b = 0;
            try {
                b |= uo(a), ue() || (b |= 1048576), 1200 >= Math.floor(a.document.body.getBoundingClientRect().width) || (b |= 32768), xH(a) && (b |= 33554432)
            } catch (c) {
                b |= 32
            }
            return b
        },
        xH = a => {
            a = a.document.getElementsByClassName("adsbygoogle");
            for (let b = 0; b < a.length; b++)
                if ("autorelaxed" == uH(a[b])) return !0;
            return !1
        };

    function zH(a) {
        const b = zo(a, !0),
            c = Ao(a).scrollWidth,
            d = Ao(a).scrollHeight;
        let e = "unknown";
        a && a.document && a.document.readyState && (e = a.document.readyState);
        var f = Eo(a);
        const g = [];
        var h = [];
        const k = [],
            l = [];
        var m = [],
            n = [],
            p = [];
        let q = 0,
            x = 0,
            z = Infinity,
            G = Infinity,
            E = null;
        var K = LB({
            Qb: !1
        }, a);
        for (var H of K) {
            K = H.getBoundingClientRect();
            const Ea = b - (K.bottom + f);
            var N = void 0,
                J = void 0;
            if (H.className && kc(H.className, "adsbygoogle-ablated-ad-slot")) {
                N = H.getAttribute("google_element_uid");
                J = a.google_sv_map;
                if (!N || !J ||
                    !J[N]) continue;
                N = (J = Uk(J[N])) ? J.height : 0;
                J = J ? J.width : 0
            } else if (N = K.bottom - K.top, J = K.right - K.left, 1 >= N || 1 >= J) continue;
            g.push(N);
            k.push(J);
            l.push(N * J);
            H.className && kc(H.className, "google-auto-placed") ? (x += 1, H.className && kc(H.className, "pedestal_container") && (E = N)) : (z = Math.min(z, Ea), n.push(K), q += 1, h.push(N), m.push(N * J));
            G = Math.min(G, Ea);
            p.push(K)
        }
        z = Infinity === z ? null : z;
        G = Infinity === G ? null : G;
        f = AH(n);
        p = AH(p);
        h = BH(b, h);
        n = BH(b, g);
        m = BH(b * c, m);
        H = BH(b * c, l);
        return new CH(a, {
            mi: e,
            Kc: b,
            ej: c,
            dj: d,
            Ui: q,
            Ih: x,
            Kh: DH(g),
            Lh: DH(k),
            Jh: DH(l),
            Zi: f,
            Yi: p,
            Xi: z,
            Wi: G,
            we: h,
            ue: n,
            Dh: m,
            Ch: H,
            gj: E
        })
    }

    function EH(a, b, c, d) {
        const e = ue() && !(900 <= wo(a.i));
        d = Za(d, f => db(a.j, f)).join(",");
        return {
            wpc: b,
            su: c,
            eid: d,
            doc: a.g.mi,
            pg_h: FH(a.g.Kc),
            pg_w: FH(a.g.ej),
            pg_hs: FH(a.g.dj),
            c: FH(a.g.Ui),
            aa_c: FH(a.g.Ih),
            av_h: FH(a.g.Kh),
            av_w: FH(a.g.Lh),
            av_a: FH(a.g.Jh),
            s: FH(a.g.Zi),
            all_s: FH(a.g.Yi),
            b: FH(a.g.Xi),
            all_b: FH(a.g.Wi),
            d: FH(a.g.we),
            all_d: FH(a.g.ue),
            ard: FH(a.g.Dh),
            all_ard: FH(a.g.Ch),
            pd_h: FH(a.g.gj),
            dt: e ? "m" : "d"
        }
    }
    class CH {
        constructor(a, b) {
            this.i = a;
            this.g = b;
            this.j = "633794002 633794005 21066126 21066127 21065713 21065714 21065715 21065716 42530887 42530888 42530889 42530890 42530891 42530892 42530893".split(" ")
        }
    }

    function DH(a) {
        return Wd.apply(null, Za(a, b => 0 < b)) || null
    }

    function BH(a, b) {
        return 0 >= a ? null : Vd.apply(null, b) / a
    }

    function AH(a) {
        let b = Infinity;
        for (let e = 0; e < a.length - 1; e++)
            for (let f = e + 1; f < a.length; f++) {
                var c = a[e],
                    d = a[f];
                c = Math.max(Math.max(0, c.left - d.right, d.left - c.right), Math.max(0, c.top - d.bottom, d.top - c.bottom));
                0 < c && (b = Math.min(c, b))
            }
        return Infinity !== b ? b : null
    }

    function FH(a) {
        return null == a ? null : Number.isInteger(a) ? a.toString() : a.toFixed(3)
    };

    function GH(a, b) {
        b = (T(b) || 0) - Eo(b);
        let c = 0;
        for (let d = 0; d < a.length; d++) {
            const e = a[d].getBoundingClientRect();
            TB(e) && e.top <= b && (c += 1)
        }
        return c
    }

    function HH(a) {
        const b = {};
        var c = NB({
            Qb: !1,
            wd: !1,
            xd: !1,
            yd: !1
        }, a).map(d => d.getBoundingClientRect()).filter(TB);
        b.Cf = c.length;
        c = OB({
            xd: !0
        }, a).map(d => d.getBoundingClientRect()).filter(TB);
        b.eg = c.length;
        c = OB({
            yd: !0
        }, a).map(d => d.getBoundingClientRect()).filter(TB);
        b.Jg = c.length;
        c = OB({
            wd: !0
        }, a).map(d => d.getBoundingClientRect()).filter(TB);
        b.Hf = c.length;
        c = (T(a) || 0) - Eo(a);
        c = NB({
            Qb: !1
        }, a).map(d => d.getBoundingClientRect()).filter(TB).filter(Ja(IH, null, c));
        b.Df = c.length;
        a = zH(a);
        c = null != a.g.we ? a.g.we : null;
        null !=
            c && (b.Ag = c);
        a = null != a.g.ue ? a.g.ue : null;
        null != a && (b.Ef = a);
        return b
    }

    function PF(a, b, {
        Ed: c,
        ae: d,
        ne: e
    } = {}) {
        return Dv(997, () => JH(a, b, {
            Ed: c,
            ae: d,
            ne: e
        }), a.g)
    }

    function QF(a, b, c, d) {
        var e = c.Eb ? c.Eb : a.C;
        const f = yB(e, b.g.length);
        e = a.j.Ff ? e.g : void 0;
        const g = uG(vG(rG(tG(sG(qG(oG(pG(mG(nG(kG(c.types), a.ga), c.gf || []), a.Z), c.tj || [])), f.Jc || void 0, e, b), c.minWidth, c.maxWidth)), f.wb || void 0));
        a.T && g.g.push(new ZF(a.T));
        b = 1;
        a.j.wf ? b = 2 : a.Ya() && (b = 3);
        wG(g, b);
        a.j.nf && (g.l = !0);
        return Dv(995, () => lH(a.i, g.build(), d, a.B || void 0), a.g)
    }

    function SF(a, b) {
        const c = wH(a.g);
        if (c) {
            const d = Aq(a.I, b),
                e = sv(a.g.document, a.G, null, null, {}, d);
            e && (hv(e.pb, c, 2, 256), Dv(996, () => KH(a, e, d), a.g))
        }
    }

    function LH(a) {
        return a.F ? a.F : a.F = a.g.google_ama_state
    }

    function JH(a, b, {
        Ed: c,
        ae: d,
        ne: e
    } = {}) {
        const f = b.ha;
        if (f.A) return !1;
        var g = b.ja(),
            h = f.g();
        if (!pH(a.g, h, g, a.l)) return !1;
        h = null;
        f.Dc ? .includes(6) ? (h = Math.round(g.getBoundingClientRect().height), h = new Bq(null, {
            google_max_responsive_height: null == c ? h : Math.min(c, h),
            google_full_width_responsive: "false"
        })) : h = null == c ? null : new Bq(null, {
            google_max_responsive_height: c
        });
        c = Cq(M(f.Td, 2) || 0);
        g = Dq(f.G);
        const k = MH(a, f),
            l = NH(a),
            m = Aq(a.I, f.T ? f.T.g(b.ka) : null, h, d || null, c, g, k, l),
            n = b.fill(a.G, m);
        if (e && !OH(a, n, m) || !Dv(996,
                () => KH(a, n, m), a.g)) return !1;
        gk(9, [f.G, f.Rb]);
        a.Ya() && WG(u($G), b);
        return !0
    }

    function MH(a, b) {
        return jq(lq(cB(b).map(Eq), () => {
            a.A.push(18)
        }))
    }

    function NH(a) {
        if (!a.Ya()) return null;
        var b = a.i.g.g ? .B();
        if (null == b) return null;
        b = b.join("~");
        a = a.i.g.g ? .A() ? ? null;
        return Fq({
            fi: b,
            ui: a
        })
    }

    function OH(a, b, c) {
        if (!b) return !1;
        var d = b.wa,
            e = d.style.width;
        d.style.width = "100%";
        var f = d.offsetWidth;
        d.style.width = e;
        d = a.g;
        e = b.wa;
        c = c && c.Ac() || {};
        if (d !== d.top) var g = Ve(d) ? 3 : 16;
        else if (488 > wo(d))
            if (d.innerHeight >= d.innerWidth)
                if (g = wo(d), !g || .3 < (g - f) / g) g = 6;
                else {
                    if (g = "true" != c.google_full_width_responsive) b: {
                        var h = e.parentElement;
                        for (g = wo(d); h; h = h.parentElement) {
                            const k = Ye(h, d);
                            if (!k) continue;
                            const l = hf(k.width);
                            if (l && !(l >= g) && "visible" != k.overflow) {
                                g = !0;
                                break b
                            }
                        }
                        g = !1
                    }
                    g = g ? 7 : !0
                }
        else g = 5;
        else g = 4;
        if (!0 !==
            g) f = g;
        else {
            if (!(c = "true" == c.google_full_width_responsive)) a: {
                do
                    if ((c = Ye(e, d)) && "fixed" == c.position) {
                        c = !1;
                        break a
                    }
                while (e = e.parentElement);
                c = !0
            }
            c ? (d = wo(d), f = d - f, f = d && 0 <= f ? !0 : d ? -10 > f ? 11 : 0 > f ? 14 : 12 : 10) : f = 9
        }
        if (f) {
            a = a.g;
            b = b.wa;
            if (f = ov(a, b)) b.style.border = b.style.borderStyle = b.style.outline = b.style.outlineStyle = b.style.transition = "none", b.style.borderSpacing = b.style.padding = "0", mv(b, f, "0px"), b.style.width = wo(a) + "px", pv(a, b, f), b.style.zIndex = 30;
            return !0
        }
        ev(b.pb);
        return !1
    }

    function KH(a, b, c) {
        if (!b) return !1;
        try {
            wv(a.g, b.wa, c)
        } catch (d) {
            return ev(b.pb), a.A.push(6), !1
        }
        return !0
    }
    class PH {
        constructor(a, b, c, d, e = {}, f = [], g = !1) {
            this.i = a;
            this.G = b;
            this.g = c;
            this.C = d.Eb;
            this.ga = d.uc || [];
            this.I = d.vi || null;
            this.Z = d.ii || [];
            this.T = d.be || [];
            this.j = e;
            this.l = !1;
            this.O = [];
            this.A = [];
            this.H = this.F = void 0;
            this.Ha = f;
            this.B = g ? new AF : null
        }
        va() {
            return this.i
        }
        da() {
            return this.g
        }
        xa(a) {
            this.O.push(a)
        }
        Ya() {
            if (0 == (this.i.g.g ? .l().length ? ? 0)) return !1;
            if (0 == (w(It) || 0)) return !0;
            if (void 0 === this.H) {
                const a = wG(rG(qG(kG([0, 1, 2]))), 1).build(),
                    b = Dv(995, () => lH(this.i, a), this.g);
                this.H = this.i.g.g ? .I(b) || !1
            }
            return this.H
        }
        Pe() {
            return !!this.j.Zg
        }
        Cd() {
            return !xH(this.g)
        }
        pa() {
            return this.B
        }
    }
    const IH = (a, b) => b.top <= a;

    function QH(a, b, c, d, e, f = 0, g = 0) {
        this.Sa = a;
        this.Od = f;
        this.Nd = g;
        this.errors = b;
        this.Bb = c;
        this.g = d;
        this.i = e
    };
    var RH = (a, {
        Cd: b = !1,
        Pe: c = !1,
        wj: d = !1,
        Ya: e = !1
    } = {}) => {
        const f = [];
        d && f.push(9);
        if (e) {
            a.includes(4) && !c && b && f.push(8);
            a.includes(1) && f.push(1);
            d = a.includes(3);
            e = a.includes(2) && !v(ft);
            const g = a.includes(1);
            (d || e || g) && f.push(10)
        } else a.includes(3) && f.push(6), a.includes(4) && !c && b && f.push(8), a.includes(1) && f.push(1, 5), a.includes(2) && !v(ft) && f.push(7);
        a.includes(4) && c && b && f.push(8);
        return f
    };

    function SH(a, b, c) {
        a = RH(a, {
            Cd: b.Cd(),
            Pe: b.Pe(),
            wj: !!b.j.Ge,
            Ya: b.Ya()
        });
        return new TH(a, b, c)
    }

    function UH(a, b) {
        const c = MF[b];
        return c ? Dv(998, () => c(a.g), a.A) : (a.g.xa(12), !0)
    }

    function VH(a, b) {
        return new Promise(c => {
            setTimeout(() => {
                c(UH(a, b))
            })
        })
    }

    function WH(a) {
        a.g.l = !0;
        return Promise.all(a.i.map(b => VH(a, b))).then(b => {
            b.includes(!1) && a.g.xa(5);
            a.i.splice(0, a.i.length)
        })
    }
    class TH {
        constructor(a, b, c) {
            this.l = a.slice(0);
            this.i = a.slice(0);
            this.j = eb(this.i, 1);
            this.g = b;
            this.A = c
        }
    };
    const XH = class {
        constructor(a) {
            this.g = a;
            this.exception = void 0
        }
    };

    function YH(a) {
        return WH(a).then(() => {
            var b = a.g.i.i.filter(yA).g.length;
            var c = a.g.O.slice(0);
            var d = a.g;
            d = [...d.A, ...(d.i.g.g ? .C() || [])];
            b = new QH(b, c, d, a.g.i.i.g.length, a.g.i.l.g, a.g.i.i.filter(yA).filter(zA).g.length, a.g.i.i.filter(zA).g.length);
            return new XH(b)
        })
    };
    var ZH = a => {
            let b = 0;
            a.forEach(c => b = Math.max(b, c.getBoundingClientRect().width));
            return c => c.getBoundingClientRect().width > .5 * b
        },
        $H = a => {
            const b = T(a) || 0;
            return c => c.getBoundingClientRect().height >= .75 * b
        };
    var aI = (a, b) => {
        b = YA(b, a);
        const c = b.map(d => d.g);
        b = b.filter(d => {
            d = d.g.getBoundingClientRect();
            return 0 < d.width && 0 < d.height
        }).filter(d => ZH(c)(d.g)).filter(d => $H(a)(d.g));
        b.sort((d, e) => {
            e = e.g;
            return d.g.getBoundingClientRect().top - e.getBoundingClientRect().top
        });
        return b
    };

    function bI(a) {
        return a.reduce((b, c) => b.g.getBoundingClientRect().bottom < c.g.getBoundingClientRect().bottom ? c : b)
    }

    function cI(a, b, c, d) {
        let e = !1;
        const f = new IntersectionObserver(g => {
            for (const h of g)
                if (h.isIntersecting) e = !0;
                else {
                    if (g = e) g = a, g = b.getBoundingClientRect().bottom <= T(g.win) / 2;
                    g && (dI(a.ba, {
                        typ: "cee",
                        cet: c
                    }), e = !1)
                }
        }, {
            rootMargin: d
        });
        f.observe(b);
        Zo(a, () => {
            f.disconnect()
        })
    }
    var eI = class extends U {
        constructor(a, b, c) {
            super();
            this.win = a;
            this.g = b;
            this.ba = c
        }
    };

    function fI(a, b) {
        dI(a, {
            typ: "cdr",
            af: b.ie,
            ...(0 < b.ie ? {
                vh: b.U,
                ph: b.Kc,
                ah: b.Eh,
                at: b.Gh
            } : {})
        })
    }

    function dI(a, b) {
        a = { ...b,
            wpc: a.webPropertyCode,
            cor: a.g,
            tim: Math.round(bl() ? ? -1),
            num: a.i++
        };
        $z("ama_vignette", a, 1)
    }
    var gI = class {
        constructor(a) {
            var b = Af();
            this.webPropertyCode = a;
            this.g = b;
            this.i = 0
        }
    };
    class hI {
        g() {
            return new Bq([], {
                google_reactive_ad_format: 40,
                google_tag_origin: "qs"
            })
        }
    };
    class iI {
        g() {
            return new Bq(["adsbygoogle-resurrected-ad-slot"], {})
        }
    };

    function jI(a) {
        return Ss(a.g.document).map(b => {
            const c = new rA(b, 3);
            b = new tA(yv(a.g, b));
            return new xA(c, b, a.i, !1, 0, [], null, a.g, null)
        })
    }
    class kI {
        constructor(a) {
            var b = new iI;
            this.g = a;
            this.i = b || null
        }
    };
    const lI = {
        uf: "10px",
        ke: "10px"
    };

    function mI(a) {
        return Ko(a.g.document.querySelectorAll("INS.adsbygoogle-placeholder")).map(b => new xA(new rA(b, 1), new pA(lI), a.i, !1, 0, [], null, a.g, null))
    }
    class nI {
        constructor(a, b) {
            this.g = a;
            this.i = b || null
        }
    };

    function oI(a, b) {
        const c = [];
        b.forEach((d, e) => {
            c.push(ma(e, "replaceAll").call(e, "~", "_") + "--" + d.map(f => Number(f)).join("_"))
        });
        GG(a.i, "cnstr", c, 80)
    }
    var pI = class extends Uz {
        constructor() {
            super(-1);
            this.i = {}
        }
        l(a) {
            a = super.l(a);
            Object.assign(a, this.i);
            return a
        }
    };

    function qI(a, b) {
        return null == a ? b + "ShouldNotBeNull" : 0 == a ? b + "ShouldNotBeZero" : -1 > a ? b + "ShouldNotBeLessMinusOne" : null
    }

    function rI(a, b, c) {
        const d = qI(c.qd, "gapsMeasurementWindow") || qI(c.xc, "gapsPerMeasurementWindow") || qI(c.Gc, "maxGapsToReport");
        return null != d ? hq(Error(d)) : c.Gf || -1 != c.xc || -1 != c.Gc ? fq(new sI(a, b, c)) : hq(Error("ShouldHaveLimits"))
    }

    function tI(a) {
        return LH(a.j) && LH(a.j).placed || []
    }

    function uI(a) {
        return tI(a).map(b => Tp(Rp(b.element, a.g)))
    }

    function vI(a) {
        return tI(a).map(b => b.index)
    }

    function wI(a, b) {
        const c = b.ha;
        return !a.B && c.l && null != M(c.l, 8) && 1 == M(c.l, 8) ? [] : c.A ? (c.Z || []).map(d => Tp(Rp(d, a.g))) : [Tp(new Sp(b.ka.g, 0))]
    }

    function xI(a) {
        a.sort((e, f) => e.g - f.g);
        const b = [];
        let c = 0;
        for (let e = 0; e < a.length; ++e) {
            var d = a[e];
            let f = d.g;
            d = d.g + d.i;
            f <= c ? c = Math.max(c, d) : (b.push(new Sp(c, f - c)), c = d)
        }
        return b
    }

    function yI(a, b) {
        b = b.map(c => {
            var d = new sF;
            d = Xi(d, 1, c.g);
            c = c.getHeight();
            return Xi(d, 2, c)
        });
        return uF(tF(new vF, a), b)
    }

    function zI(a) {
        const b = D(a, sF, 2).map(c => `G${xi(c,1)}~${c.getHeight()}`);
        return `W${xi(a,1)}${b.join("")}`
    }

    function AI(a, b) {
        const c = [];
        let d = 0;
        for (const e of No(b)) {
            const f = b.get(e);
            f.sort((g, h) => h.getHeight() - g.getHeight());
            a.F || f.splice(a.A, f.length);
            !a.C && d + f.length > a.i && f.splice(a.i - d, f.length);
            c.push(yI(e, f));
            d += f.length;
            if (!a.C && d >= a.i) break
        }
        return c
    }

    function BI(a) {
        const b = D(a, vF, 5).map(c => zI(c));
        return `M${xi(a,1)}H${xi(a,2)}C${xi(a,3)}B${Number(!!O(a,4))}${b.join("")}`
    }

    function CI(a) {
        var b = hB(cq(a.j.i.i), a.g),
            c = uI(a),
            d = new Qo(vI(a));
        for (var e = 0; e < b.length; ++e)
            if (!d.contains(e)) {
                var f = wI(a, b[e]);
                c.push(...f)
            }
        c.push(new Sp(0, 0));
        c.push(Tp(new Sp(Ao(a.g).scrollHeight, 0)));
        b = xI(c);
        c = new Po;
        for (d = 0; d < b.length; ++d) e = b[d], f = a.G ? 0 : Math.floor(e.g / a.l), Lo(c, f) || c.set(f, []), c.get(f).push(e);
        b = AI(a, c);
        c = new wF;
        c = Xi(c, 1, a.i);
        c = Xi(c, 2, a.l);
        c = Xi(c, 3, a.A);
        a = Vi(c, 4, a.B);
        return si(a, 5, b)
    }

    function DI(a) {
        a = CI(a);
        return BI(a)
    }
    var sI = class {
        constructor(a, b, c) {
            this.G = -1 == c.qd;
            this.l = c.qd;
            this.F = -1 == c.xc;
            this.A = c.xc;
            this.C = -1 == c.Gc;
            this.i = c.Gc;
            this.B = c.rg;
            this.j = b;
            this.g = a
        }
    };
    const EI = {
        google_ad_channel: !0,
        google_ad_host: !0
    };

    function FI(a, b) {
        a.location.href && a.location.href.substring && (b.url = a.location.href.substring(0, 200));
        $z("ama", b, .01)
    }

    function GI(a) {
        const b = {};
        $e(EI, (c, d) => {
            d in a && (b[d] = a[d])
        });
        return b
    };

    function HI(a) {
        const b = /[a-zA-Z0-9._~-]/,
            c = /%[89a-zA-Z]./;
        return a.replace(/(%[a-zA-Z0-9]{2})/g, d => {
            if (!d.match(c)) {
                const e = decodeURIComponent(d);
                if (e.match(b)) return e
            }
            return d.toUpperCase()
        })
    }

    function II(a) {
        let b = "";
        const c = /[/%?&=]/;
        for (let d = 0; d < a.length; ++d) {
            const e = a[d];
            b = e.match(c) ? b + e : b + encodeURIComponent(e)
        }
        return b
    };

    function JI(a, b) {
        a = bi(a, 2, fh, 2);
        if (!a) return !1;
        for (let c = 0; c < a.length; c++)
            if (a[c] == b) return !0;
        return !1
    }

    function KI(a, b) {
        a = II(HI(a.location.pathname)).replace(/(^\/)|(\/$)/g, "");
        const c = bf(a),
            d = LI(a);
        return b.find(e => {
            const f = Yh(e, Pq, 7) ? jh(Uh(C(e, Pq, 7), 1)) : jh(Uh(e, 1));
            e = Yh(e, Pq, 7) ? M(C(e, Pq, 7), 2) : 2;
            if ("number" !== typeof f) return !1;
            switch (e) {
                case 1:
                    return f == c;
                case 2:
                    return d[f] || !1
            }
            return !1
        }) || null
    }

    function LI(a) {
        const b = {};
        for (;;) {
            b[bf(a)] = !0;
            if (!a) return b;
            a = a.substring(0, a.lastIndexOf("/"))
        }
    };
    var NI = a => {
            try {
                MI(a, a.localStorage)
            } catch (b) {
                FI(a, {
                    lserr: 1
                })
            }
        },
        MI = (a, b) => {
            try {
                b.removeItem("google_ama_config")
            } catch (c) {
                FI(a, {
                    lserr: 1
                })
            }
        };

    function OI(a) {
        if (v(gt)) var b = null;
        else try {
            b = a.getItem("google_ama_config")
        } catch (d) {
            b = null
        }
        try {
            var c = b ? Er(b) : null
        } catch (d) {
            c = null
        }
        return c
    };

    function PI(a) {
        return a.google_ad_modifications = a.google_ad_modifications || {}
    }

    function QI(a, b) {
        a = PI(a);
        a.processed_sra_frame_pingbacks = a.processed_sra_frame_pingbacks || {};
        const c = !a.processed_sra_frame_pingbacks[b];
        a.processed_sra_frame_pingbacks[b] = !0;
        return c
    };

    function RI(a) {
        let b = a.location.href;
        if (a === a.top) return {
            url: b,
            Qe: !0
        };
        let c = !1;
        const d = a.document;
        d && d.referrer && (b = d.referrer, a.parent === a.top && (c = !0));
        (a = a.location.ancestorOrigins) && (a = a[a.length - 1]) && -1 === b.indexOf(a) && (c = !1, b = a);
        return {
            url: b,
            Qe: c
        }
    };

    function SI(a, b) {
        $e(a, (c, d) => {
            b[d] = c
        })
    }
    var TI = a => {
        if (a == a.top) return 0;
        for (; a && a != a.top && Se(a); a = a.parent) {
            if (a.sf_) return 2;
            if (a.$sf) return 3;
            if (a.inGptIF) return 4;
            if (a.inDapIF) return 5
        }
        return 1
    };

    function UI() {
        if (VI) return VI;
        const a = tk() || window,
            b = a.google_persistent_state_async;
        return null != b && "object" == typeof b && null != b.S && "object" == typeof b.S ? VI = b : a.google_persistent_state_async = VI = new WI
    }

    function XI(a, b, c) {
        b = YI[b] || `google_ps_${b}`;
        a = a.S;
        const d = a[b];
        return void 0 === d ? (a[b] = c(), a[b]) : d
    }

    function Z(a, b, c) {
        return XI(a, b, () => c)
    }

    function ZI(a, b, c) {
        return a.S[YI[b] || `google_ps_${b}`] = c
    }

    function $I(a, b) {
        return ZI(a, b, Z(a, b, 0) + 1)
    }

    function aJ() {
        var a = UI();
        return Z(a, 20, {})
    }

    function bJ() {
        var a = UI();
        const b = Z(a, 31, !1);
        b || ZI(a, 31, !0);
        return !b
    }

    function cJ() {
        var a = UI();
        return Z(a, 26)
    }

    function dJ() {
        var a = UI();
        return Z(a, 28, [])
    }

    function eJ() {
        var a = UI();
        return XI(a, 39, fJ)
    }
    var WI = class {
            constructor() {
                this.S = {}
            }
        },
        VI = null;
    const YI = {
        [8]: "google_prev_ad_formats_by_region",
        [9]: "google_prev_ad_slotnames_by_region"
    };
    var gJ = {
            google_ad_block: "ad_block",
            google_ad_client: "client",
            google_ad_output: "output",
            google_ad_callback: "callback",
            google_ad_height: "h",
            google_ad_resize: "twa",
            google_ad_slot: "slotname",
            google_ad_unit_key: "adk",
            google_ad_dom_fingerprint: "adf",
            google_placement_id: "pi",
            google_daaos_ts: "daaos",
            google_erank: "epr",
            google_ad_width: "w",
            google_captcha_token: "captok",
            google_content_recommendation_columns_num: "cr_col",
            google_content_recommendation_rows_num: "cr_row",
            google_ctr_threshold: "ctr_t",
            google_cust_criteria: "cust_params",
            gfwrnwer: "fwrn",
            gfwrnher: "fwrnh",
            google_image_size: "image_size",
            google_last_modified_time: "lmt",
            google_loeid: "loeid",
            google_max_num_ads: "num_ads",
            google_max_radlink_len: "max_radlink_len",
            google_mtl: "mtl",
            google_native_settings_key: "nsk",
            google_enable_content_recommendations: "ecr",
            google_num_radlinks: "num_radlinks",
            google_num_radlinks_per_unit: "num_radlinks_per_unit",
            google_pucrd: "pucrd",
            google_reactive_plaf: "plaf",
            google_reactive_plat: "plat",
            google_reactive_fba: "fba",
            google_reactive_sra_channels: "plach",
            google_responsive_auto_format: "rafmt",
            armr: "armr",
            google_plas: "plas",
            google_rl_dest_url: "rl_dest_url",
            google_rl_filtering: "rl_filtering",
            google_rl_mode: "rl_mode",
            google_rt: "rt",
            google_video_play_muted: "vpmute",
            google_source_type: "src_type",
            google_restrict_data_processing: "rdp",
            google_tag_for_child_directed_treatment: "tfcd",
            google_tag_for_under_age_of_consent: "tfua",
            google_tag_origin: "to",
            google_ad_semantic_area: "sem",
            google_tfs: "tfs",
            google_package: "pwprc",
            google_tag_partner: "tp",
            fra: "fpla",
            google_ml_rank: "mlr",
            google_apsail: "psa",
            google_ad_channel: "channel",
            google_ad_type: "ad_type",
            google_ad_format: "format",
            google_color_bg: "color_bg",
            google_color_border: "color_border",
            google_color_link: "color_link",
            google_color_text: "color_text",
            google_color_url: "color_url",
            google_page_url: "url",
            google_allow_expandable_ads: "ea",
            google_ad_section: "region",
            google_cpm: "cpm",
            google_encoding: "oe",
            google_safe: "adsafe",
            google_font_face: "f",
            google_font_size: "fs",
            google_hints: "hints",
            google_ad_host: "host",
            google_ad_host_channel: "h_ch",
            google_ad_host_tier_id: "ht_id",
            google_kw_type: "kw_type",
            google_kw: "kw",
            google_contents: "contents",
            google_targeting: "targeting",
            google_adtest: "adtest",
            google_alternate_color: "alt_color",
            google_alternate_ad_url: "alternate_ad_url",
            google_cust_age: "cust_age",
            google_cust_ch: "cust_ch",
            google_cust_gender: "cust_gender",
            google_cust_interests: "cust_interests",
            google_cust_job: "cust_job",
            google_cust_l: "cust_l",
            google_cust_lh: "cust_lh",
            google_cust_u_url: "cust_u_url",
            google_cust_id: "cust_id",
            google_language: "hl",
            google_city: "gcs",
            google_country: "gl",
            google_region: "gr",
            google_content_recommendation_ad_positions: "ad_pos",
            google_content_recommendation_columns_num: "cr_col",
            google_content_recommendation_rows_num: "cr_row",
            google_content_recommendation_ui_type: "crui",
            google_content_recommendation_use_square_imgs: "cr_sq_img",
            google_color_line: "color_line",
            google_disable_video_autoplay: "disable_video_autoplay",
            google_full_width_responsive_allowed: "fwr",
            google_full_width_responsive: "fwrattr",
            efwr: "efwr",
            google_pgb_reactive: "pra",
            google_resizing_allowed: "rs",
            google_resizing_height: "rh",
            google_resizing_width: "rw",
            rpe: "rpe",
            google_responsive_formats: "resp_fmts",
            google_safe_for_responsive_override: "sfro",
            google_video_doc_id: "video_doc_id",
            google_video_product_type: "video_product_type",
            google_webgl_support: "wgl",
            easpi: "easpi",
            asptt: "asptt",
            asro: "asro",
            sugawps: "aseaascu",
            asla: "aslmt",
            asaa: "asamt",
            sedf: "asedf",
            sefa: "asefa",
            seiel: "aseiel",
            slcwct: "aslcwct",
            sacwct: "asacwct",
            slmct: "aslmct",
            samct: "asamct",
            vmsli: "itsi"
        },
        hJ = a => (a = a.innerText ||
            a.innerHTML) && (a = a.replace(/^\s+/, "").split(/\r?\n/, 1)[0].match(/^\x3c!--+(.*?)(?:--+>)?\s*$/)) && RegExp("google_ad_client").test(a[1]) ? a[1] : null,
        iJ = a => {
            if (a = a.innerText || a.innerHTML)
                if (a = a.replace(/^\s+|\s+$/g, "").replace(/\s*(\r?\n)+\s*/g, ";"), (a = a.match(/^\x3c!--+(.*?)(?:--+>)?$/) || a.match(/^\/*\s*<!\[CDATA\[(.*?)(?:\/*\s*\]\]>)?$/i)) && RegExp("google_ad_client").test(a[1])) return a[1];
            return null
        },
        jJ = a => {
            switch (a) {
                case "true":
                    return !0;
                case "false":
                    return !1;
                case "null":
                    return null;
                case "undefined":
                    break;
                default:
                    try {
                        const b = a.match(/^(?:'(.*)'|"(.*)")$/);
                        if (b) return b[1] || b[2] || "";
                        if (/^[-+]?\d*(\.\d+)?$/.test(a)) {
                            const c = parseFloat(a);
                            return c === c ? c : void 0
                        }
                    } catch (b) {}
            }
        };

    function Yn(a, b) {
        0 < a.g.size || kJ(a);
        const c = a.g.get(0);
        c ? c.push(b) : a.g.set(0, [b])
    }

    function lJ(a, b, c, d) {
        Tb(b, c, d);
        Zo(a, () => Ub(b, c, d))
    }

    function mJ(a, b) {
        1 !== a.j && (a.j = 1, 0 < a.g.size && nJ(a, b))
    }

    function kJ(a) {
        a.win.document.visibilityState ? lJ(a, a.win.document, "visibilitychange", b => {
            "hidden" === a.win.document.visibilityState && mJ(a, b);
            "visible" === a.win.document.visibilityState && (a.j = 0)
        }) : "onpagehide" in a.win ? (lJ(a, a.win, "pagehide", b => {
            mJ(a, b)
        }), lJ(a, a.win, "pageshow", () => {
            a.j = 0
        })) : lJ(a, a.win, "beforeunload", b => {
            mJ(a, b)
        })
    }

    function nJ(a, b) {
        for (let c = 9; 0 <= c; c--) a.g.get(c) ? .forEach(d => {
            d(b)
        })
    }
    var oJ = class extends U {
        constructor(a) {
            super();
            this.win = a;
            this.j = 0;
            this.g = new Map
        }
    };
    async function pJ(a, b) {
        var c = 10;
        return 0 >= c ? Promise.reject() : b() ? Promise.resolve() : new Promise((d, e) => {
            const f = a.setInterval(() => {
                --c ? b() && (a.clearInterval(f), d()) : (a.clearInterval(f), e())
            }, 200)
        })
    };

    function qJ(a) {
        const b = a.g.pc;
        return null !== b && 0 !== b ? b : a.g.pc = Bf(a.win)
    }

    function rJ(a) {
        var b = a.g.wpc;
        if (null === b || "" === b) {
            b = a.g;
            var c = a.win;
            if (c.google_ad_client) a = String(c.google_ad_client);
            else {
                if (null == (a = PI(c).head_tag_slot_vars ? .google_ad_client ? ? c.document.querySelector(".adsbygoogle[data-ad-client]") ? .getAttribute("data-ad-client"))) {
                    b: {
                        a = c.document.getElementsByTagName("script");c = c.navigator && c.navigator.userAgent || "";c = RegExp("appbankapppuzdradb|daumapps|fban|fbios|fbav|fb_iab|gsa/|messengerforios|naver|niftyappmobile|nonavigation|pinterest|twitter|ucbrowser|yjnewsapp|youtube", "i").test(c) ||
                        /i(phone|pad|pod)/i.test(c) && /applewebkit/i.test(c) && !/version|safari/i.test(c) && !Sk() ? hJ : iJ;
                        for (var d = a.length - 1; 0 <= d; d--) {
                            var e = a[d];
                            if (!e.google_parsed_script_for_pub_code && (e.google_parsed_script_for_pub_code = !0, e = c(e))) {
                                a = e;
                                break b
                            }
                        }
                        a = null
                    }
                    if (a) {
                        c = /(google_\w+) *= *(['"]?[\w.-]+['"]?) *(?:;|$)/gm;
                        for (d = {}; e = c.exec(a);) d[e[1]] = jJ(e[2]);
                        a = d;
                        a = a.google_ad_client ? a.google_ad_client : ""
                    } else a = ""
                }
                a = a ? ? ""
            }
            b = b.wpc = a
        }
        return b
    }

    function sJ(a, b) {
        var c = new Kn,
            d = qJ(a);
        c = Q(c, 1, d).ec(rJ(a));
        c = Q(c, 3, a.g.sd);
        return Q(c, 7, Math.round(b || a.win.performance.now()))
    }
    async function tJ(a) {
        await pJ(a.win, () => !(!qJ(a) || !rJ(a)))
    }
    async function uJ(a, b, c) {
        if (a.i && c.length && !a.g.lgdp.includes(Number(b))) {
            a.g.lgdp.push(Number(b));
            var d = a.win.performance.now();
            await tJ(a);
            var e = a.ua;
            a = sJ(a, d);
            d = new tm;
            b = R(d, 1, b);
            c = ki(b, 2, c, gh);
            c = I(a, 9, Ln, c);
            Un(e, c)
        }
    }
    async function vJ(a, b) {
        await tJ(a);
        var c = sJ(a);
        b = I(c, 5, Ln, b);
        a.i && !a.g.le.includes(2) && (a.g.le.push(2), Un(a.ua, b))
    }
    async function wJ(a, b, c) {
        await tJ(a);
        var d = a.ua;
        a = sJ(a, c);
        a = Q(a, 3, 1);
        b = I(a, 6, Ln, b);
        Un(d, b)
    }
    async function xJ(a, b) {
        if (a.i) {
            await tJ(a);
            var c = a.ua;
            a = sJ(a);
            b = I(a, 11, Ln, b);
            Un(c, b)
        }
    }
    var yJ = class {
        constructor(a, b) {
            this.win = tk() || window;
            this.j = b ? ? new oJ(this.win);
            this.ua = a ? ? new $n("m202401170101", 100, 100, !0, this.j);
            this.g = XI(UI(), 33, () => {
                const c = w(Ys);
                return {
                    sd: c,
                    ssp: 0 < c && Ze() < 1 / c,
                    pc: null,
                    wpc: null,
                    cu: null,
                    le: [],
                    lgdp: [],
                    psi: null
                }
            })
        }
        get i() {
            return this.g.ssp
        }
        get hd() {
            return this.g.cu
        }
        set hd(a) {
            this.g.cu = a
        }
    };
    var AJ = (a, b, c, d, e, f = null, g = null) => {
            zJ(a, new dA(a), b, c, d, e, f, g)
        },
        zJ = (a, b, c, d, e, f, g = null, h = null) => {
            if (c)
                if (d) {
                    var k = VC(d, e);
                    try {
                        const l = new BJ(a, b, c, d, e, k, f, g, h);
                        Dv(990, () => CJ(l), a)
                    } catch (l) {
                        fk() && gk(15, [l]), cA(b, Kr, Tz(DG(CG((new EG(0)).ec(c), d), k).xa(1), l)), vJ(u(yJ), jm(new sm, Dl(1)))
                    }
                } else cA(b, Kr, (new EG(0)).ec(c).xa(8)), vJ(u(yJ), jm(new sm, Dl(8)));
            else cA(b, Kr, (new EG(0)).xa(9)), vJ(u(yJ), jm(new sm, Dl(9)))
        };

    function CJ(a) {
        a.F.forEach(b => {
            switch (b) {
                case 0:
                    Dv(991, () => DJ(a), a.g);
                    break;
                case 1:
                    Dv(1073, () => {
                        const c = v(Bt);
                        OC(new UC(a.g, a.B, a.i, a.A, a.j.X, c))
                    }, a.g);
                    break;
                case 5:
                    Dv(1137, () => {
                        fA(new gA(a.g, a.B, a.i, a.A))
                    }, a.g);
                    break;
                case 2:
                    EJ(a);
                    break;
                case 6:
                    a.runAutoGames();
                    break;
                case 7:
                    Dv(1203, () => {
                        var c = C(a.i, sr, 34);
                        if (c) {
                            var d = a.g,
                                e = a.A,
                                f = c.i();
                            c = d.location.hostname;
                            var g = C(f, rr, 1) ? .g() ? ? [];
                            c = new qF(e, c, Bf(r), g);
                            if (g = C(f, rr, 1))
                                if (f = C(f, qr, 2)) {
                                    Vp(d, YE);
                                    const l = new Vo;
                                    var h = d.innerWidth;
                                    var k = .375 * h;
                                    h = new sy(k,
                                        h - k);
                                    k = d.innerWidth;
                                    k = 900 <= wo(d) ? .2 * k : .5 * k;
                                    jF(new lF(d, e, g, f, new RE(d, h, k, l, new BE(l)), c))
                                } else c.reportError("No messages");
                            else c.reportError("No settings")
                        }
                    }, a.g)
            }
        })
    }

    function DJ(a) {
        if (Br(a.i) && 1 === M(Br(a.i), 1)) {
            var b = C(Br(a.i), Gq, 6);
            b && 2 === M(b, 1) && (xv(a.g), a.C = "b")
        }
        var c = v(ht) ? void 0 : a.j.kj;
        b = null;
        b = v(ht) ? xB(a.g) : vB(a.g, c);
        if (a.j.X && Yh(a.j.X, Oq, 10)) {
            var d = $h(a.j.X.g(), 1);
            null !== d && void 0 !== d && (b = mB(a.g, d, c));
            v(zt) && 2 === a.j.X.g() ? .g() && (b = uB(a.j.X.g(), b))
        }
        Yh(a.i, Lq, 26) && (b = zB(b, C(a.i, Lq, 26), a.g));
        b = BB(b, a.g);
        c = a.j.X ? bi(a.j.X, 6, fh, 2) : [];
        d = a.j.X ? D(a.j.X, Uq, 5) : [];
        const e = a.j.X ? bi(a.j.X, 2, fh, 2) : [],
            f = Dv(993, () => {
                var g = a.i,
                    h = D(g, or, 1),
                    k = a.j.X && JI(a.j.X, 1);
                k = v(Gt) ? "" :
                    k ? "text_image" : "text";
                var l = new hI,
                    m = wA(h, a.g, {
                        Mh: l,
                        Mi: new uA(k)
                    });
                h.length != m.length && a.H.push(13);
                m = m.concat(mI(new nI(a.g, l)));
                h = 0;
                l = v(wt);
                var n = !1;
                if (Br(g) && 1 === M(Br(g), 1)) {
                    var p = C(Br(g), Gq, 6);
                    p && (h = ui(p, 2) || 0, 1 === M(p, 1) && (n = !0))
                }
                p = C(g, Ar, 24) ? .j() ? .g() ? .g() || !1;
                if (l || n || p) l = jI(new kI(a.g)), n = u($G), m = m.concat(l), n.O = !0, n.C = l.length, "n" === a.C && (a.C = C(g, Ar, 24) ? .g() ? .length ? "o" : "p");
                l = v(zt) && 2 === a.j.X.g() ? .g() && a.j.X.g() ? .j();
                l = v(ct) || l;
                a: {
                    if (n = C(g, kr, 6))
                        for (q of n.g())
                            if (Yh(q, qq, 4)) {
                                var q = !0;
                                break a
                            }
                    q = !1
                }
                l && q ? (q = m.concat, l = a.g, (n = C(g, kr, 6)) ? (l = $A(n.g(), l), k = rF(g, k, l)) : k = [], k = q.call(m, k)) : (q = m.concat, l = a.g, (n = C(g, kr, 6)) ? (l = ZA(n.g(), l), k = rF(g, k, l)) : k = [], k = q.call(m, k));
                m = k;
                g = C(g, Ar, 24);
                return new oH(m, a.g, h, g)
            }, a.g);
        a.l = new PH(f, a.A, a.g, {
            Eb: b,
            vi: a.O,
            uc: a.j.uc,
            ii: c,
            be: d
        }, FJ(a), e, v(vt));
        LH(a.l) ? .optimization ? .ablatingThisPageview && !a.l.Ya() && (xv(a.g), u($G).B = !0, a.C = "f");
        a.G = SH(e, a.l, a.g);
        Dv(992, () => YH(a.G), a.g).then(Dv(994, () => a.ga.bind(a), a.g), a.Z.bind(a));
        GJ(a)
    }

    function EJ(a) {
        const b = C(a.i, pr, 18);
        b && SD(new TD(a.g, new zE(a.g, a.A), b, new gw(a.g), D(a.i, or, 1)))
    }

    function FJ(a) {
        const b = v(yt);
        if (!Cr(a.i)) return {
            nf: b,
            wf: !1,
            Yf: !1,
            qh: !1,
            fg: !1,
            Zg: !1,
            hj: 0,
            Qg: 0,
            Ff: HJ(a),
            Ge: a.I
        };
        const c = Cr(a.i);
        return {
            nf: b || O(c, 14, !1),
            wf: O(c, 2, !1),
            Yf: O(c, 3, !1),
            qh: O(c, 4, !1),
            fg: O(c, 5, !1),
            Zg: O(c, 6, !1),
            hj: wi($h(c, 8)),
            Qg: M(c, 10),
            Ff: HJ(a),
            Ge: a.I
        }
    }

    function GJ(a) {
        if (v(Qu)) {
            var b = new gI(a.A);
            const e = C(a.i, kr, 6) ? .g(),
                f = 0 < e ? .length;
            var c = b,
                d = !!Zv(a.g).reactiveTypeEnabledInAsfe[8];
            dI(c, {
                typ: "pv",
                asp: Number(f),
                ve: Number(d)
            });
            f && (a = new eI(a.g, e, b), b = aI(a.win, a.g), 0 === b.length ? fI(a.ba, {
                ie: 0
            }) : (c = bI(b), d = c.g.getBoundingClientRect(), fI(a.ba, {
                ie: b.length,
                U: T(a.win),
                Kc: Ao(a.win).scrollHeight,
                Eh: d.height,
                Gh: a.win.scrollY + d.top
            }), c = c.g, cI(a, c, 0, "-50% 0px 0px 0px"), cI(a, c, 1, "0px 0px 0px 0px")))
        }
    }

    function HJ(a) {
        return v(ot) || v(zt) && 2 === a.j.X ? .g() ? .g() ? !1 : a.j.X && Yh(a.j.X, Oq, 10) ? .5 <= ($h(a.j.X.g(), 1) || 0) : !0
    }

    function IJ(a, b) {
        for (var c = Sz(Sz(new EG(b.Sa), b.errors), a.H), d = b.Bb, e = 0; e < d.length; e++) a: {
            for (var f = c, g = d[e], h = 0; h < f.B.length; h++)
                if (f.B[h] == g) break a;f.B.push(g)
        }
        c.g.pp = b.Nd;
        c.g.ppp = b.Od;
        c.g.ppos = b.placementPositionDiffs;
        c.g.eatf = b.qc;
        c.g.eatfAbg = b.rc;
        c.g.reatf = b.Ob;
        c = DG(CG(c.H(a.G.l.slice(0)), a.i), a.F).ec(a.A);
        if (d = b.Ia) c.g.as_count = d.Cf, c.g.d_count = d.eg, c.g.ng_count = d.Jg, c.g.am_count = d.Hf, c.g.atf_count = d.Df, c.g.mdns = FG(d.Ag), c.g.alldns = FG(d.Ef);
        c = c.G(b.Zb).gh(b.pd);
        d = b.Kc;
        null != d && (c.g.pgh = d);
        c.g.abl = b.mg;
        c.g.rr = a.C;
        void 0 !== b.exception && Tz(c, b.exception).xa(1);
        return c
    }

    function JJ(a, b) {
        var c = IJ(a, b);
        cA(a.B, 0 < b.errors.length || 0 < a.H.length || void 0 !== b.exception ? Kr : Jr, c);
        if (C(a.i, Ar, 24)) {
            a.l.i.g.g ? .F();
            b = LH(a.l);
            const d = u($G);
            d.j = !!b ? .optimization ? .ablationFromStorage;
            b ? .optimization ? .ablatingThisPageview && (d.G = !0);
            d.T = !!b ? .optimization ? .availableAbg;
            b = u($G);
            c = new RG(c);
            b.A ? (c.i.sl = HG(b.A ? ? []), c.i.daaos = HG(b.H ? ? []), c.i.ab = IG(b.G), c.i.rr = IG(b.O), c.i.oab = IG(b.F), null != b.j && (c.i.sab = IG(b.j)), b.B && (c.i.fb = IG(b.B)), c.i.ls = IG(b.T), JG(c, b.i.yc()), null != b.C && (c.i.rp = IG(b.C)),
                null != b.l && (c.i.expl = IG(b.l)), ZG(b, c)) : c.errors.push("irr");
            cA(a.B, Mr, c)
        }
        c = a.l ? .pa();
        v(vt) && null != c && (c = new Map([...c.j.map.entries()].map(JE)), b = new pI, oI(b, c), cA(a.B, Qr, b))
    }

    function KJ(a, b) {
        const c = u(yJ);
        if (c.i) {
            var d = new sm,
                e = b.Bb.filter(g => null !== g),
                f = a.H.concat(b.errors, b.exception ? [1] : []).filter(g => null !== g);
            nm(lm(qm(pm(om(mm(gm(im(km(hm(d, a.G.l.slice(0).map(g => {
                var h = new Cl;
                return Wh(h, 1, eh(g))
            })), e.map(g => {
                var h = new Fl;
                return Wh(h, 1, eh(g))
            })), f.map(g => Dl(g))), C(a.i, Yq, 23) ? .g()), b.Sa).G(b.Zb), b.Ob), b.qc), b.rc), a.F.map(g => g.toString())), Ml(Ll(Kl(Jl(Il(Hl(Gl(new Nl, b.Ia ? .Cf), b.Ia ? .eg), b.Ia ? .Jg), b.Ia ? .Hf), b.Ia ? .Df), b.Ia ? .Ag), b.Ia ? .Ef));
            if (b.pd)
                for (let g of No(b.pd)) {
                    e =
                        new ji;
                    for (let h of b.pd.get(g)) Rl(e, Pl(Ol(new Ql, h.lb), h.sh));
                    rm(d).set(g.toString(), e)
                }
            C(a.i, Ar, 24) && em(d);
            vJ(c, d)
        }
    }

    function LJ(a) {
        return Br(a.i) && 1 === M(Br(a.i), 1) ? !(C(Br(a.i), Gq, 6) && 1 <= (ui(C(Br(a.i), Gq, 6), 3) || 0)) : !1
    }

    function MJ(a) {
        if (LJ(a)) {
            a = a.l;
            var b = OB({
                xd: !0,
                yd: !0
            }, a.g);
            a = 0 < GH(b, a.g)
        } else a = a.l.g, b = NB({
            Qb: !1,
            wd: !1
        }, a), a = 0 < GH(b, a);
        return a
    }

    function NJ(a, b) {
        try {
            v(et) && a.l ? .va() ? .A()
        } catch (c) {
            cA(a.B, Pr, Tz(DG(CG((new EG(b)).ec(a.A), a.i), a.F).xa(14), c))
        }
    }

    function OJ(a, b, c) {
        {
            var d = LH(a.l),
                e = b.g;
            const f = e.g,
                g = e.Nd;
            let h = e.Sa,
                k = e.Od,
                l = e.errors.slice(),
                m = e.Bb.slice(),
                n = b.exception;
            const p = PI(a.g).had_ads_ablation ? ? !1;
            d ? (d.numAutoAdsPlaced ? h += d.numAutoAdsPlaced : a.G.j && m.push(13), void 0 !== d.exception && (n = d.exception), d.numPostPlacementsPlaced && (k += d.numPostPlacementsPlaced), c = {
                Sa: h,
                Nd: g,
                Od: k,
                Zb: f,
                errors: e.errors.slice(),
                Bb: m,
                exception: n,
                Ob: c,
                qc: !!d.eatf,
                rc: !!d.eatfAbg,
                mg: p
            }) : (m.push(12), a.G.j && m.push(13), c = {
                Sa: h,
                Nd: g,
                Od: k,
                Zb: f,
                errors: l,
                Bb: m,
                exception: n,
                Ob: c,
                qc: !1,
                rc: !1,
                mg: p
            })
        }
        c.Ia = HH(a.l.g);
        if (b = b.g.i) c.pd = b;
        c.Kc = Ao(a.g).scrollHeight;
        if (fk() || C(a.i, Xq, 25) ? .j()) {
            d = cq(a.l.i.i);
            b = [];
            for (const f of d) {
                d = {};
                e = f.I;
                for (const g of No(e)) d[g] = e.get(g);
                d = {
                    anchorElement: AA(f),
                    position: f.g(),
                    clearBoth: f.H,
                    locationType: f.Rb,
                    placed: f.A,
                    placementProto: f.l ? f.l.toJSON() : null,
                    articleStructure: f.B ? f.B.toJSON() : null,
                    rejectionReasons: d
                };
                b.push(d)
            }
            gk(14, [{
                placementIdentifiers: b
            }, a.l.G, c.Ia])
        }
        return c
    }

    function PJ(a, b) {
        var c = a.l.g;
        c = c.googleSimulationState = c.googleSimulationState || {};
        c.amaConfigPlacementCount = b.Zb;
        c.numAutoAdsPlaced = b.Sa;
        c.hasAtfAd = b.Ob;
        void 0 !== b.exception && (c.exception = b.exception);
        null != a.l && (a = rI(a.g, a.l, {
            qd: -1,
            xc: -1,
            Gc: -1,
            rg: !0,
            Gf: !0
        }), null != a.g ? (c.placementPositionDiffs = DI(a.getValue()), b = CI(a.getValue()), a = new xF, a = I(a, 2, yF, b), c.placementPositionDiffsReport = bj(a)) : (b = a.i.message, c.placementPositionDiffs = "E" + b, a = new xF, a = mi(a, 1, yF, uh(b)), c.placementPositionDiffsReport = bj(a)))
    }

    function QJ(a, b) {
        JJ(a, {
            Sa: 0,
            Zb: void 0,
            errors: [],
            Bb: [],
            exception: b,
            Ob: void 0,
            qc: void 0,
            rc: void 0,
            Ia: void 0
        });
        KJ(a, {
            Sa: 0,
            Zb: void 0,
            errors: [],
            Bb: [],
            exception: b,
            Ob: void 0,
            qc: void 0,
            rc: void 0,
            Ia: void 0
        })
    }
    class BJ {
        constructor(a, b, c, d, e, f, g, h, k) {
            this.g = a;
            this.B = b;
            this.A = c;
            this.i = d;
            this.j = e;
            this.F = f;
            this.O = h || null;
            this.H = [];
            this.I = k;
            this.T = g;
            this.C = "n"
        }
        runAutoGames() {
            const a = C(this.i, Zq, 32);
            a && this.T.runAutoGames({
                win: this.g,
                webPropertyCode: this.A,
                Mf: a,
                Lb: (C(this.i, hr, 33) ? .g() ? .i() ? ? null) || fr().i()
            })
        }
        ga(a) {
            try {
                NJ(this, a.g.Sa);
                const b = MJ(this) || LJ(this) ? MJ(this) : void 0;
                Ir({
                    ze: b
                }, this.g);
                const c = OJ(this, a, MJ(this));
                Yh(this.i, Xq, 25) && ai(C(this.i, Xq, 25), 1) && PJ(this, c);
                JJ(this, c);
                KJ(this, c);
                Zz(753, () => {
                    if (v(jt) &&
                        null != this.l) {
                        var d = rI(this.g, this.l, {
                                qd: w(ut),
                                xc: w(tt),
                                Gc: w(lt),
                                rg: !0,
                                Gf: !1
                            }),
                            e = Tc(c);
                        null != d.g ? (d = DI(d.getValue()), e.placementPositionDiffs = d) : e.placementPositionDiffs = "E" + d.i.message;
                        e = IJ(this, e);
                        cA(this.B, Lr, e)
                    }
                })()
            } catch (b) {
                QJ(this, b)
            }
        }
        Z(a) {
            NJ(this, 0);
            QJ(this, a)
        }
    };
    var RJ = class extends S {},
        SJ = hj(RJ);

    function TJ(a) {
        try {
            var b = a.localStorage.getItem("google_auto_fc_cmp_setting") || null
        } catch (d) {
            b = null
        }
        const c = b;
        return c ? iq(() => SJ(c)) : fq(null)
    };

    function UJ(a, b) {
        return Vi(a, 5, b)
    }
    var VJ = class extends S {
        constructor() {
            super()
        }
        g() {
            return O(this, 6)
        }
    };
    VJ.P = [10];
    var YJ = ({
        win: a,
        Ad: b,
        pg: c = !1,
        qg: d = !1
    }) => WJ({
        win: a,
        Ad: b,
        pg: c,
        qg: d
    }) ? (b = Z(UI(), 24)) ? XJ(a, UJ(new VJ, oE(b))) : hq(Error("tcunav")) : XJ(a, UJ(new VJ, !0));

    function WJ({
        win: a,
        Ad: b,
        pg: c,
        qg: d
    }) {
        if (!(d = !d && sE(new wE(a)))) {
            if (c = !c) {
                if (b) {
                    a = TJ(a);
                    if (null != a.g)
                        if ((a = a.getValue()) && null != M(a, 1)) b: switch (a = M(a, 1), a) {
                            case 1:
                                a = !0;
                                break b;
                            default:
                                throw Error("Unhandled AutoGdprFeatureStatus: " + a);
                        } else a = !1;
                        else aA(806, a.i), a = !1;
                    b = !a
                }
                c = b
            }
            d = c
        }
        return d ? !0 : !1
    }

    function XJ(a, b) {
        return (a = Xj(b, a)) ? fq(a) : hq(Error("unav"))
    };
    var ZJ = class extends S {};
    class $J {
        constructor(a, b, c, d, e) {
            this.g = a;
            this.l = b;
            this.B = c;
            this.i = !1;
            this.j = d;
            this.A = e
        }
    };
    class aK {
        constructor() {
            this.promise = new Promise((a, b) => {
                this.resolve = a;
                this.g = b
            })
        }
    };

    function bK() {
        const {
            promise: a,
            resolve: b
        } = new aK;
        return {
            promise: a,
            resolve: b
        }
    };

    function cK(a, b, c = () => {}) {
        b.google_llp || (b.google_llp = {});
        b = b.google_llp;
        let d = b[a];
        if (d) return d;
        d = bK();
        b[a] = d;
        c();
        return d
    }

    function dK(a, b, c) {
        return cK(a, b, () => {
            We(b.document, c)
        }).promise
    };

    function eK() {
        const a = {};
        Yb(at) && (a.bust = Yb(at));
        var b = UI();
        b = Z(b, 38, "");
        "" !== b && (a.sbust = b);
        return a
    }
    const fK = new Map([
        [2, 7],
        [3, 1],
        [4, 3],
        [5, 12]
    ]);

    function gK(a, b, c) {
        c = $c(c, eK());
        if (1 === a) return {
            eo: We(b.document, c),
            Wc: new Promise(() => {})
        };
        if (fK.has(a)) return {
            Wc: dK(fK.get(a), b, c)
        };
        throw Error(`Unexpected chunkId: ${a}`);
    };
    var hK = class {
        constructor(a) {
            this.kb = a
        }
        runAutoGames({
            win: a,
            webPropertyCode: b,
            Mf: c,
            Lb: d
        }) {
            bA(1116, gK(5, a, this.kb).Wc.then(e => {
                e.runAutoGames({
                    win: a,
                    webPropertyCode: b,
                    serializedAutoGamesConfig: bj(c),
                    serializedFloatingToolbarMessages: bj(d)
                })
            }))
        }
    };
    var iK = {
            Jk: "google_ads_preview",
            wl: "google_mc_lab",
            Ml: "google_anchor_debug",
            Ll: "google_bottom_anchor_debug",
            INTERSTITIAL: "google_ia_debug",
            im: "google_scr_debug",
            km: "google_ia_debug_allow_onclick",
            Im: "googleads",
            yh: "google_pedestal_debug",
            bn: "google_responsive_slot_preview",
            an: "google_responsive_dummy_ad",
            zk: "google_audio_sense",
            Ck: "google_auto_gallery",
            Ek: "google_auto_storify_swipeable",
            Dk: "google_auto_storify_scrollable",
            Bk: "google_games_single_game",
            Ak: "google_games_catalog"
        },
        jK = {
            google_bottom_anchor_debug: 1,
            google_anchor_debug: 2,
            google_ia_debug: 8,
            google_scr_debug: 9,
            googleads: 2,
            google_pedestal_debug: 30
        };
    var kK = {
        INTERSTITIAL: 1,
        BOTTOM_ANCHOR: 2,
        TOP_ANCHOR: 3,
        1: "INTERSTITIAL",
        2: "BOTTOM_ANCHOR",
        3: "TOP_ANCHOR"
    };

    function lK(a, b) {
        if (!a) return !1;
        a = a.hash;
        if (!a || !a.indexOf) return !1;
        if (-1 != a.indexOf(b)) return !0;
        b = mK(b);
        return "go" != b && -1 != a.indexOf(b) ? !0 : !1
    }

    function mK(a) {
        let b = "";
        $e(a.split("_"), c => {
            b += c.substr(0, 2)
        });
        return b
    }

    function nK() {
        var a = r.location;
        let b = !1;
        $e(iK, c => {
            lK(a, c) && (b = !0)
        });
        return b
    }

    function oK(a, b) {
        switch (a) {
            case 1:
                return lK(b, "google_ia_debug");
            case 2:
                return lK(b, "google_bottom_anchor_debug");
            case 3:
                return lK(b, "google_anchor_debug") || lK(b, "googleads")
        }
    };

    function pK({
        win: a,
        webPropertyCode: b,
        kb: c
    }) {
        lK(a.location, "google_games_single_game") ? qK(a, b, 1, c) : lK(a.location, "google_games_catalog") && qK(a, b, 2, c)
    }

    function qK(a, b, c, d) {
        var e = new Zq;
        c = Wh(e, 1, eh(c));
        (new hK(d)).runAutoGames({
            win: a,
            webPropertyCode: b,
            Mf: c,
            Lb: fr().i()
        })
    };
    var rK = class extends S {
        constructor() {
            super()
        }
        Bi() {
            return Ri(this, 3)
        }
    };
    const sK = {
        "-": 0,
        Y: 2,
        N: 1
    };
    var tK = class extends S {
        constructor() {
            super()
        }
        getVersion() {
            return xi(this, 2)
        }
    };
    tK.P = [3];

    function uK(a) {
        return a.includes("~") ? a.split("~").slice(1) : []
    };

    function vK(a) {
        return Nf(0 !== a.length % 4 ? a + "A" : a).map(b => b.toString(2).padStart(8, "0")).join("")
    }

    function wK(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        return parseInt(a, 2)
    }

    function xK(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        const b = [1, 2, 3, 5];
        let c = 0;
        for (let d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    }

    function yK(a, b) {
        a = vK(a);
        return a.length < b ? a.padEnd(b, "0") : a
    };

    function zK(a) {
        var b = vK(a),
            c = wK(b.slice(0, 6));
        a = wK(b.slice(6, 12));
        var d = new tK;
        c = Yi(d, 1, c);
        a = Yi(c, 2, a);
        b = b.slice(12);
        c = wK(b.slice(0, 12));
        d = [];
        let e = b.slice(12).replace(/0+$/, "");
        for (let k = 0; k < c; k++) {
            if (0 === e.length) throw Error(`Found ${k} of ${c} sections [${d}] but reached end of input [${b}]`);
            var f = 0 === wK(e[0]);
            e = e.slice(1);
            var g = AK(e, b),
                h = 0 === d.length ? 0 : d[d.length - 1];
            h = xK(g) + h;
            e = e.slice(g.length);
            if (f) d.push(h);
            else {
                f = AK(e, b);
                g = xK(f);
                for (let l = 0; l <= g; l++) d.push(h + l);
                e = e.slice(f.length)
            }
        }
        if (0 <
            e.length) throw Error(`Found ${c} sections [${d}] but has remaining input [${e}], entire input [${b}]`);
        return ki(a, 3, d, gh)
    }

    function AK(a, b) {
        const c = a.indexOf("11");
        if (-1 === c) throw Error(`Expected section bitstring but not found in [${a}] part of [${b}]`);
        return a.slice(0, c + 2)
    };
    var BK = class extends S {
        constructor() {
            super()
        }
    };
    var CK = class extends S {
        constructor() {
            super()
        }
    };
    var DK = class extends S {
        getVersion() {
            return xi(this, 1)
        }
    };
    var EK = class extends S {
        constructor() {
            super()
        }
    };

    function FK(a) {
        var b = new GK;
        return F(b, 1, a)
    }
    var GK = class extends S {
        constructor() {
            super()
        }
    };
    const HK = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        IK = 6 + HK.reduce((a, b) => a + b);
    var JK = class extends S {
        constructor() {
            super()
        }
    };
    var KK = class extends S {
        getVersion() {
            return xi(this, 1)
        }
    };
    var LK = class extends S {
        constructor() {
            super()
        }
    };

    function MK(a) {
        var b = new NK;
        return F(b, 1, a)
    }
    var NK = class extends S {
        constructor() {
            super()
        }
    };
    const OK = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        PK = 6 + OK.reduce((a, b) => a + b);
    var QK = class extends S {
        constructor() {
            super()
        }
    };
    var RK = class extends S {
        constructor() {
            super()
        }
    };
    var SK = class extends S {
        getVersion() {
            return xi(this, 1)
        }
    };
    var TK = class extends S {
        constructor() {
            super()
        }
    };

    function UK(a) {
        var b = new VK;
        return F(b, 1, a)
    }
    var VK = class extends S {
        constructor() {
            super()
        }
    };
    const WK = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        XK = 6 + WK.reduce((a, b) => a + b);
    var YK = class extends S {
        constructor() {
            super()
        }
    };
    var ZK = class extends S {
        constructor() {
            super()
        }
        getVersion() {
            return xi(this, 1)
        }
    };
    const $K = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        aL = 6 + $K.reduce((a, b) => a + b);
    var bL = "a".charCodeAt(),
        cL = Sc(mo),
        dL = Sc(no);

    function eL() {
        var a = new fL;
        return Q(a, 1, 0)
    }

    function gL(a) {
        const b = Qi(a, 1);
        a = xi(a, 2);
        return new Date(1E3 * b + a / 1E6)
    }
    var fL = class extends S {};

    function hL(a, b) {
        if (a.g + b > a.i.length) throw Error("Requested length " + b + " is past end of string.");
        const c = a.i.substring(a.g, a.g + b);
        a.g += b;
        return parseInt(c, 2)
    }

    function iL(a) {
        let b = hL(a, 12);
        const c = [];
        for (; b--;) {
            var d = !0 === !!hL(a, 1),
                e = hL(a, 16);
            if (d)
                for (d = hL(a, 16); e <= d; e++) c.push(e);
            else c.push(e)
        }
        c.sort((f, g) => f - g);
        return c
    }

    function jL(a, b, c) {
        const d = [];
        for (let e = 0; e < b; e++)
            if (hL(a, 1)) {
                const f = e + 1;
                if (c && -1 === c.indexOf(f)) throw Error(`ID: ${f} is outside of allowed values!`);
                d.push(f)
            }
        return d
    }

    function kL(a) {
        const b = hL(a, 16);
        return !0 === !!hL(a, 1) ? (a = iL(a), a.forEach(c => {
            if (c > b) throw Error(`ID ${c} is past MaxVendorId ${b}!`);
        }), a) : jL(a, b)
    }
    class lL {
        constructor(a) {
            if (/[^01]/.test(a)) throw Error(`Input bitstring ${a} is malformed!`);
            this.i = a;
            this.g = 0
        }
        skip(a) {
            this.g += a
        }
    };
    var nL = (a, b) => {
        try {
            var c = Nf(a.split(".")[0]).map(e => e.toString(2).padStart(8, "0")).join("");
            const d = new lL(c);
            c = {};
            c.tcString = a;
            c.gdprApplies = !0;
            d.skip(78);
            c.cmpId = hL(d, 12);
            c.cmpVersion = hL(d, 12);
            d.skip(30);
            c.tcfPolicyVersion = hL(d, 6);
            c.isServiceSpecific = !!hL(d, 1);
            c.useNonStandardStacks = !!hL(d, 1);
            c.specialFeatureOptins = mL(jL(d, 12, dL), dL);
            c.purpose = {
                consents: mL(jL(d, 24, cL), cL),
                legitimateInterests: mL(jL(d, 24, cL), cL)
            };
            c.purposeOneTreatment = !!hL(d, 1);
            c.publisherCC = String.fromCharCode(bL + hL(d, 6)) + String.fromCharCode(bL +
                hL(d, 6));
            c.vendor = {
                consents: mL(kL(d), b),
                legitimateInterests: mL(kL(d), b)
            };
            return c
        } catch (d) {
            return null
        }
    };
    const mL = (a, b) => {
        const c = {};
        if (Array.isArray(b) && 0 !== b.length)
            for (const d of b) c[d] = -1 !== a.indexOf(d);
        else
            for (const d of a) c[d] = !0;
        delete c[0];
        return c
    };
    var oL = class extends S {
        g() {
            return null != L(this, 2)
        }
    };
    var pL = class extends S {
        g() {
            return null != L(this, 2)
        }
    };
    var qL = class extends S {};
    var rL = class extends S {},
        sL = hj(rL);
    rL.P = [7];

    function tL(a) {
        a = uL(a);
        try {
            var b = a ? sL(a) : null
        } catch (c) {
            b = null
        }
        return b ? C(b, qL, 4) || null : null
    }

    function uL(a) {
        a = (new Wj(a)).get("FCCDCF", "");
        if (a)
            if (a.startsWith("%")) try {
                var b = decodeURIComponent(a)
            } catch (c) {
                b = null
            } else b = a;
            else b = null;
        return b
    };

    function vL(a) {
        a.__uspapiPostMessageReady || wL(new xL(a))
    }

    function wL(a) {
        a.g = b => {
            const c = "string" === typeof b.data;
            let d;
            try {
                d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            const e = d.__uspapiCall;
            e && "getUSPData" === e.command && a.win.__uspapi(e.command, e.version, (f, g) => {
                const h = {};
                h.__uspapiReturn = {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && "function" === typeof b.source.postMessage && b.source.postMessage(f, b.origin);
                return f
            })
        };
        a.win.addEventListener("message", a.g);
        a.win.__uspapiPostMessageReady = !0
    }
    var xL = class {
        constructor(a) {
            this.win = a;
            this.g = null
        }
    };

    function yL(a) {
        a.__tcfapiPostMessageReady || zL(new AL(a))
    }

    function zL(a) {
        a.i = b => {
            const c = "string" == typeof b.data;
            let d;
            try {
                d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            const e = d.__tcfapiCall;
            !e || "ping" !== e.command && "getTCData" !== e.command && "addEventListener" !== e.command && "removeEventListener" !== e.command || a.g.__tcfapi(e.command, e.version, (f, g) => {
                const h = {};
                h.__tcfapiReturn = "removeEventListener" === e.command ? {
                    success: f,
                    callId: e.callId
                } : {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && "function" === typeof b.source.postMessage && b.source.postMessage(f,
                    b.origin);
                return f
            }, e.parameter)
        };
        a.g.addEventListener("message", a.i);
        a.g.__tcfapiPostMessageReady = !0
    }
    var AL = class {
        constructor(a) {
            this.g = a;
            this.i = null
        }
    };
    var BL = class extends S {};
    var CL = class extends S {
            g() {
                return null != L(this, 1)
            }
        },
        DL = hj(CL);
    CL.P = [2];

    function EL(a, b, c) {
        function d(m) {
            if (10 > m.length) return null;
            var n = g(m.slice(0, 4));
            n = h(n);
            m = g(m.slice(6, 10));
            m = k(m);
            return "1" + n + m + "N"
        }

        function e(m) {
            if (10 > m.length) return null;
            var n = g(m.slice(0, 6));
            n = h(n);
            m = g(m.slice(6, 10));
            m = k(m);
            return "1" + n + m + "N"
        }

        function f(m) {
            if (12 > m.length) return null;
            var n = g(m.slice(0, 6));
            n = h(n);
            m = g(m.slice(8, 12));
            m = k(m);
            return "1" + n + m + "N"
        }

        function g(m) {
            const n = [];
            let p = 0;
            for (let q = 0; q < m.length / 2; q++) n.push(wK(m.slice(p, p + 2))), p += 2;
            return n
        }

        function h(m) {
            return m.every(n => 1 === n) ?
                "Y" : "N"
        }

        function k(m) {
            return m.some(n => 1 === n) ? "Y" : "N"
        }
        if (0 === a.length) return null;
        a = a.split(".");
        if (2 < a.length) return null;
        a = vK(a[0]);
        const l = wK(a.slice(0, 6));
        a = a.slice(6);
        if (1 !== l) return null;
        switch (b) {
            case 8:
                return d(a);
            case 10:
            case 12:
            case 9:
                return e(a);
            case 11:
                return c ? f(a) : null;
            default:
                return null
        }
    };

    function FL(a) {
        var b = v(Vs);
        a !== a.top || a.__uspapi || a.frames.__uspapiLocator || (a = new GL(a, b), HL(a), IL(a))
    }

    function HL(a) {
        !a.l || a.g.__uspapi || a.g.frames.__uspapiLocator || (a.g.__uspapiManager = "fc", $D(a.g, "__uspapiLocator"), La("__uspapi", (...b) => JL(a, ...b), a.g), vL(a.g))
    }

    function IL(a) {
        !a.i || a.g.__tcfapi || a.g.frames.__tcfapiLocator || (a.g.__tcfapiManager = "fc", $D(a.g, "__tcfapiLocator"), a.g.__tcfapiEventListeners = a.g.__tcfapiEventListeners || [], La("__tcfapi", (...b) => KL(a, ...b), a.g), yL(a.g))
    }

    function JL(a, b, c, d) {
        "function" === typeof d && "getUSPData" === b && d({
            version: 1,
            uspString: a.l
        }, !0)
    }

    function LL(a, b) {
        if (!b ? .g() || 0 === P(b, 1).length || 0 == D(b, BL, 2).length) return null;
        const c = P(b, 1);
        let d;
        try {
            var e = zK(c.split("~")[0]);
            d = uK(c)
        } catch (f) {
            return null
        }
        b = D(b, BL, 2).reduce((f, g) => Qi(ML(f), 1) > Qi(ML(g), 1) ? f : g);
        e = bi(e, 3, hh, 2).indexOf(xi(b, 1));
        return -1 === e || e >= d.length ? null : {
            uspString: EL(d[e], xi(b, 1), a.A),
            te: gL(ML(b))
        }
    }

    function NL(a) {
        a = a.find(b => 13 === Ri(b, 1));
        if (a ? .g()) try {
            return DL(P(a, 2))
        } catch (b) {}
        return null
    }

    function ML(a) {
        return Yh(a, fL, 2) ? C(a, fL, 2) : eL()
    }

    function KL(a, b, c, d, e = null) {
        if ("function" === typeof d)
            if (c && (2.1 < c || 1 >= c)) d(null, !1);
            else switch (c = a.g.__tcfapiEventListeners, b) {
                case "getTCData":
                    !e || Array.isArray(e) && e.every(f => "number" === typeof f) ? d(OL(a, e, null), !0) : d(null, !1);
                    break;
                case "ping":
                    d({
                        gdprApplies: !0,
                        cmpLoaded: !0,
                        cmpStatus: "loaded",
                        displayStatus: "disabled",
                        apiVersion: "2.1",
                        cmpVersion: 2,
                        cmpId: 300
                    });
                    break;
                case "addEventListener":
                    b = c.push(d);
                    d(OL(a, null, b - 1), !0);
                    break;
                case "removeEventListener":
                    c[e] ? (c[e] = null, d(!0)) : d(!1);
                    break;
                case "getInAppTCData":
                case "getVendorList":
                    d(null, !1)
            }
    }

    function OL(a, b, c) {
        if (!a.i) return null;
        b = nL(a.i, b);
        b.addtlConsent = null != a.j ? a.j : void 0;
        b.cmpStatus = "loaded";
        b.eventStatus = "tcloaded";
        null != c && (b.listenerId = c);
        return b
    }
    class GL {
        constructor(a, b) {
            this.g = a;
            this.A = b;
            b = uL(this.g.document);
            try {
                var c = b ? sL(b) : null
            } catch (e) {
                c = null
            }(b = c) ? (c = C(b, pL, 5) || null, b = D(b, oL, 7), b = NL(b ? ? []), c = {
                Qf: c,
                lg: b
            }) : c = {
                Qf: null,
                lg: null
            };
            b = c;
            c = LL(this, b.lg);
            b = b.Qf;
            if (b ? .g() && 0 !== P(b, 2).length) {
                var d = Yh(b, fL, 1) ? C(b, fL, 1) : eL();
                b = {
                    uspString: P(b, 2),
                    te: gL(d)
                }
            } else b = null;
            this.l = b && c ? c.te > b.te ? c.uspString : b.uspString : b ? b.uspString : c ? c.uspString : null;
            this.i = (c = tL(a.document)) && null != L(c, 1) ? P(c, 1) : null;
            this.j = (a = tL(a.document)) && null != L(a, 2) ? P(a, 2) : null
        }
    };
    const PL = a => {
        const b = a[0] / 255,
            c = a[1] / 255;
        a = a[2] / 255;
        return .2126 * (.03928 >= b ? b / 12.92 : Math.pow((b + .055) / 1.055, 2.4)) + .7152 * (.03928 >= c ? c / 12.92 : Math.pow((c + .055) / 1.055, 2.4)) + .0722 * (.03928 >= a ? a / 12.92 : Math.pow((a + .055) / 1.055, 2.4))
    };
    var QL = (a, b) => {
        a = PL(a);
        b = PL(b);
        return (Math.max(a, b) + .05) / (Math.min(a, b) + .05)
    };
    var RL = Promise;
    class SL {
        constructor(a) {
            this.j = a
        }
        i(a, b, c) {
            this.j.then(d => {
                d.i(a, b, c)
            })
        }
        g(a, b) {
            return this.j.then(c => c.g(a, b))
        }
    };
    class TL {
        constructor(a) {
            this.data = a
        }
    };

    function UL(a, b) {
        VL(a, b);
        return new WL(a)
    }
    class WL {
        constructor(a) {
            this.j = a
        }
        i(a, b, c = []) {
            const d = new MessageChannel;
            VL(d.port1, b);
            this.j.postMessage(a, [d.port2].concat(c))
        }
        g(a, b) {
            return new RL(c => {
                this.i(a, c, b)
            })
        }
    }

    function VL(a, b) {
        b && (a.onmessage = c => {
            b(new TL(c.data, UL(c.ports[0])))
        })
    };
    var ZL = ({
        destination: a,
        Na: b,
        origin: c,
        me: d = "ZNWN1d",
        onMessage: e,
        Mg: f
    }) => XL({
        destination: a,
        Ci: () => b.contentWindow,
        cj: YL(c),
        me: d,
        onMessage: e,
        Mg: f
    });
    const XL = ({
            destination: a,
            Ci: b,
            cj: c,
            ho: d,
            me: e,
            onMessage: f,
            Mg: g
        }) => {
            const h = Object.create(null);
            c.forEach(k => {
                h[k] = !0
            });
            return new SL(new RL((k, l) => {
                const m = n => {
                    n.source && n.source === b() && !0 === h[n.origin] && (n.data.n || n.data) === e && (a.removeEventListener("message", m, !1), d && n.data.t !== d ? l(Error(`Token mismatch while establishing channel "${e}". Expected ${d}, but received ${n.data.t}.`)) : (k(UL(n.ports[0], f)), g && g(n)))
                };
                a.addEventListener("message", m, !1)
            }))
        },
        YL = a => {
            a = "string" === typeof a ? [a] : a;
            const b = Object.create(null);
            a.forEach(c => {
                if ("null" === c) throw Error("Receiving from null origin not allowed without token verification. Please use NullOriginConnector.");
                b[c] = !0
            });
            return a
        };

    function $L(a, b, c, d, e, f, g = null) {
        if (v(it)) var h = e ? OI(e) : null;
        else {
            try {
                h = a.localStorage
            } catch (m) {
                h = null
            }
            h = h ? OI(h) : null
        }
        a: {
            if (d) try {
                var k = Er(d);
                break a
            } catch (m) {
                FI(a, {
                    cfg: 1,
                    inv: 1
                })
            }
            k = null
        }
        if (d = k) {
            if (e) {
                k = new Nq;
                F(d, 3, k);
                h = Cr(d) && vi(Cr(d), 13) ? vi(Cr(d), 13) : 1;
                h = Date.now() + 864E5 * h;
                Number.isFinite(h) && Zi(k, 1, Math.round(h));
                k = Sh(d);
                if (Cr(d)) {
                    h = new Mq;
                    var l = Cr(d);
                    l = ai(l, 23);
                    h = Vi(h, 23, null == l ? void 0 : l);
                    l = O(Cr(d), 12, !1);
                    h = Vi(h, 12, l);
                    l = O(Cr(d), 15, !1);
                    h = Vi(h, 15, l);
                    F(k, 15, h)
                }
                h = D(k, or, 1);
                for (l = 0; l < h.length; l++) Wh(h[l],
                    11);
                Wh(k, 22);
                if (v(gt)) NI(a);
                else try {
                    (e || a.localStorage).setItem("google_ama_config", bj(k))
                } catch (m) {
                    FI(a, {
                        lserr: 1
                    })
                }
            }
            e = KI(a, D(d, Wq, 7));
            k = {};
            v(ht) || (k.kj = C(d, ir, 8) || new ir);
            e && (k.X = e);
            e && JI(e, 3) && (k.uc = [1]);
            e = k;
            if (7 === c.google_pgb_reactive && !e.X) return !1;
            QI(a, 2) && (gk(5, [d.toJSON()]), c = GI(c), f = new hK(f), k = e.X, c.google_package = k && L(k, 4) || "", AJ(a, b, d, e, f, new Bq(["google-auto-placed"], c), g));
            return !0
        }
        h && (FI(a, {
            cfg: 1,
            cl: 1
        }), v(it) ? null != e && MI(a, e) : NI(a));
        return !1
    };
    var bM = a => {
        const b = a.D;
        null == b.google_ad_output && (b.google_ad_output = "html");
        if (null != b.google_ad_client) {
            var c;
            (c = String(b.google_ad_client)) ? (c = c.toLowerCase(), "ca-" != c.substring(0, 3) && (c = "ca-" + c)) : c = "";
            b.google_ad_client = c
        }
        null != b.google_ad_slot && (b.google_ad_slot = String(b.google_ad_slot));
        b.google_webgl_support = !!Sj.WebGLRenderingContext;
        b.google_ad_section = b.google_ad_section || b.google_ad_region || "";
        b.google_country = b.google_country || b.google_gl || "";
        c = (new Date).getTime();
        Array.isArray(b.google_color_bg) &&
            (b.google_color_bg = aM(a, b.google_color_bg, c));
        Array.isArray(b.google_color_text) && (b.google_color_text = aM(a, b.google_color_text, c));
        Array.isArray(b.google_color_link) && (b.google_color_link = aM(a, b.google_color_link, c));
        Array.isArray(b.google_color_url) && (b.google_color_url = aM(a, b.google_color_url, c));
        Array.isArray(b.google_color_border) && (b.google_color_border = aM(a, b.google_color_border, c));
        Array.isArray(b.google_color_line) && (b.google_color_line = aM(a, b.google_color_line, c))
    };

    function aM(a, b, c) {
        a.g |= 2;
        return b[c % b.length]
    };
    var cM = (a, b = !1) => {
        try {
            return b ? (new Yd(a.innerWidth, a.innerHeight)).round() : he(a || window).round()
        } catch (c) {
            return new Yd(-12245933, -12245933)
        }
    };

    function dM(a = r) {
        a = a.devicePixelRatio;
        return "number" === typeof a ? +a.toFixed(3) : null
    }

    function eM(a, b = r) {
        a = a.scrollingElement || ("CSS1Compat" == a.compatMode ? a.documentElement : a.body);
        return new Xd(b.pageXOffset || a.scrollLeft, b.pageYOffset || a.scrollTop)
    }

    function fM(a) {
        try {
            return !(!a || !(a.offsetWidth || a.offsetHeight || a.getClientRects().length))
        } catch (b) {
            return !1
        }
    };

    function gM(a, b) {
        var c = Wz,
            d;
        var e;
        d = (e = (e = ok()) && (d = e.initialLayoutRect) && "number" === typeof d.top && "number" === typeof d.left && "number" === typeof d.width && "number" === typeof d.height ? new kk(d.left, d.top, d.width, d.height) : null) ? new Xd(e.left, e.top) : (d = rk()) && Aa(d.rootBounds) ? new Xd(d.rootBounds.left + d.boundingClientRect.left, d.rootBounds.top + d.boundingClientRect.top) : null;
        if (d) return d;
        try {
            var f = new Xd(0, 0),
                g = ge(b);
            var h = g ? je(g) : window;
            if (Wb(h, "parent")) {
                do {
                    if (h == a) var k = Dk(b);
                    else {
                        var l = Ck(b);
                        k = new Xd(l.left,
                            l.top)
                    }
                    g = k;
                    f.x += g.x;
                    f.y += g.y
                } while (h && h != a && h != h.parent && (b = h.frameElement) && (h = h.parent))
            }
            return f
        } catch (m) {
            return c.Ba(888, m), new Xd(-12245933, -12245933)
        }
    };

    function hM(a, b, c) {
        return c ? ak(b, c, a.g) : null
    }

    function iM(a, b, c, d) {
        if (d) {
            var e = Qi(c, 2) - Date.now() / 1E3;
            e = {
                Fd: Math.max(e, 0),
                path: P(c, 3),
                domain: P(c, 4),
                eh: !1
            };
            c = c.getValue();
            a = a.g;
            O(d, 5) && Zj(a) && (new Wj(a.document)).set(b, c, e)
        }
    }

    function jM(a, b, c) {
        if (c && ak(b, c, a.g))
            for (const d of kM(a.g.location.hostname)) bk(b, c, a.g, "/", d)
    }
    var lM = class {
        constructor(a) {
            this.g = a;
            this.i = 0
        }
    };

    function kM(a) {
        if ("localhost" === a) return ["localhost"];
        a = a.split(".");
        if (2 > a.length) return [];
        const b = [];
        for (let c = 0; c < a.length - 1; ++c) b.push(a.slice(c).join("."));
        return b
    };

    function mM(a, b, c) {
        return Zz(629, function(d) {
            delete a._gfp_s_;
            if (v(Zs) && Z(UI(), 37, !1)) return Promise.resolve();
            if (!d) throw Error("Invalid JSONP response");
            d = d._cookies_;
            if (!d) return Promise.resolve();
            if (0 === d.length) throw Error("Invalid JSONP response");
            for (const f of d) {
                var e = f._domain_;
                const g = f._value_,
                    h = f._expires_,
                    k = f._path_;
                d = f._version_ || 1;
                if ("string" !== typeof e || "string" !== typeof g || "number" !== typeof h || "string" !== typeof k || "number" !== typeof d || !g) throw Error("Invalid JSONP response");
                e = Mj(Lj(Kj(Ij(g),
                    h), k), e);
                switch (d) {
                    case 1:
                        iM(c, "__gads", e, b);
                        break;
                    case 2:
                        iM(c, "__gpi", e, b)
                }
            }
            return Promise.resolve()
        })
    }

    function nM(a, b, c) {
        let d;
        if (0 === a.i) {
            if (hM(a, "__gads", b)) var e = !0;
            else e = a.g, O(b, 5) && Zj(e) && (new Wj(e.document)).set("GoogleAdServingTest", "Good", void 0), (e = "Good" === ak("GoogleAdServingTest", b, a.g)) && bk("GoogleAdServingTest", b, a.g);
            a.i = e ? 2 : 1
        }
        2 === a.i && (d = mM(c, b, a));
        c._gfp_p_ = !0;
        return d
    }

    function oM(a, b, c, d) {
        d = {
            domain: c.location.hostname,
            callback: "_gfp_s_",
            client: d
        };
        var e = hM(b, "__gads", a);
        e && (d.cookie = e);
        (e = hM(b, "__gpi", a)) && !e.includes("&") && (d.gpic = e);
        const f = $c(sj `https://partner.googleadservices.com/gampad/cookie.js`, d),
            g = nM(b, a, c);
        g ? new Promise(h => {
            c._gfp_s_ = k => {
                g(k).then(h)
            };
            We(c.document, f)
        }) : Promise.resolve()
    }

    function pM(a, b, c) {
        "_gfp_p_" in b || (b._gfp_p_ = !1);
        var d = new lM(b);
        c = b.google_ad_client || c;
        const e = b._gfp_p_;
        if ("boolean" !== typeof e) throw Error(`Illegal value of ${"_gfp_p_"}: ${e}`);
        e ? Promise.resolve() : oM(a, d, b, c)
    };
    const qM = (a, b) => {
            b = b.listener;
            (a = (0, a.__gpp)("addEventListener", b)) && b(a, !0)
        },
        rM = (a, b) => {
            (0, a.__gpp)("removeEventListener", b.listener, b.listenerId)
        },
        sM = (a, b) => {
            (0, a.__gpp)("getSection", c => {
                b.callback({
                    ob: c ? ? void 0,
                    md: c ? void 0 : 4
                })
            }, b.apiPrefix)
        },
        tM = {
            Ec: a => a.listener,
            Sb: (a, b) => ({
                __gppCall: {
                    callId: b,
                    command: "addEventListener",
                    version: "1.1"
                }
            }),
            xb: (a, b) => {
                b = b.__gppReturn;
                a(b.returnValue, b.success)
            }
        },
        uM = {
            Ec: a => a.listener,
            Sb: (a, b) => ({
                __gppCall: {
                    callId: b,
                    command: "removeEventListener",
                    version: "1.1",
                    parameter: a.listenerId
                }
            }),
            xb: (a, b) => {
                b = b.__gppReturn;
                const c = b.returnValue.data;
                a ? .(c, b.success)
            }
        },
        vM = {
            Ec: a => a.callback,
            Sb: (a, b) => ({
                __gppCall: {
                    callId: b,
                    command: "getSection",
                    version: "1.1",
                    parameter: a.apiPrefix
                }
            }),
            xb: (a, b) => {
                b = b.__gppReturn;
                a({
                    ob: b.returnValue ? ? void 0,
                    md: b.success ? void 0 : 2
                })
            }
        };

    function wM(a) {
        let b = {};
        "string" === typeof a.data ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            df: b.__gppReturn.callId
        }
    }

    function xM(a) {
        if (!a) return !1;
        const b = zK(a.split("~")[0]),
            c = uK(a);
        for (let yi = 0; yi < bi(b, 3, hh, 2).length; ++yi) {
            const UP = bi(b, 3, hh, 2)[yi],
                ac = c[yi];
            switch (UP) {
                case 8:
                    if (0 === ac.length) throw Error("Cannot decode empty USCA section string.");
                    const Zf = ac.split(".");
                    if (2 < Zf.length) throw Error(`Expected at most 1 sub-section but got ${Zf.length-1} when decoding ${ac}.`);
                    var d = void 0,
                        e = void 0,
                        f = void 0,
                        g = void 0,
                        h = void 0,
                        k = void 0,
                        l = void 0,
                        m = void 0,
                        n = void 0,
                        p = void 0,
                        q = void 0,
                        x = void 0,
                        z = void 0,
                        G = void 0,
                        E = void 0,
                        K = void 0,
                        H = void 0,
                        N = void 0,
                        J = void 0,
                        Ea = void 0,
                        Ya = void 0,
                        Eb = void 0,
                        ba = void 0,
                        tb = Zf[0];
                    if (0 === tb.length) throw Error("Cannot decode empty core segment string.");
                    let zi = yK(tb, IK);
                    const Jm = wK(zi.slice(0, 6));
                    zi = zi.slice(6);
                    if (1 !== Jm) throw Error(`Unable to decode unsupported USCA Section specification version ${Jm} - only version 1 is supported.`);
                    let Km = 0;
                    const sa = [];
                    for (let la = 0; la < HK.length; la++) {
                        const fa = HK[la];
                        sa.push(wK(zi.slice(Km, Km + fa)));
                        Km += fa
                    }
                    var rc = new DK;
                    ba = Yi(rc, 1, Jm);
                    var sc = sa.shift();
                    Eb =
                        R(ba, 2, sc);
                    var Sd = sa.shift();
                    Ya = R(Eb, 3, Sd);
                    var aa = sa.shift();
                    Ea = R(Ya, 4, aa);
                    var tc = sa.shift();
                    J = R(Ea, 5, tc);
                    var Lm = sa.shift();
                    N = R(J, 6, Lm);
                    var Mm = new CK,
                        Nm = sa.shift();
                    H = R(Mm, 1, Nm);
                    var Om = sa.shift();
                    K = R(H, 2, Om);
                    var Pm = sa.shift();
                    E = R(K, 3, Pm);
                    var Qm = sa.shift();
                    G = R(E, 4, Qm);
                    var Rm = sa.shift();
                    z = R(G, 5, Rm);
                    var Sm = sa.shift();
                    x = R(z, 6, Sm);
                    var Tm = sa.shift();
                    q = R(x, 7, Tm);
                    var Um = sa.shift();
                    p = R(q, 8, Um);
                    var Vm = sa.shift();
                    n = R(p, 9, Vm);
                    m = F(N, 7, n);
                    var Wm = new BK,
                        Xm = sa.shift();
                    l = R(Wm, 1, Xm);
                    var Ym = sa.shift();
                    k = R(l, 2, Ym);
                    h =
                        F(m, 8, k);
                    var Zm = sa.shift();
                    g = R(h, 9, Zm);
                    var $m = sa.shift();
                    f = R(g, 10, $m);
                    var an = sa.shift();
                    e = R(f, 11, an);
                    var $f = sa.shift();
                    const uw = d = R(e, 12, $f);
                    if (1 === Zf.length) var Ai = FK(uw);
                    else {
                        var Bi = FK(uw),
                            Ci = void 0,
                            Fe = void 0,
                            Di = void 0,
                            Ei = Zf[1];
                        if (0 === Ei.length) throw Error("Cannot decode empty GPC segment string.");
                        const la = yK(Ei, 3),
                            fa = wK(la.slice(0, 2));
                        if (0 > fa || 1 < fa) throw Error(`Attempting to decode unknown GPC segment subsection type ${fa}.`);
                        Di = fa + 1;
                        const ag = wK(la.charAt(2));
                        var bn = new EK;
                        Fe = R(bn, 2, Di);
                        Ci = Wi(Fe,
                            1, !!ag);
                        Ai = F(Bi, 2, Ci)
                    }
                    const vw = C(Ai, DK, 1);
                    if (1 === Ri(vw, 5) || 1 === Ri(vw, 6)) return !0;
                    break;
                case 10:
                    if (0 === ac.length) throw Error("Cannot decode empty USCO section string.");
                    const bg = ac.split(".");
                    if (2 < bg.length) throw Error(`Expected at most 2 segments but got ${bg.length} when decoding ${ac}.`);
                    var Ge = void 0,
                        He = void 0,
                        Fi = void 0,
                        Wa = void 0,
                        cg = void 0,
                        Gi = void 0,
                        Hi = void 0,
                        dg = void 0,
                        eg = void 0,
                        fg = void 0,
                        gg = void 0,
                        hg = void 0,
                        Kb = void 0,
                        uc = void 0,
                        wb = void 0,
                        mb = void 0,
                        Ii = void 0,
                        Ie = void 0,
                        Je = bg[0];
                    if (0 === Je.length) throw Error("Cannot decode empty core segment string.");
                    let Ji = yK(Je, PK);
                    const cn = wK(Ji.slice(0, 6));
                    Ji = Ji.slice(6);
                    if (1 !== cn) throw Error(`Unable to decode unsupported USCO Section specification version ${cn} - only version 1 is supported.`);
                    let dn = 0;
                    const Pa = [];
                    for (let la = 0; la < OK.length; la++) {
                        const fa = OK[la];
                        Pa.push(wK(Ji.slice(dn, dn + fa)));
                        dn += fa
                    }
                    var xb = new KK;
                    Ie = Yi(xb, 1, cn);
                    var Ga = Pa.shift();
                    Ii = R(Ie, 2, Ga);
                    var cb = Pa.shift();
                    mb = R(Ii, 3, cb);
                    var nb = Pa.shift();
                    wb = R(mb, 4, nb);
                    var Qa = Pa.shift();
                    uc = R(wb, 5, Qa);
                    var Lb = Pa.shift();
                    Kb = R(uc, 6, Lb);
                    var Ki = new JK,
                        Li = Pa.shift();
                    hg = R(Ki, 1, Li);
                    var Nc = Pa.shift();
                    gg = R(hg, 2, Nc);
                    var Mi = Pa.shift();
                    fg = R(gg, 3, Mi);
                    var ig = Pa.shift();
                    eg = R(fg, 4, ig);
                    var jg = Pa.shift();
                    dg = R(eg, 5, jg);
                    var Td = Pa.shift();
                    Hi = R(dg, 6, Td);
                    var en = Pa.shift();
                    Gi = R(Hi, 7, en);
                    cg = F(Kb, 7, Gi);
                    var kg = Pa.shift();
                    Wa = R(cg, 8, kg);
                    var Ni = Pa.shift();
                    Fi = R(Wa, 9, Ni);
                    var VP = Pa.shift();
                    He = R(Fi, 10, VP);
                    var WP = Pa.shift();
                    const ww = Ge = R(He, 11, WP);
                    if (1 === bg.length) var xw = MK(ww);
                    else {
                        var XP = MK(ww),
                            yw = void 0,
                            zw = void 0,
                            Aw = void 0,
                            Bw = bg[1];
                        if (0 === Bw.length) throw Error("Cannot decode empty GPC segment string.");
                        const la = yK(Bw, 3),
                            fa = wK(la.slice(0, 2));
                        if (0 > fa || 1 < fa) throw Error(`Attempting to decode unknown GPC segment subsection type ${fa}.`);
                        Aw = fa + 1;
                        const ag = wK(la.charAt(2));
                        var YP = new LK;
                        zw = R(YP, 2, Aw);
                        yw = Wi(zw, 1, !!ag);
                        xw = F(XP, 2, yw)
                    }
                    const Cw = C(xw, KK, 1);
                    if (1 === Ri(Cw, 5) || 1 === Ri(Cw, 6)) return !0;
                    break;
                case 12:
                    if (0 === ac.length) throw Error("Cannot decode empty usct section string.");
                    const lg = ac.split(".");
                    if (2 < lg.length) throw Error(`Expected at most 2 segments but got ${lg.length} when decoding ${ac}.`);
                    var ZP =
                        void 0,
                        Dw = void 0,
                        Ew = void 0,
                        Fw = void 0,
                        Gw = void 0,
                        Hw = void 0,
                        Iw = void 0,
                        Jw = void 0,
                        Kw = void 0,
                        Lw = void 0,
                        Mw = void 0,
                        Nw = void 0,
                        Ow = void 0,
                        Pw = void 0,
                        Qw = void 0,
                        Rw = void 0,
                        Sw = void 0,
                        Tw = void 0,
                        Uw = void 0,
                        Vw = void 0,
                        Ww = void 0,
                        Xw = void 0,
                        Yw = lg[0];
                    if (0 === Yw.length) throw Error("Cannot decode empty core segment string.");
                    let Oi = yK(Yw, XK);
                    const fn = wK(Oi.slice(0, 6));
                    Oi = Oi.slice(6);
                    if (1 !== fn) throw Error(`Unable to decode unsupported USCT Section specification version ${fn} - only version 1 is supported.`);
                    let gn = 0;
                    const wa = [];
                    for (let la = 0; la < WK.length; la++) {
                        const fa = WK[la];
                        wa.push(wK(Oi.slice(gn, gn + fa)));
                        gn += fa
                    }
                    var $P = new SK;
                    Xw = Yi($P, 1, fn);
                    var aQ = wa.shift();
                    Ww = R(Xw, 2, aQ);
                    var bQ = wa.shift();
                    Vw = R(Ww, 3, bQ);
                    var cQ = wa.shift();
                    Uw = R(Vw, 4, cQ);
                    var dQ = wa.shift();
                    Tw = R(Uw, 5, dQ);
                    var eQ = wa.shift();
                    Sw = R(Tw, 6, eQ);
                    var fQ = new RK,
                        gQ = wa.shift();
                    Rw = R(fQ, 1, gQ);
                    var hQ = wa.shift();
                    Qw = R(Rw, 2, hQ);
                    var iQ = wa.shift();
                    Pw = R(Qw, 3, iQ);
                    var jQ = wa.shift();
                    Ow = R(Pw, 4, jQ);
                    var kQ = wa.shift();
                    Nw = R(Ow, 5, kQ);
                    var lQ = wa.shift();
                    Mw = R(Nw, 6, lQ);
                    var mQ = wa.shift();
                    Lw =
                        R(Mw, 7, mQ);
                    var nQ = wa.shift();
                    Kw = R(Lw, 8, nQ);
                    Jw = F(Sw, 7, Kw);
                    var oQ = new QK,
                        pQ = wa.shift();
                    Iw = R(oQ, 1, pQ);
                    var qQ = wa.shift();
                    Hw = R(Iw, 2, qQ);
                    var rQ = wa.shift();
                    Gw = R(Hw, 3, rQ);
                    Fw = F(Jw, 8, Gw);
                    var sQ = wa.shift();
                    Ew = R(Fw, 9, sQ);
                    var tQ = wa.shift();
                    Dw = R(Ew, 10, tQ);
                    var uQ = wa.shift();
                    const Zw = ZP = R(Dw, 11, uQ);
                    if (1 === lg.length) var $w = UK(Zw);
                    else {
                        var vQ = UK(Zw),
                            ax = void 0,
                            bx = void 0,
                            cx = void 0,
                            dx = lg[1];
                        if (0 === dx.length) throw Error("Cannot decode empty GPC segment string.");
                        const la = yK(dx, 3),
                            fa = wK(la.slice(0, 2));
                        if (0 > fa || 1 < fa) throw Error(`Attempting to decode unknown GPC segment subsection type ${fa}.`);
                        cx = fa + 1;
                        const ag = wK(la.charAt(2));
                        var wQ = new TK;
                        bx = R(wQ, 2, cx);
                        ax = Wi(bx, 1, !!ag);
                        $w = F(vQ, 2, ax)
                    }
                    const ex = C($w, SK, 1);
                    if (1 === Ri(ex, 5) || 1 === Ri(ex, 6)) return !0;
                    break;
                case 9:
                    if (0 === ac.length) throw Error("Cannot decode empty USVA section string.");
                    let Pi = yK(ac, aL);
                    const hn = wK(Pi.slice(0, 6));
                    Pi = Pi.slice(6);
                    if (1 !== hn) throw Error(`Unable to decode unsupported USVA Section specification version ${hn} - only version 1 is supported.`);
                    let jn = 0;
                    const Ha = [];
                    for (let la = 0; la < $K.length; la++) {
                        const fa = $K[la];
                        Ha.push(wK(Pi.slice(jn,
                            jn + fa)));
                        jn += fa
                    }
                    var xQ = hn,
                        yQ = new ZK,
                        zQ = Yi(yQ, 1, xQ),
                        AQ = Ha.shift(),
                        BQ = R(zQ, 2, AQ),
                        CQ = Ha.shift(),
                        DQ = R(BQ, 3, CQ),
                        EQ = Ha.shift(),
                        FQ = R(DQ, 4, EQ),
                        GQ = Ha.shift(),
                        HQ = R(FQ, 5, GQ),
                        IQ = Ha.shift();
                    var JQ = R(HQ, 6, IQ);
                    var KQ = new YK,
                        LQ = Ha.shift(),
                        MQ = R(KQ, 1, LQ),
                        NQ = Ha.shift(),
                        OQ = R(MQ, 2, NQ),
                        PQ = Ha.shift(),
                        QQ = R(OQ, 3, PQ),
                        RQ = Ha.shift(),
                        SQ = R(QQ, 4, RQ),
                        TQ = Ha.shift(),
                        UQ = R(SQ, 5, TQ),
                        VQ = Ha.shift(),
                        WQ = R(UQ, 6, VQ),
                        XQ = Ha.shift(),
                        YQ = R(WQ, 7, XQ),
                        ZQ = Ha.shift();
                    var $Q = R(YQ, 8, ZQ);
                    var aR = F(JQ, 7, $Q),
                        bR = Ha.shift(),
                        cR = R(aR, 8, bR),
                        dR = Ha.shift(),
                        eR = R(cR,
                            9, dR),
                        fR = Ha.shift(),
                        gR = R(eR, 10, fR),
                        hR = Ha.shift(),
                        fx = R(gR, 11, hR);
                    if (1 === Ri(fx, 5) || 1 === Ri(fx, 6)) return !0
            }
        }
        return !1
    }
    var BM = class extends U {
        constructor(a) {
            var {
                gppApiDetectionMode: b,
                timeoutMs: c
            } = {};
            super();
            this.caller = new eE(a, b && 1 !== b && 3 !== b ? "__gppLocator_non_existent" : "__gppLocator", b && 1 !== b && 2 !== b ? void 0 : d => "function" === typeof d.__gpp, wM);
            this.caller.A.set("addEventListener", qM);
            this.caller.j.set("addEventListener", tM);
            this.caller.A.set("removeEventListener", rM);
            this.caller.j.set("removeEventListener", uM);
            this.caller.A.set("getDataWithCallback", sM);
            this.caller.j.set("getDataWithCallback", vM);
            this.timeoutMs = c ? ?
                500
        }
        i() {
            this.caller.ma();
            super.i()
        }
        addEventListener(a) {
            const b = Nb(() => {
                    a(yM, !0)
                }),
                c = -1 === this.timeoutMs ? void 0 : setTimeout(() => {
                    b()
                }, this.timeoutMs);
            dE(this.caller, "addEventListener", {
                listener: (d, e) => {
                    clearTimeout(c);
                    try {
                        if (void 0 === d.pingData ? .gppVersion || "1" === d.pingData.gppVersion || "1.0" === d.pingData.gppVersion) {
                            this.removeEventListener(d.listenerId);
                            var f = {
                                eventName: "signalStatus",
                                data: "ready",
                                pingData: {
                                    internalErrorState: 1,
                                    gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                                    applicableSections: [-1]
                                }
                            }
                        } else Array.isArray(d.pingData.applicableSections) &&
                            0 !== d.pingData.applicableSections.length ? f = d : (this.removeEventListener(d.listenerId), f = {
                                eventName: "signalStatus",
                                data: "ready",
                                pingData: {
                                    internalErrorState: 2,
                                    gppString: "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                                    applicableSections: [-1]
                                }
                            });
                        a(f, e)
                    } catch {
                        if (d ? .listenerId) try {
                            this.removeEventListener(d.listenerId)
                        } catch {
                            a(zM, !0);
                            return
                        }
                        a(AM, !0)
                    }
                }
            })
        }
        removeEventListener(a) {
            dE(this.caller, "removeEventListener", {
                listenerId: a
            })
        }
    };
    const AM = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                internalErrorState: 2,
                gppString: "GPP_ERROR_STRING_UNAVAILABLE",
                applicableSections: [-1]
            },
            listenerId: -1
        },
        yM = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        },
        zM = {
            eventName: "signalStatus",
            data: "ready",
            pingData: {
                gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
                internalErrorState: 2,
                applicableSections: [-1]
            },
            listenerId: -1
        };

    function CM(a) {
        return !a || 1 === a.length && -1 === a[0]
    };

    function DM(a, b) {
        if (b.internalErrorState) $i(a, 11, b.gppString);
        else if (CM(b.applicableSections)) {
            var c = ki(a, 10, b.applicableSections, kh);
            Vi(c, 12, !1)
        } else {
            c = !1;
            try {
                c = xM(b.gppString)
            } catch (d) {
                aA(1182, d)
            }
            a = ki(a, 10, b.applicableSections, kh);
            b = $i(a, 11, b.gppString);
            Vi(b, 12, c)
        }
    }

    function EM(a) {
        const b = new BM(a.pubWin);
        if (!bE(b.caller)) return Promise.resolve(null);
        const c = UI(),
            d = Z(c, 35);
        if (d) return Promise.resolve(d);
        const e = new Promise(f => {
            f = {
                resolve: f
            };
            const g = Z(c, 36, []);
            g.push(f);
            ZI(c, 36, g)
        });
        d || null === d || (ZI(c, 35, null), b.addEventListener(f => {
            if ("ready" === f.pingData.signalStatus || CM(f.pingData.applicableSections)) {
                f = f.pingData;
                ZI(c, 35, f);
                DM(a.i, f);
                for (const g of Z(c, 36, [])) g.resolve(f);
                ZI(c, 36, [])
            }
        }));
        return e
    };

    function FM(a) {
        a.easpi = v(vu);
        a.asla = .4;
        a.asaa = -1;
        a.sedf = !1;
        a.asro = v(ou);
        a.sefa = !0;
        v(uu) && (a.sugawps = !0);
        const b = u(Xb).g(Zt.g, Zt.defaultValue);
        b.length && (a.seiel = b.join("~"));
        a.slcwct = w(hu);
        a.sacwct = w(Ot);
        v(eu) && (a.slmct = w(iu), a.samct = w(Qt))
    };

    function GM(a, b) {
        return gD({
            K: a,
            Te: 3E3,
            We: a.innerWidth > to ? 650 : 0,
            ua: Vz,
            Rf: b,
            Dj: v(yu)
        })
    };
    var HM = a => {
        let b = 0;
        try {
            b |= uo(a)
        } catch (c) {
            b |= 32
        }
        return b
    };
    var IM = a => {
        let b = 0;
        try {
            b |= uo(a), b |= vo(a, 1E4)
        } catch (c) {
            b |= 32
        }
        return b
    };

    function JM(a) {
        return a.prerendering ? 3 : {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""] || 0
    }

    function KM(a) {
        let b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    }

    function LM(a) {
        return null != a.hidden ? a.hidden : null != a.mozHidden ? a.mozHidden : null != a.webkitHidden ? a.webkitHidden : null
    }

    function MM(a, b) {
        if (3 == JM(b)) var c = !1;
        else a(), c = !0;
        if (!c) {
            const d = () => {
                Ub(b, "prerenderingchange", d);
                a()
            };
            Tb(b, "prerenderingchange", d)
        }
    };
    var NM = (a, b, c = !0, d = !1) => {
        let e = 0;
        try {
            e |= uo(a);
            var f;
            if (!(f = !a.navigator)) {
                var g = a.navigator;
                f = "brave" in g && "isBrave" in g.brave || !1
            }
            e |= f || /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
            e |= vo(a, 2500, d);
            d || (e |= xo(a));
            !c || b && GF(b) || (e |= 4194304)
        } catch (h) {
            e |= 32
        }
        return e
    };

    function OM(a, b, c, d = null) {
        let e = uo(a);
        hD(a.navigator ? .userAgent) && (e |= 1048576);
        const f = a.innerWidth;
        1200 > f && (e |= 65536);
        const g = a.innerHeight;
        650 > g && (e |= 2097152);
        d && 0 === e && (d = 3 === d ? "left" : "right", (b = PM({
            K: a,
            wg: b,
            bh: 1,
            position: d,
            R: f,
            U: g,
            tb: new Set,
            minWidth: 120,
            minHeight: 500
        })) ? c && Zv(a).sideRailPlasParam.set(d, `${b.width}x${b.height}_${String(d).charAt(0)}`) : e |= 16);
        return e
    }

    function QM(a) {
        if (v(Lt)) return [...Zv(a).sideRailPlasParam.values()].join("|");
        if (0 !== OM(a, !0, !1)) return "";
        const b = [],
            c = a.innerWidth,
            d = a.innerHeight;
        for (const e of ["left", "right"]) {
            const f = PM({
                K: a,
                wg: !0,
                bh: 1,
                position: e,
                R: c,
                U: d,
                tb: new Set,
                minWidth: 120,
                minHeight: 500
            });
            f && b.push(`${f.width}x${f.height}_${String(e).charAt(0)}`)
        }
        return b.join("|")
    }

    function RM(a, b) {
        return null !== re(a, c => c.nodeType === Node.ELEMENT_NODE && b.has(c))
    }

    function SM(a, b) {
        return re(a, c => c.nodeType === Node.ELEMENT_NODE && "fixed" === b.getComputedStyle(c, null).position)
    }

    function TM(a) {
        const b = [];
        for (const c of a.document.querySelectorAll("*")) {
            const d = a.getComputedStyle(c, null);
            "fixed" === d.position && "none" !== d.display && "hidden" !== d.visibility && b.push(c)
        }
        return b
    }

    function UM(a) {
        return Math.round(10 * Math.round(a / 10))
    }

    function VM(a) {
        return `${a.position}-${UM(a.R)}x${UM(a.U)}-${UM(a.scrollY+a.cc)}Y`
    }

    function WM(a) {
        return `f-${VM({position:a.position,cc:a.cc,scrollY:0,R:a.R,U:a.U})}`
    }

    function XM(a, b) {
        a = Math.min(a ? ? Infinity, b ? ? Infinity);
        return Infinity !== a ? a : 0
    }

    function YM(a, b, c) {
        const d = Zv(c.K).sideRailProcessedFixedElements;
        if (!d.has(a)) {
            var e = a.getBoundingClientRect();
            if (e) {
                var f = Math.max(e.top - 10, 0),
                    g = Math.min(e.bottom + 10, c.U),
                    h = Math.max(e.left - 10, 0);
                e = Math.min(e.right + 10, c.R);
                for (var k = .3 * c.R; f <= g; f += 10) {
                    if (0 < e && h < k) {
                        var l = WM({
                            position: "left",
                            cc: f,
                            R: c.R,
                            U: c.U
                        });
                        b.set(l, XM(b.get(l), h))
                    }
                    if (h < c.R && e > c.R - k) {
                        l = WM({
                            position: "right",
                            cc: f,
                            R: c.R,
                            U: c.U
                        });
                        const m = c.R - e;
                        b.set(l, XM(b.get(l), m))
                    }
                }
                d.add(a)
            }
        }
    }

    function PM(a) {
        if (1200 > a.R || 650 > a.U) return null;
        var b = Zv(a.K).sideRailAvailableSpace;
        if (!a.wg) {
            var c = {
                    K: a.K,
                    R: a.R,
                    U: a.U,
                    tb: a.tb
                },
                d = `f-${UM(c.R)}x${UM(c.U)}`;
            if (!b.has(d)) {
                b.set(d, 0);
                Zv(c.K).sideRailProcessedFixedElements.clear();
                d = new Set([...Array.from(c.K.document.querySelectorAll("[data-anchor-status],[data-side-rail-status]")), ...c.tb]);
                for (var e of TM(c.K)) RM(e, d) || YM(e, b, c)
            }
        }
        c = [];
        d = .9 * a.U;
        var f = Eo(a.K),
            g = e = (a.U - d) / 2,
            h = d / 7;
        for (var k = 0; 8 > k; k++) {
            var l = c,
                m = l.push;
            a: {
                var n = g;
                var p = a.position,
                    q = b,
                    x = {
                        K: a.K,
                        R: a.R,
                        U: a.U,
                        tb: a.tb
                    };
                const G = WM({
                        position: p,
                        cc: n,
                        R: x.R,
                        U: x.U
                    }),
                    E = VM({
                        position: p,
                        cc: n,
                        scrollY: f,
                        R: x.R,
                        U: x.U
                    });
                if (q.has(E)) {
                    n = XM(q.get(G), q.get(E));
                    break a
                }
                const K = "left" === p ? 20 : x.R - 20;
                let H = K;p = .3 * x.R / 5 * ("left" === p ? 1 : -1);
                for (let N = 0; 6 > N; N++) {
                    const J = Sv(x.K.document, {
                        x: Math.round(H),
                        y: Math.round(n)
                    });
                    var z = RM(J, x.tb);
                    const Ea = SM(J, x.K);
                    if (!z && null !== Ea) {
                        YM(Ea, q, x);
                        q.delete(E);
                        break
                    }
                    z || (z = J.offsetHeight >= .25 * x.U, z = J.offsetWidth >= .9 * x.R && z);
                    if (z) q.set(E, Math.round(Math.abs(H - K) + 20));
                    else if (H !==
                        K) H -= p, p /= 2;
                    else {
                        q.set(E, 0);
                        break
                    }
                    H += p
                }
                n = XM(q.get(G), q.get(E))
            }
            m.call(l, n);
            g += h
        }
        b = a.bh;
        f = a.position;
        d = Math.round(d / 8);
        e = Math.round(e);
        g = a.minWidth;
        a = a.minHeight;
        m = [];
        h = Array(c.length).fill(0);
        for (l = 0; l < c.length; l++) {
            for (; 0 !== m.length && c[m[m.length - 1]] >= c[l];) m.pop();
            h[l] = 0 === m.length ? 0 : m[m.length - 1] + 1;
            m.push(l)
        }
        m = [];
        k = c.length - 1;
        l = Array(c.length).fill(0);
        for (n = k; 0 <= n; n--) {
            for (; 0 !== m.length && c[m[m.length - 1]] >= c[n];) m.pop();
            l[n] = 0 === m.length ? k : m[m.length - 1] - 1;
            m.push(n)
        }
        m = null;
        for (k = 0; k < c.length; k++)
            if (n = {
                    position: f,
                    width: Math.round(c[k]),
                    height: Math.round((l[k] - h[k] + 1) * d),
                    offsetY: e + h[k] * d
                }, q = n.width >= g && n.height >= a, 0 === b && q) {
                m = n;
                break
            } else 1 === b && q && (!m || n.width * n.height > m.width * m.height) && (m = n);
        return m
    };
    const ZM = {
        [27]: 512,
        [26]: 128
    };
    var $M = (a, b, c, d) => {
            switch (c) {
                case 1:
                case 2:
                    return 0 === GM(a, c);
                case 3:
                case 4:
                    return 0 === OM(a, !1, !1, c);
                case 8:
                    return 0 == NM(a, d, !("on" === b.google_adtest || lK(a.location, "google_ia_debug")), v(zu));
                case 9:
                    return b = !("on" === b.google_adtest || lK(a.location, "google_scr_debug")), !KF(a, b, d);
                case 30:
                    return 0 == yH(a);
                case 26:
                    return 0 == IM(a);
                case 27:
                    return 0 === HM(a);
                case 40:
                    return !0;
                default:
                    return !1
            }
        },
        aN = (a, b, c, d) => {
            switch (c) {
                case 0:
                case 40:
                case 10:
                case 11:
                    return 0;
                case 1:
                case 2:
                    return GM(a, c);
                case 3:
                case 4:
                    return OM(a,
                        v(Mt), v(Lt), c);
                case 8:
                    return NM(a, d, !("on" === b.google_adtest || lK(a.location, "google_ia_debug")), v(zu));
                case 9:
                    return KF(a, !("on" === b.google_adtest || lK(a.location, "google_scr_debug")), d);
                case 16:
                    return lv(b, a) ? 0 : 8388608;
                case 30:
                    return yH(a);
                case 26:
                    return IM(a);
                case 27:
                    return HM(a);
                default:
                    return 32
            }
        },
        bN = (a, b, c) => {
            const d = b.google_reactive_ad_format;
            if (!Qc(d)) return !1;
            a = Ve(a);
            if (!a || !$M(a, b, d, c)) return !1;
            b = Zv(a);
            if (Bo(b, d)) return !1;
            b.adCount[d] || (b.adCount[d] = 0);
            b.adCount[d]++;
            return !0
        },
        dN = a => {
            const b =
                a.google_reactive_ad_format;
            return !a.google_reactive_ads_config && cN(a) && 16 !== b && 10 !== b && 11 !== b && 40 !== b && 41 !== b
        },
        eN = a => {
            if (!a.hash) return null;
            let b = null;
            $e(iK, c => {
                !b && lK(a, c) && (b = jK[c])
            });
            return b
        },
        gN = (a, b) => {
            const c = Zv(a).tagSpecificState[1] || null;
            null != c && null == c.debugCard && $e(kK, d => {
                !c.debugCardRequested && "number" === typeof d && oK(d, a.location) && (c.debugCardRequested = !0, fN(a, b, e => {
                    c.debugCard = e.createDebugCard(d, a)
                }))
            })
        },
        iN = (a, b, c) => {
            if (!b) return null;
            const d = Zv(b);
            let e = 0;
            $e(Rc, f => {
                const g = ZM[f];
                g && 0 === hN(a, b, f, c) && (e |= g)
            });
            d.wasPlaTagProcessed && (e |= 256);
            a.google_reactive_tag_first && (e |= 1024);
            return e ? "" + e : null
        },
        jN = (a, b, c) => {
            const d = [];
            $e(Rc, e => {
                const f = hN(b, a, e, c);
                0 !== f && d.push(e + ":" + f)
            });
            return d.join(",") || null
        },
        kN = a => {
            const b = [],
                c = {};
            $e(a, (d, e) => {
                if ((e = ro[e]) && !c[e]) {
                    c[e] = !0;
                    if (d) d = 1;
                    else if (!1 === d) d = 2;
                    else return;
                    b.push(e + ":" + d)
                }
            });
            return b.join(",")
        },
        lN = a => {
            a = a.overlays;
            if (!a) return "";
            a = a.bottom;
            return "boolean" === typeof a ? a ? "1" : "0" : ""
        },
        hN = (a, b, c, d) => {
            if (!b) return 256;
            let e = 0;
            const f =
                Zv(b),
                g = Bo(f, c);
            if (a.google_reactive_ad_format == c || g) e |= 64;
            let h = !1;
            $e(f.reactiveTypeDisabledByPublisher, (k, l) => {
                String(c) === String(l) && (h = !0)
            });
            return h && eN(b.location) !== c && (e |= 128, 2 == c || 1 == c || 3 == c || 4 == c || 8 == c) ? e : e | aN(b, a, c, d)
        },
        mN = (a, b) => {
            if (a) {
                var c = Zv(a),
                    d = {};
                $e(b, (e, f) => {
                    (f = ro[f]) && (!1 === e || /^false$/i.test(e)) && (d[f] = !0)
                });
                $e(Rc, e => {
                    d[so[e]] && (c.reactiveTypeDisabledByPublisher[e] = !0)
                })
            }
        },
        nN = (a, b, c) => {
            b = Wz.Oa(b, c);
            return gK(3, window, a).Wc.then(b)
        },
        fN = (a, b, c) => {
            c = Wz.Oa(212, c);
            gK(4, a, b).Wc.then(c)
        },
        oN = a => {
            a = a.google_reactive_ad_format;
            return Qc(a) ? "" + a : null
        },
        cN = a => !!oN(a) || null != a.google_pgb_reactive,
        pN = a => {
            a = oN(a);
            return 26 == a || 27 == a || 30 == a || 16 == a || 40 == a || 41 == a
        };
    var qN = (a, b, c, d = null) => {
            const e = g => {
                let h;
                try {
                    h = JSON.parse(g.data)
                } catch (k) {
                    return
                }!h || h.googMsgType !== b || d && /[:|%3A]javascript\(/i.test(g.data) && !d(h, g) || c(h, g)
            };
            Tb(a, "message", e);
            let f = !1;
            return () => {
                let g = !1;
                f || (f = !0, g = Ub(a, "message", e));
                return g
            }
        },
        rN = (a, b, c, d = null) => {
            const e = qN(a, b, Ib(c, () => e()), d);
            return e
        },
        sN = (a, b, c, d, e) => {
            if (!(0 >= e) && (c.googMsgType = b, a.postMessage(JSON.stringify(c), d), a = a.frames))
                for (let f = 0; f < a.length; ++f) 1 < e && sN(a[f], b, c, d, --e)
        };

    function tN(a) {
        return "number" === typeof a.google_reactive_sra_index
    }

    function uN(a, b, c) {
        const d = b.K || b.pubWin,
            e = b.D;
        var f = jN(d, e, c);
        e.google_reactive_plat = f;
        (f = kN(a)) && (e.google_reactive_plaf = f);
        (f = lN(a)) && (e.google_reactive_fba = f);
        (f = QM(d)) && (e.google_plas = f);
        vN(a, e);
        f = eN(b.pubWin.location);
        wN(a, f, e);
        f ? (e.fra = f, e.google_pgb_reactive = 6) : e.google_pgb_reactive = 5;
        FM(e);
        e.fsapi = !0;
        8 !== f && (f = JF(c, 86400), f ? .length && (e.vmsli = Math.floor((Date.now() - Math.max(...f)) / 6E4)));
        sk() || cM(b.pubWin.top);
        f = rN(b.pubWin, "rsrai", Zz(429, (g, h) => xN(b, d, e.google_ad_client, a, g, h, c)), Zz(430,
            (g, h) => Ho(b.pubWin, "431", Vz, h)));
        b.j.push(f);
        Zv(d).wasReactiveTagRequestSent = !0;
        yN(b, a, c)
    }

    function yN(a, b, c) {
        const d = a.D,
            e = Aa(b.page_level_pubvars) ? b.page_level_pubvars : {};
        b = rN(a.pubWin, "apcnf", Zz(353, (f, g) => {
            const h = $c(a.ra.kb, eK());
            var k = a.pubWin,
                l = d.google_ad_client;
            return xf(g.origin) ? $L(k, l, e, f.config, c, h, null) : !1
        }), Zz(353, (f, g) => Ho(a.pubWin, "353", Vz, g)));
        a.j.push(b)
    }

    function xN(a, b, c, d, e, f, g) {
        if (!xf(f.origin)) return !1;
        f = e.data;
        if (!Array.isArray(f)) return !1;
        if (!QI(b, 1)) return !0;
        f && gk(6, [f]);
        e = e.amaConfig;
        const h = [],
            k = [],
            l = Zv(b);
        let m = null;
        for (let n = 0; n < f.length; n++) {
            if (!f[n]) continue;
            const p = f[n],
                q = p.adFormat;
            l && p.enabledInAsfe && (l.reactiveTypeEnabledInAsfe[q] = !0);
            if (!p.noCreative) {
                p.google_reactive_sra_index = n;
                if (9 === q && e) {
                    p.pubVars = Object.assign(p.pubVars || {}, zN(d, p));
                    const x = new LF;
                    if (EF(x, p) && x.C(p)) {
                        m = x;
                        continue
                    }
                }
                h.push(p);
                k.push(q)
            }
        }
        h.length && nN(a.ra.Wg,
            522, n => {
                AN(h, b, n, d, g)
            });
        e && $L(b, c, d, e, g, a.ra.kb, m);
        return !0
    }

    function zN(a, b) {
        const c = b.adFormat,
            d = b.adKey;
        delete b.adKey;
        const e = {};
        a = a.page_level_pubvars;
        Aa(a) && Object.assign(e, a);
        e.google_ad_unit_key = d;
        e.google_reactive_sra_index = b.google_reactive_sra_index;
        30 === c && (e.google_reactive_ad_format = 30);
        e.google_pgb_reactive = e.google_pgb_reactive || 5;
        return b.pubVars = e
    }

    function AN(a, b, c, d, e) {
        const f = [];
        for (let g = 0; g < a.length; g++) {
            const h = a[g],
                k = h.adFormat,
                l = h.adKey,
                m = c.configProcessorForAdFormat(k);
            k && m && l && (h.pubVars = zN(d, h), delete h.google_reactive_sra_index, f.push(k), Yz(466, () => m.verifyAndProcessConfig(b, h, e)))
        }
    }

    function vN(a, b) {
        const c = [];
        let d = !1;
        $e(ro, (e, f) => {
            let g;
            a.hasOwnProperty(f) && (f = a[f], f ? .google_ad_channel && (g = String(f.google_ad_channel)));
            --e;
            c[e] && "+" !== c[e] || (c[e] = g ? g.replace(/,/g, "+") : "+", d || (d = !!g))
        });
        d && (b.google_reactive_sra_channels = c.join(","))
    }

    function wN(a, b, c) {
        if (!c.google_adtest) {
            var d = a.page_level_pubvars;
            if ("on" === a.google_adtest || "on" === d ? .google_adtest || b) c.google_adtest = "on"
        }
    };
    Vb("script");
    var BN = {
        "image-top": 0,
        "image-middle": 1,
        "image-side": 2,
        "text-only": 3,
        "in-article": 4
    };

    function CN(a, b) {
        if (!lv(b, a)) return () => {};
        a = DN(b, a);
        if (!a) return () => {};
        const c = dJ();
        b = Tc(b);
        const d = {
            yb: a,
            D: b,
            offsetWidth: a.offsetWidth
        };
        c.push(d);
        return () => eb(c, d)
    }

    function DN(a, b) {
        a = b.document.getElementById(a.google_async_iframe_id);
        if (!a) return null;
        for (a = a.parentElement; a && !qv.test(a.className);) a = a.parentElement;
        return a
    }

    function EN(a, b) {
        for (let f = 0; f < a.childNodes.length; f++) {
            const g = {},
                h = a.childNodes[f];
            var c = h.style,
                d = ["width", "height"];
            for (let k = 0; k < d.length; k++) {
                const l = "google_ad_" + d[k];
                if (!g.hasOwnProperty(l)) {
                    var e = hf(c[d[k]]);
                    e = null === e ? null : Math.round(e);
                    null != e && (g[l] = e)
                }
            }
            if (g.google_ad_width == b.google_ad_width && g.google_ad_height == b.google_ad_height) return h
        }
        return null
    }

    function FN(a, b) {
        a.style.display = b ? "inline-block" : "none";
        const c = a.parentElement;
        b ? c.dataset.adStatus = a.dataset.adStatus : (a.dataset.adStatus = c.dataset.adStatus, delete c.dataset.adStatus)
    }

    function GN(a, b) {
        const c = b.innerHeight >= b.innerWidth ? 1 : 2;
        if (a.g != c) {
            a.g = c;
            a = dJ();
            for (const d of a)
                if (d.yb.offsetWidth != d.offsetWidth || d.D.google_full_width_responsive_allowed) d.offsetWidth = d.yb.offsetWidth, Yz(467, () => {
                    var e = d.yb,
                        f = d.D;
                    const g = EN(e, f);
                    f.google_full_width_responsive_allowed && (e.style.marginLeft = f.gfwroml || "", e.style.marginRight = f.gfwromr || "", e.style.height = f.gfwroh ? f.gfwroh + "px" : "", e.style.width = f.gfwrow ? f.gfwrow + "px" : "", e.style.zIndex = f.gfwroz || "", delete f.google_full_width_responsive_allowed);
                    delete f.google_ad_format;
                    delete f.google_ad_width;
                    delete f.google_ad_height;
                    delete f.google_content_recommendation_ui_type;
                    delete f.google_content_recommendation_rows_num;
                    delete f.google_content_recommendation_columns_num;
                    b.google_spfd(e, f, b);
                    const h = EN(e, f);
                    !h && g && 1 == e.childNodes.length ? (FN(g, !1), f.google_reactive_ad_format = 16, f.google_ad_section = "responsive_resize", e.dataset.adsbygoogleStatus = "reserved", e.className += " adsbygoogle-noablate", b.adsbygoogle || (b.adsbygoogle = [], We(b.document, sj `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js`)),
                        b.adsbygoogle.push({
                            element: e,
                            params: f
                        })) : h && g && h != g && (FN(g, !1), FN(h, !0))
                })
        }
    }
    var HN = class extends U {
        constructor() {
            super(...arguments);
            this.g = null
        }
        L(a) {
            const b = UI();
            if (!Z(b, 27, !1)) {
                ZI(b, 27, !0);
                this.g = a.innerHeight >= a.innerWidth ? 1 : 2;
                var c = () => {
                    GN(this, a)
                };
                Tb(a, "resize", c);
                Zo(this, () => {
                    Ub(a, "resize", c)
                })
            }
        }
    };
    var IN = class {
        constructor(a, b) {
            this.K = a;
            this.yb = b;
            this.g = null;
            this.j = 0
        }
        i() {
            10 <= ++this.j && r.clearInterval(this.g);
            var a = ov(this.K, this.yb);
            pv(this.K, this.yb, a);
            a = kv(this.yb, this.K);
            null != a && 0 === a.x || r.clearInterval(this.g)
        }
    };
    var JN = class {
        constructor(a) {
            this.g = 0;
            this.i = this.F = null;
            this.G = 0;
            this.j = [];
            this.tc = this.C = "";
            this.l = this.B = null;
            this.K = a.K;
            this.pubWin = a.pubWin;
            this.D = a.D;
            this.Fa = a.Fa;
            this.ra = a.ra;
            this.vb = a.vb;
            this.ia = a.ia
        }
    };

    function KN(a, b) {
        var c = UJ(a, oE(b));
        c = $i(c, 2, b.tcString);
        c = $i(c, 4, b.addtlConsent || "");
        Wh(c, 7, eh(b.internalErrorState));
        c = !qE(b);
        Vi(a, 9, c);
        null != b.gdprApplies && Vi(a, 3, b.gdprApplies)
    }

    function LN(a) {
        const b = new wE(a.pubWin, {
            timeoutMs: -1,
            Nh: !0
        });
        if (!sE(b)) return Promise.resolve(null);
        const c = UI(),
            d = Z(c, 24);
        if (d) return Promise.resolve(d);
        const e = new Promise(f => {
            f = {
                resolve: f
            };
            const g = Z(c, 25, []);
            g.push(f);
            ZI(c, 25, g)
        });
        d || null === d || (ZI(c, 24, null), b.addEventListener(f => {
            if (nE(f)) {
                ZI(c, 24, f);
                KN(a.i, f);
                for (const g of Z(c, 25, [])) g.resolve(f);
                ZI(c, 25, [])
            } else ZI(c, 24, null)
        }));
        return e
    };

    function MN(a, b, c = 1E5) {
        a -= b;
        return a >= c ? "M" : 0 <= a ? a : "-M"
    };
    var ON = (a, b, c) => {
        const d = b.parentElement ? .classList.contains("adsbygoogle") ? b.parentElement : b;
        c.addEventListener("load", () => NN(d));
        return rN(a, "adpnt", (e, f) => {
            if (Do(f, c.contentWindow)) {
                e = Go(e).qid;
                try {
                    c.setAttribute("data-google-query-id", e), a.googletag ? ? (a.googletag = {
                        cmd: []
                    }), a.googletag.queryIds = a.googletag.queryIds ? ? [], a.googletag.queryIds.push(e), 500 < a.googletag.queryIds.length && a.googletag.queryIds.shift()
                } catch {}
                d.dataset.adStatus = "filled";
                switch (w(Cu)) {
                    case 1:
                        e && (c.id += `/${e}`);
                        break;
                    case 2:
                        f =
                            document, e && (f = c.parentElement ? .querySelector("INS[data-aqiep]") ? ? Xe("INS", f), f.parentElement || (c.parentNode && c.parentNode.insertBefore(f, c.nextSibling), A(f, {
                                height: "0px",
                                width: "0px"
                            }), Io(f), f.setAttribute("data-aqiep", "1")), f.id = e)
                }
                e = !0
            } else e = !1;
            return e
        })
    };

    function NN(a) {
        setTimeout(() => {
            "filled" !== a.dataset.adStatus && (a.dataset.adStatus = "unfilled")
        }, 1E3)
    };
    var PN = class {
        constructor(a, b) {
            this.i = a;
            this.g = b
        }
    };
    var QN = class extends S {
        g() {
            return O(this, 6)
        }
        j() {
            return O(this, 7)
        }
    };
    var RN = class extends S {
        g() {
            return bi(this, 1, vh, 2)
        }
    };
    RN.P = [1];
    var SN = class extends S {};
    SN.P = [19];
    var TN = [13, 14];
    let UN = void 0;

    function VN() {
        ej(UN, gj);
        return UN
    }

    function WN(a) {
        ej(UN, vl);
        UN = a
    };

    function XN(a) {
        try {
            const b = a.getItem("google_adsense_settings");
            if (!b) return {};
            const c = JSON.parse(b);
            return c !== Object(c) ? {} : Pc(c, (d, e) => Object.prototype.hasOwnProperty.call(c, e) && "string" === typeof e && Array.isArray(d))
        } catch (b) {
            return {}
        }
    };

    function YN(a, b, c) {
        try {
            if (!xf(c.origin) || !Do(c, a.g.contentWindow)) return
        } catch (f) {
            return
        }
        const d = b.msg_type;
        let e;
        "string" === typeof d && (e = a.va[d]) && a.T.Lc(168, () => {
            e.call(a, b, c)
        })
    }
    class ZN extends U {
        constructor(a, b) {
            var c = Wz,
                d = Vz;
            super();
            this.j = a;
            this.g = b;
            this.T = c;
            this.ua = d;
            this.va = {};
            this.Db = this.T.Oa(168, (e, f) => void YN(this, e, f));
            this.Sc = this.T.Oa(169, (e, f) => Ho(this.j, "ras::xsf", this.ua, f));
            this.Z = [];
            this.ga(this.va);
            this.Z.push(qN(this.j, "sth", this.Db, this.Sc))
        }
        i() {
            for (const a of this.Z) a();
            this.Z.length = 0;
            super.i()
        }
    };
    class $N extends ZN {};

    function aO(a, b, c = null) {
        return new bO(a, b, c)
    }
    var bO = class extends $N {
        constructor(a, b, c) {
            super(a, b);
            this.A = c;
            this.C = u(yJ);
            this.l = () => {};
            Tb(this.g, "load", this.l)
        }
        i() {
            Ub(this.g, "load", this.l);
            super.i()
        }
        ga(a) {
            a["adsense-labs"] = b => {
                if (b = Go(b).settings)
                    if (b = dj(Nj, JSON.parse(b)), null != L(b, 1)) {
                        var c;
                        if (c = v(Zs)) c = b.W, c = 0 < ri(c, c[B], Jj, 4, 3, !1, !0).length;
                        if (c) {
                            var d = c = D(b, Jj, 4),
                                e = this.C;
                            const h = new um;
                            for (var f of d) switch (f.getVersion()) {
                                case 1:
                                    Vi(h, 1, !0);
                                    break;
                                case 2:
                                    Vi(h, 2, !0)
                            }
                            f = new vm;
                            f = I(f, 1, wm, h);
                            xJ(e, f);
                            f = this.j;
                            e = this.A;
                            if (!Z(UI(), 37, !1)) {
                                f = new lM(f);
                                for (var g of c) switch (g.getVersion()) {
                                    case 1:
                                        iM(f, "__gads", g, e);
                                        break;
                                    case 2:
                                        iM(f, "__gpi", g, e)
                                }
                                ZI(UI(), 37, !0)
                            }
                            Wh(b, 4)
                        }
                        if (v(Xs)) {
                            if (g = C(b, Jj, 5)) f = this.j, Z(UI(), 40, !1) || (f = new PN(f, {
                                Tg: !1,
                                Ug: !1
                            }), c = Qi(g, 2) - Date.now() / 1E3, c = {
                                Fd: Math.max(c, 0),
                                path: P(g, 3),
                                domain: P(g, 4),
                                eh: !1
                            }, (new Wj(f.i.document)).set("__eoi", g.getValue(), c), ZI(UI(), 40, !0));
                            Wh(b, 5)
                        }
                        g = this.j;
                        f = P(b, 1) || "";
                        if (null != YJ({
                                win: g,
                                Ad: VN()
                            }).g) {
                            c = YJ({
                                win: g,
                                Ad: VN()
                            });
                            c = null != c.g ? XN(c.getValue()) : {};
                            null !== b && (c[f] = b.toJSON());
                            try {
                                g.localStorage.setItem("google_adsense_settings",
                                    JSON.stringify(c))
                            } catch (h) {}
                        }
                    }
            }
        }
    };

    function cO(a) {
        a.A = a.C;
        a.F.style.transition = "height 500ms";
        a.l.style.transition = "height 500ms";
        a.g.style.transition = "height 500ms";
        dO(a)
    }

    function eO(a, b) {
        a.g.contentWindow.postMessage(JSON.stringify({
            msg_type: "expand-on-scroll-result",
            eos_success: !0,
            eos_amount: b,
            googMsgType: "sth"
        }), "*")
    }

    function dO(a) {
        const b = `rect(0px, ${a.g.width}px, ${a.A}px, 0px)`;
        a.g.style.clip = b;
        a.l.style.clip = b;
        a.g.setAttribute("height", a.A);
        a.g.style.height = a.A + "px";
        a.l.setAttribute("height", a.A);
        a.l.style.height = a.A + "px";
        a.F.style.height = a.A + "px"
    }

    function fO(a, b) {
        b = gf(b.r_nh);
        a.C = null == b ? 0 : b;
        if (0 >= a.C) return "1";
        a.I = Dk(a.F).y;
        a.H = Eo(a.j);
        if (a.I + a.A < a.H) return "2";
        if (a.I > zo(a.j) - a.j.innerHeight) return "3";
        b = a.H;
        a.g.setAttribute("height", a.C);
        a.g.style.height = a.C + "px";
        a.l.style.overflow = "hidden";
        a.F.style.position = "relative";
        a.F.style.transition = "height 100ms";
        a.l.style.transition = "height 100ms";
        a.g.style.transition = "height 100ms";
        b = Math.min(b + a.j.innerHeight - a.I, a.A);
        wk(a.l, {
            position: "relative",
            top: "auto",
            bottom: "auto"
        });
        b = `rect(0px, ${a.g.width}px, ${b}px, 0px)`;
        wk(a.g, {
            clip: b
        });
        wk(a.l, {
            clip: b
        });
        return "0"
    }
    class gO extends $N {
        constructor(a, b) {
            super(a.K, b);
            this.l = a.ia;
            this.F = this.l.parentElement && this.l.parentElement.classList.contains("adsbygoogle") ? this.l.parentElement : this.l;
            this.A = parseInt(this.l.style.height, 10);
            this.Ha = this.Ra = !1;
            this.pa = this.H = this.C = 0;
            this.Rc = this.A / 5;
            this.I = Dk(this.F).y;
            this.Va = Pb(Zz(651, () => {
                this.I = Dk(this.F).y;
                var c = this.H;
                this.H = Eo(this.j);
                this.A < this.C ? (c = this.H - c, 0 < c && (this.pa += c, this.pa >= this.Rc ? (cO(this), eO(this, this.C)) : (this.A = Math.min(this.C, this.A + c), eO(this, c), dO(this)))) :
                    Ub(this.j, "scroll", this.O)
            }), this);
            this.O = () => {
                var c = this.Va;
                Sj.requestAnimationFrame ? Sj.requestAnimationFrame(c) : c()
            }
        }
        ga(a) {
            a["expand-on-scroll"] = (b, c) => {
                b = Go(b);
                this.Ra || (this.Ra = !0, b = fO(this, b), "0" === b && Tb(this.j, "scroll", this.O, Qb), c.source.postMessage(JSON.stringify({
                    msg_type: "expand-on-scroll-result",
                    eos_success: "0" === b,
                    googMsgType: "sth"
                }), "*"))
            };
            a["expand-on-scroll-force-expand"] = () => {
                this.Ha || (this.Ha = !0, cO(this), Ub(this.j, "scroll", this.O))
            }
        }
        i() {
            this.O && Ub(this.j, "scroll", this.O, Qb);
            super.i()
        }
    };

    function hO(a) {
        const b = a.I.getBoundingClientRect(),
            c = 0 > b.top + b.height;
        return !(b.top > a.j.innerHeight) && !c
    }
    class iO extends U {
        constructor(a, b, c) {
            super();
            this.j = a;
            this.A = b;
            this.I = c;
            this.C = 0;
            this.l = hO(this);
            this.H = Ob(this.F, this);
            this.g = Zz(433, () => {
                var d = this.H;
                Sj.requestAnimationFrame ? Sj.requestAnimationFrame(d) : d()
            });
            Tb(this.j, "scroll", this.g, Qb)
        }
        F() {
            const a = hO(this);
            if (a && !this.l) {
                var b = {
                    rr: "vis-bcr"
                };
                const c = this.A.contentWindow;
                c && (sN(c, "ig", b, "*", 2), 10 <= ++this.C && this.g && Ub(this.j, "scroll", this.g, Qb))
            }
            this.l = a
        }
    };

    function jO(a, b) {
        Array.isArray(b) || (b = [b]);
        b = b.map(function(c) {
            return "string" === typeof c ? c : c.property + " " + c.duration + "s " + c.timing + " " + c.delay + "s"
        });
        wk(a, "transition", b.join(","))
    }
    var kO = Mb(function() {
        if (Ac) return !0;
        var a = ke(document, "DIV"),
            b = Ec ? "-webkit" : Dc ? "-moz" : Ac ? "-ms" : null,
            c = {
                transition: "opacity 1s linear"
            };
        b && (c[b + "-transition"] = "opacity 1s linear");
        b = {
            style: c
        };
        Gd("div");
        b = Jd("div", b);
        Qd(a, b);
        return "" != zk(a.firstChild, "transition")
    });

    function lO(a, b, c) {
        0 > a.i[b].indexOf(c) && (a.i[b] += c)
    }

    function mO(a, b) {
        0 <= a.g.indexOf(b) || (a.g = b + a.g)
    }

    function nO(a, b, c, d) {
        return "" != a.errors || b ? null : "" == a.g.replace(oO, "") ? null != c && a.i[0] || null != d && a.i[1] ? !1 : !0 : !1
    }

    function pO(a) {
        var b = nO(a, "", null, 0);
        if (null === b) return "XS";
        b = b ? "C" : "N";
        a = a.g;
        return 0 <= a.indexOf("a") ? b + "A" : 0 <= a.indexOf("f") ? b + "F" : b + "S"
    }
    var qO = class {
        constructor(a, b) {
            this.i = ["", ""];
            this.g = a || "";
            this.errors = b || ""
        }
        xa(a) {
            0 > this.errors.indexOf(a) && (this.errors = a + this.errors);
            return this
        }
        toString() {
            return [this.i[0], this.i[1], this.g, this.errors].join("|")
        }
    };

    function rO(a) {
        let b = a.T;
        a.G = () => {};
        sO(a, a.B, b);
        let c = a.B.parentElement;
        if (!c) return a.g;
        let d = !0,
            e = null;
        for (; c;) {
            try {
                e = /^head|html$/i.test(c.nodeName) ? null : Ye(c, b)
            } catch (g) {
                a.g.xa("c")
            }
            const f = tO(a, b, c, e);
            c.classList.contains("adsbygoogle") && e && (/^\-.*/.test(e["margin-left"]) || /^\-.*/.test(e["margin-right"])) && (a.O = !0);
            if (d && !f && uO(e)) {
                mO(a.g, "l");
                a.F = c;
                break
            }
            d = d && f;
            if (e && vO(a, e)) break;
            c = c.parentElement;
            if (!c) {
                if (b === a.pubWin) break;
                try {
                    if (c = b.frameElement, b = b.parent, !Se(b)) {
                        mO(a.g, "c");
                        break
                    }
                } catch (g) {
                    mO(a.g,
                        "c");
                    break
                }
            }
        }
        a.C && a.A && wO(a);
        return a.g
    }

    function xO(a) {
        function b(m) {
            for (let n = 0; n < m.length; n++) wk(k, m[n], "0px")
        }

        function c() {
            yO(d, g, h);
            !k || l || h || (b(zO), b(AO))
        }
        const d = a.B;
        d.style.overflow = a.Uc ? "visible" : "hidden";
        a.C && (a.F ? (jO(d, BO()), jO(a.F, BO())) : jO(d, "opacity 1s cubic-bezier(.4, 0, 1, 1), width .2s cubic-bezier(.4, 0, 1, 1) .3s, height .5s cubic-bezier(.4, 0, 1, 1)"));
        null !== a.I && (d.style.opacity = String(a.I));
        const e = null != a.width && null != a.j && (a.Qd || a.j > a.width) ? a.j : null,
            f = null != a.height && null != a.i && (a.Qd || a.i > a.height) ? a.i : null;
        if (a.H) {
            const m =
                a.H.length;
            for (let n = 0; n < m; n++) yO(a.H[n], e, f)
        }
        const g = a.j,
            h = a.i,
            k = a.F,
            l = a.O;
        a.C ? r.setTimeout(c, 1E3) : c()
    }

    function CO(a) {
        if (a.A && !a.Z || null == a.j && null == a.i && null == a.I && a.A) return a.g;
        var b = a.A;
        a.A = !1;
        rO(a);
        a.A = b;
        if (!b || null != a.check && !nO(a.g, a.check, a.j, a.i)) return a.g;
        0 <= a.g.g.indexOf("n") && (a.width = null, a.height = null);
        if (null == a.width && null !== a.j || null == a.height && null !== a.i) a.C = !1;
        (0 == a.j || 0 == a.i) && 0 <= a.g.g.indexOf("l") && (a.j = 0, a.i = 0);
        b = a.g;
        b.i[0] = "";
        b.i[1] = "";
        b.g = "";
        b.errors = "";
        xO(a);
        return rO(a)
    }

    function vO(a, b) {
        let c = !1;
        "none" == b.display && (mO(a.g, "n"), a.A && (c = !0));
        "hidden" != b.visibility && "collapse" != b.visibility || mO(a.g, "v");
        "hidden" == b.overflow && mO(a.g, "o");
        "absolute" == b.position ? (mO(a.g, "a"), c = !0) : "fixed" == b.position && (mO(a.g, "f"), c = !0);
        return c
    }

    function sO(a, b, c) {
        let d = 0;
        if (!b || !b.parentElement) return !0;
        let e = !1,
            f = 0;
        const g = b.parentElement.childNodes;
        for (let k = 0; k < g.length; k++) {
            var h = g[k];
            h == b ? e = !0 : (h = DO(a, h, c), d |= h, e && (f |= h))
        }
        f & 1 && (d & 2 && lO(a.g, 0, "o"), d & 4 && lO(a.g, 1, "o"));
        return !(d & 1)
    }

    function tO(a, b, c, d) {
        let e = null;
        try {
            e = c.style
        } catch (z) {
            a.g.xa("s")
        }
        var f = c.getAttribute("width"),
            g = gf(f),
            h = c.getAttribute("height"),
            k = gf(h),
            l = d && /^block$/.test(d.display) || e && /^block$/.test(e.display);
        b = sO(a, c, b);
        var m = d && d.width;
        const n = d && d.height;
        var p = e && e.width,
            q = e && e.height,
            x = hf(m) == a.width && hf(n) == a.height;
        m = x ? m : p;
        q = x ? n : q;
        p = hf(m);
        x = hf(q);
        g = null !== a.width && (null !== p && a.width >= p || null !== g && a.width >= g);
        x = null !== a.height && (null !== x && a.height >= x || null !== k && a.height >= k);
        k = !b && uO(d);
        x = b || x || k || !(f ||
            m || d && (!EO(String(d.minWidth)) || !FO(String(d.maxWidth))));
        l = b || g || k || l || !(h || q || d && (!EO(String(d.minHeight)) || !FO(String(d.maxHeight))));
        GO(a, 0, x, c, "width", f, a.width, a.j);
        HO(a, 0, "d", x, e, d, "width", m, a.width, a.j);
        HO(a, 0, "m", x, e, d, "minWidth", e && e.minWidth, a.width, a.j);
        HO(a, 0, "M", x, e, d, "maxWidth", e && e.maxWidth, a.width, a.j);
        a.hf ? (c = /^html|body$/i.test(c.nodeName), f = hf(n), h = d ? "auto" === d.overflowY || "scroll" === d.overflowY : !1, h = null != a.i && d && f && Math.round(f) !== a.i && !h && "100%" !== d.minHeight, a.A && !c && h && (e.setProperty("height",
            "auto", "important"), d && !EO(String(d.minHeight)) && e.setProperty("min-height", "0px", "important"), d && !FO(String(d.maxHeight)) && a.i && Math.round(f) < a.i && e.setProperty("max-height", "none", "important"))) : (GO(a, 1, l, c, "height", h, a.height, a.i), HO(a, 1, "d", l, e, d, "height", q, a.height, a.i), HO(a, 1, "m", l, e, d, "minHeight", e && e.minHeight, a.height, a.i), HO(a, 1, "M", l, e, d, "maxHeight", e && e.maxHeight, a.height, a.i));
        return b
    }

    function wO(a) {
        function b() {
            if (0 < c) {
                var l = Ye(e, d) || {
                    width: 0,
                    height: 0
                };
                const m = hf(l.width);
                l = hf(l.height);
                null !== m && null !== f && h && h(0, f - m);
                null !== l && null !== g && h && h(1, g - l);
                --c
            } else r.clearInterval(k), h && (h(0, 0), h(1, 0))
        }
        let c = 31.25;
        const d = a.T,
            e = a.B,
            f = a.j,
            g = a.i,
            h = a.G;
        let k;
        r.setTimeout(() => {
            k = r.setInterval(b, 16)
        }, 990)
    }

    function DO(a, b, c) {
        if (3 == b.nodeType) return /\S/.test(b.data) ? 1 : 0;
        if (1 == b.nodeType) {
            if (/^(head|script|style)$/i.test(b.nodeName)) return 0;
            let d = null;
            try {
                d = Ye(b, c)
            } catch (e) {}
            if (d) {
                if ("none" == d.display || "fixed" == d.position) return 0;
                if ("absolute" == d.position) {
                    if (!a.l.boundingClientRect || "hidden" == d.visibility || "collapse" == d.visibility) return 0;
                    c = null;
                    try {
                        c = b.getBoundingClientRect()
                    } catch (e) {
                        return 0
                    }
                    return (c.right > a.l.boundingClientRect.left ? 2 : 0) | (c.bottom > a.l.boundingClientRect.top ? 4 : 0)
                }
            }
            return 1
        }
        return 0
    }

    function GO(a, b, c, d, e, f, g, h) {
        if (null != h) {
            if ("string" == typeof f) {
                if ("100%" == f || !f) return;
                f = gf(f);
                null == f && (a.g.xa("n"), lO(a.g, b, "d"))
            }
            if (null != f)
                if (c) {
                    if (a.A)
                        if (a.C) {
                            const k = Math.max(f + h - (g || 0), 0),
                                l = a.G;
                            a.G = (m, n) => {
                                m == b && Ne(d, e, String(k - n));
                                l && l(m, n)
                            }
                        } else Ne(d, e, String(h))
                } else lO(a.g, b, "d")
        }
    }

    function HO(a, b, c, d, e, f, g, h, k, l) {
        if (null != l) {
            f = f && f[g];
            "string" != typeof f || ("m" == c ? EO(f) : FO(f)) || (f = hf(f), null == f ? mO(a.g, "p") : null != k && mO(a.g, f == k ? "E" : "e"));
            if ("string" == typeof h) {
                if ("m" == c ? EO(h) : FO(h)) return;
                h = hf(h);
                null == h && (a.g.xa("p"), lO(a.g, b, c))
            }
            if (null != h)
                if (d && e) {
                    if (a.A)
                        if (a.C) {
                            const m = Math.max(h + l - (k || 0), 0),
                                n = a.G;
                            a.G = (p, q) => {
                                p == b && (e[g] = m - q + "px");
                                n && n(p, q)
                            }
                        } else e[g] = l + "px"
                } else lO(a.g, b, c)
        }
    }
    var MO = class {
        constructor(a, b, c, d, e, f, g) {
            this.pubWin = a;
            this.B = b;
            this.H = c;
            this.l = new IO(this.B);
            this.F = this.G = null;
            this.O = !1;
            this.T = (a = this.B.ownerDocument) && (a.defaultView || a.parentWindow);
            this.l = new IO(this.B);
            this.A = g;
            this.Z = JO(this.l, d.rf, d.height, d.Mc);
            this.width = this.A ? this.l.boundingClientRect ? this.l.boundingClientRect.right - this.l.boundingClientRect.left : null : e;
            this.height = this.A ? this.l.boundingClientRect ? this.l.boundingClientRect.bottom - this.l.boundingClientRect.top : null : f;
            this.j = KO(d.width);
            this.i = KO(d.height);
            this.I = this.A ? KO(d.opacity) : null;
            this.check = d.check;
            this.Mc = !!d.Mc;
            this.C = "animate" == d.rf && !LO(this.l, this.i, this.Mc) && kO();
            this.Uc = !!d.Uc;
            this.g = new qO;
            LO(this.l, this.i, this.Mc) && mO(this.g, "r");
            e = this.l;
            e.g && e.i >= e.U && mO(this.g, "b");
            this.Qd = !!d.Qd;
            this.hf = !!d.hf
        }
    };

    function LO(a, b, c) {
        var d;
        (d = a.g) && !(d = !a.visible) && (c ? (b = a.i + Math.min(b, KO(a.getHeight())), a = a.g && b >= a.U) : a = a.g && a.i >= a.U, d = a);
        return d
    }
    var IO = class {
        constructor(a) {
            this.boundingClientRect = null;
            var b = a && a.ownerDocument,
                c = b && (b.defaultView || b.parentWindow);
            c = c && Ve(c);
            this.g = !!c;
            if (a) try {
                this.boundingClientRect = a.getBoundingClientRect()
            } catch (g) {}
            var d = a;
            let e = 0,
                f = this.boundingClientRect;
            for (; d;) try {
                f && (e += f.top);
                const g = d.ownerDocument,
                    h = g && (g.defaultView || g.parentWindow);
                (d = h && h.frameElement) && (f = d.getBoundingClientRect())
            } catch (g) {
                break
            }
            this.i = e;
            c = c || r;
            this.U = ("CSS1Compat" == c.document.compatMode ? c.document.documentElement : c.document.body).clientHeight;
            b = b && JM(b);
            this.visible = !!a && !(2 == b || 3 == b) && !(this.boundingClientRect && this.boundingClientRect.top >= this.boundingClientRect.bottom && this.boundingClientRect.left >= this.boundingClientRect.right)
        }
        isVisible() {
            return this.visible
        }
        getWidth() {
            return this.boundingClientRect ? this.boundingClientRect.right - this.boundingClientRect.left : null
        }
        getHeight() {
            return this.boundingClientRect ? this.boundingClientRect.bottom - this.boundingClientRect.top : null
        }
    };

    function JO(a, b, c, d) {
        switch (b) {
            case "no_rsz":
                return !1;
            case "force":
            case "animate":
                return !0;
            default:
                return LO(a, c, d)
        }
    }

    function uO(a) {
        return !!a && /^left|right$/.test(a.cssFloat || a.styleFloat)
    }

    function NO(a, b, c, d) {
        return CO(new MO(a, b, d, c, null, null, !0))
    }
    var OO = new qO("s", ""),
        oO = RegExp("[lonvafrbpEe]", "g");

    function FO(a) {
        return !a || /^(auto|none|100%)$/.test(a)
    }

    function EO(a) {
        return !a || /^(0px|auto|none|0%)$/.test(a)
    }

    function yO(a, b, c) {
        null !== b && null !== gf(a.getAttribute("width")) && a.setAttribute("width", String(b));
        null !== c && null !== gf(a.getAttribute("height")) && a.setAttribute("height", String(c));
        null !== b && (a.style.width = b + "px");
        null !== c && (a.style.height = c + "px")
    }
    var zO = "margin-left margin-right padding-left padding-right border-left-width border-right-width".split(" "),
        AO = "margin-top margin-bottom padding-top padding-bottom border-top-width border-bottom-width".split(" ");

    function BO() {
        let a = "opacity 1s cubic-bezier(.4, 0, 1, 1), width .2s cubic-bezier(.4, 0, 1, 1), height .3s cubic-bezier(.4, 0, 1, 1) .2s",
            b = zO;
        for (var c = 0; c < b.length; c++) a += ", " + b[c] + " .2s cubic-bezier(.4, 0, 1, 1)";
        b = AO;
        for (c = 0; c < b.length; c++) a += ", " + b[c] + " .3s cubic-bezier(.4, 0, 1, 1) .2s";
        return a
    }

    function KO(a) {
        return "string" === typeof a ? gf(a) : "number" === typeof a && isFinite(a) ? a : null
    };
    var PO = class extends $N {
        constructor(a, b, c) {
            super(a, b);
            this.l = c
        }
        ga(a) {
            a["resize-me"] = (b, c) => {
                b = Go(b);
                var d = b.r_chk;
                if (null == d || "" === d) {
                    var e = gf(b.r_nw),
                        f = gf(b.r_nh),
                        g = gf(b.r_no);
                    null != g || 0 !== e && 0 !== f || (g = 0);
                    var h = b.r_str;
                    h = h ? h : null; {
                        var k = /^true$/.test(b.r_ao),
                            l = /^true$/.test(b.r_ifr),
                            m = /^true$/.test(b.r_cab);
                        const q = window;
                        if (q)
                            if ("no_rsz" === h) b.err = "7", e = !0;
                            else {
                                var n = new IO(this.g);
                                if (n.g) {
                                    var p = n.getWidth();
                                    null != p && (b.w = p);
                                    p = n.getHeight();
                                    null != p && (b.h = p);
                                    JO(n, h, f, m) ? (n = this.l, d = NO(q, n, {
                                        width: e,
                                        height: f,
                                        opacity: g,
                                        check: d,
                                        rf: h,
                                        Uc: k,
                                        Qd: l,
                                        Mc: m
                                    }, [this.g]), b.r_cui && /^true$/.test(b.r_cui.toString()) && A(n, {
                                        height: (null === f ? 0 : f - 48) + "px",
                                        top: "24px"
                                    }), null != e && (b.nw = e), null != f && (b.nh = f), b.rsz = d.toString(), b.abl = pO(d), b.frsz = ("force" === h).toString(), b.err = "0", e = !0) : (b.err = "1", e = !1)
                                } else b.err = "3", e = !1
                            }
                        else b.err = "2", e = !1
                    }
                    c.source.postMessage(JSON.stringify({
                        msg_type: "resize-result",
                        r_str: h,
                        r_status: e,
                        googMsgType: "sth"
                    }), "*");
                    this.g.dataset.googleQueryId || this.g.setAttribute("data-google-query-id",
                        b.qid)
                }
            }
        }
    };
    const QO = {
        google: 1,
        googlegroups: 1,
        gmail: 1,
        googlemail: 1,
        googleimages: 1,
        googleprint: 1
    };
    const RO = /^blogger$/,
        SO = /^wordpress(.|\s|$)/i,
        TO = /^joomla!/i,
        UO = /^drupal/i,
        VO = /\/wp-content\//,
        WO = /\/wp-content\/plugins\/advanced-ads/,
        XO = /\/wp-content\/themes\/genesis/,
        YO = /\/wp-content\/plugins\/genesis/;

    function ZO(a) {
        var b = a.getElementsByTagName("script"),
            c = b.length;
        for (var d = 0; d < c; ++d) {
            var e = b[d];
            if (e.hasAttribute("src")) {
                e = e.getAttribute("src") || "";
                if (WO.test(e)) return 5;
                if (YO.test(e)) return 6
            }
        }
        b = a.getElementsByTagName("link");
        c = b.length;
        for (d = 0; d < c; ++d)
            if (e = b[d], e.hasAttribute("href") && (e = e.getAttribute("href") || "", XO.test(e) || YO.test(e))) return 6;
        a = a.getElementsByTagName("meta");
        d = a.length;
        for (e = 0; e < d; ++e) {
            var f = a[e];
            if ("generator" == f.getAttribute("name") && f.hasAttribute("content")) {
                f = f.getAttribute("content") ||
                    "";
                if (RO.test(f)) return 1;
                if (SO.test(f)) return 2;
                if (TO.test(f)) return 3;
                if (UO.test(f)) return 4
            }
        }
        for (a = 0; a < c; ++a)
            if (d = b[a], "stylesheet" == d.getAttribute("rel") && d.hasAttribute("href") && (d = d.getAttribute("href") || "", VO.test(d))) return 2;
        return 0
    };
    let $O = navigator;
    var aP = a => {
            let b = 1;
            let c;
            if (void 0 != a && "" != a)
                for (b = 0, c = a.length - 1; 0 <= c; c--) {
                    var d = a.charCodeAt(c);
                    b = (b << 6 & 268435455) + d + (d << 14);
                    d = b & 266338304;
                    b = 0 != d ? b ^ d >> 21 : b
                }
            return b
        },
        bP = (a, b) => {
            if (!a || "none" == a) return 1;
            a = String(a);
            "auto" == a && (a = b, "www." == a.substring(0, 4) && (a = a.substring(4, a.length)));
            return aP(a.toLowerCase())
        };
    const cP = RegExp("^\\s*_ga=\\s*1\\.(\\d+)[^.]*\\.(.*?)\\s*$"),
        dP = RegExp("^[^=]+=\\s*GA1\\.(\\d+)[^.]*\\.(.*?)\\s*$"),
        eP = RegExp("^\\s*_ga=\\s*()(amp-[\\w.-]{22,64})$");

    function fP(a) {
        var b = window;
        return "on" === a.google_adtest || "on" === a.google_adbreak_test || b.location.host.endsWith("h5games.usercontent.goog") ? b.document.querySelector('meta[name="h5-games-eids"]') ? .getAttribute("content") ? .split(",").map(c => Math.floor(Number(c))).filter(c => !isNaN(c) && 0 < c) || [] : []
    };

    function gP(a, b) {
        b && !a.g && (b = b.split(":"), a.g = b.find(c => 0 === c.indexOf("ID=")) || null, a.j = b.find(c => 0 === c.indexOf("T=")) ? .substring(2) || null)
    }
    var hP = class {
            constructor() {
                this.l = new Date(Date.now());
                this.j = this.g = null;
                this.i = {
                    [3]: {},
                    [4]: {},
                    [5]: {}
                };
                this.i[3] = {
                    [71]: (...a) => {
                        var b = this.g;
                        var c = this.l,
                            d = Number(a[0]);
                        a = Number(a[1]);
                        b = null !== b ? bf(`${"w5uHecUBa2S"}:${d}:${b}`) % a === Math.floor(c.valueOf() / 864E5) % a : void 0;
                        return b
                    }
                };
                this.i[4] = {
                    [15]: () => {
                        var a = Number(this.j || void 0);
                        isNaN(a) ? a = void 0 : (a = new Date(1E3 * a), a = 1E4 * a.getFullYear() + 100 * (a.getMonth() + 1) + a.getDate());
                        return a
                    }
                }
            }
        },
        iP;

    function jP(a = r) {
        return a.ggeac || (a.ggeac = {})
    };

    function kP(a, b = document) {
        return !!b.featurePolicy ? .allowedFeatures().includes(a)
    };

    function lP(a = Ze()) {
        return b => bf(`${b} + ${a}`) % 1E3
    };

    function mP(a, b) {
        a.g = ao(14, b, () => {})
    }
    class nP {
        constructor() {
            this.g = () => {}
        }
    }

    function oP(a) {
        u(nP).g(a)
    };

    function pP(a = jP()) {
        bo(u(co), a);
        qP(a);
        mP(u(nP), a);
        u(Xb).i()
    }

    function qP(a) {
        const b = u(Xb);
        b.j = (c, d) => ao(5, a, () => !1)(c, d, 1);
        b.l = (c, d) => ao(6, a, () => 0)(c, d, 1);
        b.A = (c, d) => ao(7, a, () => "")(c, d, 1);
        b.g = (c, d) => ao(8, a, () => [])(c, d, 1);
        b.i = () => {
            ao(15, a, () => {})(1)
        }
    };

    function rP(a, b, c) {
        var d = {
            [0]: lP(Bf(b).toString())
        };
        if (c) {
            c = hM(new lM(b), "__gads", c) || "";
            iP || (iP = new hP);
            b = iP;
            gP(b, c);
            oP(b.i);
            const e = (new RegExp(/(?:^|:)(ID=[^\s:]+)/)).exec(c) ? .[1];
            d[1] = f => e ? lP(e)(f) : void 0
        }
        d = eo(a, d);
        jo.Pa(1085, uJ(u(yJ), a, d))
    }

    function sP(a, b) {
        rP(20, a, b);
        rP(17, a, b)
    }

    function tP(a) {
        const b = fo();
        a = fP(a);
        return b.concat(a).join(",")
    }

    function uP(a) {
        const b = $k();
        b && (a.debug_experiment_id = b)
    };

    function vP(a) {
        -1 === a.g && (a.g = a.data.reduce((b, c, d) => b + (c ? 2 ** d : 0), 0));
        return a.g
    }
    var wP = class {
        constructor() {
            this.data = [];
            this.g = -1
        }
        set(a, b = !0) {
            0 <= a && 52 > a && Number.isInteger(a) && this.data[a] !== b && (this.data[a] = b, this.g = -1)
        }
        get(a) {
            return !!this.data[a]
        }
    };

    function xP() {
        const a = new wP;
        "SVGElement" in r && "createElementNS" in r.document && a.set(0);
        const b = mf();
        b["allow-top-navigation-by-user-activation"] && a.set(1);
        b["allow-popups-to-escape-sandbox"] && a.set(2);
        r.crypto && r.crypto.subtle && a.set(3);
        "TextDecoder" in r && "TextEncoder" in r && a.set(4);
        return vP(a)
    };
    const yP = new Map([
            ["navigate", 1],
            ["reload", 2],
            ["back_forward", 3],
            ["prerender", 4]
        ]),
        zP = new Map([
            [0, 1],
            [1, 2],
            [2, 3]
        ]);

    function AP(a) {
        try {
            const b = a.performance ? .getEntriesByType("navigation") ? .[0];
            if (b ? .type) return yP.get(b.type) ? ? null
        } catch {}
        return zP.get(a.performance ? .navigation ? .type) ? ? null
    };
    var BP = class extends S {
        constructor() {
            super()
        }
    };

    function CP(a, b) {
        if (xc()) {
            var c = a.document.documentElement.lang;
            DP(a) ? EP(b, Bf(a), !0, "", c) : (new MutationObserver((d, e) => {
                DP(a) && (EP(b, Bf(a), !1, c, a.document.documentElement.lang), e.disconnect())
            })).observe(a.document.documentElement, {
                attributeFilter: ["class"]
            })
        }
    }

    function DP(a) {
        a = a.document ? .documentElement ? .classList;
        return !(!a ? .contains("translated-rtl") && !a ? .contains("translated-ltr"))
    }

    function EP(a, b, c, d, e) {
        Rj({
            ptt: `${a}`,
            pvsid: `${b}`,
            ibatl: String(c),
            pl: d,
            nl: e
        }, "translate-event")
    };

    function FP(a) {
        if (a = a.navigator ? .userActivation) {
            var b = 0;
            a ? .hasBeenActive && (b |= 1);
            a ? .isActive && (b |= 2);
            return b
        }
    };
    const GP = /[+, ]/;

    function HP(a, b) {
        const c = a.D;
        var d = a.pubWin,
            e = {},
            f = d.document,
            g = Ef(d),
            h = !1,
            k = "",
            l = 1;
        a: {
            l = c.google_ad_width || d.google_ad_width;
            var m = c.google_ad_height || d.google_ad_height;
            if (d && d.top == d) h = !1;
            else {
                h = d.document;
                k = h.documentElement;
                if (l && m) {
                    var n = 1;
                    let q = 1;
                    d.innerHeight ? (n = d.innerWidth, q = d.innerHeight) : k && k.clientHeight ? (n = k.clientWidth, q = k.clientHeight) : h.body && (n = h.body.clientWidth, q = h.body.clientHeight);
                    if (q > 2 * m || n > 2 * l) {
                        h = !1;
                        break a
                    }
                }
                h = !0
            }
        }
        k = h;
        l = RI(g).Qe;
        m = d.top == d ? 0 : Se(d.top) ? 1 : 2;
        n = 4;
        k || 1 != m ? k ||
            2 != m ? k && 1 == m ? n = 7 : k && 2 == m && (n = 8) : n = 6 : n = 5;
        l && (n |= 16);
        k = String(n);
        l = TI(d);
        m = !!c.google_page_url;
        e.google_iframing = k;
        0 != l && (e.google_iframing_environment = l);
        if (!m && "ad.yieldmanager.com" == f.domain) {
            for (k = f.URL.substring(f.URL.lastIndexOf("http")); - 1 < k.indexOf("%");) try {
                k = decodeURIComponent(k)
            } catch (q) {
                break
            }
            c.google_page_url = k;
            m = !!k
        }
        m ? (e.google_page_url = c.google_page_url, e.google_page_location = (h ? f.referrer : f.URL) || "EMPTY") : (h && Se(d.top) && f.referrer && d.top.document.referrer === f.referrer ? e.google_page_url =
            d.top.document.URL : e.google_page_url = h ? f.referrer : f.URL, e.google_page_location = null);
        if (f.URL === e.google_page_url) try {
            var p = Math.round(Date.parse(f.lastModified) / 1E3) || null
        } catch {
            p = null
        } else p = null;
        e.google_last_modified_time = p;
        d = g == g.top ? g.document.referrer : (d = ok()) && d.referrer || "";
        e.google_referrer_url = d;
        SI(e, c);
        e = c.google_page_location || c.google_page_url;
        "EMPTY" == e && (e = c.google_page_url);
        e ? (e = e.toString(), 0 == e.indexOf("http://") ? e = e.substring(7, e.length) : 0 == e.indexOf("https://") && (e = e.substring(8,
            e.length)), d = e.indexOf("/"), -1 == d && (d = e.length), e = e.substring(0, d).split("."), d = !1, 3 <= e.length && (d = e[e.length - 3] in QO), 2 <= e.length && (d = d || e[e.length - 2] in QO), e = d) : e = !1;
        e = e ? "pagead2.googlesyndication.com" : "googleads.g.doubleclick.net";
        b = IP(a, b);
        d = a.D;
        f = d.google_ad_channel;
        g = "/pagead/ads?";
        "ca-pub-6219811747049371" === d.google_ad_client && JP.test(f) && (g = "/pagead/lopri?");
        a = Mk(b, `https://${e}${g}` + (O(a.Fa, 9) && c.google_debug_params ? c.google_debug_params : ""));
        return c.google_ad_url = a
    }

    function KP(a) {
        try {
            if (a.parentNode) return a.parentNode
        } catch {
            return null
        }
        if (9 === a.nodeType) a: {
            try {
                const c = a ? je(a) : window;
                if (c) {
                    const d = c.frameElement;
                    if (d && Se(c.parent)) {
                        var b = d;
                        break a
                    }
                }
            } catch {}
            b = null
        }
        else b = null;
        return b
    }

    function LP(a, b) {
        var c = tP(a.pubWin);
        a.D.saaei && (c += ("" === c ? "" : ",") + a.D.saaei);
        b.eid = c;
        c = a.D.google_loeid;
        "string" === typeof c && (a.g |= 4096, b.loeid = c)
    }

    function MP(a, b) {
        a = (a = Ve(a.pubWin)) && a.document ? eM(a.document, a) : new Xd(-12245933, -12245933);
        b.scr_x = Math.round(a.x);
        b.scr_y = Math.round(a.y)
    }

    function NP(a) {
        try {
            const b = r.top.location.hash;
            if (b) {
                const c = b.match(a);
                return c && c[1] || ""
            }
        } catch {}
        return ""
    }

    function OP(a, b, c) {
        const d = a.D;
        var e = a.pubWin,
            f = a.K,
            g = Ef(window);
        d.fsapi && (b.fsapi = !0);
        b.ref = d.google_referrer_url;
        b.loc = d.google_page_location;
        var h;
        (h = ok(e)) && Aa(h.data) && "string" === typeof h.data.type ? (h = h.data.type.toLowerCase(), h = "doubleclick" == h || "adsense" == h ? null : h) : h = null;
        h && (b.apn = h.substr(0, 10));
        g = RI(g);
        b.url || b.loc || !g.url || (b.url = g.url, g.Qe || (b.usrc = 1));
        g.url != (b.loc || b.url) && (b.top = g.url);
        a.tc && (b.etu = a.tc);
        (c = iN(d, f, f ? Xj(c, f) : null)) && (b.fc = c);
        if (!Tk(d)) {
            c = a.pubWin.document;
            g = "";
            if (c.documentMode &&
                (h = se(new fe(c), "IFRAME"), h.frameBorder = "0", h.style.height = 0, h.style.width = 0, h.style.position = "absolute", c.body)) {
                c.body.appendChild(h);
                try {
                    const aa = h.contentWindow.document;
                    aa.open();
                    var k = Fd("<!DOCTYPE html>");
                    aa.write(Dd(k));
                    aa.close();
                    g += aa.documentMode
                } catch (aa) {}
                c.body.removeChild(h)
            }
            b.docm = g
        }
        let l, m, n, p, q, x, z, G, E, K;
        try {
            l = e.screenX, m = e.screenY
        } catch (aa) {}
        try {
            n = e.outerWidth, p = e.outerHeight
        } catch (aa) {}
        try {
            q = e.innerWidth, x = e.innerHeight
        } catch (aa) {}
        try {
            z = e.screenLeft, G = e.screenTop
        } catch (aa) {}
        try {
            q =
                e.innerWidth, x = e.innerHeight
        } catch (aa) {}
        try {
            E = e.screen.availWidth, K = e.screen.availTop
        } catch (aa) {}
        b.brdim = [z, G, l, m, E, K, n, p, q, x].join();
        k = 0;
        void 0 === r.postMessage && (k |= 1);
        0 < k && (b.osd = k);
        b.vis = JM(e.document);
        k = a.ia;
        e = cN(d) ? OO : CO(new MO(e, k, null, {
            width: 0,
            height: 0
        }, d.google_ad_width, d.google_ad_height, !1));
        b.rsz = e.toString();
        b.abl = pO(e);
        if (!cN(d) && (e = Uk(d), null != e)) {
            k = 0;
            a: {
                try {
                    {
                        var H = d.google_async_iframe_id;
                        const aa = window.document;
                        if (H) var N = aa.getElementById(H);
                        else {
                            var J = aa.getElementsByTagName("script"),
                                Ea = J[J.length - 1];
                            N = Ea && Ea.parentNode || null
                        }
                    }
                    if (H = N) {
                        N = [];
                        J = 0;
                        for (var Ya = Date.now(); 100 >= ++J && 50 > Date.now() - Ya && (H = KP(H));) 1 === H.nodeType && N.push(H);
                        var Eb = N;
                        b: {
                            for (Ya = 0; Ya < Eb.length; Ya++) {
                                c: {
                                    var ba = Eb[Ya];
                                    try {
                                        if (ba.parentNode && 0 < ba.offsetWidth && 0 < ba.offsetHeight && ba.style && "none" !== ba.style.display && "hidden" !== ba.style.visibility && (!ba.style.opacity || 0 !== Number(ba.style.opacity))) {
                                            const aa = ba.getBoundingClientRect();
                                            var tb = 0 < aa.right && 0 < aa.bottom;
                                            break c
                                        }
                                    } catch (aa) {}
                                    tb = !1
                                }
                                if (!tb) {
                                    var rc = !1;
                                    break b
                                }
                            }
                            rc = !0
                        }
                        if (rc) {
                            b: {
                                const aa = Date.now();rc = /^html|body$/i;tb = /^fixed/i;
                                for (ba = 0; ba < Eb.length && 50 > Date.now() - aa; ba++) {
                                    const tc = Eb[ba];
                                    if (!rc.test(tc.tagName) && tb.test(tc.style.position || Bk(tc, "position"))) {
                                        var sc = tc;
                                        break b
                                    }
                                }
                                sc = null
                            }
                            break a
                        }
                    }
                } catch {}
                sc = null
            }
            sc && sc.offsetWidth * sc.offsetHeight <= 4 * e.width * e.height && (k = 1);
            b.pfx = k
        }
        a: {
            if (.05 > Math.random() && f) try {
                const aa = f.document.getElementsByTagName("head")[0];
                var Sd = aa ? ZO(aa) : 0;
                break a
            } catch (aa) {}
            Sd = 0
        }
        f = Sd;
        0 !== f && (b.cms = f);
        d.google_lrv !== a.vb && (b.alvm = d.google_lrv ||
            "none")
    }

    function PP(a, b) {
        let c = 0;
        a.location && a.location.ancestorOrigins ? c = a.location.ancestorOrigins.length : Te(() => {
            c++;
            return !1
        }, a);
        c && (b.nhd = c)
    }

    function QP(a, b) {
        const c = Z(b, 8, {});
        b = Z(b, 9, {});
        const d = a.google_ad_section,
            e = a.google_ad_format;
        a = a.google_ad_slot;
        e ? c[d] = c[d] ? c[d] + `,${e}` : e : a && (b[d] = b[d] ? b[d] + `,${a}` : a)
    }

    function RP(a, b, c) {
        const d = a.D;
        var e = a.D;
        b.dt = lo;
        e.google_async_iframe_id && e.google_bpp && (b.bpp = e.google_bpp);
        a: {
            try {
                var f = r.performance;
                if (f && f.timing && f.now) {
                    var g = f.timing.navigationStart + Math.round(f.now()) - f.timing.domLoading;
                    break a
                }
            } catch (J) {}
            g = null
        }(e = (e = g) ? MN(e, r.Date.now() - lo, 1E6) : null) && (b.bdt = e);
        b.idt = MN(a.G, lo);
        e = a.D;
        b.shv = P(a.Fa, 2);
        a.vb && (b.mjsv = a.vb);
        "sd" == e.google_loader_used ? b.ptt = 5 : "aa" == e.google_loader_used && (b.ptt = 9);
        /^\w{1,3}$/.test(e.google_loader_used) && (b.saldr = e.google_loader_used);
        if (e = ok(a.pubWin)) b.is_amp = 1, b.amp_v = pk(e), (e = qk(e)) && (b.act = e);
        e = a.pubWin;
        e == e.top && (b.abxe = 1);
        e = new lM(a.pubWin);
        (g = hM(e, "__gads", c)) && (b.cookie = g);
        (g = hM(e, "__gpi", c)) && !g.includes("&") && (b.gpic = g);
        "1" === hM(e, "__gpi_opt_out", c) && (b.pdopt = "1");
        v(Xs) && (e = new PN(a.pubWin, {
            Tg: !1,
            Ug: !0
        }), e = O(c, 8) || (e.g.Tg || !O(c, 5)) && e.g.Ug ? void 0 : (new Wj(e.i.document)).get("__eoi") || "", e && (b.eo_id_str = e));
        e = UI();
        f = Z(e, 8, {});
        g = d.google_ad_section;
        f[g] && (b.prev_fmts = f[g]);
        f = Z(e, 9, {});
        f[g] && (b.prev_slotnames = f[g].toLowerCase());
        QP(d, e);
        g = Z(e, 15, 0);
        0 < g && (b.nras = String(g));
        (f = ok(window)) ? (f ? (g = f.pageViewId, f = f.clientId, "string" === typeof f && (g += f.replace(/\D/g, "").substr(0, 6))) : g = null, g = +g) : (g = Ef(window), f = g.google_global_correlator, f || (g.google_global_correlator = f = 1 + Math.floor(Math.random() * Math.pow(2, 43))), g = f);
        b.correlator = Z(e, 7, g);
        v(Wu) && (b.rume = 1);
        if (d.google_ad_channel) {
            g = Z(e, 10, {});
            f = "";
            var h = d.google_ad_channel.split(GP);
            for (var k = 0; k < h.length; k++) {
                var l = h[k];
                g[l] ? f += l + "+" : g[l] = !0
            }
            b.pv_ch = f
        }
        if (d.google_ad_host_channel) {
            g =
                d.google_ad_host_channel;
            f = Z(e, 11, []);
            h = g.split("|");
            e = -1;
            g = [];
            for (k = 0; k < h.length; k++) {
                l = h[k].split(GP);
                f[k] || (f[k] = {});
                var m = "";
                for (var n = 0; n < l.length; n++) {
                    var p = l[n];
                    "" !== p && (f[k][p] ? m += "+" + p : f[k][p] = !0)
                }
                m = m.slice(1);
                g[k] = m;
                "" !== m && (e = k)
            }
            f = "";
            if (-1 < e) {
                for (h = 0; h < e; h++) f += g[h] + "|";
                f += g[e]
            }
            b.pv_h_ch = f
        }
        b.frm = d.google_iframing;
        b.ife = d.google_iframing_environment;
        e = d.google_ad_client;
        try {
            var q = Ef(window),
                x = q.google_prev_clients;
            x || (x = q.google_prev_clients = {});
            if (e in x) var z = 1;
            else x[e] = !0, z = 2
        } catch {
            z =
                0
        }
        b.pv = z;
        a.K && v(Kt) && (z = a.K, z = xc() && DP(z) ? z.document.documentElement.lang : void 0, z && (b.tl = z));
        x = a.pubWin.document;
        z = a.D;
        e = a.pubWin;
        q = x.domain;
        e = (O(c, 5) && Zj(e) ? e.document.cookie : null) || "";
        h = a.pubWin.screen;
        k = x.referrer;
        m = Ok();
        if (ok()) var G = window.gaGlobal || {};
        else {
            g = Math.round((new Date).getTime() / 1E3);
            f = z.google_analytics_domain_name;
            c = "undefined" == typeof f ? bP("auto", q) : bP(f, q);
            n = -1 < e.indexOf("__utma=" + c + ".");
            l = -1 < e.indexOf("__utmb=" + c);
            (q = (tk() || window).gaGlobal) || (q = {}, (tk() || window).gaGlobal = q);
            x = !1;
            if (n) {
                var E = e.split("__utma=" + c + ".")[1].split(";")[0].split(".");
                l ? q.sid = E[3] : q.sid || (q.sid = g + "");
                q.vid = E[0] + "." + E[1];
                q.from_cookie = !0
            } else {
                q.sid || (q.sid = g + "");
                if (!q.vid) {
                    x = !0;
                    l = Math.round(2147483647 * Math.random());
                    n = $O.appName;
                    p = $O.version;
                    var K = $O.language ? $O.language : $O.browserLanguage,
                        H = $O.platform,
                        N = $O.userAgent;
                    try {
                        E = $O.javaEnabled()
                    } catch (J) {
                        E = !1
                    }
                    E = [n, p, K, H, N, E ? 1 : 0].join("");
                    h ? E += h.width + "x" + h.height + h.colorDepth : r.java && r.java.awt && (h = r.java.awt.Toolkit.getDefaultToolkit().getScreenSize(),
                        E += h.screen.width + "x" + h.screen.height);
                    E = E + e + (k || "");
                    for (h = E.length; 0 < m;) E += m-- ^ h++;
                    q.vid = (l ^ aP(E) & 2147483647) + "." + g
                }
                q.from_cookie || (q.from_cookie = !1)
            }
            if (!q.cid) {
                b: for (g = f, E = 999, g && (g = 0 == g.indexOf(".") ? g.substr(1) : g, E = g.split(".").length), g = 999, e = e.split(";"), f = 0; f < e.length; f++)
                    if (h = cP.exec(e[f]) || dP.exec(e[f]) || eP.exec(e[f])) {
                        k = h[1] || 0;
                        if (k == E) {
                            G = h[2];
                            break b
                        }
                        k < g && (g = k, G = h[2])
                    }x && G && -1 != G.search(/^\d+\.\d+$/) ? (q.vid = G, q.from_cookie = !0) : G != q.vid && (q.cid = G)
            }
            q.dh = c;
            q.hid || (q.hid = Math.round(2147483647 *
                Math.random()));
            G = q
        }
        b.ga_vid = G.vid;
        b.ga_sid = G.sid;
        b.ga_hid = G.hid;
        b.ga_fc = G.from_cookie;
        b.ga_cid = G.cid;
        b.ga_wpids = z.google_analytics_uacct;
        PP(a.pubWin, b);
        (a = d.google_ad_layout) && 0 <= BN[a] && (b.rplot = BN[a])
    }

    function SP(a, b) {
        a = a.i;
        if (a ? .g() || cJ()) b.npa = 1;
        if (a) {
            null != ai(a, 3) && (b.gdpr = O(a, 3) ? "1" : "0");
            var c = L(a, 1);
            c && (b.us_privacy = c);
            (c = L(a, 2)) && (b.gdpr_consent = c);
            (c = L(a, 4)) && (b.addtl_consent = c);
            (c = M(a, 7)) && (b.tcfe = c);
            v(Ws) && ((c = P(a, 11)) && (b.gpp = c), (a = bi(a, 10, qh, 2, void 0, void 0, 0)) && 0 < a.length && (b.gpp_sid = a.join(",")))
        }
    }

    function TP(a, b) {
        const c = a.D;
        SP(a, b);
        $e(gJ, (d, e) => {
            b[d] = c[e]
        });
        delete b.ea;
        cN(c) && (a = oN(c), b.fa = a);
        b.pi || null == c.google_ad_slot || (a = aB(c), null != a.g && (a = uq(a.getValue()), b.pi = a))
    }

    function iR(a, b) {
        var c = sk() || cM(a.pubWin.top);
        c && (b.biw = c.width, b.bih = c.height);
        c = a.pubWin;
        c !== c.top && (a = cM(a.pubWin)) && (b.isw = a.width, b.ish = a.height)
    }

    function jR(a, b) {
        var c = a.pubWin;
        null !== c && c != c.top ? (a = [c.document.URL], c.name && a.push(c.name), c = cM(c, !1), a.push(c.width.toString()), a.push(c.height.toString()), a = bf(a.join(""))) : a = 0;
        0 !== a && (b.ifk = a)
    }

    function kR(a, b) {
        (a = aJ()[a.D.google_ad_client]) && (b.psts = a.join())
    }

    function lR(a, b) {
        (a = a.pubWin.tmod) && (b.tmod = a)
    }

    function mR(a, b) {
        (a = a.pubWin.google_user_agent_client_hint) && (b.uach = Mf(a))
    }

    function nR(a, b) {
        try {
            const e = a.pubWin && a.pubWin.external && a.pubWin.external.getHostEnvironmentValue && a.pubWin.external.getHostEnvironmentValue.bind(a.pubWin.external);
            if (e) {
                var c = JSON.parse(e("os-mode")),
                    d = parseInt(c["os-mode"], 10);
                0 <= d && (b.wsm = d + 1)
            }
        } catch {}
    }

    function oR(a, b) {
        0 <= a.D.google_ad_public_floor && (b.pubf = a.D.google_ad_public_floor);
        0 <= a.D.google_ad_private_floor && (b.pvtf = a.D.google_ad_private_floor)
    }

    function pR(a, b) {
        const c = Number(a.D.google_traffic_source);
        c && Object.values(Oa).includes(c) && (b.trt = a.D.google_traffic_source)
    }

    function qR(a, b) {
        var c;
        (c = v(bv)) || (c = a.A ? .label, c = v(Gu) && c ? !!c.match(Yb(Eu)) : !1);
        c || "runAdAuction" in a.pubWin.navigator && "joinAdInterestGroup" in a.pubWin.navigator && (b.td = 1)
    }

    function rR(a, b) {
        if (null != a.A && xc()) {
            var c = new BP,
                d = aj(c, 3, a.A.label);
            R(d, 4, a.A.status);
            b.psd = Mf(bj(c))
        }
    }

    function sR(a, b) {
        v(Tu) || kP("attribution-reporting", a.pubWin.document) && (b.nt = 1)
    }

    function tR(a, b) {
        if ("string" === typeof a.D.google_privacy_treatments) {
            var c = new Map([
                ["disablePersonalization", 1]
            ]);
            a = a.D.google_privacy_treatments.split(",");
            var d = [];
            for (const [e, f] of c.entries()) c = f, a.includes(e) && d.push(c);
            d.length && (b.ppt = d.join("~"))
        }
    }

    function uR(a, b) {
        v(xu) && (b.bz = Ff(a.pubWin))
    }

    function IP(a, b) {
        const c = {};
        TP(a, c);
        mR(a, c);
        RP(a, c, b);
        c.u_tz = -(new Date).getTimezoneOffset();
        c.u_his = Ok();
        c.u_h = Sj.screen ? .height;
        c.u_w = Sj.screen ? .width;
        c.u_ah = Sj.screen ? .availHeight;
        c.u_aw = Sj.screen ? .availWidth;
        c.u_cd = Sj.screen ? .colorDepth;
        c.u_sd = dM(a.pubWin);
        c.dmc = a.pubWin.navigator ? .deviceMemory;
        Yz(889, () => {
            if (null == a.K) c.adx = -12245933, c.ady = -12245933;
            else {
                var e = gM(a.K, a.ia);
                c.adx && -12245933 != c.adx && c.ady && -12245933 != c.ady || (c.adx = Math.round(e.x), c.ady = Math.round(e.y));
                fM(a.ia) || (c.adx = -12245933,
                    c.ady = -12245933, a.g |= 32768)
            }
        });
        iR(a, c);
        jR(a, c);
        MP(a, c);
        LP(a, c);
        c.oid = 2;
        kR(a, c);
        c.pvsid = Bf(a.pubWin, Wz);
        lR(a, c);
        nR(a, c);
        c.uas = FP(a.pubWin);
        const d = AP(a.pubWin);
        d && (c.nvt = d);
        a.C && (c.scar = a.C);
        a.l instanceof Uint8Array ? c.topics = Kf(a.l) : a.l && (c.topics = a.l, c.tps = a.l);
        OP(a, c, b);
        c.fu = a.g;
        c.bc = xP();
        O(a.Fa, 9) && (uP(c), c.creatives = NP(/\b(?:creatives)=([\d,]+)/), c.adgroups = NP(/\b(?:adgroups)=([\d,]+)/), c.adgroups && (c.adtest = "on", c.disable_budget_throttling = !0, c.use_budget_filtering = !1, c.retrieve_only = !0, c.disable_fcap = !0));
        ek() && (c.atl = !0);
        uR(a, c);
        oR(a, c);
        pR(a, c);
        qR(a, c);
        rR(a, c);
        sR(a, c);
        tR(a, c);
        v(Hu) && "true" === String(a.D.google_xz) && (c.scd = 1);
        null == Yb(Iu) || !1 !== a.D.google_video_play_muted && !0 !== v(Ju) || 10 !== a.D.google_reactive_ad_format && 11 !== a.D.google_reactive_ad_format || (c.sdkv = Yb(Iu));
        return c
    }
    const JP = /YtLoPri/;
    var vR = class extends S {};
    vR.P = [5];
    var qi = class extends S {
            Ie() {
                return P(this, 18)
            }
            vd() {
                return P(this, 19)
            }
            Je() {
                return P(this, 20)
            }
        },
        wR = hj(qi);
    qi.P = [15];
    var xR = class extends S {},
        yR = hj(xR);
    xR.P = [3];
    var zR = class {
        constructor(a) {
            this.Wb = a.Wb ? ? [];
            this.Vc = a.Vc ? ? 0;
            this.Qc = a.Qc ? ? !1;
            this.Sg = !!a.Sg;
            this.bf = a.bf ? ? .1;
            this.ff = a.ff ? ? !1;
            this.ef = !!a.ef;
            this.sb = a.sb ? ? !1;
            this.zg = a.zg ? ? 0;
            this.If = a.If ? ? 0;
            this.Ae = a.Ae ? ? !1;
            this.Be = a.Be ? ? !1;
            this.pf = !!a.pf;
            this.Fe = !!a.Fe;
            this.fe = a.fe ? ? 3E4;
            this.Ee = !!a.Ee;
            this.ee = a.ee ? ? "";
            this.jb = a.jb ? ? "";
            this.Pc = !!a.Pc;
            this.qe = !!a.qe;
            this.V = !!a.V;
            this.Fc = a.Fc ? ? .3;
            this.kd = !!a.kd
        }
    };

    function AR(a, b, c, d, e) {
        const f = C(b, QN, 2);
        try {
            const k = a ? .location ? .hash ? .match(/\bgoog_cpmi=([^&]*)/);
            if (k) {
                var g = decodeURIComponent(k[1]);
                var h = wR(g)
            } else h = null
        } catch (k) {
            h = null
        }
        h = h || pi(b);
        a = f ? .g() && (488 > wo(a) || !f ? .j()) ? 0 : 1;
        b = D(b, or, 3);
        b = {
            Ej: w(St),
            jf: 2,
            he: 5,
            Vb: 300,
            Zf: b
        };
        return {
            aa: h,
            hd: c,
            Ce: a,
            Di: d,
            Za: b,
            de: {
                sf: w(su)
            },
            J: new zR({
                Wb: fo(),
                Vc: w(Pt),
                bf: w(ku),
                Qc: v(tu),
                ff: v(nu),
                ef: v(mu),
                sb: v(au),
                zg: w(hu),
                If: w(Ot),
                Ae: v(Vt),
                Be: v(Wt),
                pf: v(qu),
                Fe: v(bu),
                fe: w(Rt),
                Ee: v(Xt),
                ee: Yb(cu),
                jb: Yb(du),
                Pc: v(Yt),
                qe: v(Ut),
                V: v(ru),
                Fc: w(ju),
                kd: v($t)
            }),
            ce: e
        }
    }

    function BR(a, b) {
        a = hB(wA(b, a), a);
        if (0 !== a.length) return a.reduce((c, d) => c.ka.g > d.ka.g ? c : d)
    };

    function CR(a, b) {
        a.entries.push(Sh(b));
        return a.entries.length - 1
    }

    function DR(a, b, c, d, e, f, g, h) {
        var k = new xn,
            l = new Dm;
        c = aj(l, 1, c);
        d = aj(c, 2, d);
        b = Wi(d, 3, b);
        k = F(k, 1, b);
        b = new Em;
        b = aj(b, 2, a.i);
        e = aj(b, 3, e);
        e = F(k, 2, e);
        g = Q(e, 3, Math.round(g));
        b = D(f, vR, 15);
        e = d = k = 0;
        for (m of b) k += (O(m, 3) ? 1 : 0) + (O(m, 4) ? 1 : 0) + bi(m, 5, vh, 2).length, c = O(m, 3) ? 1 : 0, l = O(m, 4) || bi(m, 5, vh, 2).length ? 1 : 0, d += c + l, e += O(m, 3) ? 1 : 0;
        var m = new wn;
        m = Xi(m, 1, b.length);
        m = Xi(m, 2, k);
        m = Wh(m, 3, null == d ? d : ih(d));
        m = Wh(m, 4, null == e ? e : ih(e));
        m = F(g, 6, m);
        h.length ? (a = new on, a = si(a, 1, h), I(m, 5, yn, a)) : (h = new vn, h = si(h, 2, a.entries), f = D(f,
            vR, 15).length, f = Q(h, 3, f), a = F(f, 4, a.g), I(m, 4, yn, a));
        return m
    }
    var ER = class {
        constructor() {
            this.entries = [];
            this.g = this.i = null
        }
    };
    async function FR(a, b) {
        await new Promise(c => {
            0 < a.j && a.win.requestIdleCallback ? a.win.requestIdleCallback(() => void c(), {
                timeout: a.j
            }) : a.win.setTimeout(c, 0)
        });
        a.i = a.g.za(b) + a.l
    }
    var GR = class {
        constructor(a, b) {
            var c = w(Tt),
                d = w(fu);
            this.win = a;
            this.g = b;
            this.l = c;
            this.j = d;
            this.i = b.za(2) + c
        }
    };
    var HR = class {
            constructor(a) {
                this.performance = a
            }
            za() {
                return this.performance.now()
            }
        },
        IR = class {
            za() {
                return Date.now()
            }
        };
    const JR = [255, 255, 255];

    function KR(a) {
        function b(d) {
            return [Number(d[1]), Number(d[2]), Number(d[3]), 4 < d.length ? Number(d[4]) : 1]
        }
        var c = a.match(/rgb\(([0-9]+),\s*([0-9]+),\s*([0-9]+)\)/);
        if (c || (c = a.match(/rgba\(([0-9]+),\s*([0-9]+),\s*([0-9]+),\s*([0-9\\.]+)\)/))) return b(c);
        if ("transparent" === a || "" === a) return [0, 0, 0, 0];
        throw Error(`Invalid color: ${a}`);
    }

    function LR(a) {
        var b = getComputedStyle(a);
        if ("none" !== b.backgroundImage) return null;
        b = KR(b.backgroundColor);
        var c = MR(b);
        if (c) return c;
        a = (a = a.parentElement) ? LR(a) : JR;
        if (!a) return null;
        c = b[3];
        return [Math.round(c * b[0] + (1 - c) * a[0]), Math.round(c * b[1] + (1 - c) * a[1]), Math.round(c * b[2] + (1 - c) * a[2])]
    }

    function MR(a) {
        return 1 === a[3] ? [a[0], a[1], a[2]] : null
    };
    var OR = class {
        constructor(a, b, c, d) {
            this.jf = b;
            this.he = c;
            this.Vb = d;
            this.i = 0;
            this.g = new NR(a)
        }
    };

    function PR(a, b) {
        b -= a.l;
        for (const c of a.g.keys()) {
            const d = a.g.get(c);
            let e = 0;
            for (; e < d.length && d[e] < b;) e++;
            a.i -= e;
            0 < e && a.g.set(c, d.slice(e))
        }
    }
    class NR {
        constructor(a) {
            this.l = a;
            this.g = new Map;
            this.i = 0
        }
        get j() {
            return this.i
        }
    };

    function QR(a) {
        A(a, {
            border: "0",
            "box-shadow": "none",
            display: "inline",
            "float": "none",
            margin: "0",
            outline: "0",
            padding: "0"
        })
    };

    function RR(a, b) {
        return SR(a, "100 -1000 840 840", `calc(${b} - 2px)`, b, "m784-120-252-252q-30 24-69 38t-83 14q-109 0-184.5-75.5t-75.5-184.5q0-109 75.5-184.5t184.5-75.5q109 0 184.5 75.5t75.5 184.5q0 44-14 83t-38 69l252 252-56 56zm-404-280q75 0 127.5-52.5t52.5-127.5q0-75-52.5-127.5t-127.5-52.5q-75 0-127.5 52.5t-52.5 127.5q0 75 52.5 127.5t127.5 52.5z")
    }

    function TR(a, b, c) {
        switch (c) {
            case 1:
                return b = SR(a, "0 -960 960 960", "20px", "20px", "m274-274-128-70 42-42 100 14 156-156-312-170 56-56 382 98 157-155q17-17 42.5-17t42.5 17q17 17 17 42.5T812-726L656-570l98 382-56 56-170-312-156 156 14 100-42 42-70-128Z"), A(b, {
                    fill: "#FFFFFF"
                }), b;
            default:
                return a = SR(a, "0 -960 960 960", "20px", "20px", "M503-104q-24 24-57 24t-57-24L103-390q-23-23-23-56.5t23-56.5l352-353q11-11 26-17.5t32-6.5h286q33 0 56.5 23.5T879-800v286q0 17-6.5 32T855-456L503-104Zm196-536q25 0 42.5-17.5T759-700q0-25-17.5-42.5T699-760q-25 0-42.5 17.5T639-700q0 25 17.5 42.5T699-640ZM446-160l353-354v-286H513L160-446l286 286Zm353-640Z"),
                    b && A(a, {
                        fill: b
                    }), a
        }
    }

    function UR(a, b, c, d) {
        a = SR(a, "0 -960 960 960", "20px", "20px", "m256-200-56-56 224-224-224-224 56-56 224 224 224-224 56 56-224 224 224 224-56 56-224-224-224 224Z");
        A(a, {
            left: "13px",
            right: "",
            "pointer-events": "initial",
            position: "absolute",
            top: b.V ? "11px" : "15px",
            transform: "none"
        });
        d && A(a, {
            fill: "#1A73E8"
        });
        a.role = "button";
        a.ariaLabel = c;
        a.tabIndex = 0;
        return a
    }

    function SR(a, b, c, d, e) {
        const f = a.createElementNS("http://www.w3.org/2000/svg", "path");
        f.setAttribute("d", e);
        a = a.createElementNS("http://www.w3.org/2000/svg", "svg");
        a.setAttribute("viewBox", b);
        a.setAttribute("width", c);
        a.setAttribute("height", d);
        QR(a);
        a.appendChild(f);
        return a
    };
    const VR = ["Google Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200", "Google Sans Text:400,500"];

    function WR(a, b, c, d, e) {
        a = new YR(a, b, c, d, e);
        if (a.l) {
            Vp(a.win, VR);
            var f = a.win;
            b = a.message;
            c = Qv(f);
            e = c.shadowRoot;
            d = e.appendChild;
            f = new fe(f.document);
            var g = fs('<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Google+Symbols:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200"/><link href="https://fonts.googleapis.com/css?family=Google+Sans+Text:400,500" rel="stylesheet"><style>.ipr-container {font-family: \'Google Sans Text\'; font-style: normal; font-weight: 400; font-size: 12px; line-height: 14px; color: #000; border-top: 2px solid rgb(236, 237, 237); border-bottom: 2px solid rgb(236, 237, 237); background-color: #fff; padding: 5px; margin: 5px 0; text-align: center;}.ipr-button {border: none; background: none; font-family: \'Google Sans Text\'; color: #0b57d0; font-weight: 500; font-size: 14px; line-height: 22px; cursor: pointer; margin: 0; padding: 0;}.ipr-display-none {display: none;}</style><div class="ipr-container"><button class="ipr-button"></button><div class="ipr-info"></div></div>');
            d.call(e,
                te(f, as(g)));
            d = kx("ipr-container", e);
            e = kx("ipr-button", d);
            b.actionButton ? (e.appendChild(b.actionButton.buttonText), e.addEventListener("click", b.actionButton.onClick)) : e.classList.add("ipr-display-none");
            d = kx("ipr-info", d);
            b.informationText ? d.appendChild(b.informationText) : d.classList.add("ipr-display-none");
            a.g = c.Ua;
            fB(a.l, a.g);
            a.j && a.j(xm(1));
            ZR(a)
        } else $R(a)
    }

    function ZR(a) {
        const b = new Yp(a.win);
        b.L(2E3);
        Yo(a, b);
        Wp(b, () => {
            aS(a);
            $R(a);
            b.ma()
        })
    }

    function $R(a) {
        sz(a.win, a.Lb).addRegulatoryMessage({
            messageSpec: {
                regulatoryMessage: a.message,
                orderingIndex: 0
            }
        });
        a.j && a.j(xm(2))
    }

    function aS(a) {
        a.g && (a.g.parentNode ? .removeChild(a.g), a.g = null)
    }
    var YR = class extends U {
        constructor(a, b, c, d, e) {
            super();
            this.win = a;
            this.l = b;
            this.message = c;
            this.Lb = d;
            this.j = e;
            this.g = null
        }
        i() {
            aS(this);
            super.i()
        }
    };

    function bS(a, b, c, d, e, f) {
        if (!a.g) {
            var g = b.document.createElement("span");
            g.appendChild(RR(b.document, "12px"));
            g.appendChild(b.document.createTextNode(d));
            WR(b, c || null, {
                informationText: g
            }, e, f ? h => {
                var k = f.handle,
                    l = cS(f, 16);
                h = I(l, 11, Jn, h);
                k.call(f, h)
            } : f);
            a.g = !0
        }
    }
    var dS = class {
        constructor() {
            this.g = !1
        }
    };
    const eS = [{
        Sd: "1907259590",
        Id: 480,
        Fb: 220
    }, {
        Sd: "2837189651",
        Id: 400,
        Fb: 180
    }, {
        Sd: "9211025045",
        Id: 360,
        Fb: 160
    }, {
        Sd: "6584860439",
        Id: -Infinity,
        Fb: 150
    }];

    function fS(a) {
        return eS.find(b => b.Id <= a)
    };

    function gS(a, b) {
        return b ? a.replace("ca", "partner") : "pub-adfiliates-query-origin"
    };

    function hS(a) {
        iS.g.push(a)
    }
    const iS = new class {
        constructor() {
            this.g = []
        }
    };
    let jS = !1;

    function kS(a) {
        lS(a.config, 1065, a.win, () => {
            if (!a.g) {
                var b = new Gn;
                b = Q(b, 1, a.i);
                var c = new Fn;
                b = I(b, 2, Hn, c);
                mS(a.config.ba, b)
            }
        }, 1E4)
    }
    class nS {
        constructor(a, b, c) {
            this.win = a;
            this.config = b;
            this.i = c;
            this.g = !1
        }
        cancel(a) {
            this.win.clearTimeout(a)
        }
    }

    function oS(a, b, c, d, e, f) {
        const g = fS(a.document.body.clientWidth);
        d = b.sa ? pS(a, b, d, g, e, f) : qS(a, b, d, g, e, f);
        jp(d.isVisible(), !1, () => {
            jS = !1;
            var k = iS;
            for (const l of k.g) l();
            k.g.length = 0
        });
        d.show({
            cg: !0
        });
        jS = !0;
        const h = new nS(a, b, c);
        kS(h);
        hS(() => {
            var k = b.ba;
            var l = new Gn;
            l = Q(l, 1, c);
            var m = new En;
            l = I(l, 3, Hn, m);
            mS(k, l);
            h.g = !0
        })
    }

    function pS(a, b, c, d, e, f) {
        d = b.J.Qc ? rS(a, b, c, f) : sS(a, b, c, {
            se: d,
            dg: a.innerWidth,
            bg: "100%",
            Eg: "15px",
            ag: "13px",
            Fg: "center",
            kh: 0
        }, e, f);
        return my(a, d, {
            cf: b.J.Ee ? .95 : .75,
            He: .95,
            zIndex: 100001,
            rb: !0,
            ye: "adpub-drawer-root",
            xe: !1,
            Ja: !0,
            De: new V(P(b.aa, 10).replace("TERM", c))
        })
    }

    function qS(a, b, c, d, e, f) {
        a: {
            var g = a.document.body.clientWidth;
            var h = .9 * g;
            for (g = 768 >= g ? 3 : 4; 1 <= g; g--) {
                const k = d.Fb * g + 42;
                if (k <= h) {
                    h = k;
                    break a
                }
            }
        }
        d = b.J.Qc ? rS(a, b, c, f) : sS(a, b, c, {
            se: d,
            dg: h,
            bg: "600px",
            Eg: "24px",
            ag: "24px",
            Fg: "start",
            kh: 0
        }, e, f);
        return wx(a, d, {
            wc: `${h}px`,
            vc: b.la(),
            lc: P(b.aa, 14),
            zIndex: 100001,
            rb: !0,
            ld: !0,
            ye: "adpub-drawer-root",
            xe: !1,
            Ja: !0,
            De: new V(P(b.aa, 10).replace("TERM", c))
        })
    }

    function rS(a, b, c, d) {
        const e = a.document.createElement("iframe");
        var f = b.aa;
        f = new Ls(e, P(f, 16), "anno-cse", gS(b.i, O(f, 22)), "ShoppingVariant", a.location, P(f, 7), P(f, 10).replace("TERM", c), b.J.Wb, !1, !0, void 0, !0);
        f.L();
        tS(a, b, e, c, f, d);
        return e
    }

    function sS(a, b, c, d, e, f) {
        var g = b.aa,
            h = P(g, 10),
            k = h.indexOf("TERM"),
            l = d.dg,
            m = d.se;
        l = Math.max(Math.floor((l - Math.floor(l / m.Fb) * m.Fb) / 2), 5);
        m = d.bg;
        const n = P(g, 3),
            p = d.Eg,
            q = d.ag,
            x = d.Fg,
            z = P(g, 6),
            G = h.substring(0, k);
        h = h.substring(k + 4);
        k = !!O(g, 13);
        e = fs('<link href="https://fonts.googleapis.com/css2?family=Google+Material+Icons:wght@400;500;700" rel="stylesheet"><link href="https://fonts.googleapis.com/css2?family=Google+Sans:wght@400;500;700&display=swap" rel="stylesheet"><div style="font-family: Roboto, sans-serif;"><div style="border: 0 solid #eee; border-bottom-width: 1px; color: #3c4043; font-size: 13px; line-height: 20px; padding: 0 ' + js(X(p)) +
            " " + js(X(q)) + "; text-align: " + js(X(x)) + ';">' + (e ? '<div style="max-width: ' + js(X(m)) + '">' + es(n) + '\u00a0<a href="https://support.google.com/adsense/answer/11188578" target="_blank" style="color: #1967d2; text-decoration: none; white-space: nowrap">' + es(z) + "</a></div>" : "") + "</div><div style=\"border-bottom: 1px solid #eee; color: #202124; font-family: 'Google Sans'; font-size: 15px; line-height: 24px; padding: 15px " + js(X(p)) + "; text-align: " + js(X(x)) + '"><div style="display: -webkit-box; overflow: hidden; -webkit-line-clamp: 2; -webkit-box-orient: vertical;"><span style="bottom: -2px; color: #1967d2; font-family: \'Google Material Icons\'; padding-right: 5px; position: relative">search</span><span style="color:#80868b"> ' +
            es(G) + "</span>" + es(c) + '<span style="color:#80868b">' + es(h) + '</span></div></div><div id="anno-csa" style="margin:5px ' + js(X(l)) + "px\"></div><script>(function(g,o){g[o]=g[o]||function(){(g[o]['q']=g[o]['q']||[]).push(arguments)},g[o]['t']=1*new Date})(window,'_googCsa');parent.postMessage({query:" + ns(os(c)) + "},parent.location.origin);\x3c/script>" + (k ? "<script>const el = document.getElementById('anno-csa'); el.dir = 'ltr'; el.style.height = '800px'; el.style.width = '75vw'; el.style.overflow = 'hidden'; el.style.overflowWrap = 'break-word'; el.textContent = JSON.stringify(window._googCsa.q);\x3c/script>" :
                '<script async="async" src="https://www.google.com/adsense/search/ads.js">\x3c/script>') + "</div>");
        g = {
            dir: b.la() ? "rtl" : "ltr",
            lang: P(g, 7),
            style: sd({
                margin: "0",
                height: "100%",
                "padding-top": `${d.kh}px`,
                overflow: "hidden"
            })
        };
        e = as(e);
        Gd("body");
        g = Jd("body", g, e);
        e = a.document.createElement("IFRAME");
        A(e, {
            border: "0",
            width: "100%"
        });
        uS(a, b, e, c, d.se, f);
        e.srcdoc = Dd(g);
        return e
    }

    function uS(a, b, c, d, e, f) {
        const g = vS(b, a, function(h) {
            h.data.query === d && wS(a, b, c, d, e, f)
        });
        hS(() => {
            a.removeEventListener("message", g)
        })
    }

    function tS(a, b, c, d, e, f) {
        const g = vS(b, a.top, function(h) {
            "init" === h.data.action && "ShoppingVariant" === h.data.adChannel && xS(a, b, c, e, d, f)
        });
        hS(() => {
            a.top.removeEventListener("message", g)
        })
    }

    function wS(a, b, c, d, e, f) {
        const g = c.contentDocument ? .documentElement;
        g && ((new ResizeObserver(() => {
            c.height = `${g.offsetHeight}px`
        })).observe(g), yS(b, a, () => {
            const h = g.offsetHeight;
            h && (c.height = `${h}px`)
        }), zS(b, c, d, e, f))
    }

    function xS(a, b, c, d, e, f) {
        O(b.aa, 13) || Js(d, e, f);
        const g = c.contentDocument.documentElement,
            h = new ResizeObserver(() => {
                c.height = `${Math.ceil(g.offsetHeight+22)}px`
            });
        h.observe(g);
        const k = yS(b, a, () => {
            const l = g.offsetHeight;
            l && (c.height = `${l+22}px`)
        });
        hS(() => {
            h.disconnect();
            a.clearInterval(k)
        })
    }

    function zS(a, b, c, d, e) {
        const f = a.aa,
            g = b.contentWindow;
        b = b ? .contentDocument || b.contentWindow ? .document;
        if (g) {
            if (void 0 === g._googCsa) throw Error("No _googCsa");
            if (!b) throw Error("No contentDocument");
        } else throw Error("No googCsa window");
        a = {
            pubId: gS(a.i, O(f, 22)),
            styleId: d.Sd,
            disableCarousel: !0,
            query: c,
            hl: P(f, 7),
            personalizedAds: "false",
            fexp: a.J.Wb.join(","),
            adfiliateWp: a.i,
            adtest: a.ce ? "on" : ""
        };
        e && (a.afdToken = e);
        g._googCsa("ads", a, {
            container: "anno-csa",
            linkTarget: "_blank",
            number: 8,
            width: b.body.offsetWidth -
                30
        });
        O(f, 13) && (e = b.getElementById("anno-csa"), e.dir = "ltr", e.style.height = "800px", e.style.width = "75vw", e.style.overflow = "hidden", e.style.g = "break-word", e.textContent = JSON.stringify(g._googCsa.q))
    };

    function AS(a) {
        a = KR(a);
        var b = new qn;
        b = Yi(b, 1, a[0]);
        b = Yi(b, 2, a[1]);
        b = Yi(b, 3, a[2]);
        return li(b, 4, ah(a[3]), 0)
    };

    function BS(a, b, c) {
        return c.Pc ? CS(a, b, c) ? ? DS(a, b, c) : DS(a, b, c) ? ? CS(a, b, c)
    }

    function DS(a, b, c) {
        const d = c.sa === c.la;
        var e = ES(a, b, c, d);
        if (!e) return null;
        e = e.position.rd();
        const f = b.V ? 7 : 16;
        a = FS(a, b, e, c, function(g) {
            g = g.getBoundingClientRect();
            return d ? c.R - g.right : g.left
        });
        if (!a || 200 > a - f) return null;
        b = c.R;
        return {
            ta: d ? b - a : f,
            Ea: d ? f : b - a,
            ca: e
        }
    }

    function GS(a, b, c) {
        const d = wo(a),
            e = T(a);
        return 0 < Wv(new Yv(a), new hk(e - c.ca - (b.V ? 40 : 50), d - c.Ea, e - c.ca, c.ta)).size
    }

    function ES(a, b, c, d) {
        c = Math.floor(c.U * (c.Fc ? ? .3));
        const e = b.V ? 40 : 66;
        return c < e ? null : ty(a, {
            dc: d ? zy({
                ca: b.V ? 0 : 16,
                Ea: b.V ? 7 : 16
            }) : xy({
                ca: b.V ? 0 : 16,
                ta: b.V ? 7 : 16
            }),
            Se: c - e,
            Cb: 50,
            Ve: b.V ? 40 : 50,
            Gd: c,
            nb: b.V ? 7 : 16
        }, [a.document.body]).je
    }

    function FS(a, b, c, d, e) {
        a = d.sa ? HS(a, b, c, d) : IS(a, b, c, d);
        c = d.R;
        let f = d.sa ? c : .35 * c;
        a.forEach(g => {
            f = Math.min(f, e(g))
        });
        b = b.V ? 7 : 16;
        return f < b ? null : f - b
    }

    function HS(a, b, c, d) {
        const e = d.U,
            f = b.V ? 7 : 16;
        return Wv(new Yv(a), new hk(e - c - (b.V ? 40 : 50), d.R - f, e - c, f))
    }

    function IS(a, b, c, d) {
        const e = d.U,
            f = d.R;
        d = d.la;
        const g = b.V ? 7 : 16;
        return Wv(new Yv(a), new hk(e - c - (b.V ? 40 : 50), (d ? .35 * f : f) - g, e - c, (d ? g : .65 * f) + g))
    }

    function CS(a, b, c) {
        const d = c.R;
        var e = JS(a, b, c);
        let f = a = b.V ? 7 : 16;
        for (const g of e) {
            e = g.start;
            const h = g.end;
            if (e > f) {
                if (200 <= e - f - a) return KS(c, b, e, f);
                f = h + a
            } else h >= f && (f = h + a)
        }
        return 200 <= d - f - a ? KS(c, b, d, f) : null
    }

    function KS(a, b, c, d) {
        const e = a.la;
        return {
            ta: e ? LS(a, b, c, d) : d,
            Ea: e ? d : LS(a, b, c, d),
            ca: b.V ? 0 : 16
        }
    }

    function LS(a, b, c, d) {
        const e = a.R;
        b = b.V ? 7 : 16;
        return a.sa ? e - c + b : Math.max(e - d - .35 * e, e - c + b)
    }

    function JS(a, b, c) {
        const d = c.la,
            e = c.R;
        a = c.sa ? HS(a, b, b.V ? 0 : 16, c) : IS(a, b, b.V ? 0 : 16, c);
        return Array.from(a).map(f => new sy(d ? e - f.getBoundingClientRect().right : f.getBoundingClientRect().left, d ? e - f.getBoundingClientRect().left : f.getBoundingClientRect().right)).sort((f, g) => f.start - g.start)
    };

    function MS(a, b, c, d, e, f, g, h, k) {
        A(c, {
            width: "50px",
            bottom: g ? g.ca + "px" : "16px",
            left: b.la() === b.sa ? "" : g ? g.ta + "px" : "16px",
            right: b.la() === b.sa ? g ? g.Ea + "px" : "16px" : ""
        });
        c.role = "button";
        c.ariaLabel = b.Je();
        A(e, {
            display: "none"
        });
        A(d, {
            display: "none"
        });
        const l = TR(a.document, b.J.jb, b.Me.get(k) || 0);
        b.J.kd ? (a = a.document.createElement("SPAN"), A(a, {
            display: "inline-block",
            position: "absolute",
            top: b.J.V ? "12px" : "14px",
            left: "15px"
        }), c.appendChild(a), a.appendChild(l)) : (A(l, {
                position: "absolute",
                top: b.J.V ? "12px" : "14px",
                left: "15px"
            }),
            c.appendChild(l));
        NS(b, 1064, c, m => {
            h ? .();
            l.remove();
            A(c, {
                bottom: g ? g.ca + "px" : "16px",
                left: g ? g.ta + "px" : b.sa ? "16px" : b.la() ? "16px" : "65%",
                right: g ? g.Ea + "px" : OS(b),
                width: ""
            });
            c.role = "";
            c.ariaLabel = "";
            A(e, {
                display: ""
            });
            A(d, {
                display: "flex"
            });
            f.focus();
            m.preventDefault();
            return !1
        });
        c.focus()
    }

    function OS(a) {
        return a.la() ? a.sa ? "16px" : "65%" : "16px"
    }

    function PS(a, b) {
        return {
            "margin-left": b ? "6px" : "4px",
            "margin-right": b ? "4px" : "6px",
            "margin-top": a.V ? "8px" : "12px"
        }
    };

    function QS(a, b, c, d, e, f, g, h, k) {
        const l = document.createElement("SPAN");
        l.id = "gda";
        l.appendChild(UR(a.document, b.J, b.Ie(), b.J.jb));
        NS(b, 1064, l, m => {
            g ? .();
            MS(a, b, c, d, l, e, f, h, k);
            m.preventDefault();
            m.stopImmediatePropagation();
            return !1
        });
        return l
    }

    function RS(a, b) {
        (new MutationObserver(c => {
            c.forEach(d => {
                "attributes" === d.type && "0px" === a.document.body.style.paddingBottom && A(a.document.body, {
                    "padding-bottom": (b.V ? 40 : 66) + "px"
                })
            })
        })).observe(a.document.body, {
            attributes: !0
        })
    }

    function SS(a, b, c, d, e, f, g) {
        var h = b.J,
            k = a.getComputedStyle(a.document.body).paddingBottom.match(/\d+/);
        A(a.document.body, {
            "padding-bottom": (k && k.length ? Number(k[0]) : 0) + (h.V ? 40 : 66) + "px"
        });
        RS(a, b.J);
        h = document.createElement("div");
        h.id = "google-anno-sa";
        h.dir = b.la() ? "rtl" : "ltr";
        h.tabIndex = 0;
        k = {
            background: b.J.ee || "#1A73E8",
            "border-style": "solid",
            bottom: e ? e.ca + "px" : "16px",
            "border-radius": b.J.V ? e ? .ca ? "12px" : "12px 12px 0 0" : "16px",
            height: (b.J.V ? 40 : 50) + "px",
            position: "fixed",
            "text-align": "center",
            border: "0px",
            left: e ? e.ta + "px" : b.sa ? "16px" : b.la() ? "16px" : "65%",
            right: e ? e.Ea + "px" : OS(b),
            "box-shadow": "0px 1px 2px rgba(0, 0, 0, 0.3), 0px 1px 3px 1px rgba(0, 0, 0, 0.15)",
            "z-index": "1000"
        };
        A(h, k);
        A(h, {
            fill: "white"
        });
        k = document.createElement("SPAN");
        const l = document.createElement("SPAN");
        QR(l);
        var m = {
            position: "absolute",
            top: "2.5px",
            bottom: "2.5px",
            left: (b.la(), "50px"),
            right: b.la() ? "24px" : "12px",
            display: "flex",
            "flex-direction": "row",
            color: b.J.jb || "#FFFFFF",
            cursor: "pointer",
            transition: "width 5s"
        };
        A(l, m);
        b.sa || A(l, {
            "justify-content": ""
        });
        m = TR(a.document, b.J.jb, b.Me.get(d) || 0);
        if (b.J.kd) {
            const n = document.createElement("SPAN");
            A(n, {
                display: "inline-block"
            });
            A(n, PS(b.J, b.la()));
            l.appendChild(n);
            n.appendChild(m)
        } else A(m, PS(b.J, b.la())), l.appendChild(m);
        k.classList ? .add("google-anno-sa-qtx", "google-anno-skip");
        m = b.vd();
        k.tabIndex = 0;
        k.role = "link";
        k.ariaLive = "polite";
        k.ariaLabel = m.replace("TERM", d);
        A(k, {
            height: b.J.V ? "" : "40px",
            "align-items": "center",
            "line-height": b.J.V ? "35px" : "44px",
            "font-size": "16px",
            "font-weight": "400",
            "font-style": "normal",
            "font-family": "Roboto",
            "text-overflow": "ellipsis",
            "white-space": "nowrap",
            overflow: "hidden",
            "-webkit-tap-highlight-color": "transparent",
            color: b.J.jb
        });
        NS(b, 999, l, c);
        l.appendChild(k);
        c = QS(a, b, h, l, k, e, f, g, d);
        b.J.qe && !b.la() ? (h.appendChild(l), h.appendChild(c), MS(a, b, h, l, c, k, e, g, d)) : (h.appendChild(l), h.appendChild(c));
        return h
    }

    function TS(a, b, c) {
        b = b.getElementsByClassName("google-anno-sa-qtx")[0];
        b instanceof HTMLElement && (b.innerText = a.g);
        b.ariaLabel = c.aa.vd().replace("TERM", a.g);
        c = c.ba;
        b = new Cm;
        b = Zi(b, 1, a.i);
        b = aj(b, 4, a.g);
        a = c.handle;
        var d = cS(c, 13);
        b = I(d, 6, Jn, b);
        return a.call(c, b)
    }

    function US(a, b, c, d) {
        if (c.J.sb && GS(b, c.J, d) || !c.J.sb && lD(b)) return null;
        const e = c.za(20);
        d = SS(b, c, g => {
            if (!c.J.Vc || e + c.J.Vc <= c.za(21)) {
                var h = c.ba;
                var k = new zn;
                k = aj(k, 4, a.g);
                k = Zi(k, 1, a.i);
                k = Zi(k, 3, a.j);
                h = VS(h, k);
                oS(b, c, h, a.g, !1, c.l.get(a.g) || "")
            }
            g.preventDefault();
            return !1
        }, a.g, d, () => {
            var g = c.ba;
            var h = new zm;
            h = Q(h, 1, a.i);
            var k = aj(h, 2, a.g);
            h = g.handle;
            var l = cS(g, 18);
            k = I(l, 12, Jn, k);
            return h.call(g, k)
        }, () => {
            var g = c.ba,
                h = new Am,
                k = g.handle,
                l = cS(g, 19);
            h = I(l, 13, Jn, h);
            return k.call(g, h)
        });
        const f = TS(a, d, c);
        b.document.body.appendChild(d);
        return f
    }

    function WS(a, b, c, d, e, f) {
        if (a.g !== d || null !== a.i || a.l !== e) {
            if (null !== a.j) {
                var g = a.j,
                    h = c.ba;
                var k = new Bm;
                k = Q(k, 1, g);
                g = h.handle;
                var l = cS(h, 14);
                k = I(l, 7, Jn, k);
                g.call(h, k)
            }
            a.g = d;
            a.i = null;
            a.l = e;
            O(c.aa, 17) || (d = b.document.getElementById("google-anno-sa"), a.j = d ? TS(a, d, c) : US(a, b, c, f))
        }
    }
    var XS = class {
        constructor() {
            this.g = "";
            this.i = null;
            this.l = "";
            this.j = null
        }
    };

    function YS(a, b) {
        a.g >= a.i.length && (a.g = 0);
        if (jS) hS(() => void YS(a, b));
        else {
            var c = a.i[a.g++];
            a.j = !1;
            WS(a.A, a.win, a.config, c.g, c.i, a.l);
            lS(a.config, 898, a.win, () => void YS(a, b), a.sf)
        }
    }
    var ZS = class {
        constructor(a, b, c) {
            var d = new XS;
            this.win = a;
            this.config = b;
            this.A = d;
            this.l = c;
            this.i = [];
            this.j = !0;
            this.g = 0;
            this.sf = b.de.sf
        }
    };
    class $S {
        constructor(a, b) {
            this.g = a;
            this.i = b
        }
    };

    function aT(a, b, c, d) {
        b.forEach(e => {
            var f = sn(1);
            f = aj(f, 4, e);
            CR(c, f);
            d.i.push(new $S(e, e));
            d.j && YS(d, a)
        })
    };
    const bT = /[\s!'",:;\\(\\)\\?\\.\u00bf\u00a1\u30a0\uff1d\u037e\u061f\u3002\uff1f\uff1b\uff1a\u2014\u2014\uff5e\u300a\u300b\u3008\u3009\uff08\uff09\u300c\u300d\u3001\u00b7\u2026\u2025\uff01\uff0c\u00b7\u2019\u060c\u061b\u060d\u06d4\u0648]/;

    function cT(a, b) {
        switch (b) {
            case 1:
                return !0;
            default:
                return "" === a || bT.test(a)
        }
    };
    var dT = class {
        constructor(a) {
            this.g = a
        }
        isEmpty() {
            return this.g.isEmpty()
        }
        match(a) {
            return this.g.match(a)
        }
    };
    class eT {
        constructor(a) {
            this.B = a;
            this.size = 1;
            this.g = [new fT];
            this.j = [];
            this.i = new Map;
            this.A = new Map;
            this.l = 0
        }
        isEmpty() {
            return 0 === this.l
        }
        match(a) {
            let b = 0;
            const c = [];
            for (let g = 0; g < a.length; g++) {
                for (;;) {
                    var d = a.charCodeAt(g),
                        e = this.g[b];
                    if (e.contains(d)) {
                        b = e.j.get(d);
                        break
                    }
                    if (0 === b) break;
                    b = e.g
                }
                let h = b;
                for (;;) {
                    h = this.g[h].i;
                    if (0 === h) break;
                    const k = g + 1 - this.j[this.g[h].G],
                        l = g;
                    d = a;
                    e = l;
                    var f = this.B;
                    cT(d.charAt(k - 1), f) && cT(d.charAt(e + 1), f) && c.push(new gT(k, l, this.A.get(this.g[h].B)));
                    h = this.g[h].g
                }
            }
            return c
        }
    }
    class fT {
        constructor() {
            this.j = new Map;
            this.I = !1;
            this.ga = this.H = this.F = this.Z = this.O = this.T = -1
        }
        contains(a) {
            return this.j.has(a)
        }
        set A(a) {
            this.T = a
        }
        get A() {
            return this.T
        }
        set C(a) {
            this.O = a
        }
        get C() {
            return this.O
        }
        set l(a) {
            this.I = a
        }
        get l() {
            return this.I
        }
        set B(a) {
            this.H = a
        }
        get B() {
            return this.H
        }
        set g(a) {
            this.Z = a
        }
        get g() {
            return this.Z
        }
        set i(a) {
            this.F = a
        }
        get i() {
            return this.F
        }
        set G(a) {
            this.ga = a
        }
        get G() {
            return this.ga
        }
        get pa() {
            return this.j.values()
        }
    }
    var gT = class {
        constructor(a, b, c) {
            this.j = a;
            this.i = b;
            this.B = c
        }
        get l() {
            return this.j
        }
        get A() {
            return this.i
        }
        get g() {
            return this.B
        }
        get length() {
            return this.i - this.j
        }
    };
    const hT = ["block", "inline", "inline-block", "list-item", "table-cell"];
    async function iT(a, b, c, d, e) {
        d.g.za(5) >= d.i && await FR(d, 6);
        if (!c.J.Ae) {
            const f = D(c.aa, vR, 15);
            f.length && jT(a, b, c, e, f)
        }
        c.J.Be || await kT(a, c, d, e)
    }

    function jT(a, b, c, d, e) {
        c.J.Fe && !BS(a, c.J, lT(a, c)) ? lS(c, 898, a, () => {
            mT(a, b, c, d, e)
        }, c.J.fe) : mT(a, b, c, d, e)
    }

    function nT(a, b, c, d) {
        var e = !0;
        const f = b.ua;
        let g = gD({
            K: a,
            Te: 3E3,
            We: 400,
            ua: f,
            Vh: !b.J.sb
        });
        b.J.sb && !c && (g |= 16777216);
        if (c = g) e = d.g = d.g ? ? new un, Q(e, 2, c), e = !1;
        0 !== b.Ce || 0 !== oT(a, 1, f) || b.sa && 0 === oT(a, 2, f) || (Wi(d.g = d.g ? ? new un, 3, !0), e = !1);
        return e
    }

    function oT(a, b, c) {
        return gD({
            K: a,
            Te: 3E3,
            We: a.innerWidth > to ? 650 : 0,
            ua: c,
            Rf: b
        })
    }
    async function kT(a, b, c, d) {
        var e = D(b.aa, vR, 15);
        var f = new eT(b.g);
        for (var g of e)
            if (O(g, 3)) {
                e = P(g, 1);
                var h = f.i.has(e) ? f.i.get(e) : f.l++;
                f.i.set(e, h);
                f.A.set(h, e);
                var k = 0;
                for (var l = 0; l < e.length; l++) {
                    const n = e.charCodeAt(l);
                    f.g[k].contains(n) || (f.g.push(new fT), f.g[f.size].A = k, f.g[f.size].C = n, f.g[k].j.set(n, f.size), f.size++);
                    k = f.g[k].j.get(n)
                }
                f.g[k].l = !0;
                f.g[k].B = h;
                f.g[k].G = f.j.length;
                f.j.push(e.length)
            }
        g = [];
        for (g.push(0); 0 < g.length;) {
            h = g.shift();
            e = f;
            k = e.g[h];
            if (0 === h) k.g = 0, k.i = 0;
            else if (0 === k.A) k.g =
                0, k.i = k.l ? h : e.g[e.g[h].g].i;
            else {
                k = e.g[e.g[h].A].g;
                for (l = e.g[h].C;;) {
                    if (e.g[k].contains(l)) {
                        e.g[h].g = e.g[k].j.get(l);
                        break
                    }
                    if (0 === k) {
                        e.g[h].g = 0;
                        break
                    }
                    k = e.g[k].g
                }
                e.g[h].i = e.g[h].l ? h : e.g[e.g[h].g].i
            }
            for (var m of f.g[h].pa) g.push(m)
        }
        f = new dT(f);
        f.isEmpty() || (m = b.J.ef ? pT(D(b.aa, vR, 15)) : null, await b.Pa(898, qT(a, b, c, d, f, m, new OR(b.Za.Ej, b.Za.jf, b.Za.he, b.Za.Vb))))
    }

    function pT(a) {
        return RegExp(a.filter(b => O(b, 3)).map(b => P(b, 1).replace(/[/\\^$*+?.()|[\]{}]/g, "\\$&")).join("|"), "u")
    }
    async function qT(a, b, c, d, e, f, g) {
        var h = new dS;
        let k = a.document.body;
        if (O(b.aa, 17) || C(b.aa, gr, 21))
            for (; k;) {
                c.g.za(7) >= c.i && await FR(c, 8);
                if (k.nodeType === Node.TEXT_NODE && "" !== k.textContent && k.parentElement) {
                    const Kb = k.parentElement;
                    a: {
                        var l = a,
                            m = b,
                            n = Kb,
                            p = k.textContent,
                            q = d,
                            x = e,
                            z = g;
                        const wb = [];b: {
                            var G = p;
                            switch (m.g) {
                                case 1:
                                    var E = G;
                                    const xb = Array(E.length);
                                    let Ga = 0;
                                    for (let Lb = 0; Lb < E.length; Lb++) bT.test(E[Lb]) || Ga++, xb[Lb] = Ga;
                                    var K = xb;
                                    break b;
                                default:
                                    var H = G;
                                    const cb = Array(H.length);
                                    let nb = 0,
                                        Qa = 0;
                                    for (; Qa <
                                        H.length;) {
                                        for (;
                                            /\s/.test(H[Qa]);) cb[Qa] = nb, Qa++;
                                        let Lb = !1;
                                        for (; Qa < H.length && !/\s/.test(H[Qa]);) Lb = !0, cb[Qa] = nb, Qa++;
                                        Lb && (nb++, cb[Qa - 1] = nb)
                                    }
                                    K = cb
                            }
                        }
                        const mb = K;
                        if (p.includes("\u00bb")) var N = [];
                        else {
                            const xb = x.match(p),
                                Ga = new Map;
                            for (const cb of xb) {
                                const nb = cb.l;
                                if (Ga.has(nb)) {
                                    const Qa = Ga.get(nb);
                                    cb.length > Qa.length && Ga.set(nb, cb)
                                } else Ga.set(nb, cb)
                            }
                            N = Array.from(Ga.values())
                        }
                        const Ii = N;
                        let Ie = -1;
                        for (const xb of Ii) {
                            const Ga = xb.l,
                                cb = xb.A;
                            var J = z,
                                Ea = xb.g;
                            PR(J.g, J.i + mb[Ga]);
                            var Ya = J,
                                Eb = Ya.g,
                                ba = Ea;
                            if (!((Eb.g.has(ba) ?
                                    Eb.g.get(ba).length : 0) < Ya.jf && J.g.j < J.he)) continue;
                            const nb = l.getComputedStyle(n),
                                Qa = nb.fontSize.match(/\d+/);
                            if (!(Qa && 12 <= Number(Qa[0]) && 22 >= Number(Qa[0]) && db(hT, nb.display))) {
                                z.i += mb[mb.length - 1];
                                var tb = [];
                                break a
                            }
                            const Lb = Ie + 1;
                            Lb < Ga && wb.push(l.document.createTextNode(p.substring(Lb, Ga)));
                            const Ki = p.substring(Ga, cb + 1);
                            var rc = p,
                                sc = Ga,
                                Sd = cb + 1,
                                aa = l,
                                tc = n,
                                Lm = Ki,
                                Mm = rc.substring(Math.max(sc - 30, 0), sc) + "~~" + rc.substring(Sd, Math.min(Sd + 30, rc.length)),
                                Nm = xb.g,
                                Om = mb[Ga];
                            const Li = tc.getBoundingClientRect();
                            var Pm = sn(2);
                            var Qm = aj(Pm, 2, Lm);
                            var Rm = aj(Qm, 3, Mm);
                            var Sm = aj(Rm, 4, Nm);
                            var Tm = Yi(Sm, 5, Om);
                            var Um = Yi(Tm, 6, Math.round(Li.x));
                            var Vm = Yi(Um, 7, Math.round(Li.y));
                            const Nc = aa.getComputedStyle(tc);
                            var Wm = new rn;
                            var Xm = aj(Wm, 1, Nc.fontFamily);
                            var Ym = AS(Nc.color);
                            var Zm = F(Xm, 7, Ym);
                            var $m = AS(Nc.backgroundColor);
                            var an = F(Zm, 8, $m);
                            const Mi = Nc.fontSize.match(/^(\d+(\.\d+)?)px$/);
                            var $f = Yi(an, 4, Mi ? Math.round(Number(Mi[1])) : 0);
                            const ig = Math.round(Number(Nc.fontWeight));
                            isNaN(ig) || 400 === ig || Yi($f, 5, ig);
                            "none" !== Nc.textDecorationLine &&
                                aj($f, 6, Nc.textDecorationLine);
                            var Ai = F(Vm, 8, $f);
                            const jg = [];
                            let Td = tc;
                            for (; Td && 20 > jg.length;) {
                                var Bi = jg,
                                    Ci = Bi.push,
                                    Fe = Td,
                                    Di = new pn;
                                const Ni = aj(Di, 1, Fe.tagName);
                                "" !== Fe.className && ki(Ni, 2, Fe.className.split(" "), th);
                                Ci.call(Bi, Ni);
                                if ("BODY" === Td.tagName) break;
                                Td = Td.parentElement
                            }
                            var Ei = jg.reverse();
                            var bn = si(Ai, 9, Ei);
                            const en = CR(q, bn);
                            wb.push(rT(l, m, en, xb.g, Ki, n));
                            var Ge = z.g,
                                He = xb.g,
                                Fi = z.i + mb[Ga];
                            let kg = [];
                            Ge.g.has(He) && (kg = Ge.g.get(He));
                            kg.push(Fi);
                            Ge.i++;
                            Ge.g.set(He, kg);
                            Ie = cb;
                            if (0 < z.Vb && z.g.j >=
                                z.Vb) break
                        }
                        const Je = Ie + 1;0 !== Je && Je < p.length && wb.push(l.document.createTextNode(p.substring(Je)));z.i += mb[mb.length - 1];tb = wb
                    }
                    const uc = tb;
                    if (0 < uc.length && !O(b.aa, 17)) {
                        bS(h, a, b.Za.Zf ? BR(a, b.Za.Zf) : void 0, P(b.aa, 3), C(b.aa, gr, 21).i(), b.ba);
                        for (const wb of uc) Kb.insertBefore(wb, k), sT(wb);
                        Kb.removeChild(k);
                        for (k = uc[uc.length - 1]; k.lastChild;) k = k.lastChild;
                        if (0 < g.Vb && g.g.j >= g.Vb) break
                    }
                }
                a: {
                    var Wa = k,
                        cg = f,
                        Gi = g,
                        Hi = b.g;
                    if (Wa.firstChild && (Wa.nodeType !== Node.ELEMENT_NODE ? 0 : !Wa.classList ? .contains("google-anno-skip") &&
                            Wa.offsetHeight)) {
                        b: {
                            switch (Wa.tagName ? .toUpperCase ? .()) {
                                case "IFRAME":
                                case "A":
                                case "AUDIO":
                                case "BUTTON":
                                case "CANVAS":
                                case "CITE":
                                case "CODE":
                                case "EMBED":
                                case "FOOTER":
                                case "FORM":
                                case "KBD":
                                case "LABEL":
                                case "OBJECT":
                                case "PRE":
                                case "SAMP":
                                case "SCRIPT":
                                case "SELECT":
                                case "STYLE":
                                case "SUB":
                                case "SUPER":
                                case "SVG":
                                case "TEXTAREA":
                                case "TIME":
                                case "VAR":
                                case "VIDEO":
                                case null:
                                    var dg = !1;
                                    break b
                            }
                            dg = !(Wa.className.toUpperCase ? .() ? .includes("CRUMB") || Wa.id.toUpperCase ? .() ? .includes("CRUMB")) && (!cg ||
                                2 > (Wa.parentNode ? .childElementCount ? ? 0) || !!Wa.textContent ? .match(cg))
                        }
                        if (dg) {
                            k = Wa.firstChild;
                            break a
                        }
                        if (Wa.textContent ? .length) {
                            var eg = Gi;
                            b: {
                                var fg = Wa.textContent;
                                switch (Hi) {
                                    case 1:
                                        var gg = fg;
                                        let uc = 0;
                                        for (let mb = gg.length - 1; 0 <= mb; mb--) bT.test(gg[mb]) || uc++;
                                        var hg = uc;
                                        break b;
                                    default:
                                        const wb = fg.trim();
                                        hg = "" === wb ? 0 : wb.split(/\s+/).length
                                }
                            }
                            PR(eg.g, eg.i + hg)
                        }
                    }
                    let Kb = Wa;
                    for (;;) {
                        if (Kb.nextSibling) {
                            k = Kb.nextSibling;
                            break a
                        }
                        if (!Kb.parentNode) {
                            k = null;
                            break a
                        }
                        Kb = Kb.parentNode
                    }
                }
            }
    }

    function lT(a, b) {
        return {
            la: b.la(),
            sa: b.sa,
            R: wo(a),
            U: T(a),
            Pc: b.J.Pc,
            Fc: b.J.Fc
        }
    }

    function mT(a, b, c, d, e) {
        e = e.filter(g => O(g, 4) || 0 < bi(g, 5, vh, 3, void 0, !0).length).map(g => P(g, 1));
        if (0 !== e.length) {
            var f = c.J.sb ? BS(a, c.J, lT(a, c)) : null;
            nT(a, c, f, d) && (c.J.ff && rb(e), aT(b, e, d, new ZS(a, c, f)))
        }
    }

    function sT(a) {
        if (a.nodeType === Node.ELEMENT_NODE) {
            if ("A" === a.tagName) {
                var b = MR(KR(getComputedStyle(a.parentElement).color)),
                    c = MR(KR(getComputedStyle(a).color));
                var d = LR(a);
                if (d = b && c && d ? QL(c, d) < Math.min(QL(b, d), 2.5) ? b : null : b) {
                    b = d[0];
                    c = d[1];
                    d = d[2];
                    b = Number(b);
                    c = Number(c);
                    d = Number(d);
                    if (b != (b & 255) || c != (c & 255) || d != (d & 255)) throw Error('"(' + b + "," + c + "," + d + '") is not a valid RGB color');
                    c = b << 16 | c << 8 | d;
                    b = 16 > b ? "#" + (16777216 | c).toString(16).slice(1) : "#" + c.toString(16);
                    A(a, {
                        color: b
                    })
                }
            }
            for (b = 0; b < a.childElementCount; b++) sT(a.children[b])
        }
    }
    class tT {
        constructor() {
            this.g = null
        }
        get i() {
            return this.g
        }
    }

    function rT(a, b, c, d, e, f) {
        const g = a.document.createElement("SPAN");
        QR(g);
        A(g, {
            "text-decoration": "underline"
        });
        A(g, {
            "text-decoration-style": "dotted"
        });
        A(g, {
            "-webkit-text-decoration-line": "underline",
            "-webkit-text-decoration-style": "dotted"
        });
        g.appendChild(a.document.createTextNode(e));
        e = a.document.createElement("A");
        QR(e);
        A(e, {
            "text-decoration": "none",
            fill: "currentColor"
        });
        Ke(e);
        e.className = "google-anno";
        e.appendChild(RR(a.document, a.getComputedStyle(f).fontSize));
        e.appendChild(a.document.createTextNode("\u00a0"));
        e.appendChild(g);
        const h = uT(b, c, e);
        NS(b, 999, e, k => {
            try {
                var l = b.ba,
                    m = new zn;
                var n = aj(m, 4, d);
                var p = Zi(n, 1, c);
                var q = Zi(p, 2, h.i);
                const x = VS(l, q);
                oS(a, b, x, d, !0, b.A.get(d) || "");
                return !1
            } finally {
                k.preventDefault(), k.stopImmediatePropagation()
            }
        });
        return e
    }

    function uT(a, b, c) {
        const d = new tT;
        vT(a, e => {
            for (const k of e)
                if (k.isIntersecting) {
                    var f = b;
                    e = a.ba;
                    var g = new Dn;
                    g = f = Q(g, 1, f);
                    f = e.handle;
                    var h = cS(e, 11);
                    g = I(h, 4, Jn, g);
                    e = f.call(e, g);
                    d.g = e
                } else d.g && (e = a.ba, f = new Cn, g = f = Q(f, 1, d.g), f = e.handle, h = cS(e, 12), g = I(h, 5, Jn, g), f.call(e, g), d.g = null)
        }).observe(c);
        return d
    };

    function mS(a, b) {
        var c = a.handle,
            d = cS(a, 15);
        b = I(d, 9, Jn, b);
        c.call(a, b)
    }

    function VS(a, b) {
        var c = a.handle,
            d = cS(a, 10);
        b = I(d, 8, Jn, b);
        return c.call(a, b)
    }

    function cS(a, b) {
        var c = new In;
        var d = a.A++;
        c = Q(c, 1, d);
        b = Q(c, 2, Math.round(a.g.za(b) - a.i));
        return F(b, 10, a.j)
    }
    var wT = class {
        constructor(a, b, c, d) {
            this.g = a;
            this.i = b;
            this.j = c;
            this.A = 1;
            this.l = [...d]
        }
        handle(a) {
            for (const b of this.l) b(a);
            return Qi(a, 1)
        }
    };

    function lS(a, b, c, d, e) {
        c.setTimeout(xT(a, b, d), e)
    }

    function vS(a, b, c) {
        a = xT(a, 999, c);
        b.addEventListener("message", a);
        return a
    }

    function yS(a, b, c) {
        return b.setInterval(xT(a, 1066, c), 1E3)
    }

    function NS(a, b, c, d) {
        c.addEventListener("click", xT(a, b, d))
    }

    function vT(a, b) {
        return new IntersectionObserver(xT(a, 1065, b), {
            threshold: .98
        })
    }

    function xT(a, b, c) {
        return a.j.Oa(b, c, void 0, d => void yT(a, d))
    }

    function yT(a, b) {
        b.es = a.J.Wb.join(",");
        b.c = `${a.C}`
    }
    var AT = class {
        constructor(a, b, c, d, e, f, g, h, k, l, m, n, p = !1) {
            this.i = a;
            this.sa = b;
            this.Ce = c;
            this.aa = d;
            this.C = e;
            this.j = f;
            this.ba = g;
            this.ua = h;
            this.B = k;
            this.Za = l;
            this.de = m;
            this.ce = p;
            this.J = new zR(n);
            this.g = db(zT, P(d, 7)) ? 1 : 0;
            this.A = new Map;
            this.l = new Map;
            this.Me = new Map;
            for (const q of D(this.aa, vR, 15)) null != L(q, 6) && this.A.set(P(q, 1), P(q, 6)), null != L(q, 7) && this.l.set(P(q, 1), P(q, 7)), null != M(q, 10) && this.Me.set(P(q, 1), Ri(q, 10))
        }
        Pa(a, b) {
            this.j.Pa(a, b, c => void yT(this, c));
            return b
        }
        za(a) {
            return this.B.za(a)
        }
        la() {
            return 2 ===
                Ri(this.aa, 12)
        }
        Ie() {
            return this.aa.Ie()
        }
        Je() {
            return this.aa.Je()
        }
        vd() {
            return this.aa.vd()
        }
    };
    const zT = ["ja", "zh_CN", "zh_TW"];

    function BT(a, b) {
        return null == b ? `&${a}=null` : `&${a}=${Math.floor(b)}`
    }

    function CT(a, b) {
        return `&${a}=${b.toFixed(3)}`
    }

    function DT() {
        const a = new Set,
            b = FB();
        try {
            if (!b) return a;
            const c = b.pubads();
            for (const d of c.getSlots()) a.add(d.getSlotId().getDomId())
        } catch {}
        return a
    }

    function ET(a) {
        a = a.id;
        return null != a && (DT().has(a) || a.startsWith("google_ads_iframe_") || a.startsWith("aswift"))
    }

    function FT(a, b, c) {
        if (!a.sources) return !1;
        switch (GT(a)) {
            case 2:
                const d = HT(a);
                if (d) return c.some(f => IT(d, f));
                break;
            case 1:
                const e = JT(a);
                if (e) return b.some(f => IT(e, f))
        }
        return !1
    }

    function GT(a) {
        if (!a.sources) return 0;
        a = a.sources.filter(b => b.previousRect && b.currentRect);
        if (1 <= a.length) {
            a = a[0];
            if (a.previousRect.top < a.currentRect.top) return 2;
            if (a.previousRect.top > a.currentRect.top) return 1
        }
        return 0
    }

    function JT(a) {
        return KT(a, b => b.currentRect)
    }

    function HT(a) {
        return KT(a, b => b.previousRect)
    }

    function KT(a, b) {
        return a.sources.reduce((c, d) => {
            d = b(d);
            return c ? d && 0 !== d.width * d.height ? d.top < c.top ? d : c : c : d
        }, null)
    }

    function IT(a, b) {
        const c = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        a = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        return 0 >= c || 0 >= a ? !1 : 50 <= 100 * c * a / ((b.right - b.left) * (b.bottom - b.top))
    }

    function LT() {
        const a = Array.from(document.getElementsByTagName("iframe")).filter(ET),
            b = [...DT()].map(c => document.getElementById(c)).filter(c => null !== c);
        MT = window.scrollX;
        NT = window.scrollY;
        return OT = [...a, ...b].map(c => c.getBoundingClientRect())
    }

    function PT(a, b) {
        const c = MT !== window.scrollX || NT !== window.scrollY ? [] : OT,
            d = LT();
        for (const e of b.getEntries()) switch (b = e.entryType, b) {
            case "layout-shift":
                QT(a, e, c, d);
                break;
            case "largest-contentful-paint":
                b = e;
                a.Db = Math.floor(b.renderTime || b.loadTime);
                a.Va = b.size;
                break;
            case "first-input":
                b = e;
                a.va = Number((b.processingStart - b.startTime).toFixed(3));
                a.Ha = !0;
                a.g.some(f => f.entries.some(g => e.duration === g.duration && e.startTime === g.startTime)) || RT(a, e);
                break;
            case "longtask":
                b = Math.max(0, e.duration - 50);
                a.C +=
                    b;
                a.H = Math.max(a.H, b);
                a.Z += 1;
                break;
            case "event":
                RT(a, e);
                break;
            default:
                Pe(b, void 0)
        }
    }

    function ST(a) {
        a.A || (a.A = new PerformanceObserver(Cv(640, b => {
            PT(a, b)
        })));
        return a.A
    }

    function TT(a) {
        const b = Cv(641, () => {
                2 === JM(document) && UT(a)
            }),
            c = Cv(641, () => void UT(a));
        document.addEventListener("visibilitychange", b);
        document.addEventListener("pagehide", c);
        a.pa = () => {
            document.removeEventListener("visibilitychange", b);
            document.removeEventListener("pagehide", c);
            ST(a).disconnect()
        }
    }

    function UT(a) {
        if (!a.yf) {
            a.yf = !0;
            ST(a).takeRecords();
            var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=plmetrics";
            window.LayoutShift && (b += CT("cls", a.G), b += CT("mls", a.I), b += BT("nls", a.T), window.LayoutShiftAttribution && (b += CT("cas", a.B), b += BT("nas", a.Sc), b += CT("was", a.Pf)), b += CT("wls", a.ga), b += CT("tls", a.Nf));
            window.LargestContentfulPaint && (b += BT("lcp", a.Db), b += BT("lcps", a.Va));
            window.PerformanceEventTiming && a.Ha && (b += BT("fid", a.va));
            window.PerformanceLongTaskTiming && (b += BT("cbt", a.C),
                b += BT("mbt", a.H), b += BT("nlt", a.Z));
            let d = 0;
            for (var c of document.getElementsByTagName("iframe")) ET(c) && d++;
            b += BT("nif", d);
            b += BT("ifi", Qk(window));
            c = fo();
            b += `&${"eid"}=${encodeURIComponent(c.join())}`;
            b += `&${"top"}=${r===r.top?1:0}`;
            b += a.Af ? `&${"qqid"}=${encodeURIComponent(a.Af)}` : BT("pvsid", Bf(r));
            window.googletag && (b += "&gpt=1");
            c = Math.min(a.g.length - 1, Math.floor((a.A ? a.Ra : performance.interactionCount || 0) / 50));
            0 <= c && (c = a.g[c].latency, 0 <= c && (b += BT("inp", c)));
            window.fetch(b, {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            });
            a.pa()
        }
    }

    function QT(a, b, c, d) {
        if (!b.hadRecentInput) {
            a.G += Number(b.value);
            Number(b.value) > a.I && (a.I = Number(b.value));
            a.T += 1;
            if (c = FT(b, c, d)) a.B += b.value, a.Sc++;
            if (5E3 < b.startTime - a.Rc || 1E3 < b.startTime - a.zf) a.Rc = b.startTime, a.i = 0, a.j = 0;
            a.zf = b.startTime;
            a.i += b.value;
            c && (a.j += b.value);
            a.i > a.ga && (a.ga = a.i, a.Pf = a.j, a.Nf = b.startTime + b.duration)
        }
    }

    function RT(a, b) {
        VT(a, b);
        const c = a.g[a.g.length - 1],
            d = a.F[b.interactionId];
        if (d || 10 > a.g.length || b.duration > c.latency) d ? (d.entries.push(b), d.latency = Math.max(d.latency, b.duration)) : (b = {
            id: b.interactionId,
            latency: b.duration,
            entries: [b]
        }, a.F[b.id] = b, a.g.push(b)), a.g.sort((e, f) => f.latency - e.latency), a.g.splice(10).forEach(e => {
            delete a.F[e.id]
        })
    }

    function VT(a, b) {
        b.interactionId && (a.O = Math.min(a.O, b.interactionId), a.l = Math.max(a.l, b.interactionId), a.Ra = a.l ? (a.l - a.O) / 7 + 1 : 0)
    }
    var WT = class {
            constructor() {
                this.j = this.i = this.T = this.I = this.G = 0;
                this.zf = this.Rc = Number.NEGATIVE_INFINITY;
                this.g = [];
                this.F = {};
                this.Ra = 0;
                this.O = Infinity;
                this.va = this.Va = this.Db = this.Sc = this.Pf = this.B = this.Nf = this.ga = this.l = 0;
                this.Ha = !1;
                this.Z = this.H = this.C = 0;
                this.A = null;
                this.yf = !1;
                this.pa = () => {};
                const a = document.querySelector("[data-google-query-id]");
                this.Af = a ? a.getAttribute("data-google-query-id") : null;
                this.ei = {
                    ai: !1
                }
            }
            observe() {
                var a = window;
                if (!a.google_plmetrics && window.PerformanceObserver) {
                    a.google_plmetrics = !0;
                    a = ["layout-shift", "largest-contentful-paint", "first-input", "longtask"];
                    this.ei.ai && a.push("event");
                    for (const b of a) a = {
                        type: b,
                        buffered: !0
                    }, "event" === b && (a.durationThreshold = 40), ST(this).observe(a);
                    TT(this)
                }
            }
        },
        MT, NT, OT = [];
    async function XT(a, b, c, d, e, f, g, h) {
        var k = Wz,
            l = Vz;
        const m = ((h = hM(new lM(a), "__gads", h)) ? bf(h + "t2Z7mVic") % 20 : null) ? ? Math.floor(20 * Ze());
        c.J.Sg || YT(c.J.bf, k);
        var n = f.za(0);
        h = 488 > wo(a);
        const p = c.aa;
        var q = c.J,
            x = An(m);
        q = ki(x, 3, q.Wb, kh);
        e = new wT(f, n, q, e);
        k = new AT(d, h, c.Ce, p, m, k, e, l, f, c.Za, c.de, c.J, c.ce);
        d = new ER;
        b = await ZT(a, a.document, b, k, g, d);
        f = f.za(9) - n;
        k = c.J;
        if (!k.pf && !O(p, 17) && d.entries.length && !O(p, 13)) {
            g = a.document;
            n = g.createElement("LINK");
            a: {
                k = k.Qc ? sj `https://cse.google.com/cse.js?cx=${P(p,16)}&language=${P(p, 
7)}` : sj `https://www.google.com/adsense/search/ads.js`;
                if (k instanceof Zc) n.href = bd(k).toString();
                else {
                    if (-1 === Qe.indexOf("prefetch")) throw Error('TrustedResourceUrl href attribute required with rel="prefetch"');
                    k = k instanceof id ? jd(k) : Ee(k);
                    if (void 0 === k) break a;
                    n.href = k
                }
                n.rel = "prefetch"
            }
            n.as = "script";
            n.fetchPriority = "low";
            g.head.appendChild(n)
        }
        c = DR(d, h, c.hd, a.location.hostname, c.Di, p, f, b);
        a = e.handle;
        h = cS(e, 9);
        c = I(h, 3, Jn, c);
        a.call(e, c)
    }
    async function ZT(a, b, c, d, e, f) {
        b = b.body;
        if (!b || !$T(b)) return [Gm()];
        e.g.za(3) >= e.i && await FR(e, 4);
        b = (b = P(d.aa, 7)) ? (b = b.match(/^[a-z]{2,3}/i)) ? b[0].toLowerCase() : "" : "";
        f.i = b;
        b = [];
        if (a.document.querySelector('script[src*="www.google.com/adsense/search/ads.js"]')) {
            var g = b.push;
            var h = new Hm;
            var k = new Fm;
            h = I(h, 3, Im, k);
            g.call(b, h)
        }
        b.length || await iT(a, c, d, e, f);
        return b
    }

    function $T(a) {
        try {
            Vb(new ResizeObserver(() => {})), Vb(new MutationObserver(() => {}))
        } catch {
            return !1
        }
        return a.classList && void 0 !== a.classList.contains && void 0 !== a.attachShadow
    }

    function YT(a, b) {
        if (Math.random() < a) try {
            (new WT).observe()
        } catch (c) {
            b.Ba(1161, c instanceof Error ? c : Error("Unknown error."))
        }
    };
    async function aU(a, b, c, d, e, f, g) {
        if (v(wu) && (YT(w(ku), Wz), d.push(async () => {
                delete window.google_plmetrics
            }), v(pu))) return;
        a = a ? await bU(a, b, c, d, e, f, g) : await cU(b, c, d, e, f, g);
        a.Ca.length && dU(b, c, g, a)
    }
    async function cU(a, b, c, d, e, f) {
        if ("string" !== typeof d) return {
            Ga: null,
            Ca: [mn()]
        };
        d = yR(d);
        const g = pi(d);
        if (!a) return {
            Ga: g,
            Ca: [kn()]
        };
        const h = a.performance ? .now ? new HR(a.performance) : new IR,
            k = new GR(a, h),
            l = b.google_ad_client;
        if ("string" !== typeof l) return {
            Ga: g,
            Ca: [ln()]
        };
        if (vc()) return {
            Ga: g,
            Ca: [Gm()]
        };
        if (df()) return {
            Ga: g,
            Ca: [nn()]
        };
        await eU(a, c, u(yJ), AR(a, d, fU(b), f, "on" === b.google_adtest), l, h, k, e);
        return {
            Ga: g,
            Ca: []
        }
    }
    async function bU(a, b, c, d, e, f, g) {
        const h = a.performance ? .now ? new HR(a.performance) : new IR;
        a = new GR(a, h);
        if ("string" !== typeof e) return {
            Ga: null,
            Ca: [mn()]
        };
        e = yR(e);
        const k = pi(e);
        if (!b) return {
            Ga: k,
            Ca: [kn()]
        };
        const l = c.google_ad_client;
        if ("string" !== typeof l) return {
            Ga: k,
            Ca: [ln()]
        };
        if (vc()) return {
            Ga: k,
            Ca: [Gm()]
        };
        if (df()) return {
            Ga: k,
            Ca: [nn()]
        };
        await eU(b, d, u(yJ), AR(b, e, fU(c), g, "on" === c.google_adtest), l, h, a, f);
        return {
            Ga: k,
            Ca: []
        }
    }

    function dU(a, b, c, d) {
        a = DR(new ER, !!a && 488 > wo(a), fU(b), a ? .location ? .hostname ? ? "", c, d.Ga ? ? new qi, 0, d.Ca);
        c = Math.floor(20 * Ze());
        b = new In;
        b = Q(b, 1, 1);
        b = Q(b, 2, 0);
        c = An(c);
        d = fo();
        c = ki(c, 3, d, kh);
        b = F(b, 10, c);
        a = I(b, 3, Jn, a);
        b = u(yJ);
        Wz.Pa(1214, wJ(b, a, Date.now()), gU)
    }
    async function eU(a, b, c, d, e, f, g, h) {
        const k = Zv(a);
        k.wasReactiveAdConfigReceived[42] || (k.wasReactiveAdConfigReceived[42] = !0, await XT(a, b, d, e, [l => {
            Wz.Pa(1214, wJ(c, l, f.za(17)), gU)
        }], f, g, h))
    }

    function gU(a) {
        a.es = fo().join(",")
    }

    function fU(a) {
        a = a.google_page_url;
        return "string" === typeof a ? a : ""
    };

    function hU({
        Tf: a,
        fh: b
    }) {
        return a || ("dev" === b ? "dev" : "")
    };

    function iU(a) {
        Wz.lf(b => {
            b.shv = String(a);
            b.mjsv = hU({
                Tf: "m202401170101",
                fh: a
            });
            b.eid = tP(r)
        })
    };
    var jU = "undefined" === typeof sttc ? void 0 : sttc;

    function kU(a) {
        var b = Wz;
        try {
            return ej(a, ul), new SN(JSON.parse(a))
        } catch (c) {
            b.Ba(838, c instanceof Error ? c : Error(String(c)), void 0, d => {
                d.jspb = String(a)
            })
        }
        return new SN
    };
    const lU = (a, b) => {
            (0, a.__uspapi)("getUSPData", 1, (c, d) => {
                b.callback({
                    ob: c ? ? void 0,
                    md: d ? void 0 : 2
                })
            })
        },
        mU = {
            Ec: a => a.callback,
            Sb: (a, b) => ({
                __uspapiCall: {
                    callId: b,
                    command: "getUSPData",
                    version: 1
                }
            }),
            xb: (a, b) => {
                b = b.__uspapiReturn;
                a({
                    ob: b.returnValue ? ? void 0,
                    md: b.success ? void 0 : 2
                })
            }
        };

    function nU(a) {
        let b = {};
        "string" === typeof a.data ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            df: b.__uspapiReturn.callId
        }
    }

    function oU(a, b) {
        let c = {};
        if (bE(a.caller)) {
            var d = Nb(() => {
                b(c)
            });
            dE(a.caller, "getDataWithCallback", {
                callback: e => {
                    e.md || (c = e.ob);
                    d()
                }
            });
            setTimeout(d, a.timeoutMs)
        } else b(c)
    }
    var pU = class extends U {
        constructor(a) {
            super();
            this.timeoutMs = {}.timeoutMs ? ? 500;
            this.caller = new eE(a, "__uspapiLocator", b => "function" === typeof b.__uspapi, nU);
            this.caller.A.set("getDataWithCallback", lU);
            this.caller.j.set("getDataWithCallback", mU)
        }
        i() {
            this.caller.ma();
            super.i()
        }
    };

    function qU(a, b) {
        b = b && b[0];
        if (!b) return null;
        b = b.target;
        const c = b.getBoundingClientRect(),
            d = he(a.g.da() || window);
        if (0 >= c.bottom || c.bottom > d.height || 0 >= c.right || c.left >= d.width) return null;
        var e = rU(a, b, c, a.g.g.elementsFromPoint(Ud(c.left + c.width / 2, c.left, c.right - 1), Ud(c.bottom - 1 - 2, c.top, c.bottom - 1)), 1, []),
            f = rU(a, b, c, a.g.g.elementsFromPoint(Ud(c.left + c.width / 2, c.left, c.right - 1), Ud(c.top + 2, c.top, c.bottom - 1)), 2, e.qb),
            g = rU(a, b, c, a.g.g.elementsFromPoint(Ud(c.left + 2, c.left, c.right - 1), Ud(c.top + c.height / 2,
                c.top, c.bottom - 1)), 3, [...e.qb, ...f.qb]);
        const h = rU(a, b, c, a.g.g.elementsFromPoint(Ud(c.right - 1 - 2, c.left, c.right - 1), Ud(c.top + c.height / 2, c.top, c.bottom - 1)), 4, [...e.qb, ...f.qb, ...g.qb]);
        var k = sU(a, b, c),
            l = n => db(a.j, n.overlapType) && db(a.l, n.overlapDepth) && db(a.i, n.overlapDetectionPoint);
        e = Za([...e.entries, ...f.entries, ...g.entries, ...h.entries], l);
        l = Za(k, l);
        k = [...e, ...l];
        f = -2 > c.left || c.right > d.width + 2;
        f = 0 < k.length || f;
        g = ie(a.g.g);
        const m = new kk(c.left, c.top, c.width, c.height);
        e = [...$a(e, n => new kk(n.elementRect.left,
            n.elementRect.top, n.elementRect.width, n.elementRect.height)), ...qb($a(l, n => mk(m, n.elementRect))), ...Za(mk(m, new kk(0, 0, d.width, d.height)), n => 0 <= n.top && n.top + n.height <= d.height)];
        return {
            entries: k,
            isOverlappingOrOutsideViewport: f,
            scrollPosition: {
                scrollX: g.x,
                scrollY: g.y
            },
            target: b,
            targetRect: c,
            viewportSize: {
                width: d.width,
                height: d.height
            },
            overlappedArea: 20 > e.length ? tU(m, e) : uU(c, e)
        }
    }

    function vU(a, b) {
        const c = a.g.da(),
            d = a.g.g;
        return new Promise((e, f) => {
            const g = c.IntersectionObserver;
            if (g)
                if (d.elementsFromPoint)
                    if (d.createNodeIterator)
                        if (d.createRange)
                            if (c.Range.prototype.getBoundingClientRect) {
                                var h = new g(k => {
                                    const l = new jl,
                                        m = il(l, () => qU(a, k));
                                    m && (l.i.length && (m.executionTime = Math.round(Number(l.i[0].duration))), h.disconnect(), e(m))
                                }, wU);
                                h.observe(b)
                            } else f(Error("5"));
            else f(Error("4"));
            else f(Error("3"));
            else f(Error("2"));
            else f(Error("1"))
        })
    }

    function rU(a, b, c, d, e, f) {
        if (0 === c.width || 0 === c.height) return {
            entries: [],
            qb: []
        };
        const g = [],
            h = [];
        for (let m = 0; m < d.length; m++) {
            const n = d[m];
            if (n === b) continue;
            if (db(f, n)) continue;
            h.push(n);
            const p = n.getBoundingClientRect();
            if (a.g.contains(n, b)) {
                g.push(xU(a, c, n, p, 1, e));
                continue
            }
            if (a.g.contains(b, n)) {
                g.push(xU(a, c, n, p, 2, e));
                continue
            }
            a: {
                var k = a;
                var l = b;
                const z = k.g.xi(l, n);
                if (!z) {
                    k = null;
                    break a
                }
                const {
                    suspectAncestor: G,
                    Ib: E
                } = yU(k, l, z, n) || {},
                {
                    suspectAncestor: K,
                    Ib: H
                } = yU(k, n, z, l) || {};k = G && E && K && H ? E <= H ? {
                    suspectAncestor: G,
                    overlapType: zU[E]
                } : {
                    suspectAncestor: K,
                    overlapType: AU[H]
                } : G && E ? {
                    suspectAncestor: G,
                    overlapType: zU[E]
                } : K && H ? {
                    suspectAncestor: K,
                    overlapType: AU[H]
                } : null
            }
            const {
                suspectAncestor: q,
                overlapType: x
            } = k || {};
            q && x ? g.push(xU(a, c, n, p, x, e, q)) : g.push(xU(a, c, n, p, 9, e))
        }
        return {
            entries: g,
            qb: h
        }
    }

    function sU(a, b, c) {
        const d = [];
        for (b = b.parentElement; b; b = b.parentElement) {
            const f = b.getBoundingClientRect();
            if (f) {
                var e = Ye(b, a.g.da());
                e && "visible" !== e.overflow && ("auto" !== e.overflowY && "scroll" !== e.overflowY && c.bottom > f.bottom + 2 ? d.push(xU(a, c, b, f, 5, 1)) : (e = "auto" === e.overflowX || "scroll" === e.overflowX, !e && c.left < f.left - 2 ? d.push(xU(a, c, b, f, 5, 3)) : !e && c.right > f.right + 2 && d.push(xU(a, c, b, f, 5, 4))))
            }
        }
        return d
    }

    function tU(a, b) {
        if (0 === a.width || 0 === a.height || 0 === b.length) return 0;
        let c = 0;
        for (let d = 1; d < 1 << b.length; d++) {
            let e = a,
                f = 0;
            for (let g = 0; g < b.length && (!(d & 1 << g) || (f++, e = lk(e, b[g]), e)); g++);
            e && (c = 1 === f % 2 ? c + (e.width + 1) * (e.height + 1) : c - (e.width + 1) * (e.height + 1))
        }
        return c / ((a.width + 1) * (a.height + 1))
    }

    function uU(a, b) {
        if (0 === a.width || 0 === a.height || 0 === b.length) return 0;
        let c = 0;
        for (let d = a.left; d <= a.right; d++)
            for (let e = a.top; e <= a.bottom; e++)
                for (let f = 0; f < b.length; f++)
                    if (d >= b[f].left && d <= b[f].left + b[f].width && e >= b[f].top && e <= b[f].top + b[f].height) {
                        c++;
                        break
                    }
        return c / ((a.width + 1) * (a.height + 1))
    }

    function xU(a, b, c, d, e, f, g) {
        const h = {
            element: c,
            elementRect: d,
            overlapType: e,
            overlapDetectionPoint: f
        };
        if (db(a.j, e) && db(a.i, f)) {
            b = new hk(b.top, b.right - 1, b.bottom - 1, b.left);
            if ((a = BU(a, c)) && jk(b, a)) c = 4;
            else {
                a = CU(c, d);
                if (Ac) {
                    e = Hk(c, "paddingLeft");
                    f = Hk(c, "paddingRight");
                    var k = Hk(c, "paddingTop"),
                        l = Hk(c, "paddingBottom");
                    e = new hk(k, f, l, e)
                } else e = Ak(c, "paddingLeft"), f = Ak(c, "paddingRight"), k = Ak(c, "paddingTop"), l = Ak(c, "paddingBottom"), e = new hk(parseFloat(k), parseFloat(f), parseFloat(l), parseFloat(e));
                jk(b, new hk(a.top +
                    e.top, a.right - e.right, a.bottom - e.bottom, a.left + e.left)) ? c = 3 : (c = CU(c, d), c = jk(b, c) ? 2 : 1)
            }
            h.overlapDepth = c
        }
        g && (h.suspectAncestor = g);
        return h
    }

    function yU(a, b, c, d) {
        const e = [];
        for (var f = b; f && f !== c; f = f.parentElement) e.unshift(f);
        c = a.g.da();
        for (f = 0; f < e.length; f++) {
            const h = e[f];
            var g = Ye(h, c);
            if (g) {
                if ("fixed" === g.position) return {
                    suspectAncestor: h,
                    Ib: 1
                };
                if ("sticky" === g.position && a.g.contains(h.parentElement, d)) return {
                    suspectAncestor: h,
                    Ib: 2
                };
                if ("absolute" === g.position) return {
                    suspectAncestor: h,
                    Ib: 3
                };
                if ("none" !== g.cssFloat) {
                    g = h === e[0];
                    const k = DU(a, e.slice(0, f), h);
                    if (g || k) return {
                        suspectAncestor: h,
                        Ib: 4
                    }
                }
            }
        }
        return (a = DU(a, e, b)) ? {
                suspectAncestor: a,
                Ib: 5
            } :
            null
    }

    function DU(a, b, c) {
        const d = c.getBoundingClientRect();
        if (!d) return null;
        for (let e = 0; e < b.length; e++) {
            const f = b[e];
            if (!a.g.contains(f, c)) continue;
            const g = f.getBoundingClientRect();
            if (!g) continue;
            const h = Ye(f, a.g.da());
            if (h && d.bottom > g.bottom + 2 && "visible" === h.overflowY) return f
        }
        return null
    }

    function BU(a, b) {
        var c = a.g.g;
        a = c.createRange();
        if (!a) return null;
        c = c.createNodeIterator(b, NodeFilter.SHOW_TEXT, {
            acceptNode: d => /^[\s\xa0]*$/.test(d.nodeValue) ? NodeFilter.FILTER_SKIP : NodeFilter.FILTER_ACCEPT
        });
        for (b = c.nextNode(); c.nextNode(););
        c = c.previousNode();
        if (!b || !c) return null;
        a.setStartBefore(b);
        a.setEndAfter(c);
        a = a.getBoundingClientRect();
        return 0 === a.width || 0 === a.height ? null : new hk(a.top, a.right, a.bottom, a.left)
    }

    function CU(a, b) {
        if (!Ac || 9 <= Number(Oc)) {
            var c = Ak(a, "borderLeftWidth");
            d = Ak(a, "borderRightWidth");
            e = Ak(a, "borderTopWidth");
            a = Ak(a, "borderBottomWidth");
            c = new hk(parseFloat(e), parseFloat(d), parseFloat(a), parseFloat(c))
        } else {
            c = Jk(a, "borderLeft");
            var d = Jk(a, "borderRight"),
                e = Jk(a, "borderTop");
            a = Jk(a, "borderBottom");
            c = new hk(e, d, a, c)
        }
        return new hk(b.top + c.top, b.right - 1 - c.right, b.bottom - 1 - c.bottom, b.left + c.left)
    }
    class EU {
        constructor(a) {
            var b = FU;
            this.g = ee(a);
            this.j = [5, 8, 9];
            this.l = [3, 4];
            this.i = b
        }
    }
    const zU = {
            [1]: 3,
            [4]: 10,
            [3]: 12,
            [2]: 4,
            [5]: 5
        },
        AU = {
            [1]: 6,
            [4]: 11,
            [3]: 13,
            [2]: 7,
            [5]: 8
        };
    Za(af({
        Cl: 1,
        Dl: 2,
        sn: 3,
        un: 4,
        wn: 5,
        yl: 6,
        zl: 7,
        Bl: 8,
        Em: 9,
        vn: 10,
        Al: 11,
        rn: 12,
        xl: 13
    }), a => !db([1, 2], a));
    af({
        Kk: 1,
        Hm: 2,
        Vk: 3,
        xn: 4
    });
    const FU = af({
            Lk: 1,
            An: 2,
            rm: 3,
            en: 4
        }),
        wU = {
            threshold: [0, .25, .5, .75, .95, .96, .97, .98, .99, 1]
        };

    function GU(a, b, c, d) {
        const e = new aK;
        let f = "";
        const g = k => {
            try {
                const l = "object" === typeof k.data ? k.data : JSON.parse(k.data);
                f === l.paw_id && (Ub(a, "message", g), l.error ? e.g(Error(l.error)) : e.resolve(d(l)))
            } catch (l) {}
        };
        var h = "function" === typeof a.gmaSdk ? .getQueryInfo ? a.gmaSdk : void 0;
        if (h) return Tb(a, "message", g), f = c(h), e.promise;
        c = "function" === typeof a.webkit ? .messageHandlers ? .getGmaQueryInfo ? .postMessage || "function" === typeof a.webkit ? .messageHandlers ? .getGmaSig ? .postMessage ? a.webkit.messageHandlers : void 0;
        return c ? (f = String(Math.floor(2147483647 * Ze())), Tb(a, "message", g), b(c, f), e.promise) : null
    }

    function HU(a) {
        return GU(a, (b, c) => void(b.getGmaQueryInfo ? ? b.getGmaSig) ? .postMessage(c), b => b.getQueryInfo(), b => b.signal)
    };
    const IU = (a, b) => {
        try {
            const k = void 0 === O(b, 6) ? !0 : O(b, 6);
            var c = Fj(Ri(b, 2)),
                d = P(b, 3);
            a: switch (Ri(b, 4)) {
                case 1:
                    var e = "pt";
                    break a;
                case 2:
                    e = "cr";
                    break a;
                default:
                    e = ""
            }
            var f = new Hj(c, d, e),
                g = C(b, Aj, 5) ? .g() ? ? "";
            f.Bc = g;
            f.g = k;
            f.win = a;
            var h = f.build();
            yj(h)
        } catch {}
    };

    function JU(a, b) {
        a.goog_sdr_l || (Object.defineProperty(a, "goog_sdr_l", {
            value: !0
        }), "complete" === a.document.readyState ? IU(a, b) : Tb(a, "load", () => void IU(a, b)))
    };

    function KU(a) {
        const b = RegExp("^https?://[^/#?]+/?$");
        return !!a && !b.test(a)
    }

    function LU(a) {
        if (a === a.top || Se(a.top)) return Promise.resolve({
            status: 4
        });
        a: {
            try {
                var b = (a.top ? .frames ? ? {}).google_ads_top_frame;
                break a
            } catch (d) {}
            b = null
        }
        if (!b) return Promise.resolve({
            status: 2
        });
        if (a.parent === a.top && KU(a.document.referrer)) return Promise.resolve({
            status: 3
        });
        const c = new aK;
        a = new MessageChannel;
        a.port1.onmessage = d => {
            "__goog_top_url_resp" === d.data.msgType && c.resolve({
                tc: d.data.topUrl,
                status: d.data.topUrl ? 0 : 1
            })
        };
        b.postMessage({
            msgType: "__goog_top_url_req"
        }, "*", [a.port2]);
        return c.promise
    };
    var xl = {
        In: 0,
        En: 1,
        Fn: 9,
        Bn: 2,
        Cn: 3,
        Hn: 5,
        Gn: 7,
        Dn: 10
    };
    var MU = class extends S {},
        NU = hj(MU),
        OU = [1, 3];
    const PU = sj `https://securepubads.g.doubleclick.net/static/topics/topics_frame.html`;

    function QU(a) {
        const b = a.google_tag_topics_state ? ? (a.google_tag_topics_state = {});
        return b.messageChannelSendRequestFn ? Promise.resolve(b.messageChannelSendRequestFn) : new Promise(c => {
            function d(h) {
                return g.g(h).then(({
                    data: k
                }) => k)
            }
            const e = Xe("IFRAME");
            e.style.display = "none";
            e.name = "goog_topics_frame";
            e.src = bd(PU).toString();
            const f = (new URL(PU.toString())).origin,
                g = ZL({
                    destination: a,
                    Na: e,
                    origin: f,
                    me: "goog:gRpYw:doubleclick"
                });
            g.g("goog:topics:frame:handshake:ack").then(({
                data: h
            }) => {
                "goog:topics:frame:handshake:ack" ===
                h && c(d)
            });
            b.messageChannelSendRequestFn = d;
            a.document.documentElement.appendChild(e)
        })
    }

    function RU(a, b, c) {
        var d = Wz,
            e = {
                skipTopicsObservation: v(Ou)
            };
        const {
            cd: f,
            bd: g
        } = SU(c);
        b = b.google_tag_topics_state ? ? (b.google_tag_topics_state = {});
        b.getTopicsPromise || (a = a({
            message: "goog:topics:frame:get:topics",
            skipTopicsObservation: e.skipTopicsObservation,
            includeBuyerTopics: e.includeBuyerTopics
        }).then(h => {
            let k = g;
            if (h instanceof Uint8Array) k || (k = !(f instanceof Uint8Array && ob(h, f)));
            else if (wl()(h)) k || (k = h !== f);
            else return d.Ba(989, Error(JSON.stringify(h))), 7;
            if (k && c) try {
                var l = new MU;
                var m = Zi(l, 2, al());
                h instanceof Uint8Array ? mi(m, 1, OU, Mg(h, !1, !1)) : mi(m, 3, OU, eh(h));
                c.setItem("goog:cached:topics", bj(m))
            } catch {}
            return h
        }), b.getTopicsPromise = a);
        return f && !g ? Promise.resolve(f) : b.getTopicsPromise
    }

    function SU(a) {
        if (!a) return {
            cd: null,
            bd: !0
        };
        try {
            const m = a.getItem("goog:cached:topics");
            if (!m) return {
                cd: null,
                bd: !0
            };
            const n = NU(m);
            let p;
            const q = n.W;
            var b = ni(q, q[B], OU);
            switch (b) {
                case 0:
                    p = null;
                    break;
                case 1:
                    var c;
                    a = n;
                    var d = oi(n, OU, 1);
                    const z = a.W;
                    let G = z[B];
                    const E = Vh(z, G, d),
                        K = Mg(E, !0, !!(G & 34));
                    null != K && K !== E && Xh(z, G, d, K);
                    var e = K;
                    var f = null == e ? Yf() : e;
                    Xf(Vf);
                    var g = f.M;
                    if (null == g || Tf(g)) var h = g;
                    else {
                        if ("string" === typeof g) {
                            d = g;
                            Qf.test(d) && (d = d.replace(Qf, Sf));
                            let H;
                            H = atob(d);
                            const N = new Uint8Array(H.length);
                            for (d = 0; d < H.length; d++) N[d] = H.charCodeAt(d);
                            var k = N
                        } else k = null;
                        h = k
                    }
                    var l = h;
                    p = (c = null == l ? l : f.M = l) ? new Uint8Array(c) : Uf || (Uf = new Uint8Array(0));
                    break;
                case 3:
                    p = Ri(n, oi(n, OU, 3));
                    break;
                default:
                    Pe(b, void 0)
            }
            const x = Qi(n, 2) + 6048E5 < al();
            return {
                cd: p,
                bd: x
            }
        } catch {
            return {
                cd: null,
                bd: !0
            }
        }
    };

    function fJ() {
        return navigator.cookieDeprecationLabel ? Promise.race([navigator.cookieDeprecationLabel.getValue().then(a => ({
            status: 1,
            label: a
        })).catch(() => ({
            status: 2
        })), Df(w(Fu), {
            status: 5
        })]) : Promise.resolve({
            status: 3
        })
    }

    function TU(a) {
        return v(Gu) && a ? !!a.match(Yb(Eu)) : !1
    }

    function UU(a) {
        a = a.innerInsElement;
        if (!a) throw Error("no_wrapper_element_in_loader_provided_slot");
        return a
    }
    async function VU({
        Fa: a,
        ra: b,
        vb: c,
        slot: d
    }) {
        const e = d.vars,
            f = Ve(d.pubWin),
            g = UU(d),
            h = new JN({
                K: f,
                pubWin: d.pubWin,
                D: e,
                Fa: a,
                ra: b,
                vb: c,
                ia: g
            });
        h.G = Date.now();
        gk(1, [h.D]);
        Yz(1032, () => {
            if (f && v($u)) {
                var k = h.D;
                Z(UI(), 32, !1) || (ZI(UI(), 32, !0), CP(f, "sd" === k.google_loader_used ? 5 : 9))
            }
        });
        try {
            await WU(h)
        } catch (k) {
            if (!aA(159, k)) throw k;
        }
        Yz(639, () => {
            var k;
            var l = h.D;
            (k = h.K) && 1 === l.google_responsive_auto_format && !0 === l.google_full_width_responsive_allowed ? (l = (l = k.document.getElementById(l.google_async_iframe_id)) ? qe(l,
                "INS", "adsbygoogle") : null) ? (k = new IN(k, l), k.g = r.setInterval(Ja(k.i, k), 500), k.i(), k = !0) : k = !1 : k = !1;
            return k
        });
        f ? .location ? .hash ? .match(/\bgoog_cpmi=([^&]*)/) ? bA(1008, XU(d.pubWin, f, e, h.j, bj(YU()), h.i, P(a, 8)), gU) : rN(h.pubWin, "affa", k => {
            k = XU(d.pubWin, f, e, h.j, k.config, h.i, P(a, 8));
            Wz.Pa(1008, k, gU);
            return !0
        });
        return h
    }
    async function XU(a, b, c, d, e, f, g) {
        await aU(v(lu) ? a : null, b, c, d, e, f, g)
    }

    function YU() {
        const a = new xR;
        if (!v(ou)) {
            var b = new QN;
            b = Wi(b, 5, !0);
            F(a, 2, b)
        }
        if (!v(gu)) {
            b = new or;
            b = Wh(b, 2, eh(4));
            b = Wh(b, 8, eh(1));
            var c = new qq;
            c = $i(c, 7, "#dpId");
            b = F(b, 1, c);
            ti(a, 3, or, b)
        }
        return a
    }

    function WU(a) {
        if (/_sdo/.test(a.D.google_ad_format)) return Promise.resolve();
        var b = a.pubWin;
        rP(13, b);
        rP(11, b);
        b = UI();
        var c = Z(b, 23, !1);
        c || ZI(b, 23, !0);
        if (!c) {
            b = a.D.google_ad_client;
            c = a.Fa;
            b = void 0 !== Zh(c, QN, oi(c, TN, 13)) ? C(Si(c, QN, 13, TN), ZJ, 2) : ob(Si(c, RN, 14, TN) ? .g() ? ? [], [b]) ? C(C(Si(c, RN, 14, TN), QN, 2), ZJ, 2) : new ZJ;
            b = new $J(a.pubWin, a.D.google_ad_client, b, O(a.Fa, 6), O(a.Fa, 20));
            b.i = !0;
            c = C(b.B, pr, 1);
            if (b.i) {
                var d = b.g;
                if (b.j && !RD(c)) {
                    var e = new RJ;
                    e = Wh(e, 1, eh(1))
                } else e = null;
                if (e) {
                    e = bj(e);
                    try {
                        d.localStorage.setItem("google_auto_fc_cmp_setting",
                            e)
                    } catch (f) {}
                }
            }
            d = RD(c) && (b.j || b.A);
            c && d && SD(new TD(b.g, new zE(b.g, b.l), c, new gw(b.g)))
        }
        b = !ok() && !qc();
        return !b || b && !ZU(a) ? $U(a) : Promise.resolve()
    }

    function aV(a, b, c = !1) {
        b = gM(a.K, b);
        const d = sk() || cM(a.pubWin.top);
        if (!b || -12245933 === b.y || -12245933 === d.width || -12245933 === d.height || !d.height) return 0;
        let e = 0;
        try {
            const f = a.pubWin.top;
            e = eM(f.document, f).y
        } catch (f) {
            return 0
        }
        a = e + d.height;
        return b.y < e ? c ? 0 : (e - b.y) / d.height : b.y > a ? (b.y - a) / d.height : 0
    }

    function ZU(a) {
        return bV(a) || cV(a)
    }

    function bV(a) {
        const b = a.D;
        if (!b.google_pause_ad_requests) return !1;
        const c = r.setTimeout(() => {
                $z("abg:cmppar", {
                    client: a.D.google_ad_client,
                    url: a.D.google_page_url
                })
            }, 1E4),
            d = Zz(450, () => {
                b.google_pause_ad_requests = !1;
                r.clearTimeout(c);
                a.pubWin.removeEventListener("adsbygoogle-pub-unpause-ad-requests-event", d);
                ZU(a) || $U(a)
            });
        a.pubWin.addEventListener("adsbygoogle-pub-unpause-ad-requests-event", d);
        return !0
    }

    function cV(a) {
        const b = a.pubWin.document,
            c = a.ia;
        if (3 === JM(b)) return MM(Zz(332, () => {
            dV(a, eV().visible, c) || $U(a)
        }), b), !0;
        const d = eV();
        if (0 > d.hidden && 0 > d.visible) return !1;
        const e = KM(b);
        if (!e) return !1;
        if (!LM(b)) return dV(a, d.visible, c);
        if (aV(a, c) <= d.hidden) return !1;
        let f = Zz(332, () => {
            !LM(b) && f && (Ub(b, e, f), dV(a, d.visible, c) || $U(a), f = null)
        });
        return Tb(b, e, f)
    }

    function eV() {
        const a = {
            hidden: 0,
            visible: 3
        };
        r.IntersectionObserver || (a.visible = -1);
        ue() && (a.visible *= 2);
        return a
    }

    function dV(a, b, c) {
        if (!c || 0 > b) return !1;
        var d = a.D;
        if (!Co(d.google_reactive_ad_format) && (cN(d) || d.google_reactive_ads_config) || !fM(c) || aV(a, c) <= b) return !1;
        var e = UI(),
            f = Z(e, 8, {});
        e = Z(e, 9, {});
        d = d.google_ad_section || d.google_ad_region || "";
        const g = !!a.pubWin.google_apltlad;
        if (!f[d] && !e[d] && !g) return !1;
        f = new Promise(h => {
            const k = new r.IntersectionObserver((l, m) => {
                Va(l, n => {
                    0 >= n.intersectionRatio || (m.unobserve(n.target), h(void 0))
                })
            }, {
                rootMargin: `${100*b}%`
            });
            a.F = k;
            k.observe(c)
        });
        e = new Promise(h => {
            c.addEventListener("adsbygoogle-close-to-visible-event",
                () => {
                    h(void 0)
                })
        });
        ma(Promise, "any").call(Promise, [f, e]).then(() => {
            Yz(294, () => {
                $U(a)
            })
        });
        return !0
    }

    function $U(a) {
        Yz(326, () => {
            if (1 === Qk(a.D)) {
                var c = v(av),
                    d = c || v(Zu),
                    e = a.pubWin;
                if (d && e === a.K) {
                    var f = new Uj;
                    d = new Vj;
                    var g = f.setCorrelator(Bf(a.pubWin));
                    var h = tP(a.pubWin);
                    g = aj(g, 5, h);
                    R(g, 2, 1);
                    f = F(d, 1, f);
                    g = new Tj;
                    g = Wi(g, 10, !0);
                    h = v(Uu);
                    g = Wi(g, 8, h);
                    h = v(Vu);
                    g = Wi(g, 12, h);
                    h = v(Yu);
                    g = Wi(g, 7, h);
                    h = v(Xu);
                    g = Wi(g, 13, h);
                    F(f, 2, g);
                    e.google_rum_config = d.toJSON();
                    We(e.document, O(a.Fa, 9) && c ? a.ra.mj : a.ra.nj)
                } else hl(Xz)
            }
        });
        a.D.google_ad_channel = fV(a, a.D.google_ad_channel);
        a.D.google_tag_partner = gV(a, a.D.google_tag_partner);
        hV(a);
        const b = a.D.google_start_time;
        "number" === typeof b && (lo = b, a.D.google_start_time = null);
        bM(a);
        a.K && gN(a.K, $c(a.ra.gi, eK()));
        bJ() && pK({
            win: a.pubWin,
            webPropertyCode: a.D.google_ad_client,
            kb: $c(a.ra.kb, eK())
        });
        cN(a.D) && (nK() && (a.D.google_adtest = a.D.google_adtest || "on"), a.D.google_pgb_reactive = a.D.google_pgb_reactive || 3);
        return iV(a)
    }

    function fV(a, b) {
        return (b ? [b] : []).concat(PI(a.pubWin).ad_channels || []).join("+")
    }

    function gV(a, b) {
        return (b ? [b] : []).concat(PI(a.pubWin).tag_partners || []).join("+")
    }

    function jV(a) {
        const b = Xe("IFRAME");
        $e(a, (c, d) => {
            null != c && b.setAttribute(d, c)
        });
        return b
    }

    function kV(a, b, c) {
        return 9 === a.D.google_reactive_ad_format && qe(a.ia, null, "fsi_container") ? (a.ia.appendChild(b), Promise.resolve(b)) : nN(a.ra.Wg, 525, d => {
            a.ia.appendChild(b);
            d.createAdSlot(a.K, a.D, b, a.ia.parentElement, Xj(c, a.pubWin));
            return b
        })
    }

    function lV(a, b, c, d) {
        u(yJ).hd = a.D.google_page_url;
        JU(a.pubWin, Dj(Cj(R(R(Bj(new Ej, zj(new Aj, String(Bf(a.pubWin)))), 4, 1), 2, 1), P(a.Fa, 2)), O(d, 5)));
        const e = a.K;
        a.D.google_acr && a.D.google_acr(b);
        Tb(b, "load", () => {
            b && b.setAttribute("data-load-complete", !0);
            const f = e ? PI(e).enable_overlap_observer || !1 : !1;
            (a.D.ovlp || f) && e && e === a.pubWin && mV(e, a, a.ia, b)
        });
        d = f => {
            f && a.j.push(() => {
                f.ma()
            })
        };
        nV(a, b);
        oV(a, b);
        !e || cN(a.D) && !pN(a.D) || (d(new PO(e, b, a.ia)), d(new gO(a, b)), d(e.IntersectionObserver ? null : new iO(e, b, a.ia)));
        e && (d(aO(e, b, a.i)), a.j.push(CN(e, a.D)), u(HN).L(e), a.j.push(ON(e, a.ia, b)));
        b && b.setAttribute("data-google-container-id", c);
        c = a.D.iaaso;
        if (null != c) {
            d = a.ia;
            const f = d.parentElement;
            (f && qv.test(f.className) ? f : d).setAttribute("data-auto-ad-size", c)
        }
        c = a.ia;
        c.setAttribute("tabindex", "0");
        c.setAttribute("title", "Advertisement");
        c.setAttribute("aria-label", "Advertisement");
        pV(a)
    }

    function nV(a, b) {
        const c = a.pubWin,
            d = a.D.google_ad_client,
            e = aJ();
        let f = null;
        const g = qN(c, "pvt", (h, k) => {
            "string" === typeof h.token && k.source === b.contentWindow && (f = h.token, g(), e[d] = e[d] || [], e[d].push(f), 100 < e[d].length && e[d].shift())
        });
        a.j.push(g)
    }

    function qV(a, b) {
        var c = hM(a, "__gpi_opt_out", b.i);
        c && (c = Mj(Lj(Kj(Ij(c), 2147483647), "/"), b.pubWin.location.hostname), iM(a, "__gpi_opt_out", c, b.i))
    }

    function oV(a, b) {
        const c = qN(a.pubWin, "gpi-uoo", (d, e) => {
            if (e.source === b.contentWindow) {
                e = Mj(Lj(Kj(Ij(d.userOptOut ? "1" : "0"), 2147483647), "/"), a.pubWin.location.hostname);
                var f = new lM(a.pubWin);
                iM(f, "__gpi_opt_out", e, a.i);
                if (d.userOptOut || d.clearAdsData) jM(f, "__gads", a.i), jM(f, "__gpi", a.i)
            }
        });
        a.j.push(c)
    }

    function pV(a) {
        const b = ok(a.pubWin);
        if (b)
            if ("AMP-STICKY-AD" === b.container) {
                const c = d => {
                    "fill_sticky" === d.data && b.renderStart && b.renderStart()
                };
                Tb(a.pubWin, "message", Wz.Oa(616, c));
                a.j.push(() => {
                    Ub(a.pubWin, "message", c)
                })
            } else b.renderStart && b.renderStart()
    }

    function mV(a, b, c, d) {
        vU(new EU(a), c).then(e => {
            gk(8, [e]);
            return e
        }).then(e => {
            const f = c.parentElement;
            (f && qv.test(f.className) ? f : c).setAttribute("data-overlap-observer-io", e.isOverlappingOrOutsideViewport);
            return e
        }).then(e => {
            const f = b.D.armr || "",
                g = e.executionTime || "",
                h = null == b.D.iaaso ? "" : Number(b.D.iaaso),
                k = Number(e.isOverlappingOrOutsideViewport),
                l = $a(e.entries, G => `${G.overlapType}:${G.overlapDepth}:${G.overlapDetectionPoint}`),
                m = Number(e.overlappedArea.toFixed(2)),
                n = d.dataset.googleQueryId || "",
                p =
                m * e.targetRect.width * e.targetRect.height,
                q = `${e.scrollPosition.scrollX},${e.scrollPosition.scrollY}`,
                x = Rk(e.target),
                z = [e.targetRect.left, e.targetRect.top, e.targetRect.right, e.targetRect.bottom].join();
            e = `${e.viewportSize.width}x${e.viewportSize.height}`;
            $z("ovlp", {
                adf: b.D.google_ad_dom_fingerprint,
                armr: f,
                client: b.D.google_ad_client,
                eid: tP(b.D),
                et: g,
                fwrattr: b.D.google_full_width_responsive,
                iaaso: h,
                io: k,
                saldr: b.D.google_loader_used,
                oa: m,
                oe: l.join(","),
                qid: n,
                rafmt: b.D.google_responsive_auto_format,
                roa: p,
                slot: b.D.google_ad_slot,
                sp: q,
                tgt: x,
                tr: z,
                url: b.D.google_page_url,
                vp: e,
                pvc: Bf(a)
            }, 1)
        }).catch(e => {
            gk(8, ["Error:", e.message, c]);
            $z("ovlp-err", {
                err: e.message
            }, 1)
        })
    }

    function rV(a, b) {
        b.allow = b.allow && 0 < b.allow.length ? b.allow + ("; " + a) : a
    }

    function sV(a, b, c) {
        var d = a.D,
            e = d.google_async_iframe_id;
        const f = d.google_ad_width,
            g = d.google_ad_height,
            h = tN(d);
        e = {
            id: e,
            name: e
        };
        kP("browsing-topics", a.pubWin.document) && tV(a) && !v(Ku) && !TU(a.A ? .label) && (e.browsingTopics = "true");
        e.style = h ? [`width:${f}px !IMPORTANT`, `height:${g}px !IMPORTANT`].join(";") : "left:0;position:absolute;top:0;border:0;" + `width:${f}px;` + `height:${g}px;`;
        var k = mf();
        k["allow-top-navigation-by-user-activation"] && k["allow-popups-to-escape-sandbox"] && (v(Ft) && h || (k = "=" + encodeURIComponent("1"),
            b = xe(b, "fsb" + k)), e.sandbox = lf().join(" "));
        !1 === d.google_video_play_muted && rV("autoplay", e);
        k = b;
        61440 < k.length && (k = k.substring(0, 61432), k = k.replace(/%\w?$/, ""), k = k.replace(/&[^=]*=?$/, ""), k += "&trunc=1");
        if (k !== b) {
            let l = b.lastIndexOf("&", 61432); - 1 === l && (l = b.lastIndexOf("?", 61432));
            $z("trn", {
                ol: b.length,
                tr: -1 === l ? "" : b.substring(l + 1),
                url: b
            }, .01)
        }
        b = k;
        null != f && (e.width = String(f));
        null != g && (e.height = String(g));
        e.frameborder = "0";
        e.marginwidth = "0";
        e.marginheight = "0";
        e.vspace = "0";
        e.hspace = "0";
        e.allowtransparency =
            "true";
        e.scrolling = "no";
        d.dash && (e.srcdoc = d.dash);
        a.pubWin.document.featurePolicy ? .features().includes("attribution-reporting") && rV("attribution-reporting", e);
        v(Ru) && (d = a.pubWin, void 0 !== d.credentialless && (v(Su) || d.crossOriginIsolated) && (e.credentialless = "true"));
        if (h) e.src = b, e = jV(e), a = kV(a, e, c);
        else {
            c = {};
            c.dtd = MN((new Date).getTime(), lo);
            c = Mk(c, b);
            e.src = c;
            c = a.pubWin;
            c = c == c.top;
            e = jV(e);
            c && a.j.push(uk(a.pubWin, e));
            a.ia.style.visibility = "visible";
            for (a = a.ia; c = a.firstChild;) a.removeChild(c);
            a.appendChild(e);
            a = Promise.resolve(e)
        }
        return a
    }
    async function uV(a) {
        var b = a.D,
            c = a.pubWin;
        const d = a.i;
        O(d, 5) && qV(new lM(a.pubWin), a);
        var e = Xj(d, a.pubWin);
        if (!O(d, 5)) return $z("afc_noc_req", {}, w(bt)), Promise.resolve();
        v(Du) && (a.A = await eJ());
        if (!v(Mu)) {
            var f = kP("shared-storage", a.pubWin.document),
                g = kP("browsing-topics", a.pubWin.document);
            if (f || g) try {
                a.B = QU(a.pubWin)
            } catch (h) {
                aA(984, h)
            }
        }
        v(Us) || pM(d, a.pubWin, a.D.google_ad_client);
        sP(a.pubWin, d);
        if (f = a.D.google_reactive_ads_config) mN(a.K, f), uN(f, a, Xj(d)), f = f.page_level_pubvars, Aa(f) && Vc(a.D, f);
        f = kP("shared-storage",
            a.pubWin.document);
        a.B && O(d, 5) && f && !v(Au) && !Z(UI(), 34, !1) && (ZI(UI(), 34, !0), f = a.B.then(h => {
            h({
                message: "goog:spam:client_age",
                pvsid: Bf(a.pubWin),
                useObfuscatedKey: v(Bu)
            })
        }), Wz.Pa(1069, f));
        if (kP("browsing-topics", a.pubWin.document) && a.B && !v(Lu) && !TU(a.A ? .label))
            if (tV(a)) {
                a.l = 1;
                const h = Xj(a.i, a.pubWin);
                f = a.B.then(async k => {
                    await RU(k, a.pubWin, h).then(l => {
                        a.l = l
                    })
                });
                v(Nu) && (g = w(Pu), 0 < g ? await Promise.race([f, Df(g)]) : await f)
            } else a.l = 5;
        f = "";
        tN(b) ? (e = a.ra.Ij, f = Yb(Nt), "inhead" === f ? e = a.ra.Gj : "nohtml" === f && (e =
            a.ra.Hj), v(Et) && (e = $c(e, {
            hello: "world"
        })), f = e.toString() + "#" + (encodeURIComponent("RS-" + b.google_reactive_sra_index + "-") + "&" + Lk({
            adk: b.google_ad_unit_key,
            client: b.google_ad_client,
            fa: b.google_reactive_ad_format
        })), QP(b, UI()), vV(b)) : (5 === b.google_pgb_reactive && b.google_reactive_ads_config || !dN(b) || bN(c, b, e)) && vV(b) && (f = HP(a, d));
        gk(2, [b, f]);
        if (!f) return Promise.resolve();
        b.google_async_iframe_id || Pk(c);
        e = Qk(b);
        b = a.pubWin === a.K ? "a!" + e.toString(36) : `${e.toString(36)}.${Math.floor(2147483648*Math.random()).toString(36)+ 
Math.abs(Math.floor(2147483648*Math.random())^Date.now()).toString(36)}`;
        c = 0 < aV(a, a.ia, !0);
        e = {
            ifi: e,
            uci: b
        };
        c && (c = UI(), e.btvi = Z(c, 21, 1), $I(c, 21));
        f = Mk(e, f);
        c = sV(a, f, d);
        a.D.rpe && NO(a.pubWin, a.ia, {
            height: a.D.google_ad_height,
            rf: "force",
            Uc: !0,
            hf: !0,
            Zd: a.D.google_ad_client
        });
        c = await c;
        try {
            lV(a, c, b, d)
        } catch (h) {
            aA(223, h)
        }
    }

    function wV(a) {
        const b = new pU(a);
        return new Promise(c => {
            oU(b, d => {
                d && "string" === typeof d.uspString ? c(d.uspString) : c(null)
            })
        })
    }

    function xV(a) {
        var b = nf(r.top, "googlefcPresent");
        r.googlefc && !b && $z("adsense_fc_has_namespace_but_no_iframes", {
            publisherId: a
        }, 1)
    }

    function yV(a, b) {
        var c = b.Bj,
            d = b.uspString;
        b = b.Ei;
        c ? KN(a, c) : UJ(a, !0);
        if (d) {
            c = $i(a, 1, d);
            d = d.toUpperCase();
            if (4 == d.length && (-1 == d.indexOf("-") || "---" === d.substring(1)) && "1" <= d[0] && "9" >= d[0] && sK.hasOwnProperty(d[1]) && sK.hasOwnProperty(d[2]) && sK.hasOwnProperty(d[3])) {
                var e = new rK;
                e = Yi(e, 1, parseInt(d[0], 10));
                e = R(e, 2, sK[d[1]]);
                e = R(e, 3, sK[d[2]]);
                d = R(e, 4, sK[d[3]])
            } else d = null;
            d = 2 === d ? .Bi();
            Vi(c, 13, d)
        }
        b && DM(a, b)
    }

    function zV(a) {
        const b = w($s);
        if (0 >= b) return null;
        const c = al(),
            d = HU(a.pubWin);
        if (!d) return null;
        a.C = "0";
        return Promise.race([d, Df(b, "0")]).then(e => {
            $z("adsense_paw", {
                time: al() - c
            });
            1E4 < e ? .length ? aA(809, Error(`ML:${e.length}`)) : a.C = e
        }).catch(e => {
            aA(809, e)
        })
    }

    function AV(a) {
        const b = al();
        return Promise.race([Yz(832, () => LU(a)), Df(200)]).then(c => {
            $z("afc_etu", {
                etus: c ? .status ? ? 100,
                sig: al() - b,
                tms: 200
            });
            return c ? .tc
        })
    }
    async function BV(a) {
        const b = zV(a),
            c = Yz(868, () => AV(a.pubWin));
        FL(a.pubWin);
        xV(a.D.google_ad_client);
        var d = new lE(a.pubWin);
        await (iE(d, ".google.cn" === P(a.Fa, 8)) ? jE(d) : Promise.resolve(null));
        a.i = new VJ;
        d = [LN(a), wV(a.pubWin), v(Ws) ? EM(a) : null];
        d = await Promise.all(d);
        yV(a.i, {
            Bj: d[0],
            uspString: d[1],
            Ei: d[2]
        });
        await b;
        a.tc = await c || "";
        await uV(a)
    }

    function tV(a) {
        const b = a.i;
        a = a.D;
        return !a.google_restrict_data_processing && 1 !== a.google_tag_for_under_age_of_consent && 1 !== a.google_tag_for_child_directed_treatment && !!O(b, 5) && !b.g() && !cJ() && !O(b, 9) && !O(b, 13) && (!v(Ws) || !O(b, 12)) && ("string" !== typeof a.google_privacy_treatments || !a.google_privacy_treatments.split(",").includes("disablePersonalization"))
    }

    function iV(a) {
        a.D.google_allow_expandable_ads = !1;
        Ef(a.pubWin) !== a.pubWin && (a.g |= 4);
        3 === JM(a.pubWin.document) && (a.g |= 32);
        var b;
        if (b = a.K) {
            b = a.K;
            const c = wo(b);
            b = !(Ao(b).scrollWidth <= c)
        }
        b && (a.g |= 1024);
        a.pubWin.Prototype ? .Version && (a.g |= 16384);
        a.D.google_loader_features_used && (a.g |= a.D.google_loader_features_used);
        return BV(a)
    }

    function vV(a) {
        const b = UI(),
            c = a.google_ad_section;
        cN(a) && $I(b, 15);
        if (Tk(a)) {
            if (100 < $I(b, 5)) return !1
        } else if (100 < $I(b, 6) - Z(b, 15, 0) && "" === c) return !1;
        return !0
    }

    function hV(a) {
        const b = a.K;
        if (b && !PI(b).ads_density_stats_processed && !ok(b) && (PI(b).ads_density_stats_processed = !0, v(Jt) || .01 > Ze())) {
            const c = () => {
                if (b) {
                    var d = EH(zH(b), a.D.google_ad_client, b.location.hostname, tP(a.D).split(","));
                    $z("ama_stats", d, 1)
                }
            };
            Cf(b, () => {
                r.setTimeout(c, 1E3)
            })
        }
    };
    (function(a, b, c) {
        Yz(843, () => {
            if (!r.google_sa_impl) {
                var d = new $n(b);
                try {
                    Wg(k => {
                        var l = new Pn;
                        var m = new On;
                        try {
                            var n = Bf(window);
                            Q(m, 1, n)
                        } catch (z) {}
                        try {
                            var p = fo();
                            ki(m, 2, p, gh)
                        } catch (z) {}
                        try {
                            aj(m, 3, window.document.URL)
                        } catch (z) {}
                        l = F(l, 2, m);
                        m = new Nn;
                        m = R(m, 1, 1192);
                        try {
                            var q = ul(k ? .name) ? k.name : "Unknown error";
                            aj(m, 2, q)
                        } catch (z) {}
                        try {
                            var x = ul(k ? .message) ? k.message : `Caught ${k}`;
                            aj(m, 3, x)
                        } catch (z) {}
                        try {
                            const z = ul(k ? .stack) ? k.stack : Error().stack;
                            z && ki(m, 4, z.split(/\n\s*/), th)
                        } catch (z) {}
                        k = F(l, 1, m);
                        q = new Mn;
                        try {
                            aj(q,
                                1, "m202401170101")
                        } catch {}
                        I(k, 6, Qn, q);
                        Q(k, 5, 1);
                        Sn(d, k)
                    })
                } catch (k) {}
                var e = kU(a);
                iU(P(e, 2));
                WN(O(e, 6));
                gk(16, [3, e.toJSON()]);
                var f = hU({
                        Tf: b,
                        fh: P(e, 2)
                    }),
                    g = c(f, e);
                r.google_sa_impl = k => VU({
                    Fa: e,
                    ra: g,
                    vb: f,
                    slot: k
                });
                pP(jP(r));
                r.google_process_slots ? .();
                var h = (r.Prototype || {}).Version;
                null != h && $z("prtpjs", {
                    version: h
                })
            }
        })
    })(jU, "m202401170101", function(a, b) {
        const c = 2012 < xi(b, 1) ? `_fy${xi(b,1)}` : "",
            d = P(b, 3);
        b = P(b, 2);
        return {
            nj: sj `https://pagead2.googlesyndication.com/pagead/js/${b}/${d}/rum${c}.js`,
            mj: sj `https://pagead2.googlesyndication.com/pagead/js/${b}/${d}/rum_debug${c}.js`,
            Wg: sj `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/${""}reactive_library${c}.js`,
            gi: sj `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/${""}debug_card_library${c}.js`,
            Ij: sj `https://googleads.g.doubleclick.net/pagead/html/${b}/${d}/zrt_lookup${c}.html`,
            Gj: sj `https://googleads.g.doubleclick.net/pagead/html/${b}/${d}/zrt_lookup_inhead${c}.html`,
            Hj: sj `https://googleads.g.doubleclick.net/pagead/html/${b}/${d}/zrt_lookup_nohtml${c}.html`,
            fo: sj `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/${""}slotcar_library${c}.js`,
            Un: sj `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/gallerify${c}.js`,
            kb: sj `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/${""}autogames${c}.js`
        }
    });
}).call(this, "[2021,\"r20240118\",\"r20110914\",null,null,null,null,\".google.bi\",null,null,null,null,null,null,null,null,null,-1,[95320239,44759876,44759927,44759837]]");