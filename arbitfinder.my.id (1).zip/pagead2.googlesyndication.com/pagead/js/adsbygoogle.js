(function(sttc) {
    'use strict';
    var aa = {};
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var p = this || self;

    function ba(a, b) {
        var c = ca("CLOSURE_FLAGS");
        a = c && c[a];
        return null != a ? a : b
    }

    function ca(a) {
        a = a.split(".");
        for (var b = p, c = 0; c < a.length; c++)
            if (b = b[a[c]], null == b) return null;
        return b
    }

    function da(a) {
        var b = typeof a;
        return "object" == b && null != a || "function" == b
    }

    function ea(a) {
        return Object.prototype.hasOwnProperty.call(a, fa) && a[fa] || (a[fa] = ++ha)
    }
    var fa = "closure_uid_" + (1E9 * Math.random() >>> 0),
        ha = 0;

    function ia(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function ja(a, b, c) {
        if (!a) throw Error();
        if (2 < arguments.length) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    }

    function ka(a, b, c) {
        ka = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? ia : ja;
        return ka.apply(null, arguments)
    }

    function la(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    }

    function ma(a, b, c) {
        a = a.split(".");
        c = c || p;
        a[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + a[0]);
        for (var d; a.length && (d = a.shift());) a.length || void 0 === b ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
    }

    function na(a) {
        return a
    };
    let oa = (new Date).getTime();

    function pa(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    }

    function qa(a, b) {
        let c = 0;
        a = pa(String(a)).split(".");
        b = pa(String(b)).split(".");
        const d = Math.max(a.length, b.length);
        for (let g = 0; 0 == c && g < d; g++) {
            var e = a[g] || "",
                f = b[g] || "";
            do {
                e = /(\d*)(\D*)(.*)/.exec(e) || ["", "", "", ""];
                f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                if (0 == e[0].length && 0 == f[0].length) break;
                c = ra(0 == e[1].length ? 0 : parseInt(e[1], 10), 0 == f[1].length ? 0 : parseInt(f[1], 10)) || ra(0 == e[2].length, 0 == f[2].length) || ra(e[2], f[2]);
                e = e[3];
                f = f[3]
            } while (0 == c)
        }
        return c
    }

    function ra(a, b) {
        return a < b ? -1 : a > b ? 1 : 0
    };
    var ta = ba(610401301, !1),
        ua = ba(572417392, !0);

    function va() {
        var a = p.navigator;
        return a && (a = a.userAgent) ? a : ""
    }
    var wa;
    const xa = p.navigator;
    wa = xa ? xa.userAgentData || null : null;

    function ya(a) {
        return ta ? wa ? wa.brands.some(({
            brand: b
        }) => b && -1 != b.indexOf(a)) : !1 : !1
    }

    function q(a) {
        return -1 != va().indexOf(a)
    };

    function za() {
        return ta ? !!wa && 0 < wa.brands.length : !1
    }

    function Aa() {
        return za() ? !1 : q("Trident") || q("MSIE")
    }

    function Ba() {
        return za() ? ya("Microsoft Edge") : q("Edg/")
    }

    function Ca() {
        !q("Safari") || Da() || (za() ? 0 : q("Coast")) || (za() ? 0 : q("Opera")) || (za() ? 0 : q("Edge")) || Ba() || za() && ya("Opera")
    }

    function Da() {
        return za() ? ya("Chromium") : (q("Chrome") || q("CriOS")) && !(za() ? 0 : q("Edge")) || q("Silk")
    }

    function Ea(a) {
        const b = {};
        a.forEach(c => {
            b[c[0]] = c[1]
        });
        return c => b[c.find(d => d in b)] || ""
    }

    function Fa() {
        var a = va();
        if (Aa()) {
            var b = /rv: *([\d\.]*)/.exec(a);
            if (b && b[1]) a = b[1];
            else {
                b = "";
                var c = /MSIE +([\d\.]+)/.exec(a);
                if (c && c[1])
                    if (a = /Trident\/(\d.\d)/.exec(a), "7.0" == c[1])
                        if (a && a[1]) switch (a[1]) {
                            case "4.0":
                                b = "8.0";
                                break;
                            case "5.0":
                                b = "9.0";
                                break;
                            case "6.0":
                                b = "10.0";
                                break;
                            case "7.0":
                                b = "11.0"
                        } else b = "7.0";
                        else b = c[1];
                a = b
            }
            return a
        }
        c = RegExp("([A-Z][\\w ]+)/([^\\s]+)\\s*(?:\\((.*?)\\))?", "g");
        b = [];
        let d;
        for (; d = c.exec(a);) b.push([d[1], d[2], d[3] || void 0]);
        a = Ea(b);
        return (za() ? 0 : q("Opera")) ? a(["Version",
            "Opera"
        ]) : (za() ? 0 : q("Edge")) ? a(["Edge"]) : Ba() ? a(["Edg"]) : q("Silk") ? a(["Silk"]) : Da() ? a(["Chrome", "CriOS", "HeadlessChrome"]) : (a = b[2]) && a[1] || ""
    };

    function Ga(a, b) {
        if ("string" === typeof a) return "string" !== typeof b || 1 != b.length ? -1 : a.indexOf(b, 0);
        for (let c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    }

    function Ha(a, b) {
        const c = a.length,
            d = "string" === typeof a ? a.split("") : a;
        for (let e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
    }

    function Ia(a, b) {
        const c = a.length,
            d = [];
        let e = 0;
        const f = "string" === typeof a ? a.split("") : a;
        for (let g = 0; g < c; g++)
            if (g in f) {
                const h = f[g];
                b.call(void 0, h, g, a) && (d[e++] = h)
            }
        return d
    }

    function Ja(a, b) {
        const c = a.length,
            d = Array(c),
            e = "string" === typeof a ? a.split("") : a;
        for (let f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
        return d
    }

    function Ka(a, b) {
        const c = a.length,
            d = "string" === typeof a ? a.split("") : a;
        for (let e = 0; e < c; e++)
            if (e in d && b.call(void 0, d[e], e, a)) return !0;
        return !1
    }

    function La(a, b) {
        a: {
            var c = a.length;
            const d = "string" === typeof a ? a.split("") : a;
            for (--c; 0 <= c; c--)
                if (c in d && b.call(void 0, d[c], c, a)) {
                    b = c;
                    break a
                }
            b = -1
        }
        return 0 > b ? null : "string" === typeof a ? a.charAt(b) : a[b]
    }

    function Ma(a, b) {
        return 0 <= Ga(a, b)
    }

    function Na(a) {
        const b = a.length;
        if (0 < b) {
            const c = Array(b);
            for (let d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };

    function Oa(a) {
        Oa[" "](a);
        return a
    }
    Oa[" "] = function() {};
    var Pa = Aa();
    !q("Android") || Da();
    Da();
    Ca();
    var Qa = null;

    function Sa(a) {
        var b = [];
        Ta(a, function(c) {
            b.push(c)
        });
        return b
    }

    function Ta(a, b) {
        function c(k) {
            for (; d < a.length;) {
                var m = a.charAt(d++),
                    l = Qa[m];
                if (null != l) return l;
                if (!/^[\s\xa0]*$/.test(m)) throw Error("Unknown base64 encoding at char: " + m);
            }
            return k
        }
        Ua();
        for (var d = 0;;) {
            var e = c(-1),
                f = c(0),
                g = c(64),
                h = c(64);
            if (64 === h && -1 === e) break;
            b(e << 2 | f >> 4);
            64 != g && (b(f << 4 & 240 | g >> 2), 64 != h && b(g << 6 & 192 | h))
        }
    }

    function Ua() {
        if (!Qa) {
            Qa = {};
            for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++)
                for (var d = a.concat(b[c].split("")), e = 0; e < d.length; e++) {
                    var f = d[e];
                    void 0 === Qa[f] && (Qa[f] = e)
                }
        }
    };
    var Va = "undefined" != typeof structuredClone;
    var Wa = !ua;
    let Ya = !ua;
    let Za = 0,
        $a = 0;

    function ab(a) {
        var b = 0 > a;
        a = Math.abs(a);
        var c = a >>> 0;
        a = Math.floor((a - c) / 4294967296);
        if (b) {
            b = c;
            c = ~a;
            b ? b = ~b + 1 : c += 1;
            const [d, e] = [b, c];
            a = e;
            c = d
        }
        Za = c >>> 0;
        $a = a >>> 0
    }

    function bb() {
        var a = Za,
            b = $a;
        if (b & 2147483648) var c = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0));
        else b >>>= 0, a >>>= 0, 2097151 >= b ? c = "" + (4294967296 * b + a) : c = "" + (BigInt(b) << BigInt(32) | BigInt(a));
        return c
    };

    function cb(a) {
        return Array.prototype.slice.call(a)
    };
    var r = Symbol(),
        db = Symbol();

    function eb(a) {
        const b = a[r] | 0;
        1 !== (b & 1) && (Object.isFrozen(a) && (a = cb(a)), a[r] = b | 1)
    }

    function t(a, b, c) {
        return c ? a | b : a & ~b
    }

    function fb() {
        var a = [];
        a[r] |= 1;
        return a
    }

    function gb(a) {
        a[r] |= 32;
        return a
    }

    function hb(a, b) {
        b[r] = (a | 0) & -14591
    }

    function ib(a, b) {
        b[r] = (a | 34) & -14557
    }

    function jb(a) {
        a = a >> 14 & 1023;
        return 0 === a ? 536870912 : a
    };
    var kb = {},
        lb = {};

    function mb(a) {
        return !(!a || "object" !== typeof a || a.sc !== lb)
    }

    function nb(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    }
    let ob, pb = !ua;

    function qb(a, b, c) {
        if (!Array.isArray(a) || a.length) return !1;
        const d = a[r] | 0;
        if (d & 1) return !0;
        if (!(b && (Array.isArray(b) ? b.includes(c) : b.has(c)))) return !1;
        a[r] = d | 1;
        return !0
    }
    var rb;
    const sb = [];
    sb[r] = 55;
    rb = Object.freeze(sb);

    function tb(a) {
        if (a & 2) throw Error();
    }
    class ub {}
    class vb {}
    Object.freeze(new ub);
    Object.freeze(new vb);
    let wb;

    function xb(a) {
        if (wb) throw Error("");
        wb = a
    }

    function yb(a) {
        a = Error(a);
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = "warning";
        if (wb) try {
            wb(a)
        } catch (b) {
            throw b.cause = a, b;
        }
        return a
    };

    function zb(a) {
        if (null != a && "boolean" !== typeof a) {
            var b = typeof a;
            throw Error(`Expected boolean but got ${"object"!=b?b:a?Array.isArray(a)?"array":b:"null"}: ${a}`);
        }
        return a
    }
    const Ab = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function Bb(a) {
        const b = typeof a;
        return "number" === b ? Number.isFinite(a) : "string" !== b ? !1 : Ab.test(a)
    }

    function u(a) {
        if (null != a) {
            if (!Number.isFinite(a)) throw yb("enum");
            a |= 0
        }
        return a
    }

    function Cb(a) {
        return null == a ? a : Number.isFinite(a) ? a | 0 : void 0
    }

    function Db(a) {
        if ("number" !== typeof a) throw yb("int32");
        if (!Number.isFinite(a)) throw yb("int32");
        return a | 0
    }

    function Eb(a) {
        return null == a ? a : Db(a)
    }

    function Fb(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return Number.isFinite(a) ? a | 0 : void 0
    }

    function Gb(a) {
        if (null == a) return a;
        if ("string" === typeof a) {
            if (!a) return;
            a = +a
        }
        if ("number" === typeof a) return Number.isFinite(a) ? a >>> 0 : void 0
    }

    function Hb(a) {
        return "-" === a[0] ? 20 > a.length ? !0 : 20 === a.length && -922337 < Number(a.substring(0, 7)) : 19 > a.length ? !0 : 19 === a.length && 922337 > Number(a.substring(0, 6))
    }

    function Ib(a) {
        a = Math.trunc(a);
        if (!Number.isSafeInteger(a)) {
            ab(a);
            var b = Za,
                c = $a;
            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, 0 == b && (c = c + 1 >>> 0);
            b = 4294967296 * c + (b >>> 0);
            a = a ? -b : b
        }
        return a
    }

    function Jb(a) {
        var b = Math.trunc(Number(a));
        if (Number.isSafeInteger(b)) return String(b);
        b = a.indexOf("."); - 1 !== b && (a = a.substring(0, b));
        Hb(a) || (16 > a.length ? ab(Number(a)) : (a = BigInt(a), Za = Number(a & BigInt(4294967295)) >>> 0, $a = Number(a >> BigInt(32) & BigInt(4294967295))), a = bb());
        return a
    }

    function Kb(a) {
        if ("string" !== typeof a) throw Error();
        return a
    }

    function Lb(a) {
        if (null != a && "string" !== typeof a) throw Error();
        return a
    }

    function Mb(a) {
        return null == a || "string" === typeof a ? a : void 0
    }

    function Nb(a, b, c, d) {
        if (null != a && "object" === typeof a && a.ma === kb) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? (a = b[db]) ? b = a : (a = new b, d = a.A, d[r] |= 34, b = b[db] = a) : b = new b : b = void 0, b;
        let e = c = a[r] | 0;
        0 === e && (e |= d & 32);
        e |= d & 2;
        e !== c && (a[r] = e);
        return new b(a)
    };
    let Ob;

    function Pb(a, b) {
        Ob = b;
        a = new a(b);
        Ob = void 0;
        return a
    };

    function Qb(a, b) {
        return Rb(b)
    }

    function Rb(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (a) {
                    if (Array.isArray(a)) return pb || !qb(a, void 0, 9999) ? a : void 0;
                    if (null != a && a instanceof Uint8Array) {
                        let b = "",
                            c = 0;
                        const d = a.length - 10240;
                        for (; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
                        b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
                        return btoa(b)
                    }
                }
        }
        return a
    };

    function Sb(a, b, c) {
        a = cb(a);
        var d = a.length;
        const e = b & 256 ? a[d - 1] : void 0;
        d += e ? -1 : 0;
        for (b = b & 512 ? 1 : 0; b < d; b++) a[b] = c(a[b]);
        if (e) {
            b = a[b] = {};
            for (const f in e) Object.prototype.hasOwnProperty.call(e, f) && (b[f] = c(e[f]))
        }
        return a
    }

    function Tb(a, b, c, d, e, f) {
        if (null != a) {
            if (Array.isArray(a)) a = e && 0 == a.length && (a[r] | 0) & 1 ? void 0 : f && (a[r] | 0) & 2 ? a : Ub(a, b, c, void 0 !== d, e, f);
            else if (nb(a)) {
                const g = {};
                for (let h in a) Object.prototype.hasOwnProperty.call(a, h) && (g[h] = Tb(a[h], b, c, d, e, f));
                a = g
            } else a = b(a, d);
            return a
        }
    }

    function Ub(a, b, c, d, e, f) {
        const g = d || c ? a[r] | 0 : 0;
        d = d ? !!(g & 32) : void 0;
        a = cb(a);
        for (let h = 0; h < a.length; h++) a[h] = Tb(a[h], b, c, d, e, f);
        c && c(g, a);
        return a
    }

    function Vb(a) {
        return a.ma === kb ? Wb(a, Ub(a.A, Vb, void 0, void 0, !1, !1), !0) : null != a && a instanceof Uint8Array ? new Uint8Array(a) : a
    }

    function Xb(a) {
        return a.ma === kb ? a.toJSON() : Rb(a)
    }
    var Yb = Va ? structuredClone : a => Ub(a, Vb, void 0, void 0, !1, !1);

    function Zb(a, b, c = ib) {
        if (null != a) {
            if (a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = a[r] | 0;
                if (d & 2) return a;
                b && (b = 0 === d || !!(d & 32) && !(d & 64 || !(d & 16)));
                return b ? (a[r] = (d | 34) & -12293, a) : Ub(a, Zb, d & 4 ? ib : c, !0, !1, !0)
            }
            a.ma === kb && (c = a.A, d = c[r], a = d & 2 ? a : Pb(a.constructor, $b(c, d, !0)));
            return a
        }
    }

    function $b(a, b, c) {
        const d = c || b & 2 ? ib : hb,
            e = !!(b & 32);
        a = Sb(a, b, f => Zb(f, e, d));
        a[r] = a[r] | 32 | (c ? 2 : 0);
        return a
    }

    function ac(a) {
        const b = a.A,
            c = b[r];
        return c & 2 ? Pb(a.constructor, $b(b, c, !1)) : a
    };

    function bc(a, b) {
        a = a.A;
        return cc(a, a[r], b)
    }

    function cc(a, b, c, d) {
        if (-1 === c) return null;
        if (c >= jb(b)) {
            if (b & 256) return a[a.length - 1][c]
        } else {
            var e = a.length;
            if (d && b & 256 && (d = a[e - 1][c], null != d)) return d;
            b = c + (+!!(b & 512) - 1);
            if (b < e) return a[b]
        }
    }

    function y(a, b, c) {
        const d = a.A;
        let e = d[r];
        tb(e);
        C(d, e, b, c);
        return a
    }

    function C(a, b, c, d, e) {
        const f = jb(b);
        if (c >= f || e) {
            let g = b;
            if (b & 256) e = a[a.length - 1];
            else {
                if (null == d) return g;
                e = a[f + (+!!(b & 512) - 1)] = {};
                g |= 256
            }
            e[c] = d;
            c < f && (a[c + (+!!(b & 512) - 1)] = void 0);
            g !== b && (a[r] = g);
            return g
        }
        a[c + (+!!(b & 512) - 1)] = d;
        b & 256 && (a = a[a.length - 1], c in a && delete a[c]);
        return b
    }

    function dc(a, b, c) {
        return void 0 !== ec(a, b, c, !1)
    }

    function fc(a, b) {
        a = bc(a, b);
        return null == a || "boolean" === typeof a ? a : "number" === typeof a ? !!a : void 0
    }

    function gc(a, b, c) {
        a = a.A;
        let d = a[r];
        const e = 2 & d ? 1 : 2;
        let f = hc(a, d, b);
        var g = f[r] | 0;
        if (!(4 & g)) {
            if (4 & g || Object.isFrozen(f)) f = cb(f), g = ic(g, d, !1), d = C(a, d, b, f);
            var h = 0;
            let k = 0;
            for (; h < f.length; h++) {
                const m = c(f[h]);
                null != m && (f[k++] = m)
            }
            k < h && (f.length = k);
            g = jc(g, d);
            g = t(g, 20, !0);
            g = t(g, 4096, !1);
            g = t(g, 8192, !1);
            f[r] = g;
            2 & g && Object.freeze(f)
        }
        kc(g) || (c = g, (h = 1 === e) ? g = t(g, 2, !0) : g = t(g, 32, !1), g !== c && (f[r] = g), h && Object.freeze(f));
        2 === e && kc(g) && (f = cb(f), g = ic(g, d, !1), f[r] = g, C(a, d, b, f));
        return f
    }

    function hc(a, b, c) {
        a = cc(a, b, c);
        return Array.isArray(a) ? a : rb
    }

    function jc(a, b) {
        var c = !1;
        0 === a && (a = ic(a, b, c));
        return a = t(a, 1, !0)
    }

    function kc(a) {
        return !!(2 & a) && !!(4 & a) || !!(2048 & a)
    }

    function lc(a, b, c, d) {
        const e = a.A;
        let f = e[r];
        tb(f);
        if (null == c) return C(e, f, b), a;
        let g = c[r] | 0,
            h = g;
        var k = !!(2 & g) || Object.isFrozen(c);
        const m = !k && !1;
        if (!(4 & g))
            for (g = 21, k && (c = cb(c), h = 0, g = ic(g, f, !0)), k = 0; k < c.length; k++) c[k] = d(c[k]);
        m && (c = cb(c), h = 0, g = ic(g, f, !0));
        g !== h && (c[r] = g);
        C(e, f, b, c);
        return a
    }

    function D(a, b, c, d) {
        const e = a.A;
        let f = e[r];
        tb(f);
        C(e, f, b, ("0" === d ? 0 === Number(c) : c === d) ? void 0 : c);
        return a
    }

    function mc(a, b, c, d) {
        const e = a.A;
        let f = e[r];
        tb(f);
        (c = nc(e, f, c)) && c !== b && null != d && (f = C(e, f, c));
        C(e, f, b, d);
        return a
    }

    function oc(a, b, c) {
        a = a.A;
        return nc(a, a[r], b) === c ? c : -1
    }

    function pc(a, b) {
        a = a.A;
        return nc(a, a[r], b)
    }

    function nc(a, b, c) {
        let d = 0;
        for (let e = 0; e < c.length; e++) {
            const f = c[e];
            null != cc(a, b, f) && (0 !== d && (b = C(a, b, d)), d = f)
        }
        return d
    }

    function qc(a) {
        var b = rc;
        a = a.A;
        let c = a[r];
        tb(c);
        const d = cc(a, c, 3);
        b = ac(Nb(d, b, !0, c));
        d !== b && C(a, c, 3, b);
        return b
    }

    function ec(a, b, c, d) {
        a = a.A;
        let e = a[r];
        const f = cc(a, e, c, d);
        b = Nb(f, b, !1, e);
        b !== f && null != b && C(a, e, c, b, d);
        return b
    }

    function E(a, b, c) {
        b = ec(a, b, c, !1);
        if (null == b) return b;
        a = a.A;
        let d = a[r];
        if (!(d & 2)) {
            const e = ac(b);
            e !== b && (b = e, C(a, d, c, b, !1))
        }
        return b
    }

    function F(a, b, c) {
        a = a.A;
        var d = a[r],
            e = d,
            f = !(2 & d),
            g = !!(2 & e),
            h = g ? 1 : 2;
        d = 1 === h;
        h = 2 === h;
        f && (f = !g);
        g = hc(a, e, c);
        var k = g[r] | 0;
        const m = !!(4 & k);
        if (!m) {
            k = jc(k, e);
            var l = g,
                n = e;
            const w = !!(2 & k);
            w && (n = t(n, 2, !0));
            let v = !w,
                x = !0,
                z = 0,
                A = 0;
            for (; z < l.length; z++) {
                const B = Nb(l[z], b, !1, n);
                if (B instanceof b) {
                    if (!w) {
                        const J = !!((B.A[r] | 0) & 2);
                        v && (v = !J);
                        x && (x = J)
                    }
                    l[A++] = B
                }
            }
            A < z && (l.length = A);
            k = t(k, 4, !0);
            k = t(k, 16, x);
            k = t(k, 8, v);
            l[r] = k;
            w && Object.freeze(l)
        }
        b = !!(8 & k) || d && !g.length;
        if (f && !b) {
            kc(k) && (g = cb(g), k = ic(k, e, !1), e = C(a, e, c, g));
            b =
                g;
            f = k;
            for (l = 0; l < b.length; l++) k = b[l], n = ac(k), k !== n && (b[l] = n);
            f = t(f, 8, !0);
            f = t(f, 16, !b.length);
            k = b[r] = f
        }
        kc(k) || (b = k, d ? k = t(k, !g.length || 16 & k && (!m || 32 & k) ? 2 : 2048, !0) : k = t(k, 32, !1), k !== b && (g[r] = k), d && Object.freeze(g));
        h && kc(k) && (g = cb(g), k = ic(k, e, !1), g[r] = k, C(a, e, c, g));
        return g
    }

    function sc(a, b, c) {
        null == c && (c = void 0);
        return y(a, b, c)
    }

    function tc(a, b, c, d) {
        null == d && (d = void 0);
        return mc(a, b, c, d)
    }

    function uc(a, b, c) {
        const d = a.A;
        let e = d[r];
        tb(e);
        if (null == c) return C(d, e, b), a;
        let f = c[r] | 0,
            g = f;
        const h = !!(2 & f) || !!(2048 & f),
            k = h || Object.isFrozen(c);
        let m = !0,
            l = !0;
        for (let w = 0; w < c.length; w++) {
            var n = c[w];
            h || (n = !!((n.A[r] | 0) & 2), m && (m = !n), l && (l = n))
        }
        h || (f = t(f, 5, !0), f = t(f, 8, m), f = t(f, 16, l));
        k && f !== g && (c = cb(c), g = 0, f = ic(f, e, !0));
        f !== g && (c[r] = f);
        C(d, e, b, c);
        return a
    }

    function ic(a, b, c) {
        a = t(a, 2, !!(2 & b));
        a = t(a, 32, !!(32 & b) && c);
        return a = t(a, 2048, !1)
    }

    function G(a, b) {
        return Fb(bc(a, b))
    }

    function vc(a, b) {
        a = bc(a, b);
        var c;
        null == a ? c = a : Bb(a) ? "number" === typeof a ? c = Ib(a) : c = Jb(a) : c = void 0;
        return c
    }

    function H(a, b) {
        return Mb(bc(a, b))
    }

    function I(a, b) {
        return Cb(bc(a, b))
    }

    function wc(a) {
        return a ? ? 0
    }

    function K(a, b, c = !1) {
        return fc(a, b) ? ? c
    }

    function xc(a, b) {
        return wc(vc(a, b))
    }

    function yc(a, b) {
        a = a.A;
        let c = a[r];
        const d = cc(a, c, b);
        var e = null == d || "number" === typeof d ? d : "NaN" === d || "Infinity" === d || "-Infinity" === d ? Number(d) : void 0;
        null != e && e !== d && C(a, c, b, e);
        return e ? ? 0
    }

    function L(a, b) {
        return H(a, b) ? ? ""
    }

    function M(a, b) {
        return wc(I(a, b))
    }

    function zc(a, b, c, d) {
        return E(a, b, oc(a, d, c))
    }

    function Ac(a, b, c) {
        if (null != c) {
            var d = !!d;
            if (!Bb(c)) throw yb("int64");
            "string" === typeof c ? c = Jb(c) : d ? (c = Math.trunc(c), Number.isSafeInteger(c) ? c = String(c) : (d = String(c), Hb(d) ? c = d : (ab(c), c = bb()))) : c = Ib(c)
        }
        return D(a, b, c, "0")
    }

    function Bc(a, b) {
        var c = performance.now();
        if (null != c && "number" !== typeof c) throw Error(`Value of float/double field must be a number, found ${typeof c}: ${c}`);
        D(a, b, c, 0)
    }

    function Dc(a, b, c) {
        return D(a, b, Lb(c), "")
    };
    var N = class {
        constructor(a) {
            a: {
                null == a && (a = Ob);Ob = void 0;
                if (null == a) {
                    var b = 96;
                    a = []
                } else {
                    if (!Array.isArray(a)) throw Error();
                    b = a[r] | 0;
                    if (b & 64) break a;
                    var c = a;
                    b |= 64;
                    var d = c.length;
                    if (d && (--d, nb(c[d]))) {
                        b |= 256;
                        c = d - (+!!(b & 512) - 1);
                        if (1024 <= c) throw Error();
                        b = b & -16760833 | (c & 1023) << 14
                    }
                }
                a[r] = b
            }
            this.A = a
        }
        toJSON() {
            if (ob) var a = Wb(this, this.A, !1);
            else a = Ub(this.A, Xb, void 0, void 0, !1, !1), a = Wb(this, a, !0);
            return a
        }
    };
    N.prototype.ma = kb;

    function Wb(a, b, c) {
        const d = a.constructor.u;
        var e = (c ? a.A : b)[r],
            f = jb(e),
            g = !1;
        if (d && pb) {
            if (!c) {
                b = cb(b);
                var h;
                if (b.length && nb(h = b[b.length - 1]))
                    for (g = 0; g < d.length; g++)
                        if (d[g] >= f) {
                            Object.assign(b[b.length - 1] = {}, h);
                            break
                        }
                g = !0
            }
            f = b;
            c = !c;
            h = a.A[r];
            a = jb(h);
            h = +!!(h & 512) - 1;
            var k;
            for (let B = 0; B < d.length; B++) {
                var m = d[B];
                if (m < a) {
                    m += h;
                    var l = f[m];
                    null == l ? f[m] = c ? rb : fb() : c && l !== rb && eb(l)
                } else {
                    if (!k) {
                        var n = void 0;
                        f.length && nb(n = f[f.length - 1]) ? k = n : f.push(k = {})
                    }
                    l = k[m];
                    null == k[m] ? k[m] = c ? rb : fb() : c && l !== rb && eb(l)
                }
            }
        }
        k = b.length;
        if (!k) return b;
        let w, v;
        if (nb(n = b[k - 1])) {
            a: {
                var x = n;f = {};c = !1;
                for (var z in x)
                    if (Object.prototype.hasOwnProperty.call(x, z)) {
                        a = x[z];
                        if (Array.isArray(a)) {
                            h = a;
                            if (!Ya && qb(a, d, +z) || !Wa && mb(a) && 0 === a.size) a = null;
                            a != h && (c = !0)
                        }
                        null != a ? f[z] = a : c = !0
                    }
                if (c) {
                    for (let B in f) {
                        x = f;
                        break a
                    }
                    x = null
                }
            }
            x != n && (w = !0);k--
        }
        for (e = +!!(e & 512) - 1; 0 < k; k--) {
            z = k - 1;
            n = b[z];
            if (!(null == n || !Ya && qb(n, d, z - e) || !Wa && mb(n) && 0 === n.size)) break;
            v = !0
        }
        if (!w && !v) return b;
        var A;
        g ? A = b : A = Array.prototype.slice.call(b, 0, k);
        b = A;
        g && (b.length = k);
        x && b.push(x);
        return b
    }

    function Ec(a, b) {
        if (null == b) return new a;
        if (!Array.isArray(b)) throw Error("must be an array");
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error("arrays passed to jspb constructors must be mutable");
        b[r] |= 128;
        return Pb(a, gb(b))
    };

    function Fc(a, b) {
        const c = Gc;
        Gc = void 0;
        if (!b(a)) throw b = c ? c() + "\n" : "", Error(b + String(a));
    }
    const Hc = a => null !== a && void 0 !== a;
    let Gc = void 0;

    function Ic(a) {
        return b => {
            if (null == b || "" == b) b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error(void 0);
                b = Pb(a, gb(b))
            }
            return b
        }
    };
    var Jc = class extends N {};
    var Kc = class extends N {};
    Kc.u = [2, 3, 4];
    var O = class {
            constructor(a, b = !1) {
                this.g = a;
                this.defaultValue = b
            }
        },
        Lc = class {
            constructor(a, b = 0) {
                this.g = a;
                this.defaultValue = b
            }
        },
        Mc = class {
            constructor(a) {
                this.g = a;
                this.defaultValue = ""
            }
        },
        Nc = class {
            constructor(a, b = []) {
                this.g = a;
                this.defaultValue = b
            }
        };
    var Oc = new O(203);

    function Pc(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    }

    function Qc(a) {
        let b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    }

    function Rc(a) {
        let b = a;
        return function() {
            if (b) {
                const c = b;
                b = null;
                c()
            }
        }
    };

    function Sc(a, b, c) {
        a.addEventListener && a.addEventListener(b, c, !1)
    }

    function Tc(a, b, c) {
        return a.removeEventListener ? (a.removeEventListener(b, c, !1), !0) : !1
    };
    var P = a => {
        var b = "Aa";
        if (a.Aa && a.hasOwnProperty(b)) return a.Aa;
        b = new a;
        return a.Aa = b
    };
    var Uc = class {
        constructor() {
            const a = {};
            this.i = (b, c) => null != a[b] ? a[b] : c;
            this.j = (b, c) => null != a[b] ? a[b] : c;
            this.g = (b, c) => null != a[b] ? a[b] : c;
            this.h = (b, c) => null != a[b] ? a[b] : c;
            this.s = () => {}
        }
    };

    function Q(a) {
        return P(Uc).i(a.g, a.defaultValue)
    }

    function Vc(a) {
        return P(Uc).j(a.g, a.defaultValue)
    };

    function Wc(a, b) {
        const c = {};
        for (const d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
        return c
    }

    function Xc(a, b) {
        for (const c in a)
            if (b.call(void 0, a[c], c, a)) return !0;
        return !1
    }

    function Yc(a) {
        const b = [];
        let c = 0;
        for (const d in a) b[c++] = a[d];
        return b
    }

    function Zc(a) {
        const b = {};
        for (const c in a) b[c] = a[c];
        return b
    };
    var $c;
    var ad = class {
        constructor(a) {
            this.h = a
        }
        toString() {
            return this.h + ""
        }
    };

    function bd(a, b) {
        a = cd.exec(dd(a).toString());
        var c = a[3] || "";
        return ed(a[1] + fd("?", a[2] || "", b) + fd("#", c))
    }

    function dd(a) {
        return a instanceof ad && a.constructor === ad ? a.h : "type_error:TrustedResourceUrl"
    }
    var cd = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/,
        gd = {};

    function ed(a) {
        if (void 0 === $c) {
            var b = null;
            var c = p.trustedTypes;
            if (c && c.createPolicy) {
                try {
                    b = c.createPolicy("goog#html", {
                        createHTML: na,
                        createScript: na,
                        createScriptURL: na
                    })
                } catch (d) {
                    p.console && p.console.error(d.message)
                }
                $c = b
            } else $c = b
        }
        a = (b = $c) ? b.createScriptURL(a) : a;
        return new ad(a, gd)
    }

    function fd(a, b, c) {
        if (null == c) return b;
        if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
        for (var d in c)
            if (Object.prototype.hasOwnProperty.call(c, d)) {
                var e = c[d];
                e = Array.isArray(e) ? e : [e];
                for (var f = 0; f < e.length; f++) {
                    var g = e[f];
                    null != g && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
                }
            }
        return b
    };
    var hd = class {
        constructor(a) {
            this.g = a
        }
        toString() {
            return this.g.toString()
        }
    };

    function id(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    };

    function jd(a, b) {
        b = String(b);
        "application/xhtml+xml" === a.contentType && (b = b.toLowerCase());
        return a.createElement(b)
    }

    function kd(a) {
        this.g = a || p.document || document
    }
    kd.prototype.contains = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && 1 == b.nodeType) return a == b || a.contains(b);
        if ("undefined" != typeof a.compareDocumentPosition) return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };

    function ld() {
        return ta && wa ? wa.mobile : !md() && (q("iPod") || q("iPhone") || q("Android") || q("IEMobile"))
    }

    function md() {
        return ta && wa ? !wa.mobile && (q("iPad") || q("Android") || q("Silk")) : q("iPad") || q("Android") && !q("Mobile") || q("Silk")
    };
    var nd = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"),
        od = /#|$/;

    function pd(a, b) {
        var c = a.search(od);
        a: {
            var d = 0;
            for (var e = b.length; 0 <= (d = a.indexOf(b, d)) && d < c;) {
                var f = a.charCodeAt(d - 1);
                if (38 == f || 63 == f)
                    if (f = a.charCodeAt(d + e), !f || 61 == f || 38 == f || 35 == f) break a;
                d += e + 1
            }
            d = -1
        }
        if (0 > d) return null;
        e = a.indexOf("&", d);
        if (0 > e || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, -1 !== e ? e : 0).replace(/\+/g, " "))
    };

    function qd(a, b = `unexpected value ${a}!`) {
        throw Error(b);
    };
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    const rd = "alternate author bookmark canonical cite help icon license modulepreload next prefetch dns-prefetch prerender preconnect preload prev search subresource".split(" ");

    function sd(a) {
        try {
            var b;
            if (b = !!a && null != a.location.href) a: {
                try {
                    Oa(a.foo);
                    b = !0;
                    break a
                } catch (c) {}
                b = !1
            }
            return b
        } catch {
            return !1
        }
    }

    function td(a) {
        return sd(a.top) ? a.top : null
    }

    function ud(a, b) {
        const c = vd("SCRIPT", a);
        c.src = dd(b);
        (void 0) ? .tc || (b = (b = (c.ownerDocument && c.ownerDocument.defaultView || window).document.querySelector ? .("script[nonce]")) ? b.nonce || b.getAttribute("nonce") || "" : "") && c.setAttribute("nonce", b);
        return (a = a.getElementsByTagName("script")[0]) && a.parentNode ? (a.parentNode.insertBefore(c, a), c) : null
    }

    function wd(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    }

    function xd() {
        if (!globalThis.crypto) return Math.random();
        try {
            const a = new Uint32Array(1);
            globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch {
            return Math.random()
        }
    }

    function yd(a, b) {
        if (a)
            for (const c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    }

    function zd(a) {
        const b = a.length;
        if (0 == b) return 0;
        let c = 305419896;
        for (let d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return 0 < c ? c : 4294967296 + c
    }
    var Ad = /^([0-9.]+)px$/,
        Bd = /^(-?[0-9.]{1,30})$/;

    function Cd(a) {
        if (!Bd.test(a)) return null;
        a = Number(a);
        return isNaN(a) ? null : a
    }

    function R(a) {
        return (a = Ad.exec(a)) ? +a[1] : null
    }
    var Dd = (a, b) => {
            for (let e = 0; 50 > e; ++e) {
                try {
                    var c = !(!a.frames || !a.frames[b])
                } catch {
                    c = !1
                }
                if (c) return a;
                a: {
                    try {
                        const f = a.parent;
                        if (f && f != a) {
                            var d = f;
                            break a
                        }
                    } catch {}
                    d = null
                }
                if (!(a = d)) break
            }
            return null
        },
        Ed = Qc(() => ld() ? 2 : md() ? 1 : 0),
        Fd = a => {
            yd({
                display: "none"
            }, (b, c) => {
                a.style.setProperty(c, b, "important")
            })
        };
    let Gd = [];
    const Hd = () => {
        const a = Gd;
        Gd = [];
        for (const b of a) try {
            b()
        } catch {}
    };

    function Id() {
        var a = P(Uc).h(Jd.g, Jd.defaultValue),
            b = S.document;
        if (a.length && b.head)
            for (const c of a) c && b.head && (a = vd("META"), b.head.appendChild(a), a.httpEquiv = "origin-trial", a.content = c)
    }
    var Kd = () => {
            var a = Math.random;
            return Math.floor(a() * 2 ** 52)
        },
        Ld = a => {
            if ("number" !== typeof a.goog_pvsid) try {
                Object.defineProperty(a, "goog_pvsid", {
                    value: Kd(),
                    configurable: !1
                })
            } catch (b) {}
            return Number(a.goog_pvsid) || -1
        },
        Nd = a => {
            var b = Md;
            "complete" === b.readyState || "interactive" === b.readyState ? (Gd.push(a), 1 == Gd.length && (window.Promise ? Promise.resolve().then(Hd) : window.setImmediate ? setImmediate(Hd) : setTimeout(Hd, 0))) : b.addEventListener("DOMContentLoaded", a)
        };

    function vd(a, b = document) {
        return b.createElement(String(a).toLowerCase())
    };

    function Od(a, b, c = null, d = !1, e = !1) {
        Qd(a, b, c, d, e)
    }

    function Qd(a, b, c, d, e = !1) {
        a.google_image_requests || (a.google_image_requests = []);
        const f = vd("IMG", a.document);
        if (c || d) {
            const g = h => {
                c && c(h);
                if (d) {
                    h = a.google_image_requests;
                    const k = Ga(h, f);
                    0 <= k && Array.prototype.splice.call(h, k, 1)
                }
                Tc(f, "load", g);
                Tc(f, "error", g)
            };
            Sc(f, "load", g);
            Sc(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    }
    var Sd = (a, b) => {
            let c = `https://${"pagead2.googlesyndication.com"}/pagead/gen_204?id=${b}`;
            yd(a, (d, e) => {
                if (d || 0 === d) c += `&${e}=${encodeURIComponent(""+d)}`
            });
            Rd(c)
        },
        Rd = a => {
            var b = window;
            b.fetch ? b.fetch(a, {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }) : Od(b, a, void 0, !1, !1)
        };
    let Td = null;
    var Md = document,
        S = window;

    function Ud(a) {
        this.g = a || {
            cookie: ""
        }
    }
    Ud.prototype.set = function(a, b, c) {
        let d, e, f, g = !1,
            h;
        "object" === typeof c && (h = c.uc, g = c.vc || !1, f = c.domain || void 0, e = c.path || void 0, d = c.Ab);
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        void 0 === d && (d = -1);
        this.g.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (e ? ";path=" + e : "") + (0 > d ? "" : 0 == d ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + 1E3 * d)).toUTCString()) + (g ? ";secure" : "") + (null != h ? ";samesite=" + h : "")
    };
    Ud.prototype.get = function(a, b) {
        const c = a + "=",
            d = (this.g.cookie || "").split(";");
        for (let e = 0, f; e < d.length; e++) {
            f = pa(d[e]);
            if (0 == f.lastIndexOf(c, 0)) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    Ud.prototype.isEmpty = function() {
        return !this.g.cookie
    };
    Ud.prototype.clear = function() {
        var a = (this.g.cookie || "").split(";");
        const b = [];
        var c = [];
        let d, e;
        for (let f = 0; f < a.length; f++) e = pa(a[f]), d = e.indexOf("="), -1 == d ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (c = b.length - 1; 0 <= c; c--) a = b[c], this.get(a), this.set(a, "", {
            Ab: 0,
            path: void 0,
            domain: void 0
        })
    };

    function Vd(a, b = window) {
        if (K(a, 5)) try {
            return b.localStorage
        } catch {}
        return null
    }

    function Wd(a = window) {
        try {
            return a.localStorage
        } catch {
            return null
        }
    };

    function Xd(a, ...b) {
        if (0 === b.length) return ed(a[0]);
        let c = a[0];
        for (let d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return ed(c)
    };
    let Yd = null;
    var Zd = (a, b = []) => {
        let c = !1;
        p.google_logging_queue || (c = !0, p.google_logging_queue = []);
        p.google_logging_queue.push([a, b]);
        if (a = c) {
            if (null == Yd) {
                Yd = !1;
                try {
                    const d = td(p);
                    d && -1 !== d.location.hash.indexOf("google_logging") && (Yd = !0);
                    Wd(p) ? .getItem("google_logging") && (Yd = !0)
                } catch (d) {}
            }
            a = Yd
        }
        a && ud(p.document, Xd `https://pagead2.googlesyndication.com/pagead/js/logging_library.js`)
    };

    function $d(a = p) {
        let b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch {}
        return b ? .pageViewId && b ? .canonicalUrl ? b : null
    }

    function ae(a = $d()) {
        return a ? sd(a.master) ? a.master : null : null
    };
    var be = a => {
            a = ae($d(a)) || a;
            a.google_unique_id = (a.google_unique_id || 0) + 1;
            return a.google_unique_id
        },
        ce = a => {
            a = a.google_unique_id;
            return "number" === typeof a ? a : 0
        },
        de = () => {
            if (!S) return !1;
            try {
                return !(!S.navigator.standalone && !S.top.navigator.standalone)
            } catch (a) {
                return !1
            }
        },
        ee = a => {
            if (!a) return "";
            a = a.toLowerCase();
            "ca-" != a.substring(0, 3) && (a = "ca-" + a);
            return a
        };
    class fe {
        constructor(a, b) {
            this.error = a;
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror";
            this.meta = {}
        }
    }
    var ge = a => !!(a.error && a.meta && a.id);
    const he = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var ie = class {
            constructor(a, b) {
                this.g = a;
                this.h = b
            }
        },
        je = class {
            constructor(a, b, c) {
                this.url = a;
                this.l = b;
                this.Za = !!c;
                this.depth = null
            }
        };
    let ke = null;

    function le() {
        if (null === ke) {
            ke = "";
            try {
                let a = "";
                try {
                    a = p.top.location.hash
                } catch (b) {
                    a = p.location.hash
                }
                if (a) {
                    const b = a.match(/\bdeid=([\d,]+)/);
                    ke = b ? b[1] : ""
                }
            } catch (a) {}
        }
        return ke
    };

    function me() {
        const a = p.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function ne() {
        const a = p.performance;
        return a && a.now ? a.now() : null
    };
    var oe = class {
        constructor(a, b) {
            var c = ne() || me();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    const pe = p.performance,
        qe = !!(pe && pe.mark && pe.measure && pe.clearMarks),
        re = Qc(() => {
            var a;
            if (a = qe) a = le(), a = !!a.indexOf && 0 <= a.indexOf("1337");
            return a
        });

    function se(a) {
        a && pe && re() && (pe.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), pe.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }

    function te(a) {
        a.g = !1;
        a.h != a.i.google_js_reporting_queue && (re() && Ha(a.h, se), a.h.length = 0)
    }
    class ue {
        constructor(a) {
            this.h = [];
            this.i = a || p;
            let b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.h = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.g = re() || (null != b ? b : 1 > Math.random())
        }
        start(a, b) {
            if (!this.g) return null;
            a = new oe(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            pe && re() && pe.mark(b);
            return a
        }
        end(a) {
            if (this.g && "number" === typeof a.value) {
                a.duration = (ne() || me()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                pe && re() && pe.mark(b);
                !this.g || 2048 < this.h.length ||
                    this.h.push(a)
            }
        }
    };

    function ve(a, b) {
        const c = {};
        c[a] = b;
        return [c]
    }

    function we(a, b, c, d, e) {
        const f = [];
        yd(a, function(g, h) {
            (g = xe(g, b, c, d, e)) && f.push(h + "=" + g)
        });
        return f.join(b)
    }

    function xe(a, b, c, d, e) {
        if (null == a) return "";
        b = b || "&";
        c = c || ",$";
        "string" == typeof c && (c = c.split(""));
        if (a instanceof Array) {
            if (d = d || 0, d < c.length) {
                const f = [];
                for (let g = 0; g < a.length; g++) f.push(xe(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if ("object" == typeof a) return e = e || 0, 2 > e ? encodeURIComponent(we(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function ye(a) {
        let b = 1;
        for (const c in a.h) b = c.length > b ? c.length : b;
        return 3997 - b - a.i.length - 1
    }

    function ze(a, b) {
        let c = "https://pagead2.googlesyndication.com" + b,
            d = ye(a) - b.length;
        if (0 > d) return "";
        a.g.sort(function(f, g) {
            return f - g
        });
        b = null;
        let e = "";
        for (let f = 0; f < a.g.length; f++) {
            const g = a.g[f],
                h = a.h[g];
            for (let k = 0; k < h.length; k++) {
                if (!d) {
                    b = null == b ? g : b;
                    break
                }
                let m = we(h[k], a.i, ",$");
                if (m) {
                    m = e + m;
                    if (d >= m.length) {
                        d -= m.length;
                        c += m;
                        e = a.i;
                        break
                    }
                    b = null == b ? g : b
                }
            }
        }
        a = "";
        null != b && (a = e + "trn=" + b);
        return c + a
    }
    class Ae {
        constructor() {
            this.i = "&";
            this.h = {};
            this.j = 0;
            this.g = []
        }
    };

    function Be(a) {
        let b = a.toString();
        a.name && -1 == b.indexOf(a.name) && (b += ": " + a.name);
        a.message && -1 == b.indexOf(a.message) && (b += ": " + a.message);
        if (a.stack) {
            a = a.stack;
            var c = b;
            try {
                -1 == a.indexOf(c) && (a = c + "\n" + a);
                let d;
                for (; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                b = a.replace(RegExp("\n *", "g"), "\n")
            } catch (d) {
                b = c
            }
        }
        return b
    }
    var De = class {
        constructor(a, b, c = null) {
            this.B = a;
            this.C = b;
            this.h = c;
            this.g = null;
            this.i = !1;
            this.s = this.J
        }
        hb(a) {
            this.s = a
        }
        Da(a) {
            this.g = a
        }
        j(a) {
            this.i = a
        }
        ea(a, b, c) {
            let d, e;
            try {
                this.h && this.h.g ? (e = this.h.start(a.toString(), 3), d = b(), this.h.end(e)) : d = b()
            } catch (f) {
                b = this.C;
                try {
                    se(e), b = this.s(a, new fe(f, {
                        message: Be(f)
                    }), void 0, c)
                } catch (g) {
                    this.J(217, g)
                }
                if (b) window.console ? .error ? .(f);
                else throw f;
            }
            return d
        }
        oa(a, b) {
            return (...c) => this.ea(a, () => b.apply(void 0, c))
        }
        J(a, b, c, d, e) {
            e = e || "jserror";
            let f;
            try {
                const Ra = new Ae;
                var g = Ra;
                g.g.push(1);
                g.h[1] = ve("context", a);
                ge(b) || (b = new fe(b, {
                    message: Be(b)
                }));
                if (b.msg) {
                    g = Ra;
                    var h = b.msg.substring(0, 512);
                    g.g.push(2);
                    g.h[2] = ve("msg", h)
                }
                var k = b.meta || {};
                b = k;
                if (this.g) try {
                    this.g(b)
                } catch (Xa) {}
                if (d) try {
                    d(b)
                } catch (Xa) {}
                d = Ra;
                k = [k];
                d.g.push(3);
                d.h[3] = k;
                d = p;
                k = [];
                b = null;
                do {
                    var m = d;
                    if (sd(m)) {
                        var l = m.location.href;
                        b = m.document && m.document.referrer || null
                    } else l = b, b = null;
                    k.push(new je(l || "", m));
                    try {
                        d = m.parent
                    } catch (Xa) {
                        d = null
                    }
                } while (d && m != d);
                for (let Xa = 0, bg = k.length - 1; Xa <= bg; ++Xa) k[Xa].depth =
                    bg - Xa;
                m = p;
                if (m.location && m.location.ancestorOrigins && m.location.ancestorOrigins.length == k.length - 1)
                    for (l = 1; l < k.length; ++l) {
                        var n = k[l];
                        n.url || (n.url = m.location.ancestorOrigins[l - 1] || "", n.Za = !0)
                    }
                var w = k;
                let Cc = new je(p.location.href, p, !1);
                m = null;
                const Pd = w.length - 1;
                for (n = Pd; 0 <= n; --n) {
                    var v = w[n];
                    !m && he.test(v.url) && (m = v);
                    if (v.url && !v.Za) {
                        Cc = v;
                        break
                    }
                }
                v = null;
                const bk = w.length && w[Pd].url;
                0 != Cc.depth && bk && (v = w[Pd]);
                f = new ie(Cc, v);
                if (f.h) {
                    w = Ra;
                    var x = f.h.url || "";
                    w.g.push(4);
                    w.h[4] = ve("top", x)
                }
                var z = {
                    url: f.g.url ||
                        ""
                };
                if (f.g.url) {
                    var A = f.g.url.match(nd),
                        B = A[1],
                        J = A[3],
                        sa = A[4];
                    x = "";
                    B && (x += B + ":");
                    J && (x += "//", x += J, sa && (x += ":" + sa));
                    var cg = x
                } else cg = "";
                B = Ra;
                z = [z, {
                    url: cg
                }];
                B.g.push(5);
                B.h[5] = z;
                Ce(this.B, e, Ra, this.i, c)
            } catch (Ra) {
                try {
                    Ce(this.B, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: Be(Ra),
                        url: f && f.g.url
                    }, this.i, c)
                } catch (Cc) {}
            }
            return this.C
        }
        Y(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.J(a, c instanceof Error ? c : Error(c), void 0, this.g || void 0)
            })
        }
    };
    var Ee = a => "string" === typeof a,
        Fe = a => void 0 === a;
    var Ge = class extends N {};
    Ge.u = [2, 8];
    var He = [3, 4, 5],
        Ie = [6, 7];

    function Je(a) {
        return null != a ? !a : a
    }

    function Ke(a, b) {
        let c = !1;
        for (let d = 0; d < a.length; d++) {
            const e = a[d]();
            if (e === b) return e;
            null == e && (c = !0)
        }
        if (!c) return !b
    }

    function Le(a, b) {
        var c = F(a, Ge, 2);
        if (!c.length) return Me(a, b);
        a = M(a, 1);
        if (1 === a) return Je(Le(c[0], b));
        c = Ja(c, d => () => Le(d, b));
        switch (a) {
            case 2:
                return Ke(c, !1);
            case 3:
                return Ke(c, !0)
        }
    }

    function Me(a, b) {
        const c = pc(a, He);
        a: {
            switch (c) {
                case 3:
                    var d = M(a, oc(a, He, 3));
                    break a;
                case 4:
                    d = M(a, oc(a, He, 4));
                    break a;
                case 5:
                    d = M(a, oc(a, He, 5));
                    break a
            }
            d = void 0
        }
        if (d && (b = (b = b[c]) && b[d])) {
            try {
                var e = gc(a, 8, Mb);
                var f = b(...e)
            } catch (g) {
                return
            }
            e = M(a, 1);
            if (4 === e) return !!f;
            if (5 === e) return null != f;
            if (12 === e) a = L(a, oc(a, Ie, 7));
            else a: {
                switch (c) {
                    case 4:
                        a = yc(a, oc(a, Ie, 6));
                        break a;
                    case 5:
                        a = L(a, oc(a, Ie, 7));
                        break a
                }
                a = void 0
            }
            if (null != a) {
                if (6 === e) return f === a;
                if (9 === e) return null != f && 0 === qa(String(f), a);
                if (null != f) switch (e) {
                    case 7:
                        return f <
                            a;
                    case 8:
                        return f > a;
                    case 12:
                        return Ee(a) && Ee(f) && (new RegExp(a)).test(f);
                    case 10:
                        return null != f && -1 === qa(String(f), a);
                    case 11:
                        return null != f && 1 === qa(String(f), a)
                }
            }
        }
    }

    function Ne(a, b) {
        return !a || !(!b || !Le(a, b))
    };
    var Oe = class extends N {};
    Oe.u = [4];
    var Pe = class extends N {
        getValue() {
            return E(this, Oe, 2)
        }
    };
    var Qe = class extends N {},
        Re = Ic(Qe);
    Qe.u = [5];
    var Se = [1, 2, 3, 6, 7];
    var Te = class extends N {
        constructor() {
            super()
        }
    };

    function Ue(a, b) {
        try {
            const c = d => [{
                [d.Ea]: d.Ba
            }];
            return JSON.stringify([a.filter(d => d.la).map(c), b.toJSON(), a.filter(d => !d.la).map(c)])
        } catch (c) {
            return Ve(c, b), ""
        }
    }

    function Ve(a, b) {
        try {
            Sd({
                m: Be(a instanceof Error ? a : Error(String(a))),
                b: M(b, 1) || null,
                v: L(b, 2) || null
            }, "rcs_internal")
        } catch (c) {}
    }
    var We = class {
        constructor(a, b) {
            var c = new Te;
            a = D(c, 1, u(a), 0);
            b = Dc(a, 2, b);
            a = b.A;
            c = a[r];
            this.i = c & 2 ? b : Pb(b.constructor, $b(a, c, !0))
        }
    };
    var Xe = class extends N {
        constructor() {
            super()
        }
    };
    Xe.u = [2];

    function Ye(a) {
        var b = new Ze;
        return y(b, 1, u(a))
    }
    var Ze = class extends N {
        constructor() {
            super()
        }
        getValue() {
            return M(this, 1)
        }
    };

    function $e(a, b) {
        return Ac(a, 1, b)
    }

    function af(a, b) {
        return Ac(a, 2, b)
    }
    var bf = class extends N {
        constructor() {
            super()
        }
        getWidth() {
            return xc(this, 1)
        }
        getHeight() {
            return xc(this, 2)
        }
    };

    function cf(a, b) {
        return sc(a, 1, b)
    }

    function df(a, b) {
        return sc(a, 2, b)
    }

    function ef(a, b) {
        sc(a, 3, b)
    }

    function ff(a, b) {
        return D(a, 5, zb(b), !1)
    }
    var gf = class extends N {
        constructor() {
            super()
        }
        getContentUrl() {
            return L(this, 4)
        }
    };
    var rc = class extends N {};
    var hf = class extends N {};
    var jf = class extends N {
        constructor() {
            super()
        }
        getContentUrl() {
            return L(this, 1)
        }
    };

    function kf(a) {
        var b = new lf;
        return D(b, 1, u(a), 0)
    }
    var lf = class extends N {
        constructor() {
            super()
        }
    };

    function mf(a, b) {
        return tc(a, 4, nf, b)
    }
    var of = class extends N {
        constructor() {
            super()
        }
    }, nf = [4, 5, 6, 8, 9, 10, 11];
    var pf = class extends N {
        constructor() {
            super()
        }
    };

    function qf(a, b) {
        return D(a, 1, u(b), 0)
    }

    function rf(a, b) {
        return D(a, 2, u(b), 0)
    }
    var sf = class extends N {
        constructor() {
            super()
        }
    };
    var tf = class extends N {
            constructor() {
                super()
            }
        },
        uf = [1, 2];

    function vf(a, b) {
        return sc(a, 1, b)
    }

    function wf(a, b) {
        return uc(a, 2, b)
    }

    function xf(a, b) {
        return lc(a, 4, b, Db)
    }

    function yf(a, b) {
        return uc(a, 5, b)
    }

    function zf(a, b) {
        return D(a, 6, u(b), 0)
    }
    var Af = class extends N {
        constructor() {
            super()
        }
    };
    Af.u = [2, 4, 5];
    var Bf = class extends N {
        constructor() {
            super()
        }
    };
    Bf.u = [5];
    var Cf = [1, 2, 3, 4];
    var Df = class extends N {
        constructor() {
            super()
        }
    };
    Df.u = [2, 3];

    function Ef(a) {
        var b = new Ff;
        return tc(b, 4, Gf, a)
    }
    var Ff = class extends N {
            constructor() {
                super()
            }
            getTagSessionCorrelator() {
                return xc(this, 2)
            }
        },
        Gf = [4, 5, 7, 8];
    var Hf = class extends N {
        constructor() {
            super()
        }
    };
    var If = class extends N {
        constructor() {
            super()
        }
    };
    If.u = [4, 5];
    var Jf = class extends N {
        constructor() {
            super()
        }
        getTagSessionCorrelator() {
            return xc(this, 1)
        }
    };
    Jf.u = [2];
    var Kf = class extends N {
            constructor() {
                super()
            }
        },
        Lf = [4, 6];
    class Mf extends We {
        constructor() {
            super(...arguments)
        }
    }

    function Nf(a, ...b) {
        Of(a, ...b.map(c => ({
            la: !0,
            Ea: 3,
            Ba: c.toJSON()
        })))
    }

    function Pf(a, ...b) {
        Of(a, ...b.map(c => ({
            la: !0,
            Ea: 4,
            Ba: c.toJSON()
        })))
    }

    function Qf(a, ...b) {
        Of(a, ...b.map(c => ({
            la: !0,
            Ea: 7,
            Ba: c.toJSON()
        })))
    }
    var Rf = class extends Mf {};
    var Sf = (a, b) => {
        globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: 65536 > b.length,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(() => {})
    };

    function Of(a, ...b) {
        try {
            a.C && 65536 <= Ue(a.g.concat(b), a.i).length && Tf(a), a.j && !a.s && (a.s = !0, Uf(a.j, () => {
                Tf(a)
            })), a.g.push(...b), a.g.length >= a.B && Tf(a), a.g.length && null === a.h && (a.h = setTimeout(() => {
                Tf(a)
            }, a.H))
        } catch (c) {
            Ve(c, a.i)
        }
    }

    function Tf(a) {
        null !== a.h && (clearTimeout(a.h), a.h = null);
        if (a.g.length) {
            var b = Ue(a.g, a.i);
            a.D("https://pagead2.googlesyndication.com/pagead/ping?e=1", b);
            a.g = []
        }
    }
    var Vf = class extends Rf {
            constructor(a, b, c, d, e, f) {
                super(a, b);
                this.D = Sf;
                this.H = c;
                this.B = d;
                this.C = e;
                this.j = f;
                this.g = [];
                this.h = null;
                this.s = !1
            }
        },
        Wf = class extends Vf {
            constructor(a, b, c = 1E3, d = 100, e = !1, f) {
                super(a, b, c, d, e && !0, f)
            }
        };

    function Xf(a, b) {
        var c = Date.now();
        c = Number.isFinite(c) ? Math.round(c) : 0;
        b = Ac(b, 1, c);
        c = Ld(window);
        b = Ac(b, 2, c);
        return Ac(b, 6, a.s)
    }

    function Yf(a, b, c, d, e, f) {
        if (a.i) {
            var g = rf(qf(new sf, b), c);
            b = zf(wf(vf(yf(xf(new Af, d), e), g), a.g.slice()), f);
            b = Ef(b);
            Pf(a.h, Xf(a, b));
            if (1 === f || 3 === f || 4 === f && !a.g.some(h => M(h, 1) === M(g, 1) && M(h, 2) === c)) a.g.push(g), 100 < a.g.length && a.g.shift()
        }
    }

    function Zf(a, b, c, d) {
        if (a.i && a.j) {
            var e = new Df;
            b = uc(e, 2, b);
            c = uc(b, 3, c);
            d && D(c, 1, Eb(d), 0);
            d = new Ff;
            d = tc(d, 7, Gf, c);
            Pf(a.h, Xf(a, d))
        }
    }

    function $f(a, b, c, d) {
        if (a.i) {
            var e = new pf;
            b = y(e, 1, Eb(b));
            c = y(b, 2, Eb(c));
            d = y(c, 3, u(d));
            c = new Ff;
            d = tc(c, 8, Gf, d);
            Pf(a.h, Xf(a, d))
        }
    }
    var ag = class {
        constructor(a, b, c, d = new Wf(6, "unknown", b)) {
            this.s = a;
            this.j = c;
            this.h = d;
            this.g = [];
            this.i = 0 < a && xd() < 1 / a
        }
    };
    var dg = class {
        constructor() {
            this.I = {
                [3]: {},
                [4]: {},
                [5]: {}
            }
        }
    };
    var eg = /^true$/.test("false");

    function fg(a, b) {
        switch (b) {
            case 1:
                return M(a, oc(a, Se, 1));
            case 2:
                return M(a, oc(a, Se, 2));
            case 3:
                return M(a, oc(a, Se, 3));
            case 6:
                return M(a, oc(a, Se, 6));
            default:
                return null
        }
    }

    function gg(a, b) {
        if (!a) return null;
        switch (b) {
            case 1:
                return K(a, 1);
            case 7:
                return L(a, 3);
            case 2:
                return yc(a, 2);
            case 3:
                return L(a, 3);
            case 6:
                return gc(a, 4, Mb);
            default:
                return null
        }
    }
    const hg = Qc(() => {
        if (!eg) return {};
        try {
            var a = window;
            try {
                var b = a.sessionStorage
            } catch {
                b = null
            }
            if (b = b ? .getItem("GGDFSSK")) return JSON.parse(b)
        } catch {}
        return {}
    });

    function ig(a, b, c, d = 0) {
        P(jg).i[d] = P(jg).i[d] ? .add(b) ? ? (new Set).add(b);
        const e = hg();
        if (null != e[b]) return e[b];
        b = kg(d)[b];
        if (!b) return c;
        b = Re(JSON.stringify(b));
        b = lg(b);
        a = gg(b, a);
        return null != a ? a : c
    }

    function lg(a) {
        const b = P(dg).I;
        if (b) {
            const c = La(F(a, Pe, 5), d => Ne(E(d, Ge, 1), b));
            if (c) return c.getValue() ? ? null
        }
        return E(a, Oe, 4) ? ? null
    }
    class jg {
        constructor() {
            this.h = {};
            this.j = [];
            this.i = {};
            this.g = new Map
        }
    }

    function mg(a, b = !1, c) {
        return !!ig(1, a, b, c)
    }

    function ng(a, b = 0, c) {
        a = Number(ig(2, a, b, c));
        return isNaN(a) ? b : a
    }

    function og(a, b = "", c) {
        a = ig(3, a, b, c);
        return "string" === typeof a ? a : b
    }

    function pg(a, b = [], c) {
        a = ig(6, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function kg(a) {
        return P(jg).h[a] || (P(jg).h[a] = {})
    }

    function qg(a, b) {
        const c = kg(b);
        yd(a, (d, e) => c[e] = d)
    }

    function rg(a, b, c, d, e = !1) {
        const f = [],
            g = [];
        Ha(b, h => {
            const k = kg(h);
            Ha(a, m => {
                var l = pc(m, Se);
                const n = fg(m, l);
                if (n) {
                    var w = P(jg).g.get(h) ? .get(n) ? .slice(0) ? ? [];
                    a: {
                        const v = new Bf;
                        switch (l) {
                            case 1:
                                mc(v, 1, Cf, u(n));
                                break;
                            case 2:
                                mc(v, 2, Cf, u(n));
                                break;
                            case 3:
                                mc(v, 3, Cf, u(n));
                                break;
                            case 6:
                                mc(v, 4, Cf, u(n));
                                break;
                            default:
                                l = void 0;
                                break a
                        }
                        lc(v, 5, w, Db);l = v
                    }
                    if (w = l) w = !!P(jg).i[h] ? .has(n);
                    w && f.push(l);
                    if (w = l) w = !!P(jg).g.get(h) ? .has(n);
                    w && g.push(l);
                    e || (l = P(jg), l.g.has(h) || l.g.set(h, new Map), l.g.get(h).has(n) || l.g.get(h).set(n, []), d && l.g.get(h).get(n).push(d));
                    k[n] = m.toJSON()
                }
            })
        });
        (f.length || g.length) && Zf(c, f, g, d ? ? void 0)
    }

    function sg(a, b) {
        const c = kg(b);
        Ha(a, d => {
            var e = Re(JSON.stringify(d));
            const f = pc(e, Se);
            (e = fg(e, f)) && (c[e] || (c[e] = d))
        })
    }

    function tg() {
        return Ja(Object.keys(P(jg).h), a => Number(a))
    }

    function ug(a) {
        Ma(P(jg).j, a) || qg(kg(4), a)
    };

    function T(a, b, c) {
        c.hasOwnProperty(a) || Object.defineProperty(c, String(a), {
            value: b
        })
    }

    function vg(a, b, c) {
        return b[a] || c
    }

    function wg(a) {
        T(5, mg, a);
        T(6, ng, a);
        T(7, og, a);
        T(8, pg, a);
        T(13, sg, a);
        T(15, ug, a)
    }

    function xg(a) {
        T(4, b => {
            P(dg).I = b
        }, a);
        T(9, (b, c) => {
            var d = P(dg);
            null == d.I[3][b] && (d.I[3][b] = c)
        }, a);
        T(10, (b, c) => {
            var d = P(dg);
            null == d.I[4][b] && (d.I[4][b] = c)
        }, a);
        T(11, (b, c) => {
            var d = P(dg);
            null == d.I[5][b] && (d.I[5][b] = c)
        }, a);
        T(14, b => {
            var c = P(dg);
            for (const d of [3, 4, 5]) Object.assign(c.I[d], b[d])
        }, a)
    }

    function yg(a) {
        a.hasOwnProperty("init-done") || Object.defineProperty(a, "init-done", {
            value: !0
        })
    };

    function zg(a, b, c) {
        a.i = vg(1, b, () => {});
        a.j = (d, e) => vg(2, b, () => [])(d, c, e);
        a.g = () => vg(3, b, () => [])(c);
        a.h = d => {
            vg(16, b, () => {})(d, c)
        }
    }
    class Ag {
        i() {}
        h() {}
        j() {
            return []
        }
        g() {
            return []
        }
    };

    function Ce(a, b, c, d = !1, e) {
        if ((d ? a.g : Math.random()) < (e || .01)) try {
            let f;
            c instanceof Ae ? f = c : (f = new Ae, yd(c, (h, k) => {
                var m = f;
                const l = m.j++;
                h = ve(k, h);
                m.g.push(l);
                m.h[l] = h
            }));
            const g = ze(f, "/pagead/gen_204?id=" + b + "&");
            g && Od(p, g)
        } catch (f) {}
    }

    function Bg(a, b) {
        0 <= b && 1 >= b && (a.g = b)
    }
    class Cg {
        constructor() {
            this.g = Math.random()
        }
    };
    let Dg, Eg;
    const Fg = new ue(window);
    (a => {
        Dg = a ? ? new Cg;
        "number" !== typeof window.google_srt && (window.google_srt = Math.random());
        Bg(Dg, window.google_srt);
        Eg = new De(Dg, !0, Fg);
        Eg.Da(() => {});
        Eg.j(!0);
        "complete" == window.document.readyState ? window.google_measure_js_timing || te(Fg) : Fg.g && Sc(window, "load", () => {
            window.google_measure_js_timing || te(Fg)
        })
    })();
    var Gg = {
        ac: 0,
        Zb: 1,
        Wb: 2,
        Rb: 3,
        Xb: 4,
        Sb: 5,
        Yb: 6,
        Ub: 7,
        Vb: 8,
        Qb: 9,
        Tb: 10,
        bc: 11
    };
    var Hg = {
        dc: 0,
        ec: 1,
        cc: 2
    };

    function Ig(a) {
        if (0 != a.g) throw Error("Already resolved/rejected.");
    }
    var Lg = class {
        constructor() {
            this.h = new Jg(this);
            this.g = 0
        }
        resolve(a) {
            Ig(this);
            this.g = 1;
            this.j = a;
            Kg(this.h)
        }
    };

    function Kg(a) {
        switch (a.g.g) {
            case 0:
                break;
            case 1:
                a.h && a.h(a.g.j);
                break;
            case 2:
                a.i && a.i(a.g.i);
                break;
            default:
                throw Error("Unhandled deferred state.");
        }
    }
    var Jg = class {
        constructor(a) {
            this.g = a
        }
        then(a, b) {
            if (this.h) throw Error("Then functions already set.");
            this.h = a;
            this.i = b;
            Kg(this)
        }
    };
    const Mg = class {
        constructor(a) {
            this.g = a.slice(0)
        }
        forEach(a) {
            this.g.forEach((b, c) => void a(b, c, this))
        }
        filter(a) {
            return new Mg(Ia(this.g, a))
        }
        apply(a) {
            return new Mg(a(this.g.slice(0)))
        }
        sort(a) {
            return new Mg(this.g.slice(0).sort(a))
        }
        get(a) {
            return this.g[a]
        }
        add(a) {
            const b = this.g.slice(0);
            b.push(a);
            return new Mg(b)
        }
    };

    function Ng(a, b) {
        for (var c = [], d = a.length, e = 0; e < d; e++) c.push(a[e]);
        c.forEach(b, void 0)
    };
    const Pg = class {
        constructor() {
            this.g = {};
            this.h = {}
        }
        set(a, b) {
            const c = Og(a);
            this.g[c] = b;
            this.h[c] = a
        }
        get(a, b) {
            a = Og(a);
            return void 0 !== this.g[a] ? this.g[a] : b
        }
        clear() {
            this.g = {};
            this.h = {}
        }
    };

    function Og(a) {
        return a instanceof Object ? String(ea(a)) : a + ""
    };

    function Qg(a) {
        return new Rg({
            value: a
        }, null)
    }

    function Sg(a) {
        return new Rg(null, a)
    }

    function Tg(a) {
        try {
            return Qg(a())
        } catch (b) {
            return Sg(b)
        }
    }

    function Ug(a) {
        return null != a.g ? a.getValue() : null
    }

    function Vg(a, b) {
        null != a.g && b(a.getValue());
        return a
    }

    function Wg(a, b) {
        null != a.g || b(a.h);
        return a
    }
    class Rg {
        constructor(a, b) {
            this.g = a;
            this.h = b
        }
        getValue() {
            return this.g.value
        }
        map(a) {
            return null != this.g ? (a = a(this.getValue()), a instanceof Rg ? a : Qg(a)) : this
        }
    };
    const Xg = class {
        constructor(a) {
            this.g = new Pg;
            if (a)
                for (var b = 0; b < a.length; ++b) this.add(a[b])
        }
        add(a) {
            this.g.set(a, !0)
        }
        contains(a) {
            return void 0 !== this.g.g[Og(a)]
        }
    };
    class Yg {
        constructor() {
            this.g = new Pg
        }
        set(a, b) {
            let c = this.g.get(a);
            c || (c = new Xg, this.g.set(a, c));
            c.add(b)
        }
    };
    var U = class extends N {
        getId() {
            return H(this, 3)
        }
    };
    U.u = [4];
    class Zg {
        constructor({
            mb: a,
            hc: b,
            rc: c,
            Eb: d
        }) {
            this.g = b;
            this.j = new Mg(a || []);
            this.i = d;
            this.h = c
        }
    };
    const ah = a => {
            const b = [],
                c = a.j;
            c && c.g.length && b.push({
                V: "a",
                da: $g(c)
            });
            null != a.g && b.push({
                V: "as",
                da: a.g
            });
            null != a.h && b.push({
                V: "i",
                da: String(a.h)
            });
            null != a.i && b.push({
                V: "rp",
                da: String(a.i)
            });
            b.sort(function(d, e) {
                return d.V.localeCompare(e.V)
            });
            b.unshift({
                V: "t",
                da: "aa"
            });
            return b
        },
        $g = a => {
            a = a.g.slice(0).map(bh);
            a = JSON.stringify(a);
            return zd(a)
        },
        bh = a => {
            const b = {};
            null != H(a, 7) && (b.q = H(a, 7));
            null != G(a, 2) && (b.o = G(a, 2));
            null != G(a, 5) && (b.p = G(a, 5));
            return b
        };
    var ch = class extends N {
        setLocation(a) {
            return y(this, 1, u(a))
        }
    };

    function dh(a) {
        const b = [].slice.call(arguments).filter(Pc(e => null === e));
        if (!b.length) return null;
        let c = [],
            d = {};
        b.forEach(e => {
            c = c.concat(e.Wa || []);
            d = Object.assign(d, e.gb)
        });
        return new eh(c, d)
    }

    function fh(a) {
        switch (a) {
            case 1:
                return new eh(null, {
                    google_ad_semantic_area: "mc"
                });
            case 2:
                return new eh(null, {
                    google_ad_semantic_area: "h"
                });
            case 3:
                return new eh(null, {
                    google_ad_semantic_area: "f"
                });
            case 4:
                return new eh(null, {
                    google_ad_semantic_area: "s"
                });
            default:
                return null
        }
    }

    function gh(a) {
        if (null == a) var b = null;
        else {
            var c = ah(a);
            a = [];
            for (b of c) c = String(b.da), a.push(b.V + "." + (20 >= c.length ? c : c.slice(0, 19) + "_"));
            b = new eh(null, {
                google_placement_id: a.join("~")
            })
        }
        return b
    }
    class eh {
        constructor(a, b) {
            this.Wa = a;
            this.gb = b
        }
    };
    const hh = new eh(["google-auto-placed"], {
        google_reactive_ad_format: 40,
        google_tag_origin: "qs"
    });
    var ih = Ic(class extends N {});
    var jh = class extends N {};
    var kh = class extends N {};
    var lh = class extends N {};
    lh.u = [6, 7, 9, 10, 11];
    var mh = class extends N {};
    var nh = class extends N {
        constructor() {
            super()
        }
    };
    nh.u = [1];

    function oh(a) {
        if (1 != a.nodeType) var b = !1;
        else if (b = "INS" == a.tagName) a: {
            b = ["adsbygoogle-placeholder"];a = a.className ? a.className.split(/\s+/) : [];
            for (var c = {}, d = 0; d < a.length; ++d) c[a[d]] = !0;
            for (d = 0; d < b.length; ++d)
                if (!c[b[d]]) {
                    b = !1;
                    break a
                }
            b = !0
        }
        return b
    };
    var ph = new O(1271),
        qh = new O(1308, !0),
        rh = new Lc(1130, 100),
        sh = new Mc(14),
        th = new O(1247, !0),
        uh = new O(1272),
        vh = new O(316),
        wh = new O(1207, !0),
        xh = new O(313),
        yh = new O(369),
        zh = new O(1289),
        Ah = new O(1302),
        Bh = new O(217),
        Ch = new O(1314),
        Dh = new Mc(1307),
        Eh = new Lc(572636916, 25),
        Fh = new Lc(579884443),
        Gh = new Nc(556791602, ["1", "2", "4", "6"]),
        Hh = new O(579884441),
        Ih = new Lc(572636915, 150),
        Jh = new Lc(579884442),
        Kh = new O(506914611),
        Lh = new O(506852289),
        Mh = new O(1120),
        Nh = new O(567362967, !0),
        Oh = new Lc(1079, 5),
        Ph = new O(10009, !0),
        Jd = new Nc(1934, ["As0hBNJ8h++fNYlkq8cTye2qDLyom8NddByiVytXGGD0YVE+2CEuTCpqXMDxdhOMILKoaiaYifwEvCRlJ/9GcQ8AAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==", "AgRYsXo24ypxC89CJanC+JgEmraCCBebKl8ZmG7Tj5oJNx0cmH0NtNRZs3NB5ubhpbX/bIt7l2zJOSyO64NGmwMAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==",
            "A/ERL66fN363FkXxgDc6F1+ucRUkAhjEca9W3la6xaLnD2Y1lABsqmdaJmPNaUKPKVBRpyMKEhXYl7rSvrQw+AkAAACNeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MTkzNTk5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9", "A6OdGH3fVf4eKRDbXb4thXA4InNqDJDRhZ8U533U/roYjp4Yau0T3YSuc63vmAs/8ga1cD0E3A7LEq6AXk1uXgsAAACTeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MTkzNTk5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9"
        ]),
        Qh = new O(84);

    function Rh(a, b, c) {
        switch (c) {
            case 0:
                b.parentNode && b.parentNode.insertBefore(a, b);
                break;
            case 3:
                if (c = b.parentNode) {
                    var d = b.nextSibling;
                    if (d && d.parentNode != c)
                        for (; d && 8 == d.nodeType;) d = d.nextSibling;
                    c.insertBefore(a, d)
                }
                break;
            case 1:
                b.insertBefore(a, b.firstChild);
                break;
            case 2:
                b.appendChild(a)
        }
        oh(b) && (b.setAttribute("data-init-display", b.style.display), b.style.display = "block")
    };

    function Sh(a, b) {
        const c = e => {
                e = Th(e);
                return null == e ? !1 : 0 < e
            },
            d = e => {
                e = Th(e);
                return null == e ? !1 : 0 > e
            };
        switch (b) {
            case 0:
                return {
                    init: Uh(a.previousSibling, c),
                    ha: e => Uh(e.previousSibling, c),
                    na: 0
                };
            case 2:
                return {
                    init: Uh(a.lastChild, c),
                    ha: e => Uh(e.previousSibling, c),
                    na: 0
                };
            case 3:
                return {
                    init: Uh(a.nextSibling, d),
                    ha: e => Uh(e.nextSibling, d),
                    na: 3
                };
            case 1:
                return {
                    init: Uh(a.firstChild, d),
                    ha: e => Uh(e.nextSibling, d),
                    na: 3
                }
        }
        throw Error("Un-handled RelativePosition: " + b);
    }

    function Th(a) {
        return a.hasOwnProperty("google-ama-order-assurance") ? a["google-ama-order-assurance"] : null
    }

    function Uh(a, b) {
        return a && b(a) ? a : null
    };
    var Vh = {
        rectangle: 1,
        horizontal: 2,
        vertical: 4
    };
    var Wh = {
        overlays: 1,
        interstitials: 2,
        vignettes: 2,
        inserts: 3,
        immersives: 4,
        list_view: 5,
        full_page: 6,
        side_rails: 7
    };

    function Xh(a) {
        a = a.document;
        let b = {};
        a && (b = "CSS1Compat" == a.compatMode ? a.documentElement : a.body);
        return b || {}
    }

    function Yh(a) {
        return Xh(a).clientWidth
    };

    function Zh(a, b) {
        do {
            const c = wd(a, b);
            if (c && "fixed" == c.position) return !1
        } while (a = a.parentElement);
        return !0
    };

    function $h(a, b) {
        var c = ["width", "height"];
        for (let e = 0; e < c.length; e++) {
            const f = "google_ad_" + c[e];
            if (!b.hasOwnProperty(f)) {
                var d = R(a[c[e]]);
                d = null === d ? null : Math.round(d);
                null != d && (b[f] = d)
            }
        }
    }
    var ai = (a, b) => !((Bd.test(b.google_ad_width) || Ad.test(a.style.width)) && (Bd.test(b.google_ad_height) || Ad.test(a.style.height))),
        ci = (a, b) => (a = bi(a, b)) ? a.y : 0,
        bi = (a, b) => {
            try {
                const c = b.document.documentElement.getBoundingClientRect(),
                    d = a.getBoundingClientRect();
                return {
                    x: d.left - c.left,
                    y: d.top - c.top
                }
            } catch (c) {
                return null
            }
        },
        di = (a, b, c, d, e) => {
            if (a !== a.top) return td(a) ? 3 : 16;
            if (!(488 > Yh(a))) return 4;
            if (!(a.innerHeight >= a.innerWidth)) return 5;
            const f = Yh(a);
            if (!f || (f - c) / f > d) a = 6;
            else {
                if (c = "true" != e.google_full_width_responsive) a: {
                    c =
                    b.parentElement;
                    for (b = Yh(a); c; c = c.parentElement)
                        if ((d = wd(c, a)) && (e = R(d.width)) && !(e >= b) && "visible" != d.overflow) {
                            c = !0;
                            break a
                        }
                    c = !1
                }
                a = c ? 7 : !0
            }
            return a
        },
        ei = (a, b, c, d) => {
            const e = di(b, c, a, .3, d);
            !0 !== e ? a = e : "true" == d.google_full_width_responsive || Zh(c, b) ? (b = Yh(b), a = b - a, a = b && 0 <= a ? !0 : b ? -10 > a ? 11 : 0 > a ? 14 : 12 : 10) : a = 9;
            return a
        },
        fi = (a, b, c) => {
            a = a.style;
            "rtl" == b ? a.marginRight = c : a.marginLeft = c
        };
    const gi = (a, b) => {
            if (3 == b.nodeType) return /\S/.test(b.data);
            if (1 == b.nodeType) {
                if (/^(script|style)$/i.test(b.nodeName)) return !1;
                let c;
                try {
                    c = wd(b, a)
                } catch (d) {}
                return !c || "none" != c.display && !("absolute" == c.position && ("hidden" == c.visibility || "collapse" == c.visibility))
            }
            return !1
        },
        hi = (a, b, c) => {
            a = bi(b, a);
            return "rtl" == c ? -a.x : a.x
        };
    var ii = (a, b) => {
        var c;
        c = (c = b.parentElement) ? (c = wd(c, a)) ? c.direction : "" : "";
        if (c) {
            b.style.border = b.style.borderStyle = b.style.outline = b.style.outlineStyle = b.style.transition = "none";
            b.style.borderSpacing = b.style.padding = "0";
            fi(b, c, "0px");
            b.style.width = Yh(a) + "px";
            if (0 !== hi(a, b, c)) {
                fi(b, c, "0px");
                var d = hi(a, b, c);
                fi(b, c, -1 * d + "px");
                a = hi(a, b, c);
                0 !== a && a !== d && fi(b, c, d / (a - d) * d + "px")
            }
            b.style.zIndex = 30
        }
    };
    var ji = class {
        constructor(a, b) {
            this.U = a;
            this.i = b
        }
        height() {
            return this.i
        }
        g(a) {
            return 300 < a && 300 < this.i ? this.U : Math.min(1200, Math.round(a))
        }
        h() {}
    };
    var ki = (a, b, c, d = e => e) => {
            let e;
            return a.style && a.style[c] && d(a.style[c]) || (e = wd(a, b)) && e[c] && d(e[c]) || null
        },
        li = a => b => b.U <= a,
        oi = (a, b, c, d) => {
            const e = a && mi(c, b),
                f = ni(b, d);
            return g => !(e && g.height() >= f)
        },
        pi = a => b => b.height() <= a,
        mi = (a, b) => ci(a, b) < Xh(b).clientHeight - 100,
        qi = (a, b) => {
            var c = ki(b, a, "height", R);
            if (c) return c;
            var d = b.style.height;
            b.style.height = "inherit";
            c = ki(b, a, "height", R);
            b.style.height = d;
            if (c) return c;
            c = Infinity;
            do(d = b.style && R(b.style.height)) && (c = Math.min(c, d)), (d = ki(b, a, "maxHeight", R)) && (c =
                Math.min(c, d)); while ((b = b.parentElement) && "HTML" != b.tagName);
            return c
        };
    const ni = (a, b) => {
        const c = 0 == ce(a);
        return b && c ? Math.max(250, 2 * Xh(a).clientHeight / 3) : 250
    };
    var ri = {
        google_ad_channel: !0,
        google_ad_client: !0,
        google_ad_host: !0,
        google_ad_host_channel: !0,
        google_adtest: !0,
        google_tag_for_child_directed_treatment: !0,
        google_tag_for_under_age_of_consent: !0,
        google_tag_partner: !0,
        google_restrict_data_processing: !0,
        google_page_url: !0,
        google_debug_params: !0,
        google_shadow_mode: !0,
        google_adbreak_test: !0,
        google_ad_frequency_hint: !0,
        google_admob_interstitial_slot: !0,
        google_admob_rewarded_slot: !0,
        google_admob_ads_only: !0,
        google_ad_start_delay_hint: !0,
        google_max_ad_content_rating: !0,
        google_traffic_source: !0,
        google_overlays: !0,
        google_privacy_treatments: !0,
        google_xz: !0
    };
    const si = RegExp("(^| )adsbygoogle($| )");

    function ti(a, b) {
        for (let c = 0; c < b.length; c++) {
            const d = b[c],
                e = id(d.property);
            a[e] = d.value
        }
    };
    var ui = class extends N {};
    var vi = class extends N {};
    var wi = class extends N {
        g() {
            return fc(this, 23)
        }
    };
    var xi = class extends N {};
    var yi = class extends N {};
    var zi = class extends N {};
    var Ai = class extends N {};
    var Bi = class extends N {};
    var Ci = class extends N {
            getName() {
                return H(this, 4)
            }
        },
        Di = [1, 2, 3];
    var Ei = class extends N {};
    Ei.u = [2, 5, 6, 11];
    var Fi = class extends N {};
    var Hi = class extends N {
            g() {
                return zc(this, Fi, 2, Gi)
            }
        },
        Gi = [1, 2];
    var Ii = class extends N {
        g() {
            return E(this, Hi, 3)
        }
    };
    Ii.u = [1, 4];
    var Ji = class extends N {},
        Ki = Ic(Ji);
    Ji.u = [1, 2, 5, 7];

    function Li(a) {
        var b = [];
        Ng(a.getElementsByTagName("p"), function(c) {
            100 <= Mi(c) && b.push(c)
        });
        return b
    }

    function Mi(a) {
        if (3 == a.nodeType) return a.length;
        if (1 != a.nodeType || "SCRIPT" == a.tagName) return 0;
        var b = 0;
        Ng(a.childNodes, function(c) {
            b += Mi(c)
        });
        return b
    }

    function Ni(a) {
        return 0 == a.length || isNaN(a[0]) ? a : "\\" + (30 + parseInt(a[0], 10)) + " " + a.substring(1)
    }

    function Oi(a, b) {
        if (null == a.g) return b;
        switch (a.g) {
            case 1:
                return b.slice(1);
            case 2:
                return b.slice(0, b.length - 1);
            case 3:
                return b.slice(1, b.length - 1);
            case 0:
                return b;
            default:
                throw Error("Unknown ignore mode: " + a.g);
        }
    }
    const Pi = class {
        constructor(a, b, c, d) {
            this.j = a;
            this.h = b;
            this.i = c;
            this.g = d
        }
        query(a) {
            var b = [];
            try {
                b = a.querySelectorAll(this.j)
            } catch (f) {}
            if (!b.length) return [];
            a = Na(b);
            a = Oi(this, a);
            "number" === typeof this.h && (b = this.h, 0 > b && (b += a.length), a = 0 <= b && b < a.length ? [a[b]] : []);
            if ("number" === typeof this.i) {
                b = [];
                for (var c = 0; c < a.length; c++) {
                    var d = Li(a[c]),
                        e = this.i;
                    0 > e && (e += d.length);
                    0 <= e && e < d.length && b.push(d[e])
                }
                a = b
            }
            return a
        }
        toString() {
            return JSON.stringify({
                nativeQuery: this.j,
                occurrenceIndex: this.h,
                paragraphIndex: this.i,
                ignoreMode: this.g
            })
        }
    };
    class Qi {
        constructor() {
            var a = Xd `https://pagead2.googlesyndication.com/pagead/js/err_rep.js`;
            this.g = null;
            this.i = !1;
            this.s = Math.random();
            this.h = this.J;
            this.B = a
        }
        Da(a) {
            this.g = a
        }
        j(a) {
            this.i = a
        }
        hb(a) {
            this.h = a
        }
        J(a, b, c = .01, d, e = "jserror") {
            if ((this.i ? this.s : Math.random()) > c) return !1;
            ge(b) || (b = new fe(b, {
                context: a,
                id: e
            }));
            if (d || this.g) b.meta = {}, this.g && this.g(b.meta), d && d(b.meta);
            p.google_js_errors = p.google_js_errors || [];
            p.google_js_errors.push(b);
            p.error_rep_loaded || (ud(p.document, this.B), p.error_rep_loaded = !0);
            return !1
        }
        ea(a, b, c) {
            try {
                return b()
            } catch (d) {
                if (!this.h(a, d, .01, c, "jserror")) throw d;
            }
        }
        oa(a, b) {
            return (...c) => this.ea(a, () => b.apply(void 0, c))
        }
        Y(a, b) {
            b.catch(c => {
                c = c ? c : "unknown rejection";
                this.J(a, c instanceof Error ? c : Error(c), void 0, this.g || void 0)
            })
        }
    };
    const Ri = (a, b) => {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        2048 > b.length && b.push(a)
    };
    var Si = (a, b, c, d, e = !1) => {
            const f = d || window,
                g = "undefined" !== typeof queueMicrotask;
            return function() {
                e && g && queueMicrotask(() => {
                    f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1;
                    f.google_rum_task_id_counter += 1
                });
                const h = ne();
                let k, m = 3;
                try {
                    k = b.apply(this, arguments)
                } catch (l) {
                    m = 13;
                    if (!c) throw l;
                    c(a, l)
                } finally {
                    f.google_measure_js_timing && h && Ri({
                        label: a.toString(),
                        value: h,
                        duration: (ne() || 0) - h,
                        type: m,
                        ...(e && g && {
                            taskId: f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1
                        })
                    }, f)
                }
                return k
            }
        },
        Ti = (a, b) => Si(a, b, (c, d) => {
            (new Qi).J(c, d)
        }, void 0, !1);

    function Ui(a, b, c) {
        return Si(a, b, void 0, c, !0).apply()
    }

    function Vi(a) {
        if (!a) return null;
        var b = H(a, 7);
        if (H(a, 1) || a.getId() || 0 < gc(a, 4, Mb).length) {
            var c = H(a, 3),
                d = H(a, 1),
                e = gc(a, 4, Mb);
            b = G(a, 2);
            var f = G(a, 5);
            a = Wi(I(a, 6));
            var g = "";
            d && (g += d);
            c && (g += "#" + Ni(c));
            if (e)
                for (c = 0; c < e.length; c++) g += "." + Ni(e[c]);
            b = (e = g) ? new Pi(e, b, f, a) : null
        } else b = b ? new Pi(b, G(a, 2), G(a, 5), Wi(I(a, 6))) : null;
        return b
    }
    var Xi = {
        1: 1,
        2: 2,
        3: 3,
        0: 0
    };

    function Wi(a) {
        return null == a ? a : Xi[a]
    }
    var Yi = {
        1: 0,
        2: 1,
        3: 2,
        4: 3
    };

    function Zi(a) {
        return a.google_ama_state = a.google_ama_state || {}
    }

    function $i(a) {
        a = Zi(a);
        return a.optimization = a.optimization || {}
    };
    var aj = a => {
        switch (I(a, 8)) {
            case 1:
            case 2:
                if (null == a) var b = null;
                else b = E(a, U, 1), null == b ? b = null : (a = I(a, 2), b = null == a ? null : new Zg({
                    mb: [b],
                    Eb: a
                }));
                return null != b ? Qg(b) : Sg(Error("Missing dimension when creating placement id"));
            case 3:
                return Sg(Error("Missing dimension when creating placement id"));
            default:
                return Sg(Error("Invalid type: " + I(a, 8)))
        }
    };
    var bj = (a, b) => {
        const c = [];
        let d = a;
        for (a = () => {
                c.push({
                    anchor: d.anchor,
                    position: d.position
                });
                return d.anchor == b.anchor && d.position == b.position
            }; d;) {
            switch (d.position) {
                case 1:
                    if (a()) return c;
                    d.position = 2;
                case 2:
                    if (a()) return c;
                    if (d.anchor.firstChild) {
                        d = {
                            anchor: d.anchor.firstChild,
                            position: 1
                        };
                        continue
                    } else d.position = 3;
                case 3:
                    if (a()) return c;
                    d.position = 4;
                case 4:
                    if (a()) return c
            }
            for (; d && !d.anchor.nextSibling && d.anchor.parentNode != d.anchor.ownerDocument.body;) {
                d = {
                    anchor: d.anchor.parentNode,
                    position: 3
                };
                if (a()) return c;
                d.position = 4;
                if (a()) return c
            }
            d && d.anchor.nextSibling ? d = {
                anchor: d.anchor.nextSibling,
                position: 1
            } : d = null
        }
        return c
    };

    function cj(a, b) {
        const c = new Yg,
            d = new Xg;
        b.forEach(e => {
            if (zc(e, Ai, 1, Di)) {
                e = zc(e, Ai, 1, Di);
                if (E(e, jh, 1) && E(E(e, jh, 1), U, 1) && E(e, jh, 2) && E(E(e, jh, 2), U, 1)) {
                    const g = dj(a, E(E(e, jh, 1), U, 1)),
                        h = dj(a, E(E(e, jh, 2), U, 1));
                    if (g && h)
                        for (var f of bj({
                                anchor: g,
                                position: I(E(e, jh, 1), 2)
                            }, {
                                anchor: h,
                                position: I(E(e, jh, 2), 2)
                            })) c.set(ea(f.anchor), f.position)
                }
                E(e, jh, 3) && E(E(e, jh, 3), U, 1) && (f = dj(a, E(E(e, jh, 3), U, 1))) && c.set(ea(f), I(E(e, jh, 3), 2))
            } else zc(e, Bi, 2, Di) ? ej(a, zc(e, Bi, 2, Di), c) : zc(e, zi, 3, Di) && fj(a, zc(e, zi, 3, Di), d)
        });
        return new gj(c,
            d)
    }
    class gj {
        constructor(a, b) {
            this.h = a;
            this.g = b
        }
    }
    const ej = (a, b, c) => {
            E(b, jh, 2) ? (b = E(b, jh, 2), (a = dj(a, E(b, U, 1))) && c.set(ea(a), I(b, 2))) : E(b, U, 1) && (a = hj(a, E(b, U, 1))) && a.forEach(d => {
                d = ea(d);
                c.set(d, 1);
                c.set(d, 4);
                c.set(d, 2);
                c.set(d, 3)
            })
        },
        fj = (a, b, c) => {
            E(b, U, 1) && (a = hj(a, E(b, U, 1))) && a.forEach(d => {
                c.add(ea(d))
            })
        },
        dj = (a, b) => (a = hj(a, b)) && 0 < a.length ? a[0] : null,
        hj = (a, b) => (b = Vi(b)) ? b.query(a) : null;
    class V extends Error {
        constructor(a = "") {
            super();
            this.name = "TagError";
            this.message = a ? "adsbygoogle.push() error: " + a : "";
            Error.captureStackTrace ? Error.captureStackTrace(this, V) : this.stack = Error().stack || ""
        }
    };
    let ij, W;
    const jj = new ue(p);
    var kj = a => {
        null != a && (p.google_measure_js_timing = a);
        p.google_measure_js_timing || te(jj)
    };
    ((a, b = !0) => {
        ij = a || new Cg;
        "number" !== typeof p.google_srt && (p.google_srt = Math.random());
        Bg(ij, p.google_srt);
        W = new De(ij, b, jj);
        W.j(!0);
        "complete" == p.document.readyState ? kj() : jj.g && Sc(p, "load", () => {
            kj()
        })
    })();
    var lj = (a, b, c) => W.ea(a, b, c),
        mj = (a, b, c) => {
            const d = P(Ag).g();
            !b.eid && d.length && (b.eid = d.toString());
            Ce(ij, a, b, !0, c)
        },
        nj = (a, b) => {
            W.Y(a, b)
        },
        oj = (a, b, c, d) => {
            let e;
            ge(b) ? e = b.msg || Be(b.error) : e = Be(b);
            return 0 == e.indexOf("TagError") ? ((b instanceof fe ? b.error : b).pbr = !0, !1) : W.J(a, b, c, d)
        };
    var pj = class {
        constructor() {
            this.g = Kd();
            this.h = 0
        }
    };

    function qj(a, b, c) {
        switch (c) {
            case 2:
            case 3:
                break;
            case 1:
            case 4:
                b = b.parentElement;
                break;
            default:
                throw Error("Unknown RelativePosition: " + c);
        }
        for (c = []; b;) {
            if (rj(b)) return !0;
            if (a.g.has(b)) break;
            c.push(b);
            b = b.parentElement
        }
        c.forEach(d => a.g.add(d));
        return !1
    }

    function sj(a) {
        a = tj(a);
        return a.has("all") || a.has("after")
    }

    function uj(a) {
        a = tj(a);
        return a.has("all") || a.has("before")
    }

    function tj(a) {
        return (a = a && a.getAttribute("data-no-auto-ads")) ? new Set(a.split("|")) : new Set
    }

    function rj(a) {
        const b = tj(a);
        return a && ("AUTO-ADS-EXCLUSION-AREA" === a.tagName || b.has("inside") || b.has("all"))
    }
    var vj = class {
        constructor() {
            this.g = new Set;
            this.h = new pj
        }
    };

    function wj(a, b) {
        if (!a) return !1;
        a = wd(a, b);
        if (!a) return !1;
        a = a.cssFloat || a.styleFloat;
        return "left" == a || "right" == a
    }

    function xj(a) {
        for (a = a.previousSibling; a && 1 != a.nodeType;) a = a.previousSibling;
        return a ? a : null
    }

    function yj(a) {
        return !!a.nextSibling || !!a.parentNode && yj(a.parentNode)
    };

    function zj(a = null) {
        ({
            googletag: a
        } = a ? ? window);
        return a ? .apiReady ? a : void 0
    };
    const Aj = a => {
        const b = zj(a);
        return b ? Ia(Ja(b.pubads().getSlots(), c => a.document.getElementById(c.getSlotElementId())), c => null != c) : null
    };
    var Bj = a => {
        const b = [];
        for (const c of a) {
            a = !0;
            for (let d = 0; d < b.length; d++) {
                const e = b[d];
                if (e.contains(c)) {
                    a = !1;
                    break
                }
                if (c.contains(e)) {
                    a = !1;
                    b[d] = c;
                    break
                }
            }
            a && b.push(c)
        }
        return b
    };

    function Cj(a, b) {
        if (a.j) return !0;
        a.j = !0;
        const c = F(a.i, lh, 1);
        a.h = 0;
        const d = Dj(a.D);
        var e = a.g;
        var f;
        try {
            var g = (f = e.localStorage.getItem("google_ama_settings")) ? ih(f) : null
        } catch (n) {
            g = null
        }
        f = null !== g && K(g, 2, !1);
        g = Zi(e);
        f && (g.eatf = !0, Zd(7, [!0, 0, !1]));
        b: {
            var h = {
                    ub: !1,
                    vb: !1
                },
                k = Na(e.document.querySelectorAll(".google-auto-placed"));
            const n = Na(e.document.querySelectorAll("ins.adsbygoogle[data-anchor-shown],ins.adsbygoogle[data-anchor-status]")),
                w = Na(e.document.querySelectorAll("ins.adsbygoogle[data-ad-format=autorelaxed]"));
            var m = (Aj(e) || Na(e.document.querySelectorAll("div[id^=div-gpt-ad]"))).concat(Na(e.document.querySelectorAll("iframe[id^=google_ads_iframe]")));
            const v = Na(e.document.querySelectorAll("div.trc_related_container,div.OUTBRAIN,div[id^=rcjsload],div[id^=ligatusframe],div[id^=crt-],iframe[id^=cto_iframe],div[id^=yandex_], div[id^=Ya_sync],iframe[src*=adnxs],div.advertisement--appnexus,div[id^=apn-ad],div[id^=amzn-native-ad],iframe[src*=amazon-adsystem],iframe[id^=ox_],iframe[src*=openx],img[src*=openx],div[class*=adtech],div[id^=adtech],iframe[src*=adtech],div[data-content-ad-placement=true],div.wpcnt div[id^=atatags-]")),
                x = Na(e.document.querySelectorAll("ins.adsbygoogle-ablated-ad-slot")),
                z = Na(e.document.querySelectorAll("div.googlepublisherpluginad")),
                A = Na(e.document.querySelectorAll("html > ins.adsbygoogle"));
            let B = [].concat(Na(e.document.querySelectorAll("iframe[id^=aswift_],iframe[id^=google_ads_frame]")), Na(e.document.querySelectorAll("body ins.adsbygoogle")));f = [];
            for (const [J, sa] of [
                    [h.lc, k],
                    [h.ub, n],
                    [h.oc, w],
                    [h.mc, m],
                    [h.qc, v],
                    [h.kc, x],
                    [h.nc, z],
                    [h.vb, A]
                ]) !1 === J ? f = f.concat(sa) : B = B.concat(sa);h = Bj(B);f = Bj(f);
            h = h.slice(0);
            for (l of f)
                for (f = 0; f < h.length; f++)(l.contains(h[f]) || h[f].contains(l)) && h.splice(f, 1);
            var l = h;e = Xh(e).clientHeight;
            for (f = 0; f < l.length; f++)
                if (!(l[f].getBoundingClientRect().top > e)) {
                    e = !0;
                    break b
                }
            e = !1
        }
        e = e ? g.eatfAbg = !0 : !1;
        if (e) return !0;
        e = new Xg([2]);
        for (g = 0; g < c.length; g++) {
            l = a;
            h = c[g];
            f = g;
            m = b;
            if (E(h, ch, 4) && e.contains(I(E(h, ch, 4), 1)) && 1 === I(h, 8) && Ej(h, d)) {
                l.h++;
                if (m = Fj(l, h, m, d)) k = Zi(l.g), k.numAutoAdsPlaced || (k.numAutoAdsPlaced = 0), E(h, U, 1) && null != G(E(h, U, 1), 5) && (k.numPostPlacementsPlaced ? k.numPostPlacementsPlaced++ :
                    k.numPostPlacementsPlaced = 1), null == k.placed && (k.placed = []), k.numAutoAdsPlaced++, k.placed.push({
                    index: f,
                    element: m.ga
                }), Zd(7, [!1, l.h, !0]);
                l = m
            } else l = null;
            if (l) return !0
        }
        Zd(7, [!1, a.h, !1]);
        return !1
    }

    function Fj(a, b, c, d) {
        if (!Ej(b, d) || 1 != I(b, 8)) return null;
        d = E(b, U, 1);
        if (!d) return null;
        d = Vi(d);
        if (!d) return null;
        d = d.query(a.g.document);
        if (0 == d.length) return null;
        d = d[0];
        var e = I(b, 2);
        e = Yi[e];
        e = void 0 === e ? null : e;
        var f;
        if (!(f = null == e)) {
            a: {
                f = a.g;
                switch (e) {
                    case 0:
                        f = wj(xj(d), f);
                        break a;
                    case 3:
                        f = wj(d, f);
                        break a;
                    case 2:
                        var g = d.lastChild;
                        f = wj(g ? 1 == g.nodeType ? g : xj(g) : null, f);
                        break a
                }
                f = !1
            }
            if (c = !f && !(!c && 2 == e && !yj(d))) c = 1 == e || 2 == e ? d : d.parentNode,
            c = !(c && !oh(c) && 0 >= c.offsetWidth);f = !c
        }
        if (!(c = f)) {
            c = a.B;
            f = I(b, 2);
            g = c.h;
            var h = ea(d);
            g = g.g.get(h);
            if (!(g = g ? g.contains(f) : !1)) a: {
                if (c.g.contains(ea(d))) switch (f) {
                    case 2:
                    case 3:
                        g = !0;
                        break a;
                    default:
                        g = !1;
                        break a
                }
                for (f = d.parentElement; f;) {
                    if (c.g.contains(ea(f))) {
                        g = !0;
                        break a
                    }
                    f = f.parentElement
                }
                g = !1
            }
            c = g
        }
        if (!c) {
            c = a.C;
            g = I(b, 2);
            a: switch (g) {
                case 1:
                    f = sj(d.previousElementSibling) || uj(d);
                    break a;
                case 4:
                    f = sj(d) || uj(d.nextElementSibling);
                    break a;
                case 2:
                    f = uj(d.firstElementChild);
                    break a;
                case 3:
                    f = sj(d.lastElementChild);
                    break a;
                default:
                    throw Error("Unknown RelativePosition: " + g);
            }
            g = qj(c, d, g);
            c = c.h;
            mj("ama_exclusion_zone", {
                typ: f ? g ? "siuex" : "siex" : g ? "suex" : "noex",
                cor: c.g,
                num: c.h++,
                dvc: Ed()
            }, .1);
            c = f || g
        }
        if (c) return null;
        f = E(b, kh, 3);
        c = {};
        f && (c.jb = H(f, 1), c.Ua = H(f, 2), c.pb = !!fc(f, 3));
        f = E(b, ch, 4) && I(E(b, ch, 4), 2) ? I(E(b, ch, 4), 2) : null;
        f = fh(f);
        g = null != G(b, 12) ? G(b, 12) : null;
        g = null == g ? null : new eh(null, {
            google_ml_rank: g
        });
        b = Gj(a, b);
        b = dh(a.s, f, g, b);
        f = a.g;
        a = a.H;
        h = f.document;
        var k = c.pb || !1;
        g = jd((new kd(h)).g, "DIV");
        const m = g.style;
        m.width = "100%";
        m.height = "auto";
        m.clear = k ? "both" : "none";
        k = g.style;
        k.textAlign = "center";
        c.Db && ti(k, c.Db);
        h = jd((new kd(h)).g, "INS");
        k = h.style;
        k.display = "block";
        k.margin = "auto";
        k.backgroundColor = "transparent";
        c.jb && (k.marginTop = c.jb);
        c.Ua && (k.marginBottom = c.Ua);
        c.lb && ti(k, c.lb);
        g.appendChild(h);
        c = {
            ya: g,
            ga: h
        };
        c.ga.setAttribute("data-ad-format", "auto");
        g = [];
        if (h = b && b.Wa) c.ya.className = h.join(" ");
        h = c.ga;
        h.className = "adsbygoogle";
        h.setAttribute("data-ad-client", a);
        g.length && h.setAttribute("data-ad-channel", g.join("+"));
        a: {
            try {
                var l = c.ya;
                if (Q(xh)) {
                    {
                        const z = Sh(d, e);
                        if (z.init) {
                            var n =
                                z.init;
                            for (d = n; d = z.ha(d);) n = d;
                            var w = {
                                anchor: n,
                                position: z.na
                            }
                        } else w = {
                            anchor: d,
                            position: e
                        }
                    }
                    l["google-ama-order-assurance"] = 0;
                    Rh(l, w.anchor, w.position)
                } else Rh(l, d, e);
                b: {
                    var v = c.ga;v.dataset.adsbygoogleStatus = "reserved";v.className += " adsbygoogle-noablate";l = {
                        element: v
                    };
                    var x = b && b.gb;
                    if (v.hasAttribute("data-pub-vars")) {
                        try {
                            x = JSON.parse(v.getAttribute("data-pub-vars"))
                        } catch (z) {
                            break b
                        }
                        v.removeAttribute("data-pub-vars")
                    }
                    x && (l.params = x);
                    (f.adsbygoogle = f.adsbygoogle || []).push(l)
                }
            } catch (z) {
                (v = c.ya) && v.parentNode &&
                    (x = v.parentNode, x.removeChild(v), oh(x) && (x.style.display = x.getAttribute("data-init-display") || "none"));
                v = !1;
                break a
            }
            v = !0
        }
        return v ? c : null
    }

    function Gj(a, b) {
        return Ug(Wg(aj(b).map(gh), c => {
            Zi(a.g).exception = c
        }))
    }
    const Hj = class {
        constructor(a, b, c, d, e) {
            this.g = a;
            this.H = b;
            this.i = c;
            this.s = e || null;
            (this.D = d) ? (a = a.document, d = F(d, Ci, 5), d = cj(a, d)) : d = cj(a.document, []);
            this.B = d;
            this.C = new vj;
            this.h = 0;
            this.j = !1
        }
    };

    function Dj(a) {
        const b = {};
        a && gc(a, 6, Cb).forEach(c => {
            b[c] = !0
        });
        return b
    }

    function Ej(a, b) {
        return a && dc(a, ch, 4) && b[I(E(a, ch, 4), 2)] ? !1 : !0
    };
    var Ij = Ic(class extends N {});

    function Jj(a) {
        try {
            var b = a.localStorage.getItem("google_auto_fc_cmp_setting") || null
        } catch (d) {
            b = null
        }
        const c = b;
        return c ? Tg(() => Ij(c)) : Qg(null)
    };

    function Kj() {
        if (Lj) return Lj;
        var a = ae() || window;
        const b = a.google_persistent_state_async;
        return null != b && "object" == typeof b && null != b.S && "object" == typeof b.S ? Lj = b : a.google_persistent_state_async = Lj = new Mj
    }

    function Nj(a, b, c) {
        b = Oj[b] || `google_ps_${b}`;
        a = a.S;
        const d = a[b];
        return void 0 === d ? (a[b] = c(), a[b]) : d
    }

    function Pj(a, b, c) {
        return Nj(a, b, () => c)
    }

    function Qj(a, b, c) {
        a.S[Oj[b] || `google_ps_${b}`] = c
    }

    function Rj(a, b) {
        Qj(a, 38, b)
    }
    var Mj = class {
            constructor() {
                this.S = {}
            }
        },
        Lj = null;
    const Oj = {
        [8]: "google_prev_ad_formats_by_region",
        [9]: "google_prev_ad_slotnames_by_region"
    };

    function Sj(a) {
        var b = new Tj;
        return y(b, 5, zb(a))
    }
    var Tj = class extends N {
        constructor() {
            super()
        }
    };
    Tj.u = [10];

    function Uj() {
        this.s = this.s;
        this.i = this.i
    }
    Uj.prototype.s = !1;

    function Vj(a, b) {
        a.s ? b() : (a.i || (a.i = []), a.i.push(b))
    };
    const Wj = a => {
        void 0 !== a.addtlConsent && "string" !== typeof a.addtlConsent && (a.addtlConsent = void 0);
        void 0 !== a.gdprApplies && "boolean" !== typeof a.gdprApplies && (a.gdprApplies = void 0);
        return void 0 !== a.tcString && "string" !== typeof a.tcString || void 0 !== a.listenerId && "number" !== typeof a.listenerId ? 2 : a.cmpStatus && "error" !== a.cmpStatus ? 0 : 3
    };

    function Xj(a) {
        if (!1 === a.gdprApplies) return !0;
        void 0 === a.internalErrorState && (a.internalErrorState = Wj(a));
        return "error" === a.cmpStatus || 0 !== a.internalErrorState ? a.internalBlockOnErrors ? (Sd({
            e: String(a.internalErrorState)
        }, "tcfe"), !1) : !0 : "loaded" !== a.cmpStatus || "tcloaded" !== a.eventStatus && "useractioncomplete" !== a.eventStatus ? !1 : !0
    }

    function Yj(a) {
        if (a.g) return a.g;
        a.g = Dd(a.h, "__tcfapiLocator");
        return a.g
    }

    function Zj(a) {
        return "function" === typeof a.h.__tcfapi || null != Yj(a)
    }

    function ak(a, b, c, d) {
        c || (c = () => {});
        if ("function" === typeof a.h.__tcfapi) a = a.h.__tcfapi, a(b, 2, c, d);
        else if (Yj(a)) {
            ck(a);
            const e = ++a.H;
            a.C[e] = c;
            a.g && a.g.postMessage({
                __tcfapiCall: {
                    command: b,
                    version: 2,
                    callId: e,
                    parameter: d
                }
            }, "*")
        } else c({}, !1)
    }

    function ck(a) {
        a.j || (a.j = b => {
            try {
                var c = ("string" === typeof b.data ? JSON.parse(b.data) : b.data).__tcfapiReturn;
                a.C[c.callId](c.returnValue, c.success)
            } catch (d) {}
        }, Sc(a.h, "message", a.j))
    }
    class dk extends Uj {
        constructor(a) {
            var b = {};
            super();
            this.h = a;
            this.g = null;
            this.C = {};
            this.H = 0;
            this.D = b.timeoutMs ? ? 500;
            this.B = b.ic ? ? !1;
            this.j = null
        }
        addEventListener(a) {
            let b = {
                internalBlockOnErrors: this.B
            };
            const c = Rc(() => a(b));
            let d = 0; - 1 !== this.D && (d = setTimeout(() => {
                b.tcString = "tcunavailable";
                b.internalErrorState = 1;
                c()
            }, this.D));
            const e = (f, g) => {
                clearTimeout(d);
                f ? (b = f, b.internalErrorState = Wj(b), b.internalBlockOnErrors = this.B, g && 0 === b.internalErrorState || (b.tcString = "tcunavailable", g || (b.internalErrorState =
                    3))) : (b.tcString = "tcunavailable", b.internalErrorState = 3);
                a(b)
            };
            try {
                ak(this, "addEventListener", e)
            } catch (f) {
                b.tcString = "tcunavailable", b.internalErrorState = 3, d && (clearTimeout(d), d = 0), c()
            }
        }
        removeEventListener(a) {
            a && a.listenerId && ak(this, "removeEventListener", null, a.listenerId)
        }
    };
    var ik = ({
            l: a,
            R: b,
            timeoutMs: c,
            ca: d,
            ia: e = !1,
            ja: f = !1
        }) => {
            b = ek({
                l: a,
                R: b,
                ia: e,
                ja: f
            });
            null != b.g || "tcunav" != b.h.message ? d(b) : fk(a, c).then(g => g.map(gk)).then(g => g.map(h => hk(a, h))).then(d)
        },
        ek = ({
            l: a,
            R: b,
            ia: c = !1,
            ja: d = !1
        }) => {
            if (!jk({
                    l: a,
                    R: b,
                    ia: c,
                    ja: d
                })) return hk(a, Sj(!0));
            b = Kj();
            return (b = Pj(b, 24)) ? hk(a, gk(b)) : Sg(Error("tcunav"))
        };

    function jk({
        l: a,
        R: b,
        ia: c,
        ja: d
    }) {
        if (!(d = !d && Zj(new dk(a)))) {
            if (c = !c) {
                if (b) {
                    a = Jj(a);
                    if (null != a.g)
                        if ((a = a.getValue()) && null != I(a, 1)) b: switch (a = I(a, 1), a) {
                            case 1:
                                a = !0;
                                break b;
                            default:
                                throw Error("Unhandled AutoGdprFeatureStatus: " + a);
                        } else a = !1;
                        else W.J(806, a.h, void 0, void 0), a = !1;
                    b = !a
                }
                c = b
            }
            d = c
        }
        return d ? !0 : !1
    }

    function fk(a, b) {
        return Promise.race([kk(), lk(a, b)])
    }

    function kk() {
        return (new Promise(a => {
            var b = Kj();
            a = {
                resolve: a
            };
            const c = Pj(b, 25, []);
            c.push(a);
            Qj(b, 25, c)
        })).then(mk)
    }

    function lk(a, b) {
        return new Promise(c => {
            a.setTimeout(c, b, Sg(Error("tcto")))
        })
    }

    function mk(a) {
        return a ? Qg(a) : Sg(Error("tcnull"))
    }

    function gk(a) {
        var b = {};
        if (Xj(a))
            if (!1 === a.gdprApplies || "tcunavailable" === a.tcString || void 0 === a.gdprApplies && !b.jc || "string" !== typeof a.tcString || !a.tcString.length) a = !0;
            else {
                b: {
                    if (a.publisher && a.publisher.restrictions && (b = a.publisher.restrictions["1"], void 0 !== b)) {
                        b = b["755"];
                        break b
                    }
                    b = void 0
                }
                0 === b ? a = !1 : a.purpose && a.vendor ? (b = a.vendor.consents, (b = !(!b || !b["755"])) && a.purposeOneTreatment && "CH" === a.publisherCC ? a = !0 : (b && (a = a.purpose.consents, b = !(!a || !a["1"])), a = b)) : a = !0
            }
        else a = !1;
        return Sj(a)
    }

    function hk(a, b) {
        return (a = Vd(b, a)) ? Qg(a) : Sg(Error("unav"))
    };
    var nk = class extends N {};
    nk.u = [1, 2, 3];
    var ok = class extends N {};
    ok.u = [1, 2, 3];
    var pk = class extends N {
        g() {
            return E(this, nk, 2)
        }
        h() {
            return E(this, ok, 3)
        }
    };
    const qk = class {
        constructor(a) {
            this.exception = a
        }
    };

    function rk(a, b) {
        try {
            var c = a.h,
                d = c.resolve,
                e = a.g;
            Zi(e.g);
            F(e.i, lh, 1);
            d.call(c, new qk(b))
        } catch (f) {
            a = a.h, b = f, Ig(a), a.g = 2, a.i = b, Kg(a.h)
        }
    }
    var sk = class {
        constructor(a, b, c) {
            this.i = a;
            this.g = b;
            this.h = c
        }
        start() {
            this.j()
        }
        j() {
            try {
                switch (this.i.document.readyState) {
                    case "complete":
                    case "interactive":
                        Cj(this.g, !0);
                        rk(this);
                        break;
                    default:
                        Cj(this.g, !1) ? rk(this) : this.i.setTimeout(ka(this.j, this), 100)
                }
            } catch (a) {
                rk(this, a)
            }
        }
    };
    var tk = class extends N {
        constructor() {
            super()
        }
        getVersion() {
            return wc(G(this, 2))
        }
    };
    tk.u = [3];

    function uk(a) {
        return Sa(0 !== a.length % 4 ? a + "A" : a).map(b => b.toString(2).padStart(8, "0")).join("")
    }

    function vk(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        return parseInt(a, 2)
    }

    function wk(a) {
        if (!/^[0-1]+$/.test(a)) throw Error(`Invalid input [${a}] not a bit string.`);
        const b = [1, 2, 3, 5];
        let c = 0;
        for (let d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    };

    function xk(a) {
        var b = uk(a),
            c = vk(b.slice(0, 6));
        a = vk(b.slice(6, 12));
        var d = new tk;
        c = D(d, 1, Eb(c), 0);
        a = D(c, 2, Eb(a), 0);
        b = b.slice(12);
        c = vk(b.slice(0, 12));
        d = [];
        let e = b.slice(12).replace(/0+$/, "");
        for (let k = 0; k < c; k++) {
            if (0 === e.length) throw Error(`Found ${k} of ${c} sections [${d}] but reached end of input [${b}]`);
            var f = 0 === vk(e[0]);
            e = e.slice(1);
            var g = yk(e, b),
                h = 0 === d.length ? 0 : d[d.length - 1];
            h = wk(g) + h;
            e = e.slice(g.length);
            if (f) d.push(h);
            else {
                f = yk(e, b);
                g = wk(f);
                for (let m = 0; m <= g; m++) d.push(h + m);
                e = e.slice(f.length)
            }
        }
        if (0 <
            e.length) throw Error(`Found ${c} sections [${d}] but has remaining input [${e}], entire input [${b}]`);
        return lc(a, 3, d, Db)
    }

    function yk(a, b) {
        const c = a.indexOf("11");
        if (-1 === c) throw Error(`Expected section bitstring but not found in [${a}] part of [${b}]`);
        return a.slice(0, c + 2)
    };
    var zk = "a".charCodeAt(),
        Ak = Yc(Gg),
        Bk = Yc(Hg);

    function Ck() {
        var a = new Dk;
        return Ac(a, 1, 0)
    }

    function Ek(a) {
        const b = xc(a, 1);
        a = wc(G(a, 2));
        return new Date(1E3 * b + a / 1E6)
    }
    var Dk = class extends N {};

    function Fk(a, b) {
        if (a.g + b > a.h.length) throw Error("Requested length " + b + " is past end of string.");
        const c = a.h.substring(a.g, a.g + b);
        a.g += b;
        return parseInt(c, 2)
    }

    function Gk(a) {
        let b = Fk(a, 12);
        const c = [];
        for (; b--;) {
            var d = !0 === !!Fk(a, 1),
                e = Fk(a, 16);
            if (d)
                for (d = Fk(a, 16); e <= d; e++) c.push(e);
            else c.push(e)
        }
        c.sort((f, g) => f - g);
        return c
    }

    function Hk(a, b, c) {
        const d = [];
        for (let e = 0; e < b; e++)
            if (Fk(a, 1)) {
                const f = e + 1;
                if (c && -1 === c.indexOf(f)) throw Error(`ID: ${f} is outside of allowed values!`);
                d.push(f)
            }
        return d
    }

    function Ik(a) {
        const b = Fk(a, 16);
        return !0 === !!Fk(a, 1) ? (a = Gk(a), a.forEach(c => {
            if (c > b) throw Error(`ID ${c} is past MaxVendorId ${b}!`);
        }), a) : Hk(a, b)
    }
    class Jk {
        constructor(a) {
            if (/[^01]/.test(a)) throw Error(`Input bitstring ${a} is malformed!`);
            this.h = a;
            this.g = 0
        }
        skip(a) {
            this.g += a
        }
    };
    var Lk = (a, b) => {
        try {
            var c = Sa(a.split(".")[0]).map(e => e.toString(2).padStart(8, "0")).join("");
            const d = new Jk(c);
            c = {};
            c.tcString = a;
            c.gdprApplies = !0;
            d.skip(78);
            c.cmpId = Fk(d, 12);
            c.cmpVersion = Fk(d, 12);
            d.skip(30);
            c.tcfPolicyVersion = Fk(d, 6);
            c.isServiceSpecific = !!Fk(d, 1);
            c.useNonStandardStacks = !!Fk(d, 1);
            c.specialFeatureOptins = Kk(Hk(d, 12, Bk), Bk);
            c.purpose = {
                consents: Kk(Hk(d, 24, Ak), Ak),
                legitimateInterests: Kk(Hk(d, 24, Ak), Ak)
            };
            c.purposeOneTreatment = !!Fk(d, 1);
            c.publisherCC = String.fromCharCode(zk + Fk(d, 6)) + String.fromCharCode(zk +
                Fk(d, 6));
            c.vendor = {
                consents: Kk(Ik(d), b),
                legitimateInterests: Kk(Ik(d), b)
            };
            return c
        } catch (d) {
            return null
        }
    };
    const Kk = (a, b) => {
        const c = {};
        if (Array.isArray(b) && 0 !== b.length)
            for (const d of b) c[d] = -1 !== a.indexOf(d);
        else
            for (const d of a) c[d] = !0;
        delete c[0];
        return c
    };
    var Mk = class extends N {
        g() {
            return null != H(this, 2)
        }
    };
    var Nk = class extends N {
        g() {
            return null != H(this, 2)
        }
    };
    var Ok = class extends N {};
    var Pk = class extends N {},
        Qk = Ic(Pk);
    Pk.u = [7];

    function Rk(a) {
        a = Sk(a);
        try {
            var b = a ? Qk(a) : null
        } catch (c) {
            b = null
        }
        return b ? E(b, Ok, 4) || null : null
    }

    function Sk(a) {
        a = (new Ud(a)).get("FCCDCF", "");
        if (a)
            if (a.startsWith("%")) try {
                var b = decodeURIComponent(a)
            } catch (c) {
                b = null
            } else b = a;
            else b = null;
        return b
    };

    function Tk(a) {
        a.__uspapiPostMessageReady || Uk(new Vk(a))
    }

    function Uk(a) {
        a.g = b => {
            const c = "string" === typeof b.data;
            let d;
            try {
                d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            const e = d.__uspapiCall;
            e && "getUSPData" === e.command && a.l.__uspapi(e.command, e.version, (f, g) => {
                const h = {};
                h.__uspapiReturn = {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && "function" === typeof b.source.postMessage && b.source.postMessage(f, b.origin);
                return f
            })
        };
        a.l.addEventListener("message", a.g);
        a.l.__uspapiPostMessageReady = !0
    }
    var Vk = class {
        constructor(a) {
            this.l = a;
            this.g = null
        }
    };
    Yc(Gg).map(a => Number(a));
    Yc(Hg).map(a => Number(a));

    function Wk(a) {
        a.__tcfapiPostMessageReady || Xk(new Yk(a))
    }

    function Xk(a) {
        a.h = b => {
            const c = "string" == typeof b.data;
            let d;
            try {
                d = c ? JSON.parse(b.data) : b.data
            } catch (f) {
                return
            }
            const e = d.__tcfapiCall;
            !e || "ping" !== e.command && "getTCData" !== e.command && "addEventListener" !== e.command && "removeEventListener" !== e.command || a.g.__tcfapi(e.command, e.version, (f, g) => {
                const h = {};
                h.__tcfapiReturn = "removeEventListener" === e.command ? {
                    success: f,
                    callId: e.callId
                } : {
                    returnValue: f,
                    success: g,
                    callId: e.callId
                };
                f = c ? JSON.stringify(h) : h;
                b.source && "function" === typeof b.source.postMessage && b.source.postMessage(f,
                    b.origin);
                return f
            }, e.parameter)
        };
        a.g.addEventListener("message", a.h);
        a.g.__tcfapiPostMessageReady = !0
    }
    var Yk = class {
        constructor(a) {
            this.g = a;
            this.h = null
        }
    };
    var Zk = class extends N {};
    var $k = class extends N {
            g() {
                return null != H(this, 1)
            }
        },
        al = Ic($k);
    $k.u = [2];

    function bl(a, b, c) {
        function d(l) {
            if (10 > l.length) return null;
            var n = g(l.slice(0, 4));
            n = h(n);
            l = g(l.slice(6, 10));
            l = k(l);
            return "1" + n + l + "N"
        }

        function e(l) {
            if (10 > l.length) return null;
            var n = g(l.slice(0, 6));
            n = h(n);
            l = g(l.slice(6, 10));
            l = k(l);
            return "1" + n + l + "N"
        }

        function f(l) {
            if (12 > l.length) return null;
            var n = g(l.slice(0, 6));
            n = h(n);
            l = g(l.slice(8, 12));
            l = k(l);
            return "1" + n + l + "N"
        }

        function g(l) {
            const n = [];
            let w = 0;
            for (let v = 0; v < l.length / 2; v++) n.push(vk(l.slice(w, w + 2))), w += 2;
            return n
        }

        function h(l) {
            return l.every(n => 1 === n) ?
                "Y" : "N"
        }

        function k(l) {
            return l.some(n => 1 === n) ? "Y" : "N"
        }
        if (0 === a.length) return null;
        a = a.split(".");
        if (2 < a.length) return null;
        a = uk(a[0]);
        const m = vk(a.slice(0, 6));
        a = a.slice(6);
        if (1 !== m) return null;
        switch (b) {
            case 8:
                return d(a);
            case 10:
            case 12:
            case 9:
                return e(a);
            case 11:
                return c ? f(a) : null;
            default:
                return null
        }
    };
    var cl = (a, b) => {
        const c = a.document,
            d = () => {
                if (!a.frames[b])
                    if (c.body) {
                        const e = vd("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };

    function dl() {
        var a = Q(qh);
        S !== S.top || S.__uspapi || S.frames.__uspapiLocator || (a = new el(a), fl(a), gl(a))
    }

    function fl(a) {
        !a.j || a.g.__uspapi || a.g.frames.__uspapiLocator || (a.g.__uspapiManager = "fc", cl(a.g, "__uspapiLocator"), ma("__uspapi", (...b) => hl(a, ...b), a.g), Tk(a.g))
    }

    function gl(a) {
        !a.h || a.g.__tcfapi || a.g.frames.__tcfapiLocator || (a.g.__tcfapiManager = "fc", cl(a.g, "__tcfapiLocator"), a.g.__tcfapiEventListeners = a.g.__tcfapiEventListeners || [], ma("__tcfapi", (...b) => il(a, ...b), a.g), Wk(a.g))
    }

    function hl(a, b, c, d) {
        "function" === typeof d && "getUSPData" === b && d({
            version: 1,
            uspString: a.j
        }, !0)
    }

    function jl(a, b) {
        if (!b ? .g() || 0 === L(b, 1).length || 0 == F(b, Zk, 2).length) return null;
        const c = L(b, 1);
        let d;
        try {
            var e = xk(c.split("~")[0]);
            d = c.includes("~") ? c.split("~").slice(1) : []
        } catch (f) {
            return null
        }
        b = F(b, Zk, 2).reduce((f, g) => xc(kl(f), 1) > xc(kl(g), 1) ? f : g);
        e = gc(e, 3, Fb).indexOf(wc(G(b, 1)));
        return -1 === e || e >= d.length ? null : {
            uspString: bl(d[e], wc(G(b, 1)), a.s),
            xa: Ek(kl(b))
        }
    }

    function ll(a) {
        a = a.find(b => 13 === M(b, 1));
        if (a ? .g()) try {
            return al(L(a, 2))
        } catch (b) {}
        return null
    }

    function kl(a) {
        return dc(a, Dk, 2) ? E(a, Dk, 2) : Ck()
    }

    function il(a, b, c, d, e = null) {
        if ("function" === typeof d)
            if (c && (2.1 < c || 1 >= c)) d(null, !1);
            else switch (c = a.g.__tcfapiEventListeners, b) {
                case "getTCData":
                    !e || Array.isArray(e) && e.every(f => "number" === typeof f) ? d(ml(a, e, null), !0) : d(null, !1);
                    break;
                case "ping":
                    d({
                        gdprApplies: !0,
                        cmpLoaded: !0,
                        cmpStatus: "loaded",
                        displayStatus: "disabled",
                        apiVersion: "2.1",
                        cmpVersion: 2,
                        cmpId: 300
                    });
                    break;
                case "addEventListener":
                    b = c.push(d);
                    d(ml(a, null, b - 1), !0);
                    break;
                case "removeEventListener":
                    c[e] ? (c[e] = null, d(!0)) : d(!1);
                    break;
                case "getInAppTCData":
                case "getVendorList":
                    d(null, !1)
            }
    }

    function ml(a, b, c) {
        if (!a.h) return null;
        b = Lk(a.h, b);
        b.addtlConsent = null != a.i ? a.i : void 0;
        b.cmpStatus = "loaded";
        b.eventStatus = "tcloaded";
        null != c && (b.listenerId = c);
        return b
    }
    class el {
        constructor(a) {
            var b = S;
            this.g = b;
            this.s = a;
            a = Sk(this.g.document);
            try {
                var c = a ? Qk(a) : null
            } catch (e) {
                c = null
            }(a = c) ? (c = E(a, Nk, 5) || null, a = F(a, Mk, 7), a = ll(a ? ? []), c = {
                Va: c,
                Ya: a
            }) : c = {
                Va: null,
                Ya: null
            };
            a = c;
            c = jl(this, a.Ya);
            a = a.Va;
            if (a ? .g() && 0 !== L(a, 2).length) {
                var d = dc(a, Dk, 1) ? E(a, Dk, 1) : Ck();
                a = {
                    uspString: L(a, 2),
                    xa: Ek(d)
                }
            } else a = null;
            this.j = a && c ? c.xa > a.xa ? c.uspString : a.uspString : a ? a.uspString : c ? c.uspString : null;
            this.h = (c = Rk(b.document)) && null != H(c, 1) ? L(c, 1) : null;
            this.i = (b = Rk(b.document)) && null != H(b, 2) ? L(b,
                2) : null
        }
    };
    const nl = {
        google_ad_channel: !0,
        google_ad_host: !0
    };

    function ol(a, b) {
        a.location.href && a.location.href.substring && (b.url = a.location.href.substring(0, 200));
        mj("ama", b, .01)
    }

    function pl(a) {
        const b = {};
        yd(nl, (c, d) => {
            d in a && (b[d] = a[d])
        });
        return b
    };

    function ql(a) {
        const b = /[a-zA-Z0-9._~-]/,
            c = /%[89a-zA-Z]./;
        return a.replace(/(%[a-zA-Z0-9]{2})/g, d => {
            if (!d.match(c)) {
                const e = decodeURIComponent(d);
                if (e.match(b)) return e
            }
            return d.toUpperCase()
        })
    }

    function rl(a) {
        let b = "";
        const c = /[/%?&=]/;
        for (let d = 0; d < a.length; ++d) {
            const e = a[d];
            b = e.match(c) ? b + e : b + encodeURIComponent(e)
        }
        return b
    };

    function sl(a) {
        a = gc(a, 2, Cb);
        if (!a) return !1;
        for (let b = 0; b < a.length; b++)
            if (1 == a[b]) return !0;
        return !1
    }

    function tl(a, b) {
        a = rl(ql(a.location.pathname)).replace(/(^\/)|(\/$)/g, "");
        const c = zd(a),
            d = ul(a);
        return b.find(e => {
            if (dc(e, yi, 7)) {
                var f = E(e, yi, 7);
                f = Gb(bc(f, 1))
            } else f = Gb(bc(e, 1));
            e = dc(e, yi, 7) ? I(E(e, yi, 7), 2) : 2;
            if ("number" !== typeof f) return !1;
            switch (e) {
                case 1:
                    return f == c;
                case 2:
                    return d[f] || !1
            }
            return !1
        }) || null
    }

    function ul(a) {
        const b = {};
        for (;;) {
            b[zd(a)] = !0;
            if (!a) return b;
            a = a.substring(0, a.lastIndexOf("/"))
        }
    };
    var vl = a => {
        a = E(a, xi, 3);
        return !a || vc(a, 1) <= Date.now() ? !1 : !0
    };

    function wl(a) {
        if (Q(vh)) var b = null;
        else try {
            b = a.getItem("google_ama_config")
        } catch (d) {
            b = null
        }
        try {
            var c = b ? Ki(b) : null
        } catch (d) {
            c = null
        }
        return c
    };
    var xl = class extends N {
        g() {
            return E(this, pk, 2)
        }
        h() {
            return K(this, 3)
        }
    };
    var yl = class extends N {
        g() {
            return gc(this, 1, Mb)
        }
        h() {
            return E(this, xl, 2)
        }
    };
    yl.u = [1];
    var zl = class extends N {
        getId() {
            return wc(G(this, 1))
        }
    };
    zl.u = [2];
    var Al = class extends N {};
    Al.u = [2];
    var Bl = class extends N {};
    Bl.u = [2];
    var Cl = class extends N {
        g() {
            return xc(this, 2)
        }
        h() {
            return xc(this, 4)
        }
        i() {
            return K(this, 3)
        }
    };
    var Dl = class extends N {};
    Dl.u = [1, 4, 2, 3];
    var Fl = class extends N {
        h() {
            return zc(this, xl, 13, El)
        }
        j() {
            return void 0 !== ec(this, xl, oc(this, El, 13))
        }
        g() {
            return zc(this, yl, 14, El)
        }
        i() {
            return void 0 !== ec(this, yl, oc(this, El, 14))
        }
    };
    Fl.u = [19];
    var El = [13, 14];
    let Gl = void 0;

    function Hl(a) {
        Fc(Gl, Fe);
        Gl = a
    };

    function X(a) {
        return a.google_ad_modifications = a.google_ad_modifications || {}
    }

    function Il(a) {
        a = X(a);
        const b = a.space_collapsing || "none";
        return a.remove_ads_by_default ? {
            Sa: !0,
            Kb: b,
            ua: a.ablation_viewport_offset
        } : null
    }

    function Jl(a, b) {
        a = X(a);
        a.had_ads_ablation = !0;
        a.remove_ads_by_default = !0;
        a.space_collapsing = "slot";
        a.ablation_viewport_offset = b
    }

    function Kl(a) {
        X(S).allow_second_reactive_tag = a
    }

    function Ll() {
        const a = X(window);
        a.afg_slotcar_vars || (a.afg_slotcar_vars = {});
        return a.afg_slotcar_vars
    };

    function Ml(a) {
        return X(a) ? .head_tag_slot_vars ? .google_ad_host ? ? Nl(a)
    }

    function Nl(a) {
        return a.document ? .querySelector('meta[name="google-adsense-platform-account"]') ? .getAttribute("content") ? ? null
    };
    const Ol = [2, 7, 1];
    var Rl = (a, b, c = "", d = null) => 1 === b && Pl(c, d) ? !0 : Ql(a, c, e => Ka(F(e, Jc, 2), f => I(f, 1) === b)),
        Pl = (a, b) => b ? b.j() ? K(b.h(), 1) : b.i() && "" !== a && 1 === b.g().g().length && b.g().g()[0] === a ? K(b.g().h(), 1) : !1 : !1,
        Sl = (a, b) => {
            b = wc(G(b, 18)); - 1 !== b && (a.tmod = b)
        },
        Ul = a => {
            const b = td(S) || S;
            return Tl(b, a) ? !0 : Ql(S, "", c => Ka(gc(c, 3, Cb), d => d === a))
        };

    function Tl(a, b) {
        a = (a = (a = a.location && a.location.hash) && a.match(/forced_clientside_labs=([\d,]+)/)) && a[1];
        return !!a && Ma(a.split(","), b.toString())
    }

    function Ql(a, b, c) {
        a = td(a) || a;
        const d = Vl(a);
        b && (b = ee(String(b)));
        return Xc(d, (e, f) => Object.prototype.hasOwnProperty.call(d, f) && (!b || b === f) && c(e))
    }

    function Vl(a) {
        a = Wl(a);
        const b = {};
        yd(a, (c, d) => {
            try {
                const e = new Kc(c);
                b[d] = e
            } catch (e) {}
        });
        return b
    }
    var Wl = a => {
        Fc(Gl, Hc);
        a = ek({
            l: a,
            R: Gl
        });
        return null != a.g ? Xl(a.getValue()) : {}
    };

    function Xl(a) {
        try {
            const b = a.getItem("google_adsense_settings");
            if (!b) return {};
            const c = JSON.parse(b);
            return c !== Object(c) ? {} : Wc(c, (d, e) => Object.prototype.hasOwnProperty.call(c, e) && "string" === typeof e && Array.isArray(d))
        } catch (b) {
            return {}
        }
    }

    function Yl(a) {
        mj("atf_ad_settings_from_ppabg", {
            p_s: a
        }, .01)
    }
    const Zl = a => {
            mj("overlay_settings_from_ppabg", {
                p_s: a
            }, .01)
        },
        $l = (a, b) => {
            if (Ml(p)) return Ol;
            if (b ? .j()) {
                var c = L(b.h(), 9);
                b = b ? .h() ? .g() ? .h();
                if (!a || c != a || !b) return Ol;
                Zl(!1);
                return gc(b, 3, Cb)
            }
            if (b ? .i()) {
                c = b ? .g() ? .g();
                if (!c || 1 !== c.length || !a || c[0] !== a || L(b, 17) != p.location.host) return Ol;
                a = b ? .g() ? .h() ? .g() ? .h();
                if (!a) return Ol;
                Zl(!0);
                return gc(a, 3, Cb)
            }
            return Ol
        };
    var am = (a, b) => {
        const c = [];
        a = $l(a, b);
        a.includes(1) || c.push(1);
        a.includes(2) || c.push(2);
        a.includes(7) || c.push(7);
        return c
    };

    function bm(a, b, c, d) {
        cm(new dm(a, b, c, d))
    }

    function cm(a) {
        Wg(Vg(ek({
            l: a.l,
            R: K(a.g, 6)
        }), b => {
            em(a, b, !0)
        }), () => {
            fm(a)
        })
    }

    function em(a, b, c) {
        Wg(Vg(gm(b), d => {
            hm("ok");
            a.h(d, {
                fromLocalStorage: !0
            })
        }), () => {
            var d = a.l;
            try {
                b.removeItem("google_ama_config")
            } catch (e) {
                ol(d, {
                    lserr: 1
                })
            }
            c ? fm(a) : a.h(null, null)
        })
    }

    function fm(a) {
        Wg(Vg(im(a), b => {
            a.h(b, {
                fromPABGSettings: !0
            })
        }), () => {
            jm(a)
        })
    }

    function gm(a) {
        return (a = (a = wl(a)) ? vl(a) ? a : null : null) ? Qg(a) : Sg(Error("invlocst"))
    }

    function im(a) {
        if (Ml(a.l) && !K(a.g, 22)) return Sg(Error("invtag"));
        a: {
            var b = a.l;
            var c = a.i;a = a.g;
            if (a ? .j())(b = a ? .h() ? .g() ? .g()) && (0 < F(b, lh, 1).length || Q(wh) && 0 < F(b, mh, 3).length) ? Yl(!1) : b = null;
            else {
                if (a ? .i()) {
                    const d = a ? .g() ? .g(),
                        e = a ? .g() ? .h() ? .g() ? .g();
                    if (d && 1 === d.length && d[0] === c && e && (0 < F(e, lh, 1).length || Q(wh) && 0 < F(e, mh, 3).length) && L(a, 17) === b.location.host) {
                        Yl(!0);
                        b = e;
                        break a
                    }
                }
                b = null
            }
        }
        b ? (c = new Ji, a = F(b, lh, 1), c = uc(c, 1, a), a = F(b, Ei, 2), c = uc(c, 7, a), Q(wh) && 0 < F(b, mh, 3).length && (a = new nh, b = F(b, mh, 3), b = uc(a,
            1, b), sc(c, 6, b)), b = Qg(c)) : b = Sg(Error("invtag"));
        return b
    }

    function jm(a) {
        ik({
            l: a.l,
            R: K(a.g, 6),
            timeoutMs: 50,
            ca: b => {
                km(a, b)
            }
        })
    }

    function km(a, b) {
        Wg(Vg(b, c => {
            em(a, c, !1)
        }), c => {
            hm(c.message);
            a.h(null, null)
        })
    }

    function hm(a) {
        mj("abg::amalserr", {
            status: a,
            guarding: "true",
            timeout: 50,
            rate: .01
        }, .01)
    }
    class dm {
        constructor(a, b, c, d) {
            this.l = a;
            this.g = b;
            this.i = c;
            this.h = d
        }
    };
    var nm = (a, b, c, d) => {
        try {
            const e = tl(a, F(c, Ei, 7));
            if (e && sl(e)) {
                H(e, 4) && (d = dh(d, new eh(null, {
                    google_package: H(e, 4)
                })));
                const f = new Hj(a, b, c, e, d);
                Ui(1E3, () => {
                    var g = new Lg;
                    (new sk(a, f, g)).start();
                    return g.h
                }, a).then(la(lm, a), la(mm, a))
            }
        } catch (e) {
            ol(a, {
                atf: -1
            })
        }
    };
    const lm = a => {
            ol(a, {
                atf: 1
            })
        },
        mm = (a, b) => {
            (a.google_ama_state = a.google_ama_state || {}).exception = b;
            ol(a, {
                atf: 0
            })
        };

    function om(a) {
        a.easpi = Q(Mh);
        a.asla = .4;
        a.asaa = -1;
        a.sedf = !1;
        a.asro = Q(Kh);
        a.sefa = !0;
        Q(Lh) && (a.sugawps = !0);
        const b = P(Uc).h(Gh.g, Gh.defaultValue);
        b.length && (a.seiel = b.join("~"));
        a.slcwct = Vc(Ih);
        a.sacwct = Vc(Eh);
        Q(Hh) && (a.slmct = Vc(Jh), a.samct = Vc(Fh))
    };

    function pm(a, b) {
        if (!a) return !1;
        a = a.hash;
        if (!a || !a.indexOf) return !1;
        if (-1 != a.indexOf(b)) return !0;
        b = qm(b);
        return "go" != b && -1 != a.indexOf(b) ? !0 : !1
    }

    function qm(a) {
        let b = "";
        yd(a.split("_"), c => {
            b += c.substr(0, 2)
        });
        return b
    };
    Pa || Ca();
    class rm {
        constructor() {
            this.promise = new Promise(a => {
                this.resolve = a
            })
        }
    };

    function sm() {
        const {
            promise: a,
            resolve: b
        } = new rm;
        return {
            promise: a,
            resolve: b
        }
    };

    function tm(a, b, c = () => {}) {
        b.google_llp || (b.google_llp = {});
        b = b.google_llp;
        let d = b[a];
        if (d) return d;
        d = sm();
        b[a] = d;
        c();
        return d
    }

    function um(a, b, c) {
        return tm(a, b, () => {
            ud(b.document, c)
        }).promise
    };

    function vm() {
        const a = {};
        P(Uc).g(sh.g, sh.defaultValue) && (a.bust = P(Uc).g(sh.g, sh.defaultValue));
        var b = Kj();
        b = Pj(b, 38, "");
        "" !== b && (a.sbust = b);
        return a
    }
    const wm = new Map([
        [2, 7],
        [3, 1],
        [4, 3],
        [5, 12]
    ]);

    function xm(a, b, c) {
        c = bd(c, vm());
        if (1 === a) return {
            Fb: ud(b.document, c),
            Ta: new Promise(() => {})
        };
        if (wm.has(a)) return {
            Ta: um(wm.get(a), b, c)
        };
        throw Error(`Unexpected chunkId: ${a}`);
    };

    function ym(a) {
        a.google_reactive_ads_global_state ? (null == a.google_reactive_ads_global_state.sideRailProcessedFixedElements && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new Set), null == a.google_reactive_ads_global_state.sideRailAvailableSpace && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new Map), null == a.google_reactive_ads_global_state.sideRailPlasParam && (a.google_reactive_ads_global_state.sideRailPlasParam = new Map)) : a.google_reactive_ads_global_state = new zm;
        return a.google_reactive_ads_global_state
    }
    class zm {
        constructor() {
            this.wasPlaTagProcessed = !1;
            this.wasReactiveAdConfigReceived = {};
            this.adCount = {};
            this.wasReactiveAdVisible = {};
            this.stateForType = {};
            this.reactiveTypeEnabledInAsfe = {};
            this.wasReactiveTagRequestSent = !1;
            this.reactiveTypeDisabledByPublisher = {};
            this.tagSpecificState = {};
            this.messageValidationEnabled = !1;
            this.floatingAdsStacking = new Am;
            this.sideRailProcessedFixedElements = new Set;
            this.sideRailAvailableSpace = new Map;
            this.sideRailPlasParam = new Map
        }
    }
    var Am = class {
        constructor() {
            this.maxZIndexRestrictions = {};
            this.nextRestrictionId = 0;
            this.maxZIndexListeners = []
        }
    };
    var Bm = a => {
        if (p.google_apltlad) return null;
        var b = Q(Ah) && 1 === (p.top == p ? 0 : sd(p.top) ? 1 : 2);
        if (p !== p.top && !b || !a.google_ad_client) return null;
        p.google_apltlad = !0;
        b = {
            enable_page_level_ads: {
                pltais: !0
            },
            google_ad_client: a.google_ad_client
        };
        const c = b.enable_page_level_ads;
        yd(a, (d, e) => {
            ri[e] && "google_ad_client" !== e && (c[e] = d)
        });
        c.google_pgb_reactive = 7;
        om(c);
        if ("google_ad_section" in a || "google_ad_region" in a) c.google_ad_section = a.google_ad_section || a.google_ad_region;
        return b
    };

    function Cm(a, b) {
        X(S).ama_ran_on_page || Ui(1001, () => {
            Dm(new Em(a, b))
        }, p)
    }

    function Dm(a) {
        bm(a.l, a.h, a.g.google_ad_client || "", (b, c) => {
            var d = a.l,
                e = a.g;
            X(S).ama_ran_on_page || b && Fm(d, e, b, c)
        })
    }
    class Em {
        constructor(a, b) {
            this.l = p;
            this.g = a;
            this.h = b
        }
    }

    function Fm(a, b, c, d) {
        d && (Zi(a).configSourceInAbg = d);
        dc(c, Ii, 24) && (d = $i(a), d.availableAbg = !0, d.ablationFromStorage = !!E(c, Ii, 24) ? .g() ? .g());
        if (da(b.enable_page_level_ads) && 7 === b.enable_page_level_ads.google_pgb_reactive) {
            if (!tl(a, F(c, Ei, 7))) {
                mj("amaait", {
                    value: "true"
                });
                return
            }
            mj("amaait", {
                value: "false"
            })
        }
        X(S).ama_ran_on_page = !0;
        E(c, wi, 15) ? .g() && (X(a).enable_overlap_observer = !0);
        var e = E(c, vi, 13);
        e && 1 === I(e, 1) ? (d = 0, (e = E(e, ui, 6)) && G(e, 3) && (d = G(e, 3) || 0), Jl(a, d)) : E(c, Ii, 24) ? .g() ? .g() && ($i(a).ablatingThisPageview = !0, Jl(a, 1));
        Zd(3, [c.toJSON()]);
        const f = b.google_ad_client || "";
        b = pl(da(b.enable_page_level_ads) ? b.enable_page_level_ads : {});
        const g = dh(hh, new eh(null, b));
        lj(782, () => {
            nm(a, f, c, g)
        })
    };

    function Gm(a, b) {
        a = a.document;
        for (var c = void 0, d = 0; !c || a.getElementById(c + "_host");) c = "aswift_" + d++;
        a = c;
        c = Number(b.google_ad_width || 0);
        b = Number(b.google_ad_height || 0);
        d = document.createElement("div");
        d.id = a + "_host";
        const e = d.style;
        e.border = "none";
        e.height = `${b}px`;
        e.width = `${c}px`;
        e.margin = "0px";
        e.padding = "0px";
        e.position = "relative";
        e.visibility = "visible";
        e.backgroundColor = "transparent";
        e.display = "inline-block";
        return {
            tb: a,
            Mb: d
        }
    };

    function Hm({
        va: a,
        Ca: b
    }) {
        return a || ("dev" === b ? "dev" : "")
    };
    var Im = {
            google_analytics_domain_name: !0,
            google_analytics_uacct: !0,
            google_pause_ad_requests: !0,
            google_user_agent_client_hint: !0
        },
        Jm = a => (a = a.innerText || a.innerHTML) && (a = a.replace(/^\s+/, "").split(/\r?\n/, 1)[0].match(/^\x3c!--+(.*?)(?:--+>)?\s*$/)) && RegExp("google_ad_client").test(a[1]) ? a[1] : null,
        Km = a => {
            if (a = a.innerText || a.innerHTML)
                if (a = a.replace(/^\s+|\s+$/g, "").replace(/\s*(\r?\n)+\s*/g, ";"), (a = a.match(/^\x3c!--+(.*?)(?:--+>)?$/) || a.match(/^\/*\s*<!\[CDATA\[(.*?)(?:\/*\s*\]\]>)?$/i)) && RegExp("google_ad_client").test(a[1])) return a[1];
            return null
        },
        Lm = a => {
            switch (a) {
                case "true":
                    return !0;
                case "false":
                    return !1;
                case "null":
                    return null;
                case "undefined":
                    break;
                default:
                    try {
                        const b = a.match(/^(?:'(.*)'|"(.*)")$/);
                        if (b) return b[1] || b[2] || "";
                        if (/^[-+]?\d*(\.\d+)?$/.test(a)) {
                            const c = parseFloat(a);
                            return c === c ? c : void 0
                        }
                    } catch (b) {}
            }
        };

    function Mm(a) {
        if (a.google_ad_client) var b = String(a.google_ad_client);
        else {
            if (null == (b = X(a).head_tag_slot_vars ? .google_ad_client ? ? a.document.querySelector(".adsbygoogle[data-ad-client]") ? .getAttribute("data-ad-client"))) {
                b: {
                    b = a.document.getElementsByTagName("script");a = a.navigator && a.navigator.userAgent || "";a = RegExp("appbankapppuzdradb|daumapps|fban|fbios|fbav|fb_iab|gsa/|messengerforios|naver|niftyappmobile|nonavigation|pinterest|twitter|ucbrowser|yjnewsapp|youtube", "i").test(a) || /i(phone|pad|pod)/i.test(a) &&
                    /applewebkit/i.test(a) && !/version|safari/i.test(a) && !de() ? Jm : Km;
                    for (var c = b.length - 1; 0 <= c; c--) {
                        var d = b[c];
                        if (!d.google_parsed_script_for_pub_code && (d.google_parsed_script_for_pub_code = !0, d = a(d))) {
                            b = d;
                            break b
                        }
                    }
                    b = null
                }
                if (b) {
                    a = /(google_\w+) *= *(['"]?[\w.-]+['"]?) *(?:;|$)/gm;
                    for (c = {}; d = a.exec(b);) c[d[1]] = Lm(d[2]);
                    b = c;
                    b = b.google_ad_client ? b.google_ad_client : ""
                } else b = ""
            }
            b = b ? ? ""
        }
        return b
    };
    var Nm = {
        "120x90": !0,
        "160x90": !0,
        "180x90": !0,
        "200x90": !0,
        "468x15": !0,
        "728x15": !0
    };

    function Om(a, b) {
        if (15 == b) {
            if (728 <= a) return 728;
            if (468 <= a) return 468
        } else if (90 == b) {
            if (200 <= a) return 200;
            if (180 <= a) return 180;
            if (160 <= a) return 160;
            if (120 <= a) return 120
        }
        return null
    };
    var Pm = class extends N {
        constructor() {
            super()
        }
        getVersion() {
            return L(this, 2)
        }
    };

    function Qm(a, b) {
        return y(a, 2, Lb(b))
    }

    function Rm(a, b) {
        return y(a, 3, Lb(b))
    }

    function Sm(a, b) {
        return y(a, 4, Lb(b))
    }

    function Tm(a, b) {
        return y(a, 5, Lb(b))
    }

    function Um(a, b) {
        return y(a, 9, Lb(b))
    }

    function Vm(a, b) {
        return uc(a, 10, b)
    }

    function Wm(a, b) {
        return y(a, 11, zb(b))
    }

    function Xm(a, b) {
        return y(a, 1, Lb(b))
    }

    function Ym(a, b) {
        return y(a, 7, zb(b))
    }
    var Zm = class extends N {
        constructor() {
            super()
        }
    };
    Zm.u = [10, 6];
    const $m = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function an() {
        var a = S;
        if ("function" !== typeof a.navigator ? .userAgentData ? .getHighEntropyValues) return null;
        const b = a.google_tag_data ? ? (a.google_tag_data = {});
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues($m).then(c => {
            b.uach ? ? (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function bn(a) {
        return Wm(Vm(Tm(Qm(Xm(Sm(Ym(Um(Rm(new Zm, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), a.fullVersionList ? .map(b => {
            var c = new Pm;
            c = y(c, 1, Lb(b.brand));
            return y(c, 2, Lb(b.version))
        }) || []), a.wow64 || !1)
    }

    function cn() {
        return an() ? .then(a => bn(a)) ? ? null
    };

    function dn() {
        var a = S;
        a.google_sa_impl && !a.document.getElementById("google_shimpl") && (delete a.google_sa_queue, delete a.google_sa_impl)
    }

    function en(a, b) {
        b.google_ad_host || (a = Nl(a)) && (b.google_ad_host = a)
    }

    function fn(a, b, c = "") {
        Q(Ch) || dn();
        S.google_sa_queue || (S.google_sa_queue = [], S.google_process_slots = W.oa(215, () => {
            gn(S.google_sa_queue)
        }), a = hn(c, a, b), a = xm(1, S, a).Fb, Q(Ch) || (a.id = "google_shimpl"))
    }

    function gn(a) {
        const b = a.shift();
        "function" === typeof b && W.ea(216, b);
        a.length && p.setTimeout(W.oa(215, () => {
            gn(a)
        }), 0)
    }

    function jn(a, b) {
        a.google_sa_queue = a.google_sa_queue || [];
        a.google_sa_impl ? b() : a.google_sa_queue.push(b)
    }

    function hn(a, b, c) {
        var d = S;
        b = K(c, 4) ? b.Gb : b.Hb;
        a: {
            if (K(c, 4)) {
                if (a = a || Mm(d)) {
                    d = {
                        client: a,
                        plah: d.location.host
                    };
                    break a
                }
                throw Error("PublisherCodeNotFoundForAma");
            }
            d = {}
        }
        return bd(b, d)
    }

    function kn(a) {
        a: {
            var b = [p.top];
            var c = [];
            let e = 0,
                f;
            for (; f = b[e++];) {
                c.push(f);
                try {
                    if (f.frames)
                        for (let g = 0; g < f.frames.length && 1024 > b.length; ++g) b.push(f.frames[g])
                } catch {}
            }
            b = c;
            for (c = 0; c < b.length; c++) try {
                var d = b[c].frames.google_esf;
                if (d) {
                    Td = d;
                    break a
                }
            } catch (g) {}
            Td = null
        }
        if (Td) return null;d = vd("IFRAME");d.id = "google_esf";d.name = "google_esf";b = a.Pb;c = P(Uc).g(Dh.g, Dh.defaultValue);
        "inhead" === c ? b = a.Nb : "nohtml" === c && (b = a.Ob);Q(zh) && (b = bd(b, {
            hello: "world"
        }));d.src = dd(b).toString();d.style.display = "none";
        return d
    }

    function ln(a, b, c, d) {
        const {
            tb: e,
            Mb: f
        } = Gm(a, b);
        c.appendChild(f);
        mn(a, c, b);
        c = b.google_start_time ? ? oa;
        const g = (new Date).getTime();
        b.google_lrv = Hm({
            va: "m202401170101",
            Ca: L(d, 2)
        });
        b.google_async_iframe_id = e;
        b.google_start_time = c;
        b.google_bpp = g > c ? g - c : 1;
        a.google_sv_map = a.google_sv_map || {};
        a.google_sv_map[e] = b;
        jn(a, () => {
            var h = f;
            if (!h || !h.isConnected)
                if (h = a.document.getElementById(String(b.google_async_iframe_id) + "_host"), null == h) throw Error("no_div");
            (h = a.google_sa_impl({
                pubWin: a,
                vars: b,
                innerInsElement: h
            })) &&
            W.Y(911, h)
        })
    }

    function mn(a, b, c) {
        var d = c.google_ad_output,
            e = c.google_ad_format,
            f = c.google_ad_width || 0,
            g = c.google_ad_height || 0;
        e || "html" !== d && null != d || (e = f + "x" + g);
        d = !c.google_ad_slot || c.google_override_format || !Nm[c.google_ad_width + "x" + c.google_ad_height] && "aa" === c.google_loader_used;
        e && d ? e = e.toLowerCase() : e = "";
        c.google_ad_format = e;
        if ("number" !== typeof c.google_reactive_sra_index || !c.google_ad_unit_key) {
            e = [c.google_ad_slot, c.google_orig_ad_format || c.google_ad_format, c.google_ad_type, c.google_orig_ad_width || c.google_ad_width,
                c.google_orig_ad_height || c.google_ad_height
            ];
            d = [];
            f = 0;
            for (g = b; g && 25 > f; g = g.parentNode, ++f) 9 === g.nodeType ? d.push("") : d.push(g.id);
            (d = d.join()) && e.push(d);
            c.google_ad_unit_key = zd(e.join(":")).toString();
            e = [];
            for (d = 0; b && 25 > d; ++d) {
                f = (f = 9 !== b.nodeType && b.id) ? "/" + f : "";
                a: {
                    if (b && b.nodeName && b.parentElement) {
                        g = b.nodeName.toString().toLowerCase();
                        const h = b.parentElement.childNodes;
                        let k = 0;
                        for (let m = 0; m < h.length; ++m) {
                            const l = h[m];
                            if (l.nodeName && l.nodeName.toString().toLowerCase() === g) {
                                if (b === l) {
                                    g = "." + k;
                                    break a
                                }++k
                            }
                        }
                    }
                    g =
                    ""
                }
                e.push((b.nodeName && b.nodeName.toString().toLowerCase()) + f + g);
                b = b.parentElement
            }
            b = e.join() + ":";
            e = [];
            if (a) try {
                let h = a.parent;
                for (d = 0; h && h !== a && 25 > d; ++d) {
                    const k = h.frames;
                    for (f = 0; f < k.length; ++f)
                        if (a === k[f]) {
                            e.push(f);
                            break
                        }
                    a = h;
                    h = a.parent
                }
            } catch (h) {}
            c.google_ad_dom_fingerprint = zd(b + e.join()).toString()
        }
    }

    function nn() {
        var a = td(p);
        a && (a = ym(a), a.tagSpecificState[1] || (a.tagSpecificState[1] = {
            debugCard: null,
            debugCardRequested: !1
        }))
    }

    function on() {
        const a = cn();
        null != a && a.then(b => {
            a: {
                ob = !0;
                try {
                    var c = JSON.stringify(b.toJSON(), Qb);
                    break a
                } finally {
                    ob = !1
                }
                c = void 0
            }
            S.google_user_agent_client_hint = c
        });
        Id()
    };

    function pn(a) {
        return b => !!(b.fa & a)
    }
    class Y extends ji {
        constructor(a, b, c, d = !1) {
            super(a, b);
            this.fa = c;
            this.xb = d
        }
        pa() {
            return this.fa
        }
        h(a, b, c) {
            c.style.height = this.height() + "px";
            b.rpe = !0
        }
    };
    const qn = {
            image_stacked: 1 / 1.91,
            image_sidebyside: 1 / 3.82,
            mobile_banner_image_sidebyside: 1 / 3.82,
            pub_control_image_stacked: 1 / 1.91,
            pub_control_image_sidebyside: 1 / 3.82,
            pub_control_image_card_stacked: 1 / 1.91,
            pub_control_image_card_sidebyside: 1 / 3.74,
            pub_control_text: 0,
            pub_control_text_card: 0
        },
        rn = {
            image_stacked: 80,
            image_sidebyside: 0,
            mobile_banner_image_sidebyside: 0,
            pub_control_image_stacked: 80,
            pub_control_image_sidebyside: 0,
            pub_control_image_card_stacked: 85,
            pub_control_image_card_sidebyside: 0,
            pub_control_text: 80,
            pub_control_text_card: 80
        },
        sn = {
            pub_control_image_stacked: 100,
            pub_control_image_sidebyside: 200,
            pub_control_image_card_stacked: 150,
            pub_control_image_card_sidebyside: 250,
            pub_control_text: 100,
            pub_control_text_card: 150
        };

    function tn(a) {
        var b = 0;
        a.P && b++;
        a.K && b++;
        a.L && b++;
        if (3 > b) return {
            N: "Tags data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num should be set together."
        };
        b = a.P.split(",");
        const c = a.L.split(",");
        a = a.K.split(",");
        if (b.length !== c.length || b.length !== a.length) return {
            N: 'Lengths of parameters data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num must match. Example: \n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'
        };
        if (2 < b.length) return {
            N: "The parameter length of attribute data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num is too long. At most 2 parameters for each attribute are needed: one for mobile and one for desktop, while " + `you are providing ${b.length} parameters. Example: ${'\n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'}.`
        };
        const d = [],
            e = [];
        for (let g = 0; g <
            b.length; g++) {
            var f = Number(c[g]);
            if (Number.isNaN(f) || 0 === f) return {
                N: `Wrong value '${c[g]}' for ${"data-matched-content-rows-num"}.`
            };
            d.push(f);
            f = Number(a[g]);
            if (Number.isNaN(f) || 0 === f) return {
                N: `Wrong value '${a[g]}' for ${"data-matched-content-columns-num"}.`
            };
            e.push(f)
        }
        return {
            L: d,
            K: e,
            bb: b
        }
    }

    function un(a) {
        return 1200 <= a ? {
            width: 1200,
            height: 600
        } : 850 <= a ? {
            width: a,
            height: Math.floor(.5 * a)
        } : 550 <= a ? {
            width: a,
            height: Math.floor(.6 * a)
        } : 468 <= a ? {
            width: a,
            height: Math.floor(.7 * a)
        } : {
            width: a,
            height: Math.floor(3.44 * a)
        }
    };
    const vn = Oa("script");
    class wn {
        constructor(a, b, c = null, d = null, e = null, f = null, g = null, h = null, k = null, m = null, l = null, n = null) {
            this.B = a;
            this.ba = b;
            this.fa = c;
            this.g = d;
            this.X = e;
            this.h = f;
            this.i = g;
            this.C = h;
            this.D = k;
            this.j = m;
            this.s = l;
            this.H = n
        }
        size() {
            return this.ba
        }
    };
    const xn = ["google_content_recommendation_ui_type", "google_content_recommendation_columns_num", "google_content_recommendation_rows_num"];
    var yn = class extends ji {
        g(a) {
            return Math.min(1200, Math.max(this.U, Math.round(a)))
        }
    };

    function zn(a, b) {
        An(a, b);
        if ("pedestal" === b.google_content_recommendation_ui_type) return new wn(9, new yn(a, Math.floor(a * b.google_phwr)));
        var c = ld();
        468 > a ? c ? (c = a - 8 - 8, c = Math.floor(c / 1.91 + 70) + Math.floor(11 * (c * qn.mobile_banner_image_sidebyside + rn.mobile_banner_image_sidebyside) + 96), a = {
            aa: a,
            Z: c,
            K: 1,
            L: 12,
            P: "mobile_banner_image_sidebyside"
        }) : (a = un(a), a = {
            aa: a.width,
            Z: a.height,
            K: 1,
            L: 13,
            P: "image_sidebyside"
        }) : (a = un(a), a = {
            aa: a.width,
            Z: a.height,
            K: 4,
            L: 2,
            P: "image_stacked"
        });
        Bn(b, a);
        return new wn(9, new yn(a.aa, a.Z))
    }

    function Cn(a, b) {
        An(a, b);
        var c = tn({
            L: b.google_content_recommendation_rows_num,
            K: b.google_content_recommendation_columns_num,
            P: b.google_content_recommendation_ui_type
        });
        if (c.N) a = {
            aa: 0,
            Z: 0,
            K: 0,
            L: 0,
            P: "image_stacked",
            N: c.N
        };
        else {
            var d = 2 === c.bb.length && 468 <= a ? 1 : 0;
            var e = c.bb[d];
            e = 0 === e.indexOf("pub_control_") ? e : "pub_control_" + e;
            var f = sn[e];
            let g = c.K[d];
            for (; a / g < f && 1 < g;) g--;
            f = g;
            d = c.L[d];
            c = Math.floor(((a - 8 * f - 8) / f * qn[e] + rn[e]) * d + 8 * d + 8);
            a = 1500 < a ? {
                    width: 0,
                    height: 0,
                    Ib: `Calculated slot width is too large: ${a}`
                } :
                1500 < c ? {
                    width: 0,
                    height: 0,
                    Ib: `Calculated slot height is too large: ${c}`
                } : {
                    width: a,
                    height: c
                };
            a = {
                aa: a.width,
                Z: a.height,
                K: f,
                L: d,
                P: e
            }
        }
        if (a.N) throw new V(a.N);
        Bn(b, a);
        return new wn(9, new yn(a.aa, a.Z))
    }

    function An(a, b) {
        if (0 >= a) throw new V(`Invalid responsive width from Matched Content slot ${b.google_ad_slot}: ${a}. Please ensure to put this Matched Content slot into a non-zero width div container.`);
    }

    function Bn(a, b) {
        a.google_content_recommendation_ui_type = b.P;
        a.google_content_recommendation_columns_num = b.K;
        a.google_content_recommendation_rows_num = b.L
    };
    class Dn extends ji {
        g() {
            return this.U
        }
        h(a, b, c) {
            ii(a, c);
            c.style.height = this.height() + "px";
            b.rpe = !0
        }
    };
    const En = {
        "image-top": a => 600 >= a ? 284 + .414 * (a - 250) : 429,
        "image-middle": a => 500 >= a ? 196 - .13 * (a - 250) : 164 + .2 * (a - 500),
        "image-side": a => 500 >= a ? 205 - .28 * (a - 250) : 134 + .21 * (a - 500),
        "text-only": a => 500 >= a ? 187 - .228 * (a - 250) : 130,
        "in-article": a => 420 >= a ? a / 1.2 : 460 >= a ? a / 1.91 + 130 : 800 >= a ? a / 4 : 200
    };
    var Fn = class extends ji {
            g() {
                return Math.min(1200, this.U)
            }
        },
        Gn = (a, b, c, d, e) => {
            var f = e.google_ad_layout || "image-top";
            if ("in-article" == f) {
                var g = a;
                if ("false" == e.google_full_width_responsive) a = g;
                else if (a = di(b, c, g, .2, e), !0 !== a) e.gfwrnwer = a, a = g;
                else if (a = Yh(b))
                    if (e.google_full_width_responsive_allowed = !0, c.parentElement) {
                        b: {
                            g = c;
                            for (let h = 0; 100 > h && g.parentElement; ++h) {
                                const k = g.parentElement.childNodes;
                                for (let m = 0; m < k.length; ++m) {
                                    const l = k[m];
                                    if (l != g && gi(b, l)) break b
                                }
                                g = g.parentElement;
                                g.style.width = "100%";
                                g.style.height = "auto"
                            }
                        }
                        ii(b, c)
                    }
                else a = g;
                else a = g
            }
            if (250 > a) throw new V("Fluid responsive ads must be at least 250px wide: availableWidth=" + a);
            a = Math.min(1200, Math.floor(a));
            if (d && "in-article" != f) {
                f = Math.ceil(d);
                if (50 > f) throw new V("Fluid responsive ads must be at least 50px tall: height=" + f);
                return new wn(11, new ji(a, f))
            }
            if ("in-article" != f && (d = e.google_ad_layout_key)) {
                f = "" + d;
                c = Math.pow(10, 3);
                if (e = (d = f.match(/([+-][0-9a-z]+)/g)) && d.length)
                    for (b = [], g = 0; g < e; g++) b.push(parseInt(d[g], 36) / c);
                else b = null;
                if (!b) throw new V("Invalid data-ad-layout-key value: " + f);
                f = (a + -725) / 1E3;
                c = 0;
                d = 1;
                e = b.length;
                for (g = 0; g < e; g++) c += b[g] * d, d *= f;
                f = Math.ceil(1E3 * c - -725 + 10);
                if (isNaN(f)) throw new V("Invalid height: height=" + f);
                if (50 > f) throw new V("Fluid responsive ads must be at least 50px tall: height=" + f);
                if (1200 < f) throw new V("Fluid responsive ads must be at most 1200px tall: height=" + f);
                return new wn(11, new ji(a, f))
            }
            d = En[f];
            if (!d) throw new V("Invalid data-ad-layout value: " + f);
            c = mi(c, b);
            b = Yh(b);
            b = "in-article" !== f ||
                c || a !== b ? Math.ceil(d(a)) : Math.ceil(1.25 * d(a));
            return new wn(11, "in-article" == f ? new Fn(a, b) : new ji(a, b))
        };

    function Hn(a) {
        return b => {
            for (let c = a.length - 1; 0 <= c; --c)
                if (!a[c](b)) return !1;
            return !0
        }
    }

    function In(a, b) {
        var c = Jn.slice(0);
        const d = c.length;
        let e = null;
        for (let f = 0; f < d; ++f) {
            const g = c[f];
            if (a(g)) {
                if (null == b || b(g)) return g;
                null === e && (e = g)
            }
        }
        return e
    };
    var Z = [new Y(970, 90, 2), new Y(728, 90, 2), new Y(468, 60, 2), new Y(336, 280, 1), new Y(320, 100, 2), new Y(320, 50, 2), new Y(300, 600, 4), new Y(300, 250, 1), new Y(250, 250, 1), new Y(234, 60, 2), new Y(200, 200, 1), new Y(180, 150, 1), new Y(160, 600, 4), new Y(125, 125, 1), new Y(120, 600, 4), new Y(120, 240, 4), new Y(120, 120, 1, !0)],
        Jn = [Z[6], Z[12], Z[3], Z[0], Z[7], Z[14], Z[1], Z[8], Z[10], Z[4], Z[15], Z[2], Z[11], Z[5], Z[13], Z[9], Z[16]];
    var Ln = (a, b, c, d, e) => {
            "false" == e.google_full_width_responsive ? c = {
                F: a,
                G: 1
            } : "autorelaxed" === b && e.google_full_width_responsive || Kn(b) || e.google_ad_resize ? (b = ei(a, c, d, e), c = !0 !== b ? {
                F: a,
                G: b
            } : {
                F: Yh(c) || a,
                G: !0
            }) : c = {
                F: a,
                G: 2
            };
            const {
                F: f,
                G: g
            } = c;
            return !0 !== g ? {
                F: a,
                G: g
            } : d.parentElement ? {
                F: f,
                G: g
            } : {
                F: a,
                G: g
            }
        },
        On = (a, b, c, d, e) => {
            const {
                F: f,
                G: g
            } = lj(247, () => Ln(a, b, c, d, e));
            var h = !0 === g;
            const k = R(d.style.width),
                m = R(d.style.height),
                {
                    W: l,
                    T: n,
                    pa: w,
                    ab: v
                } = Mn(f, b, c, d, e, h);
            h = Nn(b, w);
            var x;
            const z = (x = ki(d, c, "marginLeft", R)) ? x + "px" :
                "",
                A = (x = ki(d, c, "marginRight", R)) ? x + "px" : "";
            x = ki(d, c, "zIndex") || "";
            return new wn(h, l, w, null, v, g, n, z, A, m, k, x)
        },
        Kn = a => "auto" == a || /^((^|,) *(horizontal|vertical|rectangle) *)+$/.test(a),
        Mn = (a, b, c, d, e, f) => {
            b = Pn(c, a, b);
            let g;
            var h = !1;
            let k = !1;
            var m = 488 > Yh(c);
            if (m) {
                g = Zh(d, c);
                var l = mi(d, c);
                h = !l && g;
                k = l && g
            }
            l = [li(a), pn(b)];
            l.push(oi(m, c, d, k));
            null != e.google_max_responsive_height && l.push(pi(e.google_max_responsive_height));
            m = [x => !x.xb];
            if (h || k) h = qi(c, d), m.push(pi(h));
            let n = In(Hn(l), Hn(m));
            if (!n) throw new V("No slot size for availableWidth=" +
                a);
            const {
                W: w,
                T: v
            } = lj(248, () => {
                var x;
                a: if (f) {
                    if (e.gfwrnh && (x = R(e.gfwrnh))) {
                        x = {
                            W: new Dn(a, x),
                            T: !0
                        };
                        break a
                    }
                    x = a / 1.2;
                    var z = Math;
                    var A = z.min;
                    if (e.google_resizing_allowed || "true" == e.google_full_width_responsive) var B = Infinity;
                    else {
                        B = d;
                        let sa = Infinity;
                        do {
                            var J = ki(B, c, "height", R);
                            J && (sa = Math.min(sa, J));
                            (J = ki(B, c, "maxHeight", R)) && (sa = Math.min(sa, J))
                        } while ((B = B.parentElement) && "HTML" != B.tagName);
                        B = sa
                    }
                    z = A.call(z, x, B);
                    if (z < .5 * x || 100 > z) z = x;
                    x = {
                        W: new Dn(a, Math.floor(z)),
                        T: z < x ? 102 : !0
                    }
                } else x = {
                    W: n,
                    T: 100
                };
                return x
            });
            return "in-article" === e.google_ad_layout && c.location && "#hffwroe2etoq" == c.location.hash ? {
                W: Qn(a, c, d, w, e),
                T: !1,
                pa: b,
                ab: g
            } : {
                W: w,
                T: v,
                pa: b,
                ab: g
            }
        };
    const Nn = (a, b) => {
            if ("auto" == a) return 1;
            switch (b) {
                case 2:
                    return 2;
                case 1:
                    return 3;
                case 4:
                    return 4;
                case 3:
                    return 5;
                case 6:
                    return 6;
                case 5:
                    return 7;
                case 7:
                    return 8
            }
            throw Error("bad mask");
        },
        Pn = (a, b, c) => {
            if ("auto" == c) c = Math.min(1200, Yh(a)), b = .25 >= b / c ? 4 : 3;
            else {
                b = 0;
                for (let d in Vh) - 1 != c.indexOf(d) && (b |= Vh[d])
            }
            return b
        },
        Qn = (a, b, c, d, e) => {
            const f = e.google_ad_height || ki(c, b, "height", R);
            b = Gn(a, b, c, f, e).size();
            return b.U * b.height() > a * d.height() ? new Y(b.U, b.height(), 1) : d
        };
    var Rn = (a, b, c, d, e) => {
        var f;
        (f = Yh(b)) ? 488 > Yh(b) ? b.innerHeight >= b.innerWidth ? (e.google_full_width_responsive_allowed = !0, ii(b, c), f = {
            F: f,
            G: !0
        }) : f = {
            F: a,
            G: 5
        } : f = {
            F: a,
            G: 4
        }: f = {
            F: a,
            G: 10
        };
        const {
            F: g,
            G: h
        } = f;
        if (!0 !== h || a == g) return new wn(12, new ji(a, d), null, null, !0, h, 100);
        const {
            W: k,
            T: m,
            pa: l
        } = Mn(g, "auto", b, c, e, !0);
        return new wn(1, k, l, 2, !0, h, m)
    };
    var Tn = (a, b) => {
            const c = b.google_ad_format;
            if ("autorelaxed" === c) {
                a: {
                    if ("pedestal" !== b.google_content_recommendation_ui_type)
                        for (const d of xn)
                            if (null != b[d]) {
                                a = !0;
                                break a
                            }
                    a = !1
                }
                return a ? 9 : 5
            }
            if (Kn(c)) return 1;
            if ("link" === c) return 4;
            if ("fluid" == c) return "in-article" !== b.google_ad_layout || !a.location || "#hffwroe2etop" != a.location.hash && "#hffwroe2etoq" != a.location.hash ? 8 : (Sn(b), 1);
            if (27 === b.google_reactive_ad_format) return Sn(b), 1
        },
        Vn = (a, b, c, d, e = !1) => {
            var f = b.offsetWidth || (c.google_ad_resize || e) && ki(b, d, "width",
                R) || c.google_ad_width || 0;
            4 === a && (c.google_ad_format = "auto", a = 1);
            e = (e = Un(a, f, b, c, d)) ? e : On(f, c.google_ad_format, d, b, c);
            e.size().h(d, c, b);
            null != e.fa && (c.google_responsive_formats = e.fa);
            null != e.X && (c.google_safe_for_responsive_override = e.X);
            null != e.h && (!0 === e.h ? c.google_full_width_responsive_allowed = !0 : (c.google_full_width_responsive_allowed = !1, c.gfwrnwer = e.h));
            null != e.i && !0 !== e.i && (c.gfwrnher = e.i);
            d = e.s || c.google_ad_width;
            null != d && (c.google_resizing_width = d);
            d = e.j || c.google_ad_height;
            null != d && (c.google_resizing_height =
                d);
            d = e.size().g(f);
            const g = e.size().height();
            c.google_ad_width = d;
            c.google_ad_height = g;
            var h = e.size();
            f = h.g(f) + "x" + h.height();
            c.google_ad_format = f;
            c.google_responsive_auto_format = e.B;
            null != e.g && (c.armr = e.g);
            c.google_ad_resizable = !0;
            c.google_override_format = 1;
            c.google_loader_features_used = 128;
            !0 === e.h && (c.gfwrnh = e.size().height() + "px");
            null != e.C && (c.gfwroml = e.C);
            null != e.D && (c.gfwromr = e.D);
            null != e.j && (c.gfwroh = e.j);
            null != e.s && (c.gfwrow = e.s);
            null != e.H && (c.gfwroz = e.H);
            f = td(window) || window;
            pm(f.location,
                "google_responsive_dummy_ad") && (Ma([1, 2, 3, 4, 5, 6, 7, 8], e.B) || 1 === e.g) && 2 !== e.g && (f = JSON.stringify({
                googMsgType: "adpnt",
                key_value: [{
                    key: "qid",
                    value: "DUMMY_AD"
                }]
            }), c.dash = `<${vn}>window.top.postMessage('${f}', '*'); 
          </${vn}> 
          <div id="dummyAd" style="width:${d}px;height:${g}px; 
            background:#ddd;border:3px solid #f00;box-sizing:border-box; 
            color:#000;"> 
            <p>Requested size:${d}x${g}</p> 
            <p>Rendered size:${d}x${g}</p> 
          </div>`);
            1 != a && (a = e.size().height(), b.style.height = a + "px")
        };
    const Un = (a, b, c, d, e) => {
            const f = d.google_ad_height || ki(c, e, "height", R);
            switch (a) {
                case 5:
                    const {
                        F: g,
                        G: h
                    } = lj(247, () => Ln(b, d.google_ad_format, e, c, d));
                    !0 === h && b != g && ii(e, c);
                    !0 === h ? d.google_full_width_responsive_allowed = !0 : (d.google_full_width_responsive_allowed = !1, d.gfwrnwer = h);
                    return zn(g, d);
                case 9:
                    return Cn(b, d);
                case 8:
                    return Gn(b, e, c, f, d);
                case 10:
                    return Rn(b, e, c, f, d)
            }
        },
        Sn = a => {
            a.google_ad_format = "auto";
            a.armr = 3
        };

    function Wn(a, b) {
        a.google_resizing_allowed = !0;
        a.ovlp = !0;
        a.google_ad_format = "auto";
        a.iaaso = !0;
        a.armr = b
    };

    function Xn(a, b) {
        var c = td(b);
        if (c) {
            c = Yh(c);
            const d = wd(a, b) || {},
                e = d.direction;
            if ("0px" === d.width && "none" !== d.cssFloat) return -1;
            if ("ltr" === e && c) return Math.floor(Math.min(1200, c - a.getBoundingClientRect().left));
            if ("rtl" === e && c) return a = b.document.body.getBoundingClientRect().right - a.getBoundingClientRect().right, Math.floor(Math.min(1200, c - a - Math.floor((c - b.document.body.clientWidth) / 2)))
        }
        return -1
    };

    function Yn(a, b) {
        switch (a) {
            case "google_reactive_ad_format":
                return a = parseInt(b, 10), isNaN(a) ? 0 : a;
            case "google_allow_expandable_ads":
                return /^true$/.test(b);
            default:
                return b
        }
    }

    function Zn(a, b) {
        if (a.getAttribute("src")) {
            var c = a.getAttribute("src") || "",
                d = pd(c, "client");
            d && (b.google_ad_client = Yn("google_ad_client", d));
            (c = pd(c, "host")) && (b.google_ad_host = Yn("google_ad_host", c))
        }
        a = a.attributes;
        c = a.length;
        for (d = 0; d < c; d++) {
            var e = a[d];
            if (/data-/.test(e.name)) {
                const f = pa(e.name.replace("data-matched-content", "google_content_recommendation").replace("data", "google").replace(/-/g, "_"));
                b.hasOwnProperty(f) || (e = Yn(f, e.value), null !== e && (b[f] = e))
            }
        }
    }

    function $n(a) {
        if (a = $d(a)) switch (a.data && a.data.autoFormat) {
            case "rspv":
                return 13;
            case "mcrspv":
                return 15;
            default:
                return 14
        } else return 12
    }

    function ao(a, b, c, d) {
        Zn(a, b);
        if (c.document && c.document.body && !Tn(c, b) && !b.google_reactive_ad_format) {
            var e = parseInt(a.style.width, 10),
                f = Xn(a, c);
            if (0 < f && e > f) {
                var g = parseInt(a.style.height, 10);
                e = !!Nm[e + "x" + g];
                let h = f;
                if (e) {
                    const k = Om(f, g);
                    if (k) h = k, b.google_ad_format = k + "x" + g + "_0ads_al";
                    else throw new V("No slot size for availableWidth=" + f);
                }
                b.google_ad_resize = !0;
                b.google_ad_width = h;
                e || (b.google_ad_format = null, b.google_override_format = !0);
                f = h;
                a.style.width = `${f}px`;
                Wn(b, 4)
            }
        }
        if (488 > Yh(c)) {
            f = td(c) || c;
            (g =
                a.offsetWidth) || (g = ki(a, c, "width", R));
            g = g || b.google_ad_width || 0;
            e = b.google_ad_client;
            if (d = pm(f.location, "google_responsive_slot_preview") || Q(Bh) || Rl(f, 1, e, d)) b: if (b.google_reactive_ad_format || b.google_ad_resize || Tn(c, b) || ai(a, b)) d = !1;
                else {
                    for (d = a; d; d = d.parentElement) {
                        f = wd(d, c);
                        if (!f) {
                            b.gfwrnwer = 18;
                            d = !1;
                            break b
                        }
                        if (!Ma(["static", "relative"], f.position)) {
                            b.gfwrnwer = 17;
                            d = !1;
                            break b
                        }
                    }
                    d = di(c, a, g, .3, b);
                    !0 !== d ? (b.gfwrnwer = d, d = !1) : d = c === c.top ? !0 : !1
                }
            d ? (Wn(b, 1), d = !0) : d = !1
        } else d = !1;
        if (g = Tn(c, b)) Vn(g, a, b, c, d);
        else {
            if (ai(a, b)) {
                if (d = wd(a, c)) a.style.width = d.width, a.style.height = d.height, $h(d, b);
                b.google_ad_width || (b.google_ad_width = a.offsetWidth);
                b.google_ad_height || (b.google_ad_height = a.offsetHeight);
                b.google_loader_features_used = 256;
                b.google_responsive_auto_format = $n(c)
            } else $h(a.style, b);
            c.location && "#gfwmrp" == c.location.hash || 12 == b.google_responsive_auto_format && "true" == b.google_full_width_responsive ? Vn(10, a, b, c, !1) : .01 > Math.random() && 12 === b.google_responsive_auto_format && (a = ei(a.offsetWidth || parseInt(a.style.width,
                10) || b.google_ad_width, c, a, b), !0 !== a ? (b.efwr = !1, b.gfwrnwer = a) : b.efwr = !0)
        }
    };
    var bo = a => {
        if (a == a.top) return 0;
        for (; a && a != a.top && sd(a); a = a.parent) {
            if (a.sf_) return 2;
            if (a.$sf) return 3;
            if (a.inGptIF) return 4;
            if (a.inDapIF) return 5
        }
        return 1
    };

    function Uf(a, b, c = 0) {
        0 < a.g.size || co(a);
        c = Math.min(Math.max(0, c), 9);
        const d = a.g.get(c);
        d ? d.push(b) : a.g.set(c, [b])
    }

    function eo(a, b, c, d) {
        Sc(b, c, d);
        Vj(a, () => Tc(b, c, d))
    }

    function fo(a, b) {
        1 !== a.h && (a.h = 1, 0 < a.g.size && go(a, b))
    }

    function co(a) {
        a.l.document.visibilityState ? eo(a, a.l.document, "visibilitychange", b => {
            "hidden" === a.l.document.visibilityState && fo(a, b);
            "visible" === a.l.document.visibilityState && (a.h = 0)
        }) : "onpagehide" in a.l ? (eo(a, a.l, "pagehide", b => {
            fo(a, b)
        }), eo(a, a.l, "pageshow", () => {
            a.h = 0
        })) : eo(a, a.l, "beforeunload", b => {
            fo(a, b)
        })
    }

    function go(a, b) {
        for (let c = 9; 0 <= c; c--) a.g.get(c) ? .forEach(d => {
            d(b)
        })
    }
    var ho = class extends Uj {
        constructor(a) {
            super();
            this.l = a;
            this.h = 0;
            this.g = new Map
        }
    };
    async function io(a, b) {
        var c = 10;
        return 0 >= c ? Promise.reject() : b() ? Promise.resolve() : new Promise((d, e) => {
            const f = a.setInterval(() => {
                --c ? b() && (a.clearInterval(f), d()) : (a.clearInterval(f), e())
            }, 200)
        })
    };

    function jo(a) {
        const b = a.g.pc;
        return null !== b && 0 !== b ? b : a.g.pc = Ld(a.l)
    }

    function ko(a) {
        const b = a.g.wpc;
        return null !== b && "" !== b ? b : a.g.wpc = Mm(a.l)
    }

    function lo(a, b) {
        var c = new of ;
        var d = jo(a);
        c = Ac(c, 1, d);
        d = ko(a);
        c = Dc(c, 2, d);
        c = Ac(c, 3, a.g.sd);
        return Ac(c, 7, Math.round(b || a.l.performance.now()))
    }
    async function mo(a) {
        await io(a.l, () => !(!jo(a) || !ko(a)))
    }

    function no(a) {
        var b = P(oo);
        b.j && lj(1178, () => {
            const c = b.B;
            a(c);
            b.g.psi = c.toJSON()
        })
    }
    async function po(a) {
        var b = P(oo);
        if (b.j && !b.g.le.includes(1)) {
            b.g.le.push(1);
            var c = b.l.performance.now();
            await mo(b);
            a = cf(df(ff(new gf, a), af($e(new bf, Xh(b.l).scrollWidth), Xh(b.l).scrollHeight)), af($e(new bf, Yh(b.l)), Xh(b.l).clientHeight));
            var d = new jf;
            Q(th) ? (Dc(a, 4, b.i), Dc(d, 1, b.i)) : (Dc(a, 4, b.l ? .document ? .URL), Dc(d, 1, b.l ? .document ? .URL));
            var e = bo(b.l);
            0 !== e && ef(a, Ye(e));
            Qf(b.h, mf(lo(b, c), a));
            Uf(b.s, () => {
                try {
                    if (null != b.g ? .psi) {
                        var f = Ec(hf, Yb(b.g.psi));
                        sc(d, 2, f)
                    }
                } catch {}
                f = b.h;
                var g = lo(b);
                g = tc(g, 8,
                    nf, d);
                Qf(f, g)
            }, 9)
        }
    }
    async function qo(a, b, c) {
        if (a.j && c.length && !a.g.lgdp.includes(Number(b))) {
            a.g.lgdp.push(Number(b));
            var d = a.l.performance.now();
            await mo(a);
            var e = a.h;
            a = lo(a, d);
            d = new Xe;
            b = D(d, 1, u(b), 0);
            c = lc(b, 2, c, Db);
            c = tc(a, 9, nf, c);
            Qf(e, c)
        }
    }
    async function ro(a, b) {
        await mo(a);
        var c = a.h;
        a = lo(a);
        a = Ac(a, 3, 1);
        b = tc(a, 10, nf, b);
        Qf(c, b)
    }
    var oo = class {
        constructor(a, b) {
            this.l = ae() || window;
            this.s = b ? ? new ho(this.l);
            this.h = a ? ? new Wf(2, "m202401170101", 100, 100, !0, this.s);
            this.g = Nj(Kj(), 33, () => {
                const c = Vc(rh);
                return {
                    sd: c,
                    ssp: 0 < c && xd() < 1 / c,
                    pc: null,
                    wpc: null,
                    cu: null,
                    le: [],
                    lgdp: [],
                    psi: null
                }
            })
        }
        get j() {
            return this.g.ssp
        }
        get i() {
            return this.g.cu
        }
        set i(a) {
            this.g.cu = a
        }
        get B() {
            return null === this.g.psi ? new hf : Ec(hf, Yb(this.g.psi))
        }
    };

    function so() {
        var a = window;
        return "on" === p.google_adtest || "on" === p.google_adbreak_test || a.location.host.endsWith("h5games.usercontent.goog") ? a.document.querySelector('meta[name="h5-games-eids"]') ? .getAttribute("content") ? .split(",").map(b => Math.floor(Number(b))).filter(b => !isNaN(b) && 0 < b) || [] : []
    };

    function to(a, b) {
        return a instanceof HTMLScriptElement && b.test(a.src) ? 0 : 1
    }

    function uo(a) {
        var b = S.document;
        if (b.currentScript) return to(b.currentScript, a);
        for (const c of b.scripts)
            if (0 === to(c, a)) return 0;
        return 1
    };

    function vo(a, b) {
        return {
            [3]: {
                [55]: () => 0 === a,
                [23]: c => Rl(S, Number(c)),
                [24]: c => Ul(Number(c)),
                [61]: () => K(b, 6),
                [63]: () => K(b, 6) || ".google.ch" === L(b, 8)
            },
            [4]: {},
            [5]: {
                [6]: () => L(b, 15)
            }
        }
    };

    function wo(a = p) {
        return a.ggeac || (a.ggeac = {})
    };

    function xo(a, b = document) {
        return !!b.featurePolicy ? .features().includes(a)
    }

    function yo(a, b = document) {
        return !!b.featurePolicy ? .allowedFeatures().includes(a)
    };

    function zo(a, b) {
        try {
            const d = a.split(".");
            a = p;
            let e = 0,
                f;
            for (; null != a && e < d.length; e++) f = a, a = a[d[e]], "function" === typeof a && (a = f[d[e]]());
            var c = a;
            if (typeof c === b) return c
        } catch {}
    }
    var Ao = {
        [3]: {
            [8]: a => {
                try {
                    return null != ca(a)
                } catch {}
            },
            [9]: a => {
                try {
                    var b = ca(a)
                } catch {
                    return
                }
                if (a = "function" === typeof b) b = b && b.toString && b.toString(), a = "string" === typeof b && -1 != b.indexOf("[native code]");
                return a
            },
            [10]: () => window === window.top,
            [6]: a => Ma(P(Ag).g(), Number(a)),
            [27]: a => {
                a = zo(a, "boolean");
                return void 0 !== a ? a : void 0
            },
            [60]: a => {
                try {
                    return !!p.document.querySelector(a)
                } catch {}
            },
            [69]: a => xo(a, p.document),
            [70]: a => yo(a, p.document)
        },
        [4]: {
            [3]: () => Ed(),
            [6]: a => {
                a = zo(a, "number");
                return void 0 !== a ? a : void 0
            }
        },
        [5]: {
            [2]: () => window.location.href,
            [3]: () => {
                try {
                    return window.top.location.hash
                } catch {
                    return ""
                }
            },
            [4]: a => {
                a = zo(a, "string");
                return void 0 !== a ? a : void 0
            }
        }
    };

    function Bo(a, b) {
        const c = new Map;
        for (const [f, g] of a[1].entries()) {
            var d = f,
                e = g;
            const {
                ib: h,
                eb: k,
                fb: m
            } = e[e.length - 1];
            c.set(d, h + k * m)
        }
        for (const f of b)
            for (const g of F(f, Al, 2))
                if (0 !== F(g, zl, 2).length) {
                    b = wc(Gb(bc(g, 8)));
                    M(g, 4) && !M(g, 13) && (b = c.get(M(g, 4)) ? ? 0, d = wc(Gb(bc(g, 1))) * F(g, zl, 2).length, c.set(M(g, 4), b + d));
                    d = [];
                    for (e = 0; e < F(g, zl, 2).length; e++) {
                        const h = {
                            ib: b,
                            eb: wc(Gb(bc(g, 1))),
                            fb: F(g, zl, 2).length,
                            Bb: e,
                            Xa: M(f, 1),
                            qa: g,
                            O: F(g, zl, 2)[e]
                        };
                        d.push(h)
                    }
                    Co(a[2], M(g, 10), d) || Co(a[1], M(g, 4), d) || Co(a[0], F(g, zl, 2)[0].getId(),
                        d)
                }
        return a
    }

    function Co(a, b, c) {
        if (!b) return !1;
        a.has(b) || a.set(b, []);
        a.get(b).push(...c);
        return !0
    };

    function Do(a = xd()) {
        return b => zd(`${b} + ${a}`) % 1E3
    };
    const Eo = [12, 13, 20];

    function Fo(a, b, c) {
        a.g[c] || (a.g[c] = []);
        a = a.g[c];
        a.includes(b) || a.push(b)
    }

    function Go(a, b, c, d) {
        const e = [];
        var f;
        if (f = 9 !== b) a.j[b] ? f = !0 : (a.j[b] = !0, f = !1);
        if (f) return Yf(a.M, b, c, e, [], 4), e;
        f = Eo.includes(b);
        const g = [],
            h = P(dg).I,
            k = [];
        for (const w of [0, 1, 2])
            for (const [v, x] of a.ka[w].entries()) {
                var m = v,
                    l = x;
                const z = new tf;
                var n = l.filter(A => A.Xa === b && !!a.h[A.O.getId()] && Ne(E(A.qa, Ge, 3), h) && Ne(E(A.O, Ge, 3), h));
                if (n.length)
                    for (const A of n) k.push(A.O);
                else if (!a.za && (2 === w ? (n = d[1], mc(z, 2, uf, u(m))) : n = d[0], m = n ? .(String(m)) ? ? (2 === w && 1 === M(l[0].qa, 11) ? void 0 : d[0](String(m))), void 0 !== m)) {
                    for (const A of l)
                        if (A.Xa ===
                            b) {
                            l = m - A.ib;
                            n = A.eb;
                            const B = A.fb,
                                J = A.Bb;
                            0 <= l && l < n * B && l % B === J && Ne(E(A.qa, Ge, 3), h) && Ne(E(A.O, Ge, 3), h) && (l = M(A.qa, 13), 0 !== l && void 0 !== l && (n = a.i[String(l)], void 0 !== n && n !== A.O.getId() ? $f(a.M, a.i[String(l)], A.O.getId(), l) : a.i[String(l)] = A.O.getId()), k.push(A.O))
                        }
                    0 !== pc(z, uf) && (D(z, 3, Eb(m), 0), g.push(z))
                }
            }
        for (const w of k) d = w.getId(), e.push(d), Fo(a, d, f ? 4 : c), rg(F(w, Qe, 2), f ? tg() : [c], a.M, d);
        Yf(a.M, b, c, e, g, 1);
        return e
    }

    function Ho(a, b) {
        b = b.map(c => new Bl(c)).filter(c => !Eo.includes(M(c, 1)));
        a.ka = Bo(a.ka, b)
    }

    function Io(a, b) {
        T(1, c => {
            a.h[c] = !0
        }, b);
        T(2, (c, d, e) => Go(a, c, d, e), b);
        T(3, c => (a.g[c] || []).concat(a.g[4]), b);
        T(12, c => void Ho(a, c), b);
        T(16, (c, d) => void Fo(a, c, d), b)
    }
    var Jo = class {
        constructor(a, b, c, {
            za: d = !1,
            wc: e = []
        } = {}) {
            this.ka = a;
            this.M = c;
            this.j = {};
            this.za = d;
            this.g = {
                [b]: [],
                [4]: []
            };
            this.h = {};
            this.i = {};
            if (a = le()) {
                a = a.split(",") || [];
                for (const f of a)(a = Number(f)) && (this.h[a] = !0)
            }
            for (const f of e) this.h[f] = !0
        }
    };

    function Ko(a, b) {
        a.g = vg(14, b, () => {})
    }
    class Lo {
        constructor() {
            this.g = () => {}
        }
    }

    function Mo(a) {
        P(Lo).g(a)
    };

    function No({
        sb: a,
        I: b,
        config: c,
        nb: d = wo(),
        ob: e = 0,
        M: f = new ag(E(a, Cl, 5) ? .g() ? ? 0, E(a, Cl, 5) ? .h() ? ? 0, E(a, Cl, 5) ? .i() ? ? !1),
        ka: g = Bo({
            [0]: new Map,
            [1]: new Map,
            [2]: new Map
        }, F(a, Bl, 2))
    }) {
        d.hasOwnProperty("init-done") ? (vg(12, d, () => {})(F(a, Bl, 2).map(h => h.toJSON())), vg(13, d, () => {})(F(a, Qe, 1).map(h => h.toJSON()), e), b && vg(14, d, () => {})(b), Oo(e, d)) : (Io(new Jo(g, e, f, c), d), wg(d), xg(d), yg(d), Oo(e, d), rg(F(a, Qe, 1), [e], f, void 0, !0), eg = eg || !(!c || !c.wb), Mo(Ao), b && Mo(b))
    }

    function Oo(a, b = wo()) {
        zg(P(Ag), b, a);
        Po(b, a);
        Ko(P(Lo), b);
        P(Uc).s()
    }

    function Po(a, b) {
        const c = P(Uc);
        c.i = (d, e) => vg(5, a, () => !1)(d, e, b);
        c.j = (d, e) => vg(6, a, () => 0)(d, e, b);
        c.g = (d, e) => vg(7, a, () => "")(d, e, b);
        c.h = (d, e) => vg(8, a, () => [])(d, e, b);
        c.s = () => {
            vg(15, a, () => {})(b)
        }
    };

    function Qo(a, b) {
        b = {
            [0]: Do(Ld(b).toString())
        };
        b = P(Ag).j(a, b);
        Eg.Y(1085, qo(P(oo), a, b))
    }

    function Ro(a, b, c) {
        var d = X(a);
        if (d.plle) Oo(1, wo(a));
        else {
            d.plle = !0;
            d = E(b, Dl, 12);
            var e = K(b, 9);
            No({
                sb: d,
                I: vo(c, b),
                config: {
                    za: e && !!a.google_disable_experiments,
                    wb: e
                },
                nb: wo(a),
                ob: 1
            });
            if (c = L(b, 15)) c = Number(c), P(Ag).i(c);
            for (const f of gc(b, 19, Fb)) P(Ag).h(f);
            Qo(12, a);
            Qo(10, a);
            a = td(a) || a;
            pm(a.location, "google_mc_lab") && P(Ag).h(44738307);
            pm(a.location, "google_auto_storify_swipeable") && P(Ag).h(44773747);
            pm(a.location, "google_auto_storify_scrollable") && P(Ag).h(44773746)
        }
    };

    function So(a) {
        W.Da(b => {
            b.shv = String(a);
            b.mjsv = Hm({
                va: "m202401170101",
                Ca: a
            });
            const c = P(Ag).g(),
                d = so();
            b.eid = c.concat(d).join(",")
        })
    };

    function To(a) {
        var b = W;
        try {
            return Fc(a, Ee), new Fl(JSON.parse(a))
        } catch (c) {
            b.J(838, c instanceof Error ? c : Error(String(c)), void 0, d => {
                d.jspb = String(a)
            })
        }
        return new Fl
    };

    function Uo(a) {
        if (a.g) return a.g;
        a.B && a.B(a.h) ? a.g = a.h : a.g = Dd(a.h, a.D);
        return a.g ? ? null
    }
    var Vo = class extends Uj {
        constructor(a, b, c) {
            super();
            this.D = b;
            this.B = c;
            this.C = new Map;
            this.j = new Map;
            this.h = a
        }
    };
    const Wo = (a, b) => {
            (0, a.__uspapi)("getUSPData", 1, (c, d) => {
                b.ca({
                    wa: c ? ? void 0,
                    rb: d ? void 0 : 2
                })
            })
        },
        Xo = {
            yb: a => a.ca,
            zb: (a, b) => ({
                __uspapiCall: {
                    callId: b,
                    command: "getUSPData",
                    version: 1
                }
            }),
            Cb: (a, b) => {
                b = b.__uspapiReturn;
                a({
                    wa: b.returnValue ? ? void 0,
                    rb: b.success ? void 0 : 2
                })
            }
        };
    var Yo = class extends Uj {
        constructor() {
            var a = S;
            super();
            this.timeoutMs = {}.timeoutMs ? ? 500;
            this.caller = new Vo(a, "__uspapiLocator", b => "function" === typeof b.__uspapi);
            this.caller.C.set("getDataWithCallback", Wo);
            this.caller.j.set("getDataWithCallback", Xo)
        }
    };
    var Zo = Ic(class extends N {});
    const $o = (a, b) => {
            const c = {
                cb: d => {
                    d = Zo(d);
                    b.ca({
                        wa: d
                    })
                }
            };
            b.spsp && (c.spsp = b.spsp);
            a = a.googlefc || (a.googlefc = {});
            a.__fci = a.__fci || [];
            a.__fci.push(b.command, c)
        },
        ap = {
            yb: a => a.ca,
            zb: (a, b) => ({
                __fciCall: {
                    callId: b,
                    command: a.command,
                    spsp: a.spsp || void 0
                }
            }),
            Cb: (a, b) => {
                a({
                    wa: b
                })
            }
        };
    var bp = class extends Uj {
        constructor() {
            var a = S;
            super();
            this.g = this.h = !1;
            this.caller = new Vo(a, "googlefcPresent");
            this.caller.C.set("getDataWithCallback", $o);
            this.caller.j.set("getDataWithCallback", ap)
        }
    };
    var cp = a => {
        Sc(window, "message", b => {
            let c;
            try {
                c = JSON.parse(b.data)
            } catch (d) {
                return
            }!c || "sc-cnf" !== c.googMsgType || a(c, b)
        })
    };

    function dp(a, b) {
        return null == b ? `&${a}=null` : `&${a}=${Math.floor(b)}`
    }

    function ep(a, b) {
        return `&${a}=${b.toFixed(3)}`
    }

    function fp() {
        const a = new Set,
            b = zj();
        try {
            if (!b) return a;
            const c = b.pubads();
            for (const d of c.getSlots()) a.add(d.getSlotId().getDomId())
        } catch {}
        return a
    }

    function gp(a) {
        a = a.id;
        return null != a && (fp().has(a) || a.startsWith("google_ads_iframe_") || a.startsWith("aswift"))
    }

    function hp(a, b, c) {
        if (!a.sources) return !1;
        switch (ip(a)) {
            case 2:
                const d = jp(a);
                if (d) return c.some(f => kp(d, f));
                break;
            case 1:
                const e = lp(a);
                if (e) return b.some(f => kp(e, f))
        }
        return !1
    }

    function ip(a) {
        if (!a.sources) return 0;
        a = a.sources.filter(b => b.previousRect && b.currentRect);
        if (1 <= a.length) {
            a = a[0];
            if (a.previousRect.top < a.currentRect.top) return 2;
            if (a.previousRect.top > a.currentRect.top) return 1
        }
        return 0
    }

    function lp(a) {
        return mp(a, b => b.currentRect)
    }

    function jp(a) {
        return mp(a, b => b.previousRect)
    }

    function mp(a, b) {
        return a.sources.reduce((c, d) => {
            d = b(d);
            return c ? d && 0 !== d.width * d.height ? d.top < c.top ? d : c : c : d
        }, null)
    }

    function kp(a, b) {
        const c = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        a = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        return 0 >= c || 0 >= a ? !1 : 50 <= 100 * c * a / ((b.right - b.left) * (b.bottom - b.top))
    }

    function np() {
        const a = Array.from(document.getElementsByTagName("iframe")).filter(gp),
            b = [...fp()].map(c => document.getElementById(c)).filter(c => null !== c);
        op = window.scrollX;
        pp = window.scrollY;
        return qp = [...a, ...b].map(c => c.getBoundingClientRect())
    }

    function rp() {
        var a = new sp;
        if (Q(Oc)) {
            var b = window;
            if (!b.google_plmetrics && window.PerformanceObserver) {
                b.google_plmetrics = !0;
                b = ["layout-shift", "largest-contentful-paint", "first-input", "longtask"];
                a.kb.qb && b.push("event");
                for (const c of b) b = {
                    type: c,
                    buffered: !0
                }, "event" === c && (b.durationThreshold = 40), tp(a).observe(b);
                up(a)
            }
        }
    }

    function vp(a, b) {
        const c = op !== window.scrollX || pp !== window.scrollY ? [] : qp,
            d = np();
        for (const e of b.getEntries()) switch (b = e.entryType, b) {
            case "layout-shift":
                wp(a, e, c, d);
                break;
            case "largest-contentful-paint":
                b = e;
                a.Ka = Math.floor(b.renderTime || b.loadTime);
                a.Ja = b.size;
                break;
            case "first-input":
                b = e;
                a.Ga = Number((b.processingStart - b.startTime).toFixed(3));
                a.Ha = !0;
                a.g.some(f => f.entries.some(g => e.duration === g.duration && e.startTime === g.startTime)) || xp(a, e);
                break;
            case "longtask":
                b = Math.max(0, e.duration - 50);
                a.B +=
                    b;
                a.H = Math.max(a.H, b);
                a.sa += 1;
                break;
            case "event":
                xp(a, e);
                break;
            default:
                qd(b, void 0)
        }
    }

    function tp(a) {
        a.M || (a.M = new PerformanceObserver(Ti(640, b => {
            vp(a, b)
        })));
        return a.M
    }

    function up(a) {
        const b = Ti(641, () => {
                var d = document;
                2 === (d.prerendering ? 3 : {
                    visible: 1,
                    hidden: 2,
                    prerender: 3,
                    preview: 4,
                    unloaded: 5
                }[d.visibilityState || d.webkitVisibilityState || d.mozVisibilityState || ""] || 0) && yp(a)
            }),
            c = Ti(641, () => void yp(a));
        document.addEventListener("visibilitychange", b);
        document.addEventListener("pagehide", c);
        a.Fa = () => {
            document.removeEventListener("visibilitychange", b);
            document.removeEventListener("pagehide", c);
            tp(a).disconnect()
        }
    }

    function yp(a) {
        if (!a.Na) {
            a.Na = !0;
            tp(a).takeRecords();
            var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=plmetrics";
            window.LayoutShift && (b += ep("cls", a.C), b += ep("mls", a.X), b += dp("nls", a.ra), window.LayoutShiftAttribution && (b += ep("cas", a.s), b += dp("nas", a.Ma), b += ep("was", a.Ra)), b += ep("wls", a.ta), b += ep("tls", a.Qa));
            window.LargestContentfulPaint && (b += dp("lcp", a.Ka), b += dp("lcps", a.Ja));
            window.PerformanceEventTiming && a.Ha && (b += dp("fid", a.Ga));
            window.PerformanceLongTaskTiming && (b += dp("cbt", a.B),
                b += dp("mbt", a.H), b += dp("nlt", a.sa));
            let d = 0;
            for (var c of document.getElementsByTagName("iframe")) gp(c) && d++;
            b += dp("nif", d);
            b += dp("ifi", ce(window));
            c = P(Ag).g();
            b += `&${"eid"}=${encodeURIComponent(c.join())}`;
            b += `&${"top"}=${p===p.top?1:0}`;
            b += a.Pa ? `&${"qqid"}=${encodeURIComponent(a.Pa)}` : dp("pvsid", Ld(p));
            window.googletag && (b += "&gpt=1");
            c = Math.min(a.g.length - 1, Math.floor((a.M ? a.Ia : performance.interactionCount || 0) / 50));
            0 <= c && (c = a.g[c].latency, 0 <= c && (b += dp("inp", c)));
            window.fetch(b, {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            });
            a.Fa()
        }
    }

    function wp(a, b, c, d) {
        if (!b.hadRecentInput) {
            a.C += Number(b.value);
            Number(b.value) > a.X && (a.X = Number(b.value));
            a.ra += 1;
            if (c = hp(b, c, d)) a.s += b.value, a.Ma++;
            if (5E3 < b.startTime - a.La || 1E3 < b.startTime - a.Oa) a.La = b.startTime, a.h = 0, a.i = 0;
            a.Oa = b.startTime;
            a.h += b.value;
            c && (a.i += b.value);
            a.h > a.ta && (a.ta = a.h, a.Ra = a.i, a.Qa = b.startTime + b.duration)
        }
    }

    function xp(a, b) {
        zp(a, b);
        const c = a.g[a.g.length - 1],
            d = a.D[b.interactionId];
        if (d || 10 > a.g.length || b.duration > c.latency) d ? (d.entries.push(b), d.latency = Math.max(d.latency, b.duration)) : (b = {
            id: b.interactionId,
            latency: b.duration,
            entries: [b]
        }, a.D[b.id] = b, a.g.push(b)), a.g.sort((e, f) => f.latency - e.latency), a.g.splice(10).forEach(e => {
            delete a.D[e.id]
        })
    }

    function zp(a, b) {
        b.interactionId && (a.ba = Math.min(a.ba, b.interactionId), a.j = Math.max(a.j, b.interactionId), a.Ia = a.j ? (a.j - a.ba) / 7 + 1 : 0)
    }
    var sp = class {
            constructor() {
                var a = {
                    qb: Q(Nh)
                };
                this.i = this.h = this.ra = this.X = this.C = 0;
                this.Oa = this.La = Number.NEGATIVE_INFINITY;
                this.g = [];
                this.D = {};
                this.Ia = 0;
                this.ba = Infinity;
                this.Ga = this.Ja = this.Ka = this.Ma = this.Ra = this.s = this.Qa = this.ta = this.j = 0;
                this.Ha = !1;
                this.sa = this.H = this.B = 0;
                this.M = null;
                this.Na = !1;
                this.Fa = () => {};
                const b = document.querySelector("[data-google-query-id]");
                this.Pa = b ? b.getAttribute("data-google-query-id") : null;
                this.kb = a
            }
        },
        op, pp, qp = [];
    let Ap = null;
    const Bp = [],
        Cp = new Map;
    let Dp = -1;

    function Ep(a) {
        return si.test(a.className) && "done" !== a.dataset.adsbygoogleStatus
    }

    function Fp(a, b, c) {
        a.dataset.adsbygoogleStatus = "done";
        Gp(a, b, c)
    }

    function Gp(a, b, c) {
        var d = window;
        d.google_spfd || (d.google_spfd = ao);
        var e = b.google_reactive_ads_config;
        e || ao(a, b, d, c);
        en(d, b);
        if (!Hp(a, b, d)) {
            if (e) {
                e = e.page_level_pubvars || {};
                if (X(S).page_contains_reactive_tag && !X(S).allow_second_reactive_tag) {
                    if (e.pltais) {
                        Kl(!1);
                        return
                    }
                    throw new V("Only one 'enable_page_level_ads' allowed per page.");
                }
                X(S).page_contains_reactive_tag = !0;
                Kl(7 === e.google_pgb_reactive)
            }
            b.google_unique_id = be(d);
            yd(Im, (f, g) => {
                b[g] = b[g] || d[g]
            });
            "sd" !== b.google_loader_used && (b.google_loader_used =
                "aa");
            b.google_reactive_tag_first = 1 === (X(S).first_tag_on_page || 0);
            lj(164, () => {
                ln(d, b, a, c)
            })
        }
    }

    function Hp(a, b, c) {
        var d = b.google_reactive_ads_config,
            e = "string" === typeof a.className && RegExp("(\\W|^)adsbygoogle-noablate(\\W|$)").test(a.className),
            f = Il(c);
        if (f && f.Sa && "on" !== b.google_adtest && !e) {
            e = ci(a, c);
            const g = Xh(c).clientHeight;
            e = 0 == g ? null : e / g;
            if (!f.ua || f.ua && (e || 0) >= f.ua) return a.className += " adsbygoogle-ablated-ad-slot", c = c.google_sv_map = c.google_sv_map || {}, d = ea(a), b.google_element_uid = d, c[b.google_element_uid] = b, a.setAttribute("google_element_uid", String(d)), "slot" === f.Kb && (null !== Cd(a.getAttribute("width")) &&
                a.setAttribute("width", "0"), null !== Cd(a.getAttribute("height")) && a.setAttribute("height", "0"), a.style.width = "0px", a.style.height = "0px"), !0
        }
        if ((f = wd(a, c)) && "none" === f.display && !("on" === b.google_adtest || 0 < b.google_reactive_ad_format || d)) return c.document.createComment && a.appendChild(c.document.createComment("No ad requested because of display:none on the adsbygoogle tag")), !0;
        a = null == b.google_pgb_reactive || 3 === b.google_pgb_reactive;
        return 1 !== b.google_reactive_ad_format && 8 !== b.google_reactive_ad_format ||
            !a ? !1 : (p.console && p.console.warn("Adsbygoogle tag with data-reactive-ad-format=" + String(b.google_reactive_ad_format) + " is deprecated. Check out page-level ads at https://www.google.com/adsense"), !0)
    }

    function Ip(a) {
        var b = document.getElementsByTagName("INS");
        for (let d = 0, e = b[d]; d < b.length; e = b[++d]) {
            var c = e;
            if (Ep(c) && "reserved" !== c.dataset.adsbygoogleStatus && (!a || e.id === a)) return e
        }
        return null
    }

    function Jp(a, b, c) {
        if (a && "shift" in a) {
            no(e => {
                yc(qc(e), 2) || (e = qc(e), Bc(e, 2))
            });
            for (var d = 20; 0 < a.length && 0 < d;) {
                try {
                    Kp(a.shift(), b, c)
                } catch (e) {
                    setTimeout(() => {
                        throw e;
                    })
                }--d
            }
        }
    }

    function Lp() {
        const a = vd("INS");
        a.className = "adsbygoogle";
        a.className += " adsbygoogle-noablate";
        Fd(a);
        return a
    }

    function Mp(a, b) {
        const c = {},
            d = am(a.google_ad_client, b);
        yd(Wh, (g, h) => {
            !1 === a.enable_page_level_ads ? c[h] = !1 : a.hasOwnProperty(h) ? c[h] = a[h] : d.includes(g) && (c[h] = !1)
        });
        da(a.enable_page_level_ads) && (c.page_level_pubvars = a.enable_page_level_ads);
        const e = Lp();
        Md.body.appendChild(e);
        const f = {
            google_reactive_ads_config: c,
            google_ad_client: a.google_ad_client
        };
        f.google_pause_ad_requests = !!X(S).pause_ad_requests;
        Fp(e, f, b);
        no(g => {
            yc(qc(g), 6) || (g = qc(g), Bc(g, 6))
        })
    }

    function Np(a, b) {
        ym(p).wasPlaTagProcessed = !0;
        const c = () => {
                Mp(a, b)
            },
            d = p.document;
        if (d.body || "complete" === d.readyState || "interactive" === d.readyState) Mp(a, b);
        else {
            const e = Rc(W.oa(191, c));
            Sc(d, "DOMContentLoaded", e);
            (new p.MutationObserver((f, g) => {
                d.body && (e(), g.disconnect())
            })).observe(d, {
                childList: !0,
                subtree: !0
            })
        }
    }

    function Kp(a, b, c) {
        const d = {};
        lj(165, () => {
            Op(a, d, b, c)
        }, e => {
            e.client = e.client || d.google_ad_client || a.google_ad_client;
            e.slotname = e.slotname || d.google_ad_slot;
            e.tag_origin = e.tag_origin || d.google_tag_origin
        })
    }

    function Pp(a) {
        delete a.google_checked_head;
        yd(a, (b, c) => {
            ri[c] || (delete a[c], b = c.replace("google", "data").replace(/_/g, "-"), p.console.warn(`AdSense head tag doesn't support ${b} attribute.`))
        })
    }

    function Qp(a, b) {
        var c = S.document.querySelector('script[src*="/pagead/js/adsbygoogle.js?client="]:not([data-checked-head])') || S.document.querySelector('script[src*="/pagead/js/adsbygoogle.js"][data-ad-client]:not([data-checked-head])');
        if (c) {
            c.setAttribute("data-checked-head", "true");
            var d = X(window);
            if (d.head_tag_slot_vars) Rp(c);
            else {
                no(g => {
                    g = qc(g);
                    D(g, 7, zb(!0), !1)
                });
                var e = {};
                Zn(c, e);
                Pp(e);
                var f = Zc(e);
                d.head_tag_slot_vars = f;
                c = {
                    google_ad_client: e.google_ad_client,
                    enable_page_level_ads: e
                };
                "bottom" ===
                e.google_overlays && (c.overlays = {
                    bottom: !0
                });
                delete e.google_overlays;
                S.adsbygoogle || (S.adsbygoogle = []);
                d = S.adsbygoogle;
                d.loaded ? d.push(c) : d.splice && d.splice(0, 0, c);
                e.google_adbreak_test || b.h() ? .h() ? Sp(f, a) : cp(() => {
                    Sp(f, a)
                })
            }
        }
    }

    function Rp(a) {
        const b = X(window).head_tag_slot_vars,
            c = a.getAttribute("src") || "";
        if ((a = pd(c, "client") || a.getAttribute("data-ad-client") || "") && a !== b.google_ad_client) throw new V("Warning: Do not add multiple property codes with AdSense tag to avoid seeing unexpected behavior. These codes were found on the page " + a + ", " + b.google_ad_client);
    }

    function Tp(a) {
        if ("object" === typeof a && null != a) {
            if ("string" === typeof a.type) return 2;
            if ("string" === typeof a.sound || "string" === typeof a.preloadAdBreaks) return 3
        }
        return 0
    }

    function Op(a, b, c, d) {
        if (null == a) throw new V("push() called with no parameters.");
        no(f => {
            yc(qc(f), 3) || (f = qc(f), Bc(f, 3))
        });
        d.i() && Up(a, d.g().g(), L(d, 2));
        var e = Tp(a);
        if (0 !== e)
            if (d = Ll(), d.first_slotcar_request_processing_time || (d.first_slotcar_request_processing_time = Date.now(), d.adsbygoogle_execution_start_time = oa), null == Ap) Vp(a), Bp.push(a);
            else if (3 === e) {
            const f = Ap;
            lj(787, () => {
                f.handleAdConfig(a)
            })
        } else nj(730, Ap.handleAdBreak(a));
        else {
            oa = (new Date).getTime();
            fn(c, d, Wp(a));
            Xp();
            a: {
                if (void 0 != a.enable_page_level_ads) {
                    if ("string" ===
                        typeof a.google_ad_client) {
                        e = !0;
                        break a
                    }
                    throw new V("'google_ad_client' is missing from the tag config.");
                }
                e = !1
            }
            if (e) no(f => {
                yc(qc(f), 4) || (f = qc(f), Bc(f, 4))
            }), Yp(a, d);
            else if ((e = a.params) && yd(e, (f, g) => {
                    b[g] = f
                }), "js" === b.google_ad_output) console.warn("Ads with google_ad_output='js' have been deprecated and no longer work. Contact your AdSense account manager or switch to standard AdSense ads.");
            else {
                e = Zp(a.element);
                Zn(e, b);
                c = X(p).head_tag_slot_vars || {};
                yd(c, (f, g) => {
                    b.hasOwnProperty(g) || (b[g] = f)
                });
                if (e.hasAttribute("data-require-head") &&
                    !X(p).head_tag_slot_vars) throw new V("AdSense head tag is missing. AdSense body tags don't work without the head tag. You can copy the head tag from your account on https://adsense.com.");
                if (!b.google_ad_client) throw new V("Ad client is missing from the slot.");
                if (c = 0 === (X(S).first_tag_on_page || 0) && Bm(b)) no(f => {
                    yc(qc(f), 5) || (f = qc(f), Bc(f, 5))
                }), $p(c);
                0 === (X(S).first_tag_on_page || 0) && (X(S).first_tag_on_page = 2);
                b.google_pause_ad_requests = !!X(S).pause_ad_requests;
                Fp(e, b, d)
            }
        }
    }
    let aq = !1;

    function Up(a, b, c) {
        aq || (aq = !0, a = Wp(a) || Mm(S), mj("predictive_abg", {
            a_c: a,
            p_c: b.join(),
            b_v: c
        }, .01))
    }

    function Wp(a) {
        return a.google_ad_client ? a.google_ad_client : (a = a.params) && a.google_ad_client ? a.google_ad_client : ""
    }

    function Xp() {
        if (Q(yh)) {
            var a = Il(S);
            if (!(a = a && a.Sa)) {
                a = S;
                try {
                    var b = a.localStorage
                } catch (c) {
                    b = null
                }
                b = b ? wl(b) : null;
                a = !(b && vl(b) && b)
            }
            a || Jl(S, 1)
        }
    }

    function $p(a) {
        Nd(() => {
            ym(p).wasPlaTagProcessed || p.adsbygoogle && p.adsbygoogle.push(a)
        })
    }

    function Yp(a, b) {
        0 === (X(S).first_tag_on_page || 0) && (X(S).first_tag_on_page = 1);
        if (a.tag_partner) {
            var c = a.tag_partner;
            const d = X(p);
            d.tag_partners = d.tag_partners || [];
            d.tag_partners.push(c)
        }
        Cm(a, b);
        Np(a, b)
    }

    function Zp(a) {
        if (a) {
            if (!Ep(a) && (a.id ? a = Ip(a.id) : a = null, !a)) throw new V("'element' has already been filled.");
            if (!("innerHTML" in a)) throw new V("'element' is not a good DOM element.");
        } else if (a = Ip(), !a) throw new V("All 'ins' elements in the DOM with class=adsbygoogle already have ads in them.");
        return a
    }

    function bq() {
        var a = new dk(S),
            b = new Yo,
            c = new bp,
            d = S.__cmp ? 1 : 0;
        a = Zj(a) ? 1 : 0;
        b = Uo(b.caller) ? 1 : 0;
        c.h || (c.g = !!Uo(c.caller), c.h = !0);
        c = c.g;
        mj("cmpMet", {
            tcfv1: d,
            tcfv2: a,
            usp: b,
            fc: c ? 1 : 0,
            ptt: 9
        }, .001)
    }

    function cq(a) {
        var b = Kj();
        Qj(b, 26, !!Number(a))
    }

    function dq(a) {
        Number(a) ? X(S).pause_ad_requests = !0 : (X(S).pause_ad_requests = !1, a = () => {
            if (!X(S).pause_ad_requests) {
                var b = {};
                let c;
                "function" === typeof window.CustomEvent ? c = new CustomEvent("adsbygoogle-pub-unpause-ad-requests-event", b) : (c = document.createEvent("CustomEvent"), c.initCustomEvent("adsbygoogle-pub-unpause-ad-requests-event", !!b.bubbles, !!b.cancelable, b.detail));
                S.dispatchEvent(c)
            }
        }, p.setTimeout(a, 0), p.setTimeout(a, 1E3))
    }

    function eq(a) {
        a && a.call && "function" === typeof a && window.setTimeout(a, 0)
    }

    function Sp(a, b) {
        b = xm(2, p, b.Jb).Ta.then(c => {
            null == Ap && (c.init(a), Ap = c, fq(c))
        });
        W.Y(723, b);
        b.finally(() => {
            Bp.length = 0;
            mj("slotcar", {
                event: "api_ld",
                time: Date.now() - oa,
                time_pr: Date.now() - Dp
            });
            Q(Ph) && ro(P(oo), kf(23))
        })
    }

    function fq(a) {
        for (const [c, d] of Cp) {
            var b = c;
            const e = d; - 1 !== e && (p.clearTimeout(e), Cp.delete(b))
        }
        for (b = 0; b < Bp.length; b++) {
            if (Cp.has(b)) continue;
            const c = Bp[b],
                d = Tp(c);
            lj(723, () => {
                if (3 === d) a.handleAdConfig(c);
                else if (2 === d) {
                    var e = a.handleAdBreakBeforeReady(c);
                    W.Y(730, e)
                }
            })
        }
    }

    function Vp(a) {
        var b = Bp.length;
        if (2 === Tp(a) && "preroll" === a.type && null != a.adBreakDone) {
            var c = a.adBreakDone; - 1 === Dp && (Dp = Date.now());
            var d = p.setTimeout(() => {
                try {
                    c({
                        breakType: "preroll",
                        breakName: a.name,
                        breakFormat: "preroll",
                        breakStatus: "timeout"
                    }), Cp.set(b, -1), mj("slotcar", {
                        event: "pr_to",
                        source: "adsbygoogle"
                    }), Q(Ph) && ro(P(oo), kf(22))
                } catch (e) {
                    console.error("[Ad Placement API] adBreakDone callback threw an error:", e instanceof Error ? e : Error(String(e)))
                }
            }, 1E3 * Vc(Oh));
            Cp.set(b, d)
        }
    }

    function gq() {
        var a = S.document,
            b = Xd `https://googleads.g.doubleclick.net`;
        const c = a.createElement("LINK");
        c.crossOrigin = "";
        a: {
            if (b instanceof ad) c.href = dd(b).toString();
            else {
                if (-1 === rd.indexOf("preconnect")) throw Error('TrustedResourceUrl href attribute required with rel="preconnect"');
                if (b instanceof hd) b = b instanceof hd && b.constructor === hd ? b.g : "type_error:SafeUrl";
                else {
                    c: {
                        try {
                            var d = new URL(b)
                        } catch (e) {
                            d = "https:";
                            break c
                        }
                        d = d.protocol
                    }
                    b = "javascript:" !== d ? b : void 0
                }
                if (void 0 === b) break a;
                c.href = b
            }
            c.rel =
            "preconnect"
        }
        a.head.appendChild(c)
    };
    (function(a, b, c, d = () => {}) {
        W.hb(oj);
        lj(166, () => {
            const e = new Wf(2, a);
            try {
                xb(n => {
                    var w = new Kf;
                    var v = new Jf;
                    try {
                        var x = Ld(window);
                        Ac(v, 1, x)
                    } catch (J) {}
                    try {
                        var z = P(Ag).g();
                        lc(v, 2, z, Db)
                    } catch (J) {}
                    try {
                        Dc(v, 3, window.document.URL)
                    } catch (J) {}
                    w = sc(w, 2, v);
                    v = new If;
                    v = D(v, 1, u(1191), 0);
                    try {
                        var A = Ee(n ? .name) ? n.name : "Unknown error";
                        Dc(v, 2, A)
                    } catch (J) {}
                    try {
                        var B = Ee(n ? .message) ? n.message : `Caught ${n}`;
                        Dc(v, 3, B)
                    } catch (J) {}
                    try {
                        const J = Ee(n ? .stack) ? n.stack : Error().stack;
                        J && lc(v, 4, J.split(/\n\s*/), Kb)
                    } catch (J) {}
                    n = sc(w, 1,
                        v);
                    A = new Hf;
                    try {
                        Dc(A, 1, "m202401170101")
                    } catch {}
                    tc(n, 6, Lf, A);
                    Ac(n, 5, 1);
                    Nf(e, n)
                })
            } catch (n) {}
            const f = To(b);
            So(L(f, 2));
            Hl(K(f, 6));
            Rj(Kj(), L(f, 24));
            d();
            Zd(16, [1, f.toJSON()]);
            var g = ae($d(S)) || S;
            const h = c(Hm({
                va: a,
                Ca: L(f, 2)
            }), f);
            var k = null === S.document.currentScript ? 1 : uo(h.Lb);
            Sl(g, f);
            Ro(g, f, k);
            Q(ph) && gq();
            no(n => {
                var w = wc(G(n, 1)) + 1;
                D(n, 1, Eb(w), 0);
                S.top === S && (w = wc(G(n, 2)) + 1, D(n, 2, Eb(w), 0));
                yc(qc(n), 1) || (n = qc(n), Bc(n, 1))
            });
            nj(1086, po(0 === k));
            if (!Aa() || 0 <= qa(Fa(), 11)) {
                kj(Q(Qh));
                on();
                dl();
                try {
                    rp()
                } catch {}
                nn();
                Qp(h, f);
                g = window;
                k = g.adsbygoogle;
                if (!k || !k.loaded) {
                    mj("new_abg_tag", {
                        value: `${K(f,16)}`,
                        host_v: `${K(f,22)}`,
                        frequency: .01
                    }, .01);
                    bq();
                    var m = {
                        push: n => {
                            Kp(n, h, f)
                        },
                        loaded: !0
                    };
                    try {
                        Object.defineProperty(m, "requestNonPersonalizedAds", {
                            set: cq
                        }), Object.defineProperty(m, "pauseAdRequests", {
                            set: dq
                        }), Object.defineProperty(m, "onload", {
                            set: eq
                        })
                    } catch {}
                    if (k)
                        for (var l of ["requestNonPersonalizedAds", "pauseAdRequests"]) void 0 !== k[l] && (m[l] = k[l]);
                    Jp(k, h, f);
                    g.adsbygoogle = m;
                    k && (m.onload = k.onload);
                    Q(uh) || (l = kn(h)) && document.documentElement.appendChild(l)
                }
            }
        })
    })("m202401170101",
        "undefined" === typeof sttc ? void 0 : sttc,
        function(a, b) {
            const c = 2012 < wc(G(b, 1)) ? `_fy${wc(G(b,1))}` : "",
                d = L(b, 3);
            b = L(b, 2);
            Xd `data:text/javascript,//show_ads_impl_preview.js`;
            return {
                Jb: Xd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/${""}slotcar_library${c}.js`,
                Hb: Xd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/${""}show_ads_impl${c}.js`,
                Gb: Xd `https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/${""}show_ads_impl_with_ama${c}.js`,
                Pb: Xd `https://googleads.g.doubleclick.net/pagead/html/${b}/${d}/zrt_lookup${c}.html`,
                Nb: Xd `https://googleads.g.doubleclick.net/pagead/html/${b}/${d}/zrt_lookup_inhead${c}.html`,
                Ob: Xd `https://googleads.g.doubleclick.net/pagead/html/${b}/${d}/zrt_lookup_nohtml${c}.html`,
                Lb: /^(?:https?:)?\/\/(?:pagead2\.googlesyndication\.com|securepubads\.g\.doubleclick\.net)\/pagead\/(?:js\/)?(?:show_ads|adsbygoogle)\.js(?:[?#].*)?$/
            }
        });
}).call(this, "[2021,\"r20240118\",\"r20190131\",null,null,null,null,\".google.bi\",null,null,null,[[[1310,null,null,[1]],[1277,null,null,[1]],[1308,null,null,[1]],[1275,null,null,[1]],[1311,null,null,[1]],[null,1130,null,[null,100]],[1270,null,null,[1]],[null,1032,null,[null,200],[[[12,null,null,null,4,null,\"Android\",[\"navigator.userAgent\"]],[null,500]]]],[1247,null,null,[1]],[null,1224,null,[null,0.01]],[1312,null,null,[1]],[1207,null,null,[1]],[null,1263,null,[null,-1]],[null,1265,null,[null,-1]],[null,1264,null,[null,-1]],[1267,null,null,[1]],[1268,null,null,[1]],[null,66,null,[null,-1]],[null,65,null,[null,-1]],[1241,null,null,[1]],[1285,null,null,[1]],[1300,null,null,[1]],[null,null,null,[null,null,null,[\"en\",\"de\"]],null,1273],[1223,null,null,[1]],[null,null,null,[null,null,null,[\"44786015\",\"44786016\"]],null,1261],[1298,null,null,[1]],[1231,null,null,[1]],[null,1072,null,[null,0.75]],[1313,null,null,[1]],[null,1245,null,[null,3600]],[1284,null,null,[1]],[null,572636916,null,[null,25]],[null,566560958,null,[null,30000]],[null,508040914,null,[null,100]],[null,547455356,null,[null,49]],[583331697,null,null,[1]],[null,null,null,[null,null,null,[\"1\",\"2\",\"4\",\"6\"]],null,556791602],[561639568,null,null,[1]],[null,572636915,null,[null,150]],[null,595645509,null,[null,0.3]],[null,561668774,null,[null,0.1]],[null,469675170,null,[null,30000]],[586386407,null,null,[1]],[573506525,null,null,[1]],[573506524,null,null,[1]],[586643641,null,null,[1]],[567362967,null,null,[1]],[570863962,null,null,[1]],[null,null,570879859,[null,null,\"control_1\\\\.\\\\d\"]],[null,570863961,null,[null,50]],[570879858,null,null,[1]],[null,1085,null,[null,5]],[null,63,null,[null,30]],[null,1080,null,[null,5]],[10010,null,null,[1]],[null,1027,null,[null,10]],[null,57,null,[null,120]],[null,1079,null,[null,5]],[10009,null,null,[1]],[null,1050,null,[null,30]],[null,58,null,[null,120]],[10005,null,null,[1]],[10011,null,null,[1]],[555237685,null,null,[1]],[45460956,null,null,[]],[45414947,null,null,[1]],[null,472785970,null,[null,500]],[557143911,null,null,[1]],[null,550718588,null,[null,250]],[564509651,null,null,[1]],[564509650,null,null,[1]],[null,null,null,[null,null,null,[\"As0hBNJ8h++fNYlkq8cTye2qDLyom8NddByiVytXGGD0YVE+2CEuTCpqXMDxdhOMILKoaiaYifwEvCRlJ\/9GcQ8AAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"AgRYsXo24ypxC89CJanC+JgEmraCCBebKl8ZmG7Tj5oJNx0cmH0NtNRZs3NB5ubhpbX\/bIt7l2zJOSyO64NGmwMAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3MTk1MzI3OTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"A\/ERL66fN363FkXxgDc6F1+ucRUkAhjEca9W3la6xaLnD2Y1lABsqmdaJmPNaUKPKVBRpyMKEhXYl7rSvrQw+AkAAACNeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MTkzNTk5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\",\"A6OdGH3fVf4eKRDbXb4thXA4InNqDJDRhZ8U533U\/roYjp4Yau0T3YSuc63vmAs\/8ga1cD0E3A7LEq6AXk1uXgsAAACTeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiRmxlZGdlQmlkZGluZ0FuZEF1Y3Rpb25TZXJ2ZXIiLCJleHBpcnkiOjE3MTkzNTk5OTksImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\"]],null,1934],[485990406,null,null,[]]],[[12,[[40,[[21065724],[21065725,[[203,null,null,[1]]]]],[4,null,9,null,null,null,null,[\"LayoutShift\"]],71],[10,[[31061690],[31061691,[[83,null,null,[1]],[84,null,null,[1]]]]],null,61]]],[13,[[500,[[31061692],[31061693,[[77,null,null,[1]],[78,null,null,[1]],[85,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]]]]],[4,null,6,null,null,null,null,[\"31061691\"]]],[1000,[[31078663,null,[2,[[4,null,70,null,null,null,null,[\"browsing-topics\"]],[4,null,8,null,null,null,null,[\"document.browsingTopics\"]]]]]]],[1000,[[31078664,null,[2,[[4,null,69,null,null,null,null,[\"browsing-topics\"]],[1,[[4,null,70,null,null,null,null,[\"browsing-topics\"]]]]]]]]],[1000,[[31078665,null,[2,[[4,null,8,null,null,null,null,[\"navigator.runAdAuction\"]],[4,null,70,null,null,null,null,[\"run-ad-auction\"]],[4,null,70,null,null,null,null,[\"join-ad-interest-group\"]]]]]]],[1000,[[31078666,null,[2,[[4,null,69,null,null,null,null,[\"join-ad-interest-group\"]],[1,[[4,null,70,null,null,null,null,[\"join-ad-interest-group\"]]]]]]]]],[1000,[[31078667,null,[2,[[4,null,69,null,null,null,null,[\"run-ad-auction\"]],[1,[[4,null,70,null,null,null,null,[\"run-ad-auction\"]]]]]]]]],[1000,[[31078668,null,[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]],[1000,[[31078669,null,[2,[[4,null,69,null,null,null,null,[\"attribution-reporting\"]],[1,[[4,null,70,null,null,null,null,[\"attribution-reporting\"]]]]]]]]],[1000,[[31078670,null,[4,null,70,null,null,null,null,[\"shared-storage\"]]]]],[1000,[[31078671,null,[2,[[4,null,69,null,null,null,null,[\"shared-storage\"]],[1,[[4,null,70,null,null,null,null,[\"shared-storage\"]]]]]]]]]]],[10,[[50,[[31067422],[31067423,[[null,1032,null,[]]]],[44776369],[44792510],[44804781],[44806359]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69],[1,[[31078995],[31078996,[[45545710,null,null,[1]],[45459826,null,null,[1]],[531007060,null,null,[1]],[45545724,null,null,[1]],[45430975,null,null,[1]],[531582260,null,null,[1]]]]]],[50,[[31079265],[31079266,[[573506525,null,null,[]]]]]],[50,[[31079437],[31079438,[[573506524,null,null,[]]]]]],[10,[[31079964],[31079965]]],[10,[[31080329],[31080330,[[1282,null,null,[1]]]]]],[100,[[31080333],[31080334,[[555237685,null,null,[]]]]]],[10,[[31080342],[31080343,[[1290,null,null,[1]]]]]],[25,[[31080409],[31080410,[[null,592337179,null,[null,1]]]],[31080411,[[null,592337179,null,[null,2]]]]]],[100,[[31080442],[31080443,[[1314,null,null,[1]]]]]],[1000,[[31080504,[[null,null,14,[null,null,\"31080504\"]]],[6,null,null,null,6,null,\"31080504\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31080505,[[null,null,14,[null,null,\"31080505\"]]],[6,null,null,null,6,null,\"31080505\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[10,[[31080533],[31080534,[[597181300,null,null,[1]]]]]],[1000,[[31080557,[[null,null,14,[null,null,\"31080557\"]]],[6,null,null,null,6,null,\"31080557\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[1000,[[31080558,[[null,null,14,[null,null,\"31080558\"]]],[6,null,null,null,6,null,\"31080558\"]]],[4,null,55],63,null,null,null,null,null,null,null,null,2],[10,[[31080588],[31080589,[[45614877,null,null,[1]]]]]],[10,[[31080590],[31080591,[[598587325,null,null,[1]]]]]],[1,[[42531513],[42531514,[[316,null,null,[1]]]]]],[1,[[42531644],[42531645,[[368,null,null,[1]]]],[42531646,[[369,null,null,[1]],[368,null,null,[1]]]]]],[50,[[42531705],[42531706]]],[1,[[42532242],[42532243,[[1256,null,null,[1]],[290,null,null,[1]]]]]],[1,[[42532262],[42532263,[[null,1263,null,[null,16]]]],[42532264,[[null,1263,null,[null,4294967296]]]],[42532265,[[null,1265,null,[null,60]],[null,1264,null,[null,0.2]],[1266,null,null,[1]]]],[42532266,[[null,1263,null,[null,4294967296]],[null,1265,null,[null,60]],[null,1264,null,[null,0.2]],[1266,null,null,[1]]]],[42532267,[[null,1263,null,[null,16]],[null,1265,null,[null,60]],[null,1264,null,[null,0.2]],[1266,null,null,[1]]]],[42532268,[[1266,null,null,[1]]]]]],[1,[[42532360],[42532361,[[1260,null,null,[1]],[1291,null,null,[1]]]]],null,90],[1,[[42532362],[42532363]]],[50,[[42532523],[42532524,[[1300,null,null,[]]]]]],[null,[[42532525],[42532526]]],[1,[[44719338],[44719339,[[334,null,null,[1]],[null,54,null,[null,100]],[null,66,null,[null,10]],[null,65,null,[null,1000]]]]]],[10,[[44776368],[44779257]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69],[10,[[44785292],[44785293,[[1239,null,null,[1]]]]]],[10,[[44785294],[44785295]]],[1,[[44795552],[44795553,[[1260,null,null,[1]]]]],null,90],[1,[[44795554],[44795555]]],[100,[[44795921],[44795922,[[1222,null,null,[1]]]],[44798934,[[1222,null,null,[1]]]]]],[1,[[44801778],[44801779,[[506914611,null,null,[1]]]]],[4,null,55]],[1000,[[44802674,[[506852289,null,null,[1]]],[12,null,null,null,2,null,\"smitmehta\\\\.com\/\"]]],[4,null,55]],[50,[[44809003,[[1289,null,null,[1]]]],[44809004,[[1289,null,null,[1]],[null,null,1307,[null,null,\"inhead\"]]]],[44809005,[[1289,null,null,[1]],[null,null,1307,[null,null,\"nohtml\"]]]]]],[50,[[44809530],[44809531,[[1302,null,null,[1]]]]]],[50,[[95320376,[[1309,null,null,[1]]]],[95320377,[[null,null,null,[null,null,null,[\"en\",\"de\",\"fr\"]],null,1273],[1309,null,null,[1]]]],[95320378,[[null,null,null,[null,null,null,[\"en\",\"de\",\"ja\"]],null,1273],[1309,null,null,[1]]]]],null,75],[50,[[95321957,[[null,null,null,[null,null,null,[\"en\",\"de\",\"es\"]],null,1273],[1309,null,null,[1]]]],[95321958,[[null,null,null,[null,null,null,[\"en\",\"de\",\"vi\"]],null,1273],[1309,null,null,[1]]]],[95321963,[[1309,null,null,[1]]]]],null,75],[50,[[95322180,[[null,null,null,[null,null,null,[\"en\",\"de\",\"pt\"]],null,1273],[1309,null,null,[1]]]],[95322181,[[null,null,null,[null,null,null,[\"en\",\"de\",\"ar\"]],null,1273],[1309,null,null,[1]]]],[95322182,[[null,null,null,[null,null,null,[\"en\",\"de\",\"hi\"]],null,1273],[1309,null,null,[1]]]],[95322183,[[null,null,null,[null,null,null,[\"en\",\"de\",\"it\"]],null,1273],[1309,null,null,[1]]]],[95322184,[[null,null,null,[null,null,null,[\"en\",\"de\",\"pl\"]],null,1273],[1309,null,null,[1]]]],[95322195,[[null,null,null,[null,null,null,[\"en\",\"de\",\"ko\"]],null,1273],[1309,null,null,[1]]]],[95322329,[[1309,null,null,[1]]]]],null,75],[1,[[95322433],[95322434]]],[10,[[95322745],[95322746,[[1271,null,null,[1]]]],[95322747,[[1272,null,null,[1]]]],[95322748,[[1271,null,null,[1]],[1272,null,null,[1]]]]]]]],[17,[[98,[[95320868],[95320869,[[566279275,null,null,[1]],[566279276,null,null,[1]],[1120,null,null,[1]]]],[95320870,[[1120,null,null,[1]]]]],[4,null,55],null,null,null,null,null,null,133],[1,[[95320878],[95320879,[[566279275,null,null,[1]],[1120,null,null,[1]]]],[95320880,[[566279276,null,null,[1]],[1120,null,null,[1]]]]],[4,null,55],null,null,null,null,320,null,133],[100,[[95320888],[95320889,[[null,579884443,null,[null,0.8]],[null,null,null,[null,null,null,[\"1\",\"2\",\"3\",\"4\",\"6\"]],null,556791602],[579884441,null,null,[1]],[null,579884442,null,[null,0.8]],[550910941,null,null,[1]]]],[95320890,[[null,579884443,null,[null,0.7]],[null,null,null,[null,null,null,[\"1\",\"2\",\"3\",\"4\",\"6\"]],null,556791602],[579884441,null,null,[1]],[null,579884442,null,[null,0.7]],[550910941,null,null,[1]]]],[95320891,[[null,579884443,null,[null,0.6]],[null,null,null,[null,null,null,[\"1\",\"2\",\"3\",\"4\",\"6\"]],null,556791602],[579884441,null,null,[1]],[null,579884442,null,[null,0.6]],[550910941,null,null,[1]]]],[95320892,[[null,579884443,null,[null,0.5]],[null,null,null,[null,null,null,[\"1\",\"2\",\"3\",\"4\",\"6\"]],null,556791602],[579884441,null,null,[1]],[null,579884442,null,[null,0.5]],[550910941,null,null,[1]]]],[95320893,[[null,579884443,null,[null,1]],[null,null,null,[null,null,null,[\"1\",\"2\",\"3\",\"4\",\"6\"]],null,556791602],[579884441,null,null,[1]],[null,579884442,null,[null,0.8]]]],[95320894,[[null,579884443,null,[null,1]],[null,null,null,[null,null,null,[\"1\",\"2\",\"3\",\"4\",\"6\"]],null,556791602],[579884441,null,null,[1]],[null,579884442,null,[null,0.5]]]]],[4,null,55],null,null,null,null,100,null,132],[10,[[95321252],[95321253,[[160889229,null,null,[1]]]]],[4,null,55],null,null,null,null,null,null,134],[500,[[95321626],[95321627,[[554474127,null,null,[1]]]]],[4,null,55],null,null,null,null,null,null,135],[100,[[95321861],[95321862,[[595989603,null,null,[1]]]]],[4,null,55],null,null,null,null,null,null,141],[100,[[95321966],[95321967,[[null,null,589752731,[null,null,\"#FFFFFF\"]],[null,null,589752730,[null,null,\"#1A73E8\"]]]]],[4,null,55],null,null,null,null,null,null,136],[200,[[95322162],[95322163,[[null,595730437,null,[null,100]]]],[95322164,[[null,595730437,null,[null,200]]]],[95322165,[[null,595730437,null,[null,400]]]],[95322166,[[null,595730437,null,[null,800]]]]],[4,null,55],null,null,null,null,null,null,137],[10,[[95322319],[95322320,[[595118932,null,null,[1]]]]],[4,null,55],null,null,null,null,null,null,138],[100,[[95322325],[95322326,[[595118933,null,null,[1]]]]],[4,null,55],null,null,null,null,null,null,139],[1,[[95322397],[95322398,[[null,595645509,null,[null,0.2]]]],[95322399,[[null,595645509,null,[null,0.4]]]]],[4,null,55],null,null,null,null,null,null,140]]]],null,null,[null,1000,1,1000]],[null,[],null,null,null,null,null,null,\"ca-pub-9197834342456933\"],null,\"31080557\",1,null,937552003,[95320239,44759875,44759926,44759837]]");